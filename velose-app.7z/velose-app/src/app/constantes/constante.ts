
export class Constante {

  public static habilitarDeshabilitarCaptcha(): boolean {
    let activado: boolean = false;
    let desactivado: boolean = true;
    return activado;
  };
  public static get activarServicioAlignet(): boolean {
    let activarServicioAlignet: boolean = false;
    return activarServicioAlignet;
  };

  public static get INACTIVIDAD(): any {
    let idle={
	    timeIdle:599,//2,
      timeOut:59//5
    }
    return idle;
  };
  public static get UBIGEO():any{
    let ubigeo:any=[
      {
        "posicion": 0,
        "cod_Locacion": "01",
        "descripcion": "AMAZONAS",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0101",
            "descripcion": "CHACHAPOYAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010101",
                "descripcion": "CHACHAPOYAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010102",
                "descripcion": "ASUNCION"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010103",
                "descripcion": "BALSAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010104",
                "descripcion": "CHETO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010105",
                "descripcion": "CHILIQUIN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010106",
                "descripcion": "CHUQUIBAMBA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "010107",
                "descripcion": "GRANADA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "010108",
                "descripcion": "HUANCAS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "010109",
                "descripcion": "LA JALCA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "010110",
                "descripcion": "LEIMEBAMBA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "010111",
                "descripcion": "LEVANTO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "010112",
                "descripcion": "MAGDALENA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "010113",
                "descripcion": "MARISCAL CASTILLA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "010114",
                "descripcion": "MOLINOPAMPA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "010115",
                "descripcion": "MONTEVIDEO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "010116",
                "descripcion": "OLLEROS"
              },
              {
                "posicion": 16,
                "cod_Locacion": "010117",
                "descripcion": "QUINJALCA"
              },
              {
                "posicion": 17,
                "cod_Locacion": "010118",
                "descripcion": "SAN FRANCISCO DE DAGUAS"
              },
              {
                "posicion": 18,
                "cod_Locacion": "010119",
                "descripcion": "SAN ISIDRO DE MAINO"
              },
              {
                "posicion": 19,
                "cod_Locacion": "010120",
                "descripcion": "SOLOCO"
              },
              {
                "posicion": 20,
                "cod_Locacion": "010121",
                "descripcion": "SONCHE"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0102",
            "descripcion": "BAGUA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010201",
                "descripcion": "BAGUA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010202",
                "descripcion": "ARAMANGO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010203",
                "descripcion": "COPALLIN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010204",
                "descripcion": "EL PARCO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010205",
                "descripcion": "IMAZA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010206",
                "descripcion": "LA PECA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0103",
            "descripcion": "BONGARA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010301",
                "descripcion": "JUMBILLA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010302",
                "descripcion": "CHISQUILLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010303",
                "descripcion": "CHURUJA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010304",
                "descripcion": "COROSHA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010305",
                "descripcion": "CUISPES"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010306",
                "descripcion": "FLORIDA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "010307",
                "descripcion": "JAZAN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "010308",
                "descripcion": "RECTA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "010309",
                "descripcion": "SAN CARLOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "010310",
                "descripcion": "SHIPASBAMBA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "010311",
                "descripcion": "VALERA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "010312",
                "descripcion": "YAMBRASBAMBA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0104",
            "descripcion": "CONDORCANQUI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010401",
                "descripcion": "NIEVA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010402",
                "descripcion": "EL CENEPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010403",
                "descripcion": "RIO SANTIAGO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0105",
            "descripcion": "LUYA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010501",
                "descripcion": "LAMUD"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010502",
                "descripcion": "CAMPORREDONDO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010503",
                "descripcion": "COCABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010504",
                "descripcion": "COLCAMAR"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010505",
                "descripcion": "CONILA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010506",
                "descripcion": "INGUILPATA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "010507",
                "descripcion": "LONGUITA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "010508",
                "descripcion": "LONYA CHICO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "010509",
                "descripcion": "LUYA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "010510",
                "descripcion": "LUYA VIEJO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "010511",
                "descripcion": "MARIA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "010512",
                "descripcion": "OCALLI"
              },
              {
                "posicion": 12,
                "cod_Locacion": "010513",
                "descripcion": "OCUMAL"
              },
              {
                "posicion": 13,
                "cod_Locacion": "010514",
                "descripcion": "PISUQUIA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "010515",
                "descripcion": "PROVIDENCIA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "010516",
                "descripcion": "SAN CRISTOBAL"
              },
              {
                "posicion": 16,
                "cod_Locacion": "010517",
                "descripcion": "SAN FRANCISCO DE YESO"
              },
              {
                "posicion": 17,
                "cod_Locacion": "010518",
                "descripcion": "SAN JERONIMO"
              },
              {
                "posicion": 18,
                "cod_Locacion": "010519",
                "descripcion": "SAN JUAN DE LOPECANCHA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "010520",
                "descripcion": "SANTA CATALINA"
              },
              {
                "posicion": 20,
                "cod_Locacion": "010521",
                "descripcion": "SANTO TOMAS"
              },
              {
                "posicion": 21,
                "cod_Locacion": "010522",
                "descripcion": "TINGO"
              },
              {
                "posicion": 22,
                "cod_Locacion": "010523",
                "descripcion": "TRITA"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0106",
            "descripcion": "RODRIGUEZ DE MENDOZA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010601",
                "descripcion": "SAN NICOLAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010602",
                "descripcion": "CHIRIMOTO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010603",
                "descripcion": "COCHAMAL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010604",
                "descripcion": "HUAMBO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010605",
                "descripcion": "LIMABAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010606",
                "descripcion": "LONGAR"
              },
              {
                "posicion": 6,
                "cod_Locacion": "010607",
                "descripcion": "MARISCAL BENAVIDES"
              },
              {
                "posicion": 7,
                "cod_Locacion": "010608",
                "descripcion": "MILPUC"
              },
              {
                "posicion": 8,
                "cod_Locacion": "010609",
                "descripcion": "OMIA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "010610",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "010611",
                "descripcion": "TOTORA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "010612",
                "descripcion": "VISTA ALEGRE"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0107",
            "descripcion": "UTCUBAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "010701",
                "descripcion": "BAGUA GRANDE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "010702",
                "descripcion": "CAJARURO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "010703",
                "descripcion": "CUMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "010704",
                "descripcion": "EL MILAGRO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "010705",
                "descripcion": "JAMALCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "010706",
                "descripcion": "LONYA GRANDE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "010707",
                "descripcion": "YAMON"
              }
            ]
          }
        ]
      },
      {
        "posicion": 1,
        "cod_Locacion": "02",
        "descripcion": "ANCASH",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0201",
            "descripcion": "HUARAZ",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020101",
                "descripcion": "HUARAZ"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020102",
                "descripcion": "COCHABAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020103",
                "descripcion": "COLCABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020104",
                "descripcion": "HUANCHAY"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020105",
                "descripcion": "INDEPENDENCIA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "020106",
                "descripcion": "JANGAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "020107",
                "descripcion": "LA LIBERTAD"
              },
              {
                "posicion": 7,
                "cod_Locacion": "020108",
                "descripcion": "OLLEROS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "020109",
                "descripcion": "PAMPAS GRANDE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "020110",
                "descripcion": "PARIACOTO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "020111",
                "descripcion": "PIRA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "020112",
                "descripcion": "TARICA"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0202",
            "descripcion": "AIJA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020201",
                "descripcion": "AIJA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020202",
                "descripcion": "CORIS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020203",
                "descripcion": "HUACLLAN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020204",
                "descripcion": "LA MERCED"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020205",
                "descripcion": "SUCCHA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0203",
            "descripcion": "ANTONIO RAYMONDI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020301",
                "descripcion": "LLAMELLIN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020302",
                "descripcion": "ACZO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020303",
                "descripcion": "CHACCHO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020304",
                "descripcion": "CHINGAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020305",
                "descripcion": "MIRGAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "020306",
                "descripcion": "SAN JUAN DE RONTOY"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0204",
            "descripcion": "ASUNCION",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020401",
                "descripcion": "CHACAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020402",
                "descripcion": "ACOCHACA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0205",
            "descripcion": "BOLOGNESI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020501",
                "descripcion": "CHIQUIAN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020502",
                "descripcion": "ABELARDO PARDO LEZAMETA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020503",
                "descripcion": "ANTONIO RAYMONDI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020504",
                "descripcion": "AQUIA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020505",
                "descripcion": "CAJACAY"
              },
              {
                "posicion": 5,
                "cod_Locacion": "020506",
                "descripcion": "CANIS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "020507",
                "descripcion": "COLQUIOC"
              },
              {
                "posicion": 7,
                "cod_Locacion": "020508",
                "descripcion": "HUALLANCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "020509",
                "descripcion": "HUASTA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "020510",
                "descripcion": "HUAYLLACAYAN"
              },
              {
                "posicion": 10,
                "cod_Locacion": "020511",
                "descripcion": "LA PRIMAVERA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "020512",
                "descripcion": "MANGAS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "020513",
                "descripcion": "PACLLON"
              },
              {
                "posicion": 13,
                "cod_Locacion": "020514",
                "descripcion": "SAN MIGUEL DE CORPANQUI"
              },
              {
                "posicion": 14,
                "cod_Locacion": "020515",
                "descripcion": "TICLLOS"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0206",
            "descripcion": "CARHUAZ",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020601",
                "descripcion": "CARHUAZ"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020602",
                "descripcion": "ACOPAMPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020603",
                "descripcion": "AMASHCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020604",
                "descripcion": "ANTA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020605",
                "descripcion": "ATAQUERO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "020606",
                "descripcion": "MARCARA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "020607",
                "descripcion": "PARIAHUANCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "020608",
                "descripcion": "SAN MIGUEL DE ACO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "020609",
                "descripcion": "SHILLA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "020610",
                "descripcion": "TINCO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "020611",
                "descripcion": "YUNGAR"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0207",
            "descripcion": "CARLOS FERMIN FITZCARRALD",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020701",
                "descripcion": "SAN LUIS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020702",
                "descripcion": "SAN NICOLAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020703",
                "descripcion": "YAUYA"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "0208",
            "descripcion": "CASMA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020801",
                "descripcion": "CASMA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020802",
                "descripcion": "BUENA VISTA ALTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020803",
                "descripcion": "COMANDANTE NOEL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020804",
                "descripcion": "YAUTAN"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "0209",
            "descripcion": "CORONGO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "020901",
                "descripcion": "CORONGO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "020902",
                "descripcion": "ACO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "020903",
                "descripcion": "BAMBAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "020904",
                "descripcion": "CUSCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "020905",
                "descripcion": "LA PAMPA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "020906",
                "descripcion": "YANAC"
              },
              {
                "posicion": 6,
                "cod_Locacion": "020907",
                "descripcion": "YUPAN"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "0210",
            "descripcion": "HUARI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021001",
                "descripcion": "HUARI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021002",
                "descripcion": "ANRA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021003",
                "descripcion": "CAJAY"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021004",
                "descripcion": "CHAVIN DE HUANTAR"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021005",
                "descripcion": "HUACACHI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021006",
                "descripcion": "HUACCHIS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021007",
                "descripcion": "HUACHIS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021008",
                "descripcion": "HUANTAR"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021009",
                "descripcion": "MASIN"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021010",
                "descripcion": "PAUCAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "021011",
                "descripcion": "PONTO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "021012",
                "descripcion": "RAHUAPAMPA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "021013",
                "descripcion": "RAPAYAN"
              },
              {
                "posicion": 13,
                "cod_Locacion": "021014",
                "descripcion": "SAN MARCOS"
              },
              {
                "posicion": 14,
                "cod_Locacion": "021015",
                "descripcion": "SAN PEDRO DE CHANA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "021016",
                "descripcion": "UCO"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "0211",
            "descripcion": "HUARMEY",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021101",
                "descripcion": "HUARMEY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021102",
                "descripcion": "COCHAPETI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021103",
                "descripcion": "CULEBRAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021104",
                "descripcion": "HUAYAN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021105",
                "descripcion": "MALVAS"
              }
            ]
          },
          {
            "posicion": 11,
            "cod_Locacion": "0212",
            "descripcion": "HUAYLAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021201",
                "descripcion": "CARAZ"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021202",
                "descripcion": "HUALLANCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021203",
                "descripcion": "HUATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021204",
                "descripcion": "HUAYLAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021205",
                "descripcion": "MATO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021206",
                "descripcion": "PAMPAROMAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021207",
                "descripcion": "PUEBLO LIBRE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021208",
                "descripcion": "SANTA CRUZ"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021209",
                "descripcion": "SANTO TORIBIO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021210",
                "descripcion": "YURACMARCA"
              }
            ]
          },
          {
            "posicion": 12,
            "cod_Locacion": "0213",
            "descripcion": "MARISCAL LUZURIAGA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021301",
                "descripcion": "PISCOBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021302",
                "descripcion": "CASCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021303",
                "descripcion": "ELEAZAR GUZMAN BARRON"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021304",
                "descripcion": "FIDEL OLIVAS ESCUDERO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021305",
                "descripcion": "LLAMA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021306",
                "descripcion": "LLUMPA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021307",
                "descripcion": "LUCMA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021308",
                "descripcion": "MUSGA"
              }
            ]
          },
          {
            "posicion": 13,
            "cod_Locacion": "0214",
            "descripcion": "OCROS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021401",
                "descripcion": "OCROS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021402",
                "descripcion": "ACAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021403",
                "descripcion": "CAJAMARQUILLA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021404",
                "descripcion": "CARHUAPAMPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021405",
                "descripcion": "COCHAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021406",
                "descripcion": "CONGAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021407",
                "descripcion": "LLIPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021408",
                "descripcion": "SAN CRISTOBAL DE RAJAN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021409",
                "descripcion": "SAN PEDRO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021410",
                "descripcion": "SANTIAGO DE CHILCAS"
              }
            ]
          },
          {
            "posicion": 14,
            "cod_Locacion": "0215",
            "descripcion": "PALLASCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021501",
                "descripcion": "CABANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021502",
                "descripcion": "BOLOGNESI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021503",
                "descripcion": "CONCHUCOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021504",
                "descripcion": "HUACASCHUQUE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021505",
                "descripcion": "HUANDOVAL"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021506",
                "descripcion": "LACABAMBA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021507",
                "descripcion": "LLAPO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021508",
                "descripcion": "PALLASCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021509",
                "descripcion": "PAMPAS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021510",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "021511",
                "descripcion": "TAUCA"
              }
            ]
          },
          {
            "posicion": 15,
            "cod_Locacion": "0216",
            "descripcion": "POMABAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021601",
                "descripcion": "POMABAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021602",
                "descripcion": "HUAYLLAN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021603",
                "descripcion": "PAROBAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021604",
                "descripcion": "QUINUABAMBA"
              }
            ]
          },
          {
            "posicion": 16,
            "cod_Locacion": "0217",
            "descripcion": "RECUAY",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021701",
                "descripcion": "RECUAY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021702",
                "descripcion": "CATAC"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021703",
                "descripcion": "COTAPARACO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021704",
                "descripcion": "HUAYLLAPAMPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021705",
                "descripcion": "LLACLLIN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021706",
                "descripcion": "MARCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021707",
                "descripcion": "PAMPAS CHICO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021708",
                "descripcion": "PARARIN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021709",
                "descripcion": "TAPACOCHA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021710",
                "descripcion": "TICAPAMPA"
              }
            ]
          },
          {
            "posicion": 17,
            "cod_Locacion": "0218",
            "descripcion": "SANTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021801",
                "descripcion": "CHIMBOTE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021802",
                "descripcion": "CACERES DEL PERU"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021803",
                "descripcion": "COISHCO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021804",
                "descripcion": "MACATE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021805",
                "descripcion": "MORO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021806",
                "descripcion": "NEPEÑA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021807",
                "descripcion": "SAMANCO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021808",
                "descripcion": "SANTA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021809",
                "descripcion": "NUEVO CHIMBOTE"
              }
            ]
          },
          {
            "posicion": 18,
            "cod_Locacion": "0219",
            "descripcion": "SIHUAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "021901",
                "descripcion": "SIHUAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "021902",
                "descripcion": "ACOBAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "021903",
                "descripcion": "ALFONSO UGARTE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "021904",
                "descripcion": "CASHAPAMPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "021905",
                "descripcion": "CHINGALPO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "021906",
                "descripcion": "HUAYLLABAMBA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "021907",
                "descripcion": "QUICHES"
              },
              {
                "posicion": 7,
                "cod_Locacion": "021908",
                "descripcion": "RAGASH"
              },
              {
                "posicion": 8,
                "cod_Locacion": "021909",
                "descripcion": "SAN JUAN"
              },
              {
                "posicion": 9,
                "cod_Locacion": "021910",
                "descripcion": "SICSIBAMBA"
              }
            ]
          },
          {
            "posicion": 19,
            "cod_Locacion": "0220",
            "descripcion": "YUNGAY",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "022001",
                "descripcion": "YUNGAY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "022002",
                "descripcion": "CASCAPARA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "022003",
                "descripcion": "MANCOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "022004",
                "descripcion": "MATACOTO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "022005",
                "descripcion": "QUILLO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "022006",
                "descripcion": "RANRAHIRCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "022007",
                "descripcion": "SHUPLUY"
              },
              {
                "posicion": 7,
                "cod_Locacion": "022008",
                "descripcion": "YANAMA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 2,
        "cod_Locacion": "03",
        "descripcion": "APURIMAC",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0301",
            "descripcion": "ABANCAY",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030101",
                "descripcion": "ABANCAY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030102",
                "descripcion": "CHACOCHE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030103",
                "descripcion": "CIRCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030104",
                "descripcion": "CURAHUASI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030105",
                "descripcion": "HUANIPACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030106",
                "descripcion": "LAMBRAMA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030107",
                "descripcion": "PICHIRHUA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "030108",
                "descripcion": "SAN PEDRO DE CACHORA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "030109",
                "descripcion": "TAMBURCO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0302",
            "descripcion": "ANDAHUAYLAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030201",
                "descripcion": "ANDAHUAYLAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030202",
                "descripcion": "ANDARAPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030203",
                "descripcion": "CHIARA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030204",
                "descripcion": "HUANCARAMA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030205",
                "descripcion": "HUANCARAY"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030206",
                "descripcion": "HUAYANA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030207",
                "descripcion": "KISHUARA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "030208",
                "descripcion": "PACOBAMBA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "030209",
                "descripcion": "PACUCHA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "030210",
                "descripcion": "PAMPACHIRI"
              },
              {
                "posicion": 10,
                "cod_Locacion": "030211",
                "descripcion": "POMACOCHA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "030212",
                "descripcion": "SAN ANTONIO DE CACHI"
              },
              {
                "posicion": 12,
                "cod_Locacion": "030213",
                "descripcion": "SAN JERONIMO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "030214",
                "descripcion": "SAN MIGUEL DE CHACCRAMPA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "030215",
                "descripcion": "SANTA MARIA DE CHICMO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "030216",
                "descripcion": "TALAVERA"
              },
              {
                "posicion": 16,
                "cod_Locacion": "030217",
                "descripcion": "TUMAY HUARACA"
              },
              {
                "posicion": 17,
                "cod_Locacion": "030218",
                "descripcion": "TURPO"
              },
              {
                "posicion": 18,
                "cod_Locacion": "030219",
                "descripcion": "KAQUIABAMBA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "030220",
                "descripcion": "JOSE MARIA ARGUEDAS"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0303",
            "descripcion": "ANTABAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030301",
                "descripcion": "ANTABAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030302",
                "descripcion": "EL ORO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030303",
                "descripcion": "HUAQUIRCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030304",
                "descripcion": "JUAN ESPINOZA MEDRANO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030305",
                "descripcion": "OROPESA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030306",
                "descripcion": "PACHACONAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030307",
                "descripcion": "SABAINO"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0304",
            "descripcion": "AYMARAES",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030401",
                "descripcion": "CHALHUANCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030402",
                "descripcion": "CAPAYA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030403",
                "descripcion": "CARAYBAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030404",
                "descripcion": "CHAPIMARCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030405",
                "descripcion": "COLCABAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030406",
                "descripcion": "COTARUSE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030407",
                "descripcion": "IHUAYLLO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "030408",
                "descripcion": "JUSTO APU SAHUARAURA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "030409",
                "descripcion": "LUCRE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "030410",
                "descripcion": "POCOHUANCA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "030411",
                "descripcion": "SAN JUAN DE CHACÑA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "030412",
                "descripcion": "SAÑAYCA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "030413",
                "descripcion": "SORAYA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "030414",
                "descripcion": "TAPAIRIHUA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "030415",
                "descripcion": "TINTAY"
              },
              {
                "posicion": 15,
                "cod_Locacion": "030416",
                "descripcion": "TORAYA"
              },
              {
                "posicion": 16,
                "cod_Locacion": "030417",
                "descripcion": "YANACA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0305",
            "descripcion": "COTABAMBAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030501",
                "descripcion": "TAMBOBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030502",
                "descripcion": "COTABAMBAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030503",
                "descripcion": "COYLLURQUI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030504",
                "descripcion": "HAQUIRA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030505",
                "descripcion": "MARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030506",
                "descripcion": "CHALLHUAHUACHO"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0306",
            "descripcion": "CHINCHEROS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030601",
                "descripcion": "CHINCHEROS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030602",
                "descripcion": "ANCO_HUALLO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030603",
                "descripcion": "COCHARCAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030604",
                "descripcion": "HUACCANA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030605",
                "descripcion": "OCOBAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030606",
                "descripcion": "ONGOY"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030607",
                "descripcion": "URANMARCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "030608",
                "descripcion": "RANRACANCHA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "030609",
                "descripcion": "ROCCHACC"
              },
              {
                "posicion": 9,
                "cod_Locacion": "030610",
                "descripcion": "EL PORVENIR"
              },
              {
                "posicion": 10,
                "cod_Locacion": "030611",
                "descripcion": "LOS CHANKAS"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0307",
            "descripcion": "GRAU",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "030701",
                "descripcion": "CHUQUIBAMBILLA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "030702",
                "descripcion": "CURPAHUASI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "030703",
                "descripcion": "GAMARRA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "030704",
                "descripcion": "HUAYLLATI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "030705",
                "descripcion": "MAMARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "030706",
                "descripcion": "MICAELA BASTIDAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "030707",
                "descripcion": "PATAYPAMPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "030708",
                "descripcion": "PROGRESO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "030709",
                "descripcion": "SAN ANTONIO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "030710",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "030711",
                "descripcion": "TURPAY"
              },
              {
                "posicion": 11,
                "cod_Locacion": "030712",
                "descripcion": "VILCABAMBA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "030713",
                "descripcion": "VIRUNDO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "030714",
                "descripcion": "CURASCO"
              }
            ]
          }
        ]
      },
      {
        "posicion": 3,
        "cod_Locacion": "04",
        "descripcion": "AREQUIPA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0401",
            "descripcion": "AREQUIPA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040101",
                "descripcion": "AREQUIPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040102",
                "descripcion": "ALTO SELVA ALEGRE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040103",
                "descripcion": "CAYMA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040104",
                "descripcion": "CERRO COLORADO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040105",
                "descripcion": "CHARACATO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040106",
                "descripcion": "CHIGUATA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040107",
                "descripcion": "JACOBO HUNTER"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040108",
                "descripcion": "LA JOYA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "040109",
                "descripcion": "MARIANO MELGAR"
              },
              {
                "posicion": 9,
                "cod_Locacion": "040110",
                "descripcion": "MIRAFLORES"
              },
              {
                "posicion": 10,
                "cod_Locacion": "040111",
                "descripcion": "MOLLEBAYA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "040112",
                "descripcion": "PAUCARPATA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "040113",
                "descripcion": "POCSI"
              },
              {
                "posicion": 13,
                "cod_Locacion": "040114",
                "descripcion": "POLOBAYA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "040115",
                "descripcion": "QUEQUEÑA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "040116",
                "descripcion": "SABANDIA"
              },
              {
                "posicion": 16,
                "cod_Locacion": "040117",
                "descripcion": "SACHACA"
              },
              {
                "posicion": 17,
                "cod_Locacion": "040118",
                "descripcion": "SAN JUAN DE SIGUAS"
              },
              {
                "posicion": 18,
                "cod_Locacion": "040119",
                "descripcion": "SAN JUAN DE TARUCANI"
              },
              {
                "posicion": 19,
                "cod_Locacion": "040120",
                "descripcion": "SANTA ISABEL DE SIGUAS"
              },
              {
                "posicion": 20,
                "cod_Locacion": "040121",
                "descripcion": "SANTA RITA DE SIGUAS"
              },
              {
                "posicion": 21,
                "cod_Locacion": "040122",
                "descripcion": "SOCABAYA"
              },
              {
                "posicion": 22,
                "cod_Locacion": "040123",
                "descripcion": "TIABAYA"
              },
              {
                "posicion": 23,
                "cod_Locacion": "040124",
                "descripcion": "UCHUMAYO"
              },
              {
                "posicion": 24,
                "cod_Locacion": "040125",
                "descripcion": "VITOR"
              },
              {
                "posicion": 25,
                "cod_Locacion": "040126",
                "descripcion": "YANAHUARA"
              },
              {
                "posicion": 26,
                "cod_Locacion": "040127",
                "descripcion": "YARABAMBA"
              },
              {
                "posicion": 27,
                "cod_Locacion": "040128",
                "descripcion": "YURA"
              },
              {
                "posicion": 28,
                "cod_Locacion": "040129",
                "descripcion": "JOSE LUIS BUSTAMANTE Y RIVERO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0402",
            "descripcion": "CAMANA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040201",
                "descripcion": "CAMANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040202",
                "descripcion": "JOSE MARIA QUIMPER"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040203",
                "descripcion": "MARIANO NICOLAS VALCARCEL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040204",
                "descripcion": "MARISCAL CACERES"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040205",
                "descripcion": "NICOLAS DE PIEROLA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040206",
                "descripcion": "OCOÑA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040207",
                "descripcion": "QUILCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040208",
                "descripcion": "SAMUEL PASTOR"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0403",
            "descripcion": "CARAVELI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040301",
                "descripcion": "CARAVELI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040302",
                "descripcion": "ACARI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040303",
                "descripcion": "ATICO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040304",
                "descripcion": "ATIQUIPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040305",
                "descripcion": "BELLA UNION"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040306",
                "descripcion": "CAHUACHO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040307",
                "descripcion": "CHALA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040308",
                "descripcion": "CHAPARRA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "040309",
                "descripcion": "HUANUHUANU"
              },
              {
                "posicion": 9,
                "cod_Locacion": "040310",
                "descripcion": "JAQUI"
              },
              {
                "posicion": 10,
                "cod_Locacion": "040311",
                "descripcion": "LOMAS"
              },
              {
                "posicion": 11,
                "cod_Locacion": "040312",
                "descripcion": "QUICACHA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "040313",
                "descripcion": "YAUCA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0404",
            "descripcion": "CASTILLA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040401",
                "descripcion": "APLAO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040402",
                "descripcion": "ANDAGUA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040403",
                "descripcion": "AYO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040404",
                "descripcion": "CHACHAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040405",
                "descripcion": "CHILCAYMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040406",
                "descripcion": "CHOCO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040407",
                "descripcion": "HUANCARQUI"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040408",
                "descripcion": "MACHAGUAY"
              },
              {
                "posicion": 8,
                "cod_Locacion": "040409",
                "descripcion": "ORCOPAMPA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "040410",
                "descripcion": "PAMPACOLCA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "040411",
                "descripcion": "TIPAN"
              },
              {
                "posicion": 11,
                "cod_Locacion": "040412",
                "descripcion": "UÑON"
              },
              {
                "posicion": 12,
                "cod_Locacion": "040413",
                "descripcion": "URACA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "040414",
                "descripcion": "VIRACO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0405",
            "descripcion": "CAYLLOMA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040501",
                "descripcion": "CHIVAY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040502",
                "descripcion": "ACHOMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040503",
                "descripcion": "CABANACONDE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040504",
                "descripcion": "CALLALLI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040505",
                "descripcion": "CAYLLOMA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040506",
                "descripcion": "COPORAQUE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040507",
                "descripcion": "HUAMBO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040508",
                "descripcion": "HUANCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "040509",
                "descripcion": "ICHUPAMPA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "040510",
                "descripcion": "LARI"
              },
              {
                "posicion": 10,
                "cod_Locacion": "040511",
                "descripcion": "LLUTA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "040512",
                "descripcion": "MACA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "040513",
                "descripcion": "MADRIGAL"
              },
              {
                "posicion": 13,
                "cod_Locacion": "040514",
                "descripcion": "SAN ANTONIO DE CHUCA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "040515",
                "descripcion": "SIBAYO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "040516",
                "descripcion": "TAPAY"
              },
              {
                "posicion": 16,
                "cod_Locacion": "040517",
                "descripcion": "TISCO"
              },
              {
                "posicion": 17,
                "cod_Locacion": "040518",
                "descripcion": "TUTI"
              },
              {
                "posicion": 18,
                "cod_Locacion": "040519",
                "descripcion": "YANQUE"
              },
              {
                "posicion": 19,
                "cod_Locacion": "040520",
                "descripcion": "MAJES"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0406",
            "descripcion": "CONDESUYOS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040601",
                "descripcion": "CHUQUIBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040602",
                "descripcion": "ANDARAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040603",
                "descripcion": "CAYARANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040604",
                "descripcion": "CHICHAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040605",
                "descripcion": "IRAY"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040606",
                "descripcion": "RIO GRANDE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040607",
                "descripcion": "SALAMANCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040608",
                "descripcion": "YANAQUIHUA"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0407",
            "descripcion": "ISLAY",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040701",
                "descripcion": "MOLLENDO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040702",
                "descripcion": "COCACHACRA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040703",
                "descripcion": "DEAN VALDIVIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040704",
                "descripcion": "ISLAY"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040705",
                "descripcion": "MEJIA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040706",
                "descripcion": "PUNTA DE BOMBON"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "0408",
            "descripcion": "LA UNIÒN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "040801",
                "descripcion": "COTAHUASI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "040802",
                "descripcion": "ALCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "040803",
                "descripcion": "CHARCANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "040804",
                "descripcion": "HUAYNACOTAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "040805",
                "descripcion": "PAMPAMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "040806",
                "descripcion": "PUYCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "040807",
                "descripcion": "QUECHUALLA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "040808",
                "descripcion": "SAYLA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "040809",
                "descripcion": "TAURIA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "040810",
                "descripcion": "TOMEPAMPA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "040811",
                "descripcion": "TORO"
              }
            ]
          }
        ]
      },
      {
        "posicion": 4,
        "cod_Locacion": "05",
        "descripcion": "AYACUCHO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0501",
            "descripcion": "HUAMANGA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050101",
                "descripcion": "AYACUCHO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050102",
                "descripcion": "ACOCRO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050103",
                "descripcion": "ACOS VINCHOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050104",
                "descripcion": "CARMEN ALTO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050105",
                "descripcion": "CHIARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050106",
                "descripcion": "OCROS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050107",
                "descripcion": "PACAYCASA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050108",
                "descripcion": "QUINUA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050109",
                "descripcion": "SAN JOSE DE TICLLAS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050110",
                "descripcion": "SAN JUAN BAUTISTA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "050111",
                "descripcion": "SANTIAGO DE PISCHA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "050112",
                "descripcion": "SOCOS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "050113",
                "descripcion": "TAMBILLO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "050114",
                "descripcion": "VINCHOS"
              },
              {
                "posicion": 14,
                "cod_Locacion": "050115",
                "descripcion": "JESUS NAZARENO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "050116",
                "descripcion": "ANDRES AVELINO CACERES DORREGARAY"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0502",
            "descripcion": "CANGALLO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050201",
                "descripcion": "CANGALLO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050202",
                "descripcion": "CHUSCHI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050203",
                "descripcion": "LOS MOROCHUCOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050204",
                "descripcion": "MARIA PARADO DE BELLIDO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050205",
                "descripcion": "PARAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050206",
                "descripcion": "TOTOS"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0503",
            "descripcion": "HUANCA SANCOS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050301",
                "descripcion": "SANCOS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050302",
                "descripcion": "CARAPO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050303",
                "descripcion": "SACSAMARCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050304",
                "descripcion": "SANTIAGO DE LUCANAMARCA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0504",
            "descripcion": "HUANTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050401",
                "descripcion": "HUANTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050402",
                "descripcion": "AYAHUANCO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050403",
                "descripcion": "HUAMANGUILLA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050404",
                "descripcion": "IGUAIN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050405",
                "descripcion": "LURICOCHA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050406",
                "descripcion": "SANTILLANA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050407",
                "descripcion": "SIVIA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050408",
                "descripcion": "LLOCHEGUA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050409",
                "descripcion": "CANAYRE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050410",
                "descripcion": "UCHURACCAY"
              },
              {
                "posicion": 10,
                "cod_Locacion": "050411",
                "descripcion": "PUCACOLPA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "050412",
                "descripcion": "CHACA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0505",
            "descripcion": "LA MAR",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050501",
                "descripcion": "SAN MIGUEL"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050502",
                "descripcion": "ANCO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050503",
                "descripcion": "AYNA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050504",
                "descripcion": "CHILCAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050505",
                "descripcion": "CHUNGUI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050506",
                "descripcion": "LUIS CARRANZA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050507",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050508",
                "descripcion": "TAMBO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050509",
                "descripcion": "SAMUGARI"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050510",
                "descripcion": "ANCHIHUAY"
              },
              {
                "posicion": 10,
                "cod_Locacion": "050511",
                "descripcion": "ORONCCOY"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0506",
            "descripcion": "LUCANAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050601",
                "descripcion": "PUQUIO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050602",
                "descripcion": "AUCARA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050603",
                "descripcion": "CABANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050604",
                "descripcion": "CARMEN SALCEDO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050605",
                "descripcion": "CHAVIÑA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050606",
                "descripcion": "CHIPAO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050607",
                "descripcion": "HUAC-HUAS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050608",
                "descripcion": "LARAMATE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050609",
                "descripcion": "LEONCIO PRADO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050610",
                "descripcion": "LLAUTA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "050611",
                "descripcion": "LUCANAS"
              },
              {
                "posicion": 11,
                "cod_Locacion": "050612",
                "descripcion": "OCAÑA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "050613",
                "descripcion": "OTOCA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "050614",
                "descripcion": "SAISA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "050615",
                "descripcion": "SAN CRISTOBAL"
              },
              {
                "posicion": 15,
                "cod_Locacion": "050616",
                "descripcion": "SAN JUAN"
              },
              {
                "posicion": 16,
                "cod_Locacion": "050617",
                "descripcion": "SAN PEDRO"
              },
              {
                "posicion": 17,
                "cod_Locacion": "050618",
                "descripcion": "SAN PEDRO DE PALCO"
              },
              {
                "posicion": 18,
                "cod_Locacion": "050619",
                "descripcion": "SANCOS"
              },
              {
                "posicion": 19,
                "cod_Locacion": "050620",
                "descripcion": "SANTA ANA DE HUAYCAHUACHO"
              },
              {
                "posicion": 20,
                "cod_Locacion": "050621",
                "descripcion": "SANTA LUCIA"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0507",
            "descripcion": "PARINACOCHAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050701",
                "descripcion": "CORACORA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050702",
                "descripcion": "CHUMPI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050703",
                "descripcion": "CORONEL CASTAÑEDA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050704",
                "descripcion": "PACAPAUSA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050705",
                "descripcion": "PULLO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050706",
                "descripcion": "PUYUSCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050707",
                "descripcion": "SAN FRANCISCO DE RAVACAYCO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050708",
                "descripcion": "UPAHUACHO"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "0508",
            "descripcion": "PÀUCAR DEL SARA SARA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050801",
                "descripcion": "PAUSA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050802",
                "descripcion": "COLTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050803",
                "descripcion": "CORCULLA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050804",
                "descripcion": "LAMPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050805",
                "descripcion": "MARCABAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050806",
                "descripcion": "OYOLO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050807",
                "descripcion": "PARARCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050808",
                "descripcion": "SAN JAVIER DE ALPABAMBA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050809",
                "descripcion": "SAN JOSE DE USHUA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050810",
                "descripcion": "SARA SARA"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "0509",
            "descripcion": "SUCRE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "050901",
                "descripcion": "QUEROBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "050902",
                "descripcion": "BELEN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "050903",
                "descripcion": "CHALCOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "050904",
                "descripcion": "CHILCAYOC"
              },
              {
                "posicion": 4,
                "cod_Locacion": "050905",
                "descripcion": "HUACAÑA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "050906",
                "descripcion": "MORCOLLA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "050907",
                "descripcion": "PAICO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "050908",
                "descripcion": "SAN PEDRO DE LARCAY"
              },
              {
                "posicion": 8,
                "cod_Locacion": "050909",
                "descripcion": "SAN SALVADOR DE QUIJE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "050910",
                "descripcion": "SANTIAGO DE PAUCARAY"
              },
              {
                "posicion": 10,
                "cod_Locacion": "050911",
                "descripcion": "SORAS"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "0510",
            "descripcion": "VICTOR FAJARDO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "051001",
                "descripcion": "HUANCAPI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "051002",
                "descripcion": "ALCAMENCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "051003",
                "descripcion": "APONGO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "051004",
                "descripcion": "ASQUIPATA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "051005",
                "descripcion": "CANARIA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "051006",
                "descripcion": "CAYARA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "051007",
                "descripcion": "COLCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "051008",
                "descripcion": "HUAMANQUIQUIA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "051009",
                "descripcion": "HUANCARAYLLA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "051010",
                "descripcion": "HUAYA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "051011",
                "descripcion": "SARHUA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "051012",
                "descripcion": "VILCANCHOS"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "0511",
            "descripcion": "VILCAS HUAMAN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "051101",
                "descripcion": "VILCAS HUAMAN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "051102",
                "descripcion": "ACCOMARCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "051103",
                "descripcion": "CARHUANCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "051104",
                "descripcion": "CONCEPCION"
              },
              {
                "posicion": 4,
                "cod_Locacion": "051105",
                "descripcion": "HUAMBALPA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "051106",
                "descripcion": "INDEPENDENCIA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "051107",
                "descripcion": "SAURAMA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "051108",
                "descripcion": "VISCHONGO"
              }
            ]
          }
        ]
      },
      {
        "posicion": 5,
        "cod_Locacion": "06",
        "descripcion": "CAJAMARCA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0601",
            "descripcion": "CAJAMARCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060101",
                "descripcion": "CAJAMARCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060102",
                "descripcion": "ASUNCION"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060103",
                "descripcion": "CHETILLA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060104",
                "descripcion": "COSPAN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060105",
                "descripcion": "ENCAÑADA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060106",
                "descripcion": "JESUS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060107",
                "descripcion": "LLACANORA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060108",
                "descripcion": "LOS BAÑOS DEL INCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "060109",
                "descripcion": "MAGDALENA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "060110",
                "descripcion": "MATARA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "060111",
                "descripcion": "NAMORA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "060112",
                "descripcion": "SAN JUAN"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0602",
            "descripcion": "CAJABAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060201",
                "descripcion": "CAJABAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060202",
                "descripcion": "CACHACHI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060203",
                "descripcion": "CONDEBAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060204",
                "descripcion": "SITACOCHA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0603",
            "descripcion": "CELENDIN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060301",
                "descripcion": "CELENDIN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060302",
                "descripcion": "CHUMUCH"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060303",
                "descripcion": "CORTEGANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060304",
                "descripcion": "HUASMIN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060305",
                "descripcion": "JORGE CHAVEZ"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060306",
                "descripcion": "JOSE GALVEZ"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060307",
                "descripcion": "MIGUEL IGLESIAS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060308",
                "descripcion": "OXAMARCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "060309",
                "descripcion": "SOROCHUCO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "060310",
                "descripcion": "SUCRE"
              },
              {
                "posicion": 10,
                "cod_Locacion": "060311",
                "descripcion": "UTCO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "060312",
                "descripcion": "LA LIBERTAD DE PALLAN"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0604",
            "descripcion": "CHOTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060401",
                "descripcion": "CHOTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060402",
                "descripcion": "ANGUIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060403",
                "descripcion": "CHADIN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060404",
                "descripcion": "CHIGUIRIP"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060405",
                "descripcion": "CHIMBAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060406",
                "descripcion": "CHOROPAMPA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060407",
                "descripcion": "COCHABAMBA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060408",
                "descripcion": "CONCHAN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "060409",
                "descripcion": "HUAMBOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "060410",
                "descripcion": "LAJAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "060411",
                "descripcion": "LLAMA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "060412",
                "descripcion": "MIRACOSTA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "060413",
                "descripcion": "PACCHA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "060414",
                "descripcion": "PION"
              },
              {
                "posicion": 14,
                "cod_Locacion": "060415",
                "descripcion": "QUEROCOTO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "060416",
                "descripcion": "SAN JUAN DE LICUPIS"
              },
              {
                "posicion": 16,
                "cod_Locacion": "060417",
                "descripcion": "TACABAMBA"
              },
              {
                "posicion": 17,
                "cod_Locacion": "060418",
                "descripcion": "TOCMOCHE"
              },
              {
                "posicion": 18,
                "cod_Locacion": "060419",
                "descripcion": "CHALAMARCA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0605",
            "descripcion": "CONTUMAZA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060501",
                "descripcion": "CONTUMAZA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060502",
                "descripcion": "CHILETE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060503",
                "descripcion": "CUPISNIQUE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060504",
                "descripcion": "GUZMANGO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060505",
                "descripcion": "SAN BENITO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060506",
                "descripcion": "SANTA CRUZ DE TOLEDO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060507",
                "descripcion": "TANTARICA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060508",
                "descripcion": "YONAN"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0606",
            "descripcion": "CUTERVO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060601",
                "descripcion": "CUTERVO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060602",
                "descripcion": "CALLAYUC"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060603",
                "descripcion": "CHOROS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060604",
                "descripcion": "CUJILLO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060605",
                "descripcion": "LA RAMADA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060606",
                "descripcion": "PIMPINGOS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060607",
                "descripcion": "QUEROCOTILLO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060608",
                "descripcion": "SAN ANDRES DE CUTERVO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "060609",
                "descripcion": "SAN JUAN DE CUTERVO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "060610",
                "descripcion": "SAN LUIS DE LUCMA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "060611",
                "descripcion": "SANTA CRUZ"
              },
              {
                "posicion": 11,
                "cod_Locacion": "060612",
                "descripcion": "SANTO DOMINGO DE LA CAPILLA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "060613",
                "descripcion": "SANTO TOMAS"
              },
              {
                "posicion": 13,
                "cod_Locacion": "060614",
                "descripcion": "SOCOTA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "060615",
                "descripcion": "TORIBIO CASANOVA"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0607",
            "descripcion": "HUALGAYOC",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060701",
                "descripcion": "BAMBAMARCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060702",
                "descripcion": "CHUGUR"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060703",
                "descripcion": "HUALGAYOC"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "0608",
            "descripcion": "JAEN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060801",
                "descripcion": "JAEN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060802",
                "descripcion": "BELLAVISTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060803",
                "descripcion": "CHONTALI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060804",
                "descripcion": "COLASAY"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060805",
                "descripcion": "HUABAL"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060806",
                "descripcion": "LAS PIRIAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060807",
                "descripcion": "POMAHUACA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "060808",
                "descripcion": "PUCARA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "060809",
                "descripcion": "SALLIQUE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "060810",
                "descripcion": "SAN FELIPE"
              },
              {
                "posicion": 10,
                "cod_Locacion": "060811",
                "descripcion": "SAN JOSE DEL ALTO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "060812",
                "descripcion": "SANTA ROSA"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "0609",
            "descripcion": "SAN IGNACIO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "060901",
                "descripcion": "SAN IGNACIO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "060902",
                "descripcion": "CHIRINOS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "060903",
                "descripcion": "HUARANGO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "060904",
                "descripcion": "LA COIPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "060905",
                "descripcion": "NAMBALLE"
              },
              {
                "posicion": 5,
                "cod_Locacion": "060906",
                "descripcion": "SAN JOSE DE LOURDES"
              },
              {
                "posicion": 6,
                "cod_Locacion": "060907",
                "descripcion": "TABACONAS"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "0610",
            "descripcion": "SAN MARCOS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "061001",
                "descripcion": "PEDRO GALVEZ"
              },
              {
                "posicion": 1,
                "cod_Locacion": "061002",
                "descripcion": "CHANCAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "061003",
                "descripcion": "EDUARDO VILLANUEVA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "061004",
                "descripcion": "GREGORIO PITA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "061005",
                "descripcion": "ICHOCAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "061006",
                "descripcion": "JOSE MANUEL QUIROZ"
              },
              {
                "posicion": 6,
                "cod_Locacion": "061007",
                "descripcion": "JOSE SABOGAL"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "0611",
            "descripcion": "SAN MIGUEL",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "061101",
                "descripcion": "SAN MIGUEL"
              },
              {
                "posicion": 1,
                "cod_Locacion": "061102",
                "descripcion": "BOLIVAR"
              },
              {
                "posicion": 2,
                "cod_Locacion": "061103",
                "descripcion": "CALQUIS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "061104",
                "descripcion": "CATILLUC"
              },
              {
                "posicion": 4,
                "cod_Locacion": "061105",
                "descripcion": "EL PRADO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "061106",
                "descripcion": "LA FLORIDA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "061107",
                "descripcion": "LLAPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "061108",
                "descripcion": "NANCHOC"
              },
              {
                "posicion": 8,
                "cod_Locacion": "061109",
                "descripcion": "NIEPOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "061110",
                "descripcion": "SAN GREGORIO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "061111",
                "descripcion": "SAN SILVESTRE DE COCHAN"
              },
              {
                "posicion": 11,
                "cod_Locacion": "061112",
                "descripcion": "TONGOD"
              },
              {
                "posicion": 12,
                "cod_Locacion": "061113",
                "descripcion": "UNION AGUA BLANCA"
              }
            ]
          },
          {
            "posicion": 11,
            "cod_Locacion": "0612",
            "descripcion": "SAN PABLO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "061201",
                "descripcion": "SAN PABLO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "061202",
                "descripcion": "SAN BERNARDINO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "061203",
                "descripcion": "SAN LUIS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "061204",
                "descripcion": "TUMBADEN"
              }
            ]
          },
          {
            "posicion": 12,
            "cod_Locacion": "0613",
            "descripcion": "SANTA CRUZ",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "061301",
                "descripcion": "SANTA CRUZ"
              },
              {
                "posicion": 1,
                "cod_Locacion": "061302",
                "descripcion": "ANDABAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "061303",
                "descripcion": "CATACHE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "061304",
                "descripcion": "CHANCAYBAÑOS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "061305",
                "descripcion": "LA ESPERANZA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "061306",
                "descripcion": "NINABAMBA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "061307",
                "descripcion": "PULAN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "061308",
                "descripcion": "SAUCEPAMPA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "061309",
                "descripcion": "SEXI"
              },
              {
                "posicion": 9,
                "cod_Locacion": "061310",
                "descripcion": "UTICYACU"
              },
              {
                "posicion": 10,
                "cod_Locacion": "061311",
                "descripcion": "YAUYUCAN"
              }
            ]
          }
        ]
      },
      {
        "posicion": 6,
        "cod_Locacion": "07",
        "descripcion": "CALLAO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0701",
            "descripcion": "PROV. CONST. DEL CALLAO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "070101",
                "descripcion": "CALLAO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "070102",
                "descripcion": "BELLAVISTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "070103",
                "descripcion": "CARMEN DE LA LEGUA REYNOSO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "070104",
                "descripcion": "LA PERLA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "070105",
                "descripcion": "LA PUNTA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "070106",
                "descripcion": "VENTANILLA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "070107",
                "descripcion": "MI PERU"
              }
            ]
          }
        ]
      },
      {
        "posicion": 7,
        "cod_Locacion": "08",
        "descripcion": "CUSCO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0801",
            "descripcion": "CUSCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080101",
                "descripcion": "CUSCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080102",
                "descripcion": "CCORCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080103",
                "descripcion": "POROY"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080104",
                "descripcion": "SAN JERONIMO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080105",
                "descripcion": "SAN SEBASTIAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080106",
                "descripcion": "SANTIAGO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080107",
                "descripcion": "SAYLLA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080108",
                "descripcion": "WANCHAQ"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0802",
            "descripcion": "ACOMAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080201",
                "descripcion": "ACOMAYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080202",
                "descripcion": "ACOPIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080203",
                "descripcion": "ACOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080204",
                "descripcion": "MOSOC LLACTA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080205",
                "descripcion": "POMACANCHI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080206",
                "descripcion": "RONDOCAN"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080207",
                "descripcion": "SANGARARA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0803",
            "descripcion": "ANTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080301",
                "descripcion": "ANTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080302",
                "descripcion": "ANCAHUASI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080303",
                "descripcion": "CACHIMAYO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080304",
                "descripcion": "CHINCHAYPUJIO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080305",
                "descripcion": "HUAROCONDO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080306",
                "descripcion": "LIMATAMBO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080307",
                "descripcion": "MOLLEPATA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080308",
                "descripcion": "PUCYURA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "080309",
                "descripcion": "ZURITE"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0804",
            "descripcion": "CALCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080401",
                "descripcion": "CALCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080402",
                "descripcion": "COYA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080403",
                "descripcion": "LAMAY"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080404",
                "descripcion": "LARES"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080405",
                "descripcion": "PISAC"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080406",
                "descripcion": "SAN SALVADOR"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080407",
                "descripcion": "TARAY"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080408",
                "descripcion": "YANATILE"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0805",
            "descripcion": "CANAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080501",
                "descripcion": "YANAOCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080502",
                "descripcion": "CHECCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080503",
                "descripcion": "KUNTURKANKI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080504",
                "descripcion": "LANGUI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080505",
                "descripcion": "LAYO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080506",
                "descripcion": "PAMPAMARCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080507",
                "descripcion": "QUEHUE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080508",
                "descripcion": "TUPAC AMARU"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0806",
            "descripcion": "CANCHIS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080601",
                "descripcion": "SICUANI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080602",
                "descripcion": "CHECACUPE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080603",
                "descripcion": "COMBAPATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080604",
                "descripcion": "MARANGANI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080605",
                "descripcion": "PITUMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080606",
                "descripcion": "SAN PABLO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080607",
                "descripcion": "SAN PEDRO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080608",
                "descripcion": "TINTA"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0807",
            "descripcion": "CHUMBIVILCAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080701",
                "descripcion": "SANTO TOMAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080702",
                "descripcion": "CAPACMARCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080703",
                "descripcion": "CHAMACA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080704",
                "descripcion": "COLQUEMARCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080705",
                "descripcion": "LIVITACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080706",
                "descripcion": "LLUSCO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080707",
                "descripcion": "QUIÑOTA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080708",
                "descripcion": "VELILLE"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "0808",
            "descripcion": "ESPINAR",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080801",
                "descripcion": "ESPINAR"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080802",
                "descripcion": "CONDOROMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080803",
                "descripcion": "COPORAQUE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080804",
                "descripcion": "OCORURO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080805",
                "descripcion": "PALLPATA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080806",
                "descripcion": "PICHIGUA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080807",
                "descripcion": "SUYCKUTAMBO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080808",
                "descripcion": "ALTO PICHIGUA"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "0809",
            "descripcion": "LA CONVENCION",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "080901",
                "descripcion": "SANTA ANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "080902",
                "descripcion": "ECHARATE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "080903",
                "descripcion": "HUAYOPATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "080904",
                "descripcion": "MARANURA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "080905",
                "descripcion": "OCOBAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "080906",
                "descripcion": "QUELLOUNO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "080907",
                "descripcion": "KIMBIRI"
              },
              {
                "posicion": 7,
                "cod_Locacion": "080908",
                "descripcion": "SANTA TERESA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "080909",
                "descripcion": "VILCABAMBA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "080910",
                "descripcion": "PICHARI"
              },
              {
                "posicion": 10,
                "cod_Locacion": "080911",
                "descripcion": "INKAWASI"
              },
              {
                "posicion": 11,
                "cod_Locacion": "080912",
                "descripcion": "VILLA VIRGEN"
              },
              {
                "posicion": 12,
                "cod_Locacion": "080913",
                "descripcion": "VILLA KINTIARINA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "080914",
                "descripcion": "MEGANTONI"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "0810",
            "descripcion": "PARURO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "081001",
                "descripcion": "PARURO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "081002",
                "descripcion": "ACCHA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "081003",
                "descripcion": "CCAPI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "081004",
                "descripcion": "COLCHA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "081005",
                "descripcion": "HUANOQUITE"
              },
              {
                "posicion": 5,
                "cod_Locacion": "081006",
                "descripcion": "OMACHA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "081007",
                "descripcion": "PACCARITAMBO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "081008",
                "descripcion": "PILLPINTO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "081009",
                "descripcion": "YAURISQUE"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "0811",
            "descripcion": "PAUCARTAMBO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "081101",
                "descripcion": "PAUCARTAMBO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "081102",
                "descripcion": "CAICAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "081103",
                "descripcion": "CHALLABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "081104",
                "descripcion": "COLQUEPATA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "081105",
                "descripcion": "HUANCARANI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "081106",
                "descripcion": "KOSÑIPATA"
              }
            ]
          },
          {
            "posicion": 11,
            "cod_Locacion": "0812",
            "descripcion": "QUISPICANCHI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "081201",
                "descripcion": "URCOS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "081202",
                "descripcion": "ANDAHUAYLILLAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "081203",
                "descripcion": "CAMANTI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "081204",
                "descripcion": "CCARHUAYO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "081205",
                "descripcion": "CCATCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "081206",
                "descripcion": "CUSIPATA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "081207",
                "descripcion": "HUARO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "081208",
                "descripcion": "LUCRE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "081209",
                "descripcion": "MARCAPATA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "081210",
                "descripcion": "OCONGATE"
              },
              {
                "posicion": 10,
                "cod_Locacion": "081211",
                "descripcion": "OROPESA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "081212",
                "descripcion": "QUIQUIJANA"
              }
            ]
          },
          {
            "posicion": 12,
            "cod_Locacion": "0813",
            "descripcion": "URUBAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "081301",
                "descripcion": "URUBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "081302",
                "descripcion": "CHINCHERO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "081303",
                "descripcion": "HUAYLLABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "081304",
                "descripcion": "MACHUPICCHU"
              },
              {
                "posicion": 4,
                "cod_Locacion": "081305",
                "descripcion": "MARAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "081306",
                "descripcion": "OLLANTAYTAMBO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "081307",
                "descripcion": "YUCAY"
              }
            ]
          }
        ]
      },
      {
        "posicion": 8,
        "cod_Locacion": "09",
        "descripcion": "HUANCAVELICA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "0901",
            "descripcion": "HUANCAVELICA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090101",
                "descripcion": "HUANCAVELICA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090102",
                "descripcion": "ACOBAMBILLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090103",
                "descripcion": "ACORIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090104",
                "descripcion": "CONAYCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090105",
                "descripcion": "CUENCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090106",
                "descripcion": "HUACHOCOLPA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090107",
                "descripcion": "HUAYLLAHUARA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090108",
                "descripcion": "IZCUCHACA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090109",
                "descripcion": "LARIA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090110",
                "descripcion": "MANTA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090111",
                "descripcion": "MARISCAL CACERES"
              },
              {
                "posicion": 11,
                "cod_Locacion": "090112",
                "descripcion": "MOYA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "090113",
                "descripcion": "NUEVO OCCORO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "090114",
                "descripcion": "PALCA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "090115",
                "descripcion": "PILCHACA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "090116",
                "descripcion": "VILCA"
              },
              {
                "posicion": 16,
                "cod_Locacion": "090117",
                "descripcion": "YAULI"
              },
              {
                "posicion": 17,
                "cod_Locacion": "090118",
                "descripcion": "ASCENSION"
              },
              {
                "posicion": 18,
                "cod_Locacion": "090119",
                "descripcion": "HUANDO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "0902",
            "descripcion": "ACOBAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090201",
                "descripcion": "ACOBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090202",
                "descripcion": "ANDABAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090203",
                "descripcion": "ANTA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090204",
                "descripcion": "CAJA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090205",
                "descripcion": "MARCAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090206",
                "descripcion": "PAUCARA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090207",
                "descripcion": "POMACOCHA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090208",
                "descripcion": "ROSARIO"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "0903",
            "descripcion": "ANGARAES",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090301",
                "descripcion": "LIRCAY"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090302",
                "descripcion": "ANCHONGA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090303",
                "descripcion": "CALLANMARCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090304",
                "descripcion": "CCOCHACCASA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090305",
                "descripcion": "CHINCHO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090306",
                "descripcion": "CONGALLA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090307",
                "descripcion": "HUANCA-HUANCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090308",
                "descripcion": "HUAYLLAY GRANDE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090309",
                "descripcion": "JULCAMARCA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090310",
                "descripcion": "SAN ANTONIO DE ANTAPARCO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090311",
                "descripcion": "SANTO TOMAS DE PATA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "090312",
                "descripcion": "SECCLLA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "0904",
            "descripcion": "CASTROVIRREYNA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090401",
                "descripcion": "CASTROVIRREYNA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090402",
                "descripcion": "ARMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090403",
                "descripcion": "AURAHUA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090404",
                "descripcion": "CAPILLAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090405",
                "descripcion": "CHUPAMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090406",
                "descripcion": "COCAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090407",
                "descripcion": "HUACHOS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090408",
                "descripcion": "HUAMATAMBO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090409",
                "descripcion": "MOLLEPAMPA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090410",
                "descripcion": "SAN JUAN"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090411",
                "descripcion": "SANTA ANA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "090412",
                "descripcion": "TANTARA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "090413",
                "descripcion": "TICRAPO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "0905",
            "descripcion": "CHURCAMPA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090501",
                "descripcion": "CHURCAMPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090502",
                "descripcion": "ANCO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090503",
                "descripcion": "CHINCHIHUASI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090504",
                "descripcion": "EL CARMEN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090505",
                "descripcion": "LA MERCED"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090506",
                "descripcion": "LOCROJA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090507",
                "descripcion": "PAUCARBAMBA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090508",
                "descripcion": "SAN MIGUEL DE MAYOCC"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090509",
                "descripcion": "SAN PEDRO DE CORIS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090510",
                "descripcion": "PACHAMARCA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090511",
                "descripcion": "COSME"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "0906",
            "descripcion": "HUAYTARA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090601",
                "descripcion": "HUAYTARA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090602",
                "descripcion": "AYAVI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090603",
                "descripcion": "CORDOVA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090604",
                "descripcion": "HUAYACUNDO ARMA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090605",
                "descripcion": "LARAMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090606",
                "descripcion": "OCOYO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090607",
                "descripcion": "PILPICHACA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090608",
                "descripcion": "QUERCO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090609",
                "descripcion": "QUITO-ARMA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090610",
                "descripcion": "SAN ANTONIO DE CUSICANCHA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090611",
                "descripcion": "SAN FRANCISCO DE SANGAYAICO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "090612",
                "descripcion": "SAN ISIDRO"
              },
              {
                "posicion": 12,
                "cod_Locacion": "090613",
                "descripcion": "SANTIAGO DE CHOCORVOS"
              },
              {
                "posicion": 13,
                "cod_Locacion": "090614",
                "descripcion": "SANTIAGO DE QUIRAHUARA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "090615",
                "descripcion": "SANTO DOMINGO DE CAPILLAS"
              },
              {
                "posicion": 15,
                "cod_Locacion": "090616",
                "descripcion": "TAMBO"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "0907",
            "descripcion": "TAYACAJA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "090701",
                "descripcion": "PAMPAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "090702",
                "descripcion": "ACOSTAMBO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "090703",
                "descripcion": "ACRAQUIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "090704",
                "descripcion": "AHUAYCHA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "090705",
                "descripcion": "COLCABAMBA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "090706",
                "descripcion": "DANIEL HERNANDEZ"
              },
              {
                "posicion": 6,
                "cod_Locacion": "090707",
                "descripcion": "HUACHOCOLPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "090708",
                "descripcion": "HUARIBAMBA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "090709",
                "descripcion": "ÑAHUIMPUQUIO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "090710",
                "descripcion": "PAZOS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "090711",
                "descripcion": "QUISHUAR"
              },
              {
                "posicion": 11,
                "cod_Locacion": "090712",
                "descripcion": "SALCABAMBA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "090713",
                "descripcion": "SALCAHUASI"
              },
              {
                "posicion": 13,
                "cod_Locacion": "090714",
                "descripcion": "SAN MARCOS DE ROCCHAC"
              },
              {
                "posicion": 14,
                "cod_Locacion": "090715",
                "descripcion": "SURCUBAMBA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "090716",
                "descripcion": "TINTAY PUNCU"
              },
              {
                "posicion": 16,
                "cod_Locacion": "090717",
                "descripcion": "QUICHUAS"
              },
              {
                "posicion": 17,
                "cod_Locacion": "090718",
                "descripcion": "ANDAYMARCA"
              },
              {
                "posicion": 18,
                "cod_Locacion": "090719",
                "descripcion": "ROBLE"
              },
              {
                "posicion": 19,
                "cod_Locacion": "090720",
                "descripcion": "PICHOS"
              },
              {
                "posicion": 20,
                "cod_Locacion": "090721",
                "descripcion": "SANTIAGO DE TUCUMA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 9,
        "cod_Locacion": "10",
        "descripcion": "HUANUCO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1001",
            "descripcion": "HUANUCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100101",
                "descripcion": "HUANUCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100102",
                "descripcion": "AMARILIS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100103",
                "descripcion": "CHINCHAO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100104",
                "descripcion": "CHURUBAMBA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100105",
                "descripcion": "MARGOS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "100106",
                "descripcion": "QUISQUI (KICHKI)"
              },
              {
                "posicion": 6,
                "cod_Locacion": "100107",
                "descripcion": "SAN FRANCISCO DE CAYRAN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "100108",
                "descripcion": "SAN PEDRO DE CHAULAN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "100109",
                "descripcion": "SANTA MARIA DEL VALLE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "100110",
                "descripcion": "YARUMAYO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "100111",
                "descripcion": "PILLCO MARCA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "100112",
                "descripcion": "YACUS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "100113",
                "descripcion": "SAN PABLO DE PILLAO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1002",
            "descripcion": "AMBO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100201",
                "descripcion": "AMBO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100202",
                "descripcion": "CAYNA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100203",
                "descripcion": "COLPAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100204",
                "descripcion": "CONCHAMARCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100205",
                "descripcion": "HUACAR"
              },
              {
                "posicion": 5,
                "cod_Locacion": "100206",
                "descripcion": "SAN FRANCISCO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "100207",
                "descripcion": "SAN RAFAEL"
              },
              {
                "posicion": 7,
                "cod_Locacion": "100208",
                "descripcion": "TOMAY KICHWA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1003",
            "descripcion": "DOS DE MAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100301",
                "descripcion": "LA UNION"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100307",
                "descripcion": "CHUQUIS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100311",
                "descripcion": "MARIAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100313",
                "descripcion": "PACHAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100316",
                "descripcion": "QUIVILLA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "100317",
                "descripcion": "RIPAN"
              },
              {
                "posicion": 6,
                "cod_Locacion": "100321",
                "descripcion": "SHUNQUI"
              },
              {
                "posicion": 7,
                "cod_Locacion": "100322",
                "descripcion": "SILLAPATA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "100323",
                "descripcion": "YANAS"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1004",
            "descripcion": "HUACAYBAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100401",
                "descripcion": "HUACAYBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100402",
                "descripcion": "CANCHABAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100403",
                "descripcion": "COCHABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100404",
                "descripcion": "PINRA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1005",
            "descripcion": "HUAMALIES",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100501",
                "descripcion": "LLATA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100502",
                "descripcion": "ARANCAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100503",
                "descripcion": "CHAVIN DE PARIARCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100504",
                "descripcion": "JACAS GRANDE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100505",
                "descripcion": "JIRCAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "100506",
                "descripcion": "MIRAFLORES"
              },
              {
                "posicion": 6,
                "cod_Locacion": "100507",
                "descripcion": "MONZON"
              },
              {
                "posicion": 7,
                "cod_Locacion": "100508",
                "descripcion": "PUNCHAO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "100509",
                "descripcion": "PUÑOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "100510",
                "descripcion": "SINGA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "100511",
                "descripcion": "TANTAMAYO"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "1006",
            "descripcion": "LEONCIO PRADO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100601",
                "descripcion": "RUPA-RUPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100602",
                "descripcion": "DANIEL ALOMIA ROBLES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100603",
                "descripcion": "HERMILIO VALDIZAN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100604",
                "descripcion": "JOSE CRESPO Y CASTILLO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100605",
                "descripcion": "LUYANDO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "100606",
                "descripcion": "MARIANO DAMASO BERAUN"
              },
              {
                "posicion": 6,
                "cod_Locacion": "100607",
                "descripcion": "PUCAYACU"
              },
              {
                "posicion": 7,
                "cod_Locacion": "100608",
                "descripcion": "CASTILLO GRANDE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "100609",
                "descripcion": "PUEBLO NUEVO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "100610",
                "descripcion": "SANTO DOMINGO DE ANDA"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "1007",
            "descripcion": "MARAÑON",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100701",
                "descripcion": "HUACRACHUCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100702",
                "descripcion": "CHOLON"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100703",
                "descripcion": "SAN BUENAVENTURA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100704",
                "descripcion": "LA MORADA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100705",
                "descripcion": "SANTA ROSA DE ALTO YANAJANCA"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "1008",
            "descripcion": "PACHITEA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100801",
                "descripcion": "PANAO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100802",
                "descripcion": "CHAGLLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100803",
                "descripcion": "MOLINO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100804",
                "descripcion": "UMARI"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "1009",
            "descripcion": "PUERTO INCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "100901",
                "descripcion": "PUERTO INCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "100902",
                "descripcion": "CODO DEL POZUZO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "100903",
                "descripcion": "HONORIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "100904",
                "descripcion": "TOURNAVISTA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "100905",
                "descripcion": "YUYAPICHIS"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "1010",
            "descripcion": "LAURICOCHA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "101001",
                "descripcion": "JESUS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "101002",
                "descripcion": "BAÑOS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "101003",
                "descripcion": "JIVIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "101004",
                "descripcion": "QUEROPALCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "101005",
                "descripcion": "RONDOS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "101006",
                "descripcion": "SAN FRANCISCO DE ASIS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "101007",
                "descripcion": "SAN MIGUEL DE CAURI"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "1011",
            "descripcion": "YAROWILCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "101101",
                "descripcion": "CHAVINILLO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "101102",
                "descripcion": "CAHUAC"
              },
              {
                "posicion": 2,
                "cod_Locacion": "101103",
                "descripcion": "CHACABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "101104",
                "descripcion": "APARICIO POMARES"
              },
              {
                "posicion": 4,
                "cod_Locacion": "101105",
                "descripcion": "JACAS CHICO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "101106",
                "descripcion": "OBAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "101107",
                "descripcion": "PAMPAMARCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "101108",
                "descripcion": "CHORAS"
              }
            ]
          }
        ]
      },
      {
        "posicion": 10,
        "cod_Locacion": "11",
        "descripcion": "ICA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1101",
            "descripcion": "ICA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "110101",
                "descripcion": "ICA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "110102",
                "descripcion": "LA TINGUIÑA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "110103",
                "descripcion": "LOS AQUIJES"
              },
              {
                "posicion": 3,
                "cod_Locacion": "110104",
                "descripcion": "OCUCAJE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "110105",
                "descripcion": "PACHACUTEC"
              },
              {
                "posicion": 5,
                "cod_Locacion": "110106",
                "descripcion": "PARCONA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "110107",
                "descripcion": "PUEBLO NUEVO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "110108",
                "descripcion": "SALAS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "110109",
                "descripcion": "SAN JOSE DE LOS MOLINOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "110110",
                "descripcion": "SAN JUAN BAUTISTA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "110111",
                "descripcion": "SANTIAGO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "110112",
                "descripcion": "SUBTANJALLA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "110113",
                "descripcion": "TATE"
              },
              {
                "posicion": 13,
                "cod_Locacion": "110114",
                "descripcion": "YAUCA DEL ROSARIO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1102",
            "descripcion": "CHINCHA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "110201",
                "descripcion": "CHINCHA ALTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "110202",
                "descripcion": "ALTO LARAN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "110203",
                "descripcion": "CHAVIN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "110204",
                "descripcion": "CHINCHA BAJA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "110205",
                "descripcion": "EL CARMEN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "110206",
                "descripcion": "GROCIO PRADO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "110207",
                "descripcion": "PUEBLO NUEVO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "110208",
                "descripcion": "SAN JUAN DE YANAC"
              },
              {
                "posicion": 8,
                "cod_Locacion": "110209",
                "descripcion": "SAN PEDRO DE HUACARPANA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "110210",
                "descripcion": "SUNAMPE"
              },
              {
                "posicion": 10,
                "cod_Locacion": "110211",
                "descripcion": "TAMBO DE MORA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1103",
            "descripcion": "NASCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "110301",
                "descripcion": "NASCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "110302",
                "descripcion": "CHANGUILLO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "110303",
                "descripcion": "EL INGENIO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "110304",
                "descripcion": "MARCONA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "110305",
                "descripcion": "VISTA ALEGRE"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1104",
            "descripcion": "PALPA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "110401",
                "descripcion": "PALPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "110402",
                "descripcion": "LLIPATA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "110403",
                "descripcion": "RIO GRANDE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "110404",
                "descripcion": "SANTA CRUZ"
              },
              {
                "posicion": 4,
                "cod_Locacion": "110405",
                "descripcion": "TIBILLO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1105",
            "descripcion": "PISCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "110501",
                "descripcion": "PISCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "110502",
                "descripcion": "HUANCANO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "110503",
                "descripcion": "HUMAY"
              },
              {
                "posicion": 3,
                "cod_Locacion": "110504",
                "descripcion": "INDEPENDENCIA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "110505",
                "descripcion": "PARACAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "110506",
                "descripcion": "SAN ANDRES"
              },
              {
                "posicion": 6,
                "cod_Locacion": "110507",
                "descripcion": "SAN CLEMENTE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "110508",
                "descripcion": "TUPAC AMARU INCA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 11,
        "cod_Locacion": "12",
        "descripcion": "JUNIN",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1201",
            "descripcion": "HUANCAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120101",
                "descripcion": "HUANCAYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120104",
                "descripcion": "CARHUACALLANGA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120105",
                "descripcion": "CHACAPAMPA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120106",
                "descripcion": "CHICCHE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120107",
                "descripcion": "CHILCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120108",
                "descripcion": "CHONGOS ALTO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120111",
                "descripcion": "CHUPURO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120112",
                "descripcion": "COLCA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120113",
                "descripcion": "CULLHUAS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "120114",
                "descripcion": "EL TAMBO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "120116",
                "descripcion": "HUACRAPUQUIO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "120117",
                "descripcion": "HUALHUAS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "120119",
                "descripcion": "HUANCAN"
              },
              {
                "posicion": 13,
                "cod_Locacion": "120120",
                "descripcion": "HUASICANCHA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "120121",
                "descripcion": "HUAYUCACHI"
              },
              {
                "posicion": 15,
                "cod_Locacion": "120122",
                "descripcion": "INGENIO"
              },
              {
                "posicion": 16,
                "cod_Locacion": "120124",
                "descripcion": "PARIAHUANCA"
              },
              {
                "posicion": 17,
                "cod_Locacion": "120125",
                "descripcion": "PILCOMAYO"
              },
              {
                "posicion": 18,
                "cod_Locacion": "120126",
                "descripcion": "PUCARA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "120127",
                "descripcion": "QUICHUAY"
              },
              {
                "posicion": 20,
                "cod_Locacion": "120128",
                "descripcion": "QUILCAS"
              },
              {
                "posicion": 21,
                "cod_Locacion": "120129",
                "descripcion": "SAN AGUSTIN"
              },
              {
                "posicion": 22,
                "cod_Locacion": "120130",
                "descripcion": "SAN JERONIMO DE TUNAN"
              },
              {
                "posicion": 23,
                "cod_Locacion": "120132",
                "descripcion": "SAÑO"
              },
              {
                "posicion": 24,
                "cod_Locacion": "120133",
                "descripcion": "SAPALLANGA"
              },
              {
                "posicion": 25,
                "cod_Locacion": "120134",
                "descripcion": "SICAYA"
              },
              {
                "posicion": 26,
                "cod_Locacion": "120135",
                "descripcion": "SANTO DOMINGO DE ACOBAMBA"
              },
              {
                "posicion": 27,
                "cod_Locacion": "120136",
                "descripcion": "VIQUES"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1202",
            "descripcion": "CONCEPCION",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120201",
                "descripcion": "CONCEPCION"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120202",
                "descripcion": "ACO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120203",
                "descripcion": "ANDAMARCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120204",
                "descripcion": "CHAMBARA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120205",
                "descripcion": "COCHAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120206",
                "descripcion": "COMAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120207",
                "descripcion": "HEROINAS TOLEDO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120208",
                "descripcion": "MANZANARES"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120209",
                "descripcion": "MARISCAL CASTILLA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "120210",
                "descripcion": "MATAHUASI"
              },
              {
                "posicion": 10,
                "cod_Locacion": "120211",
                "descripcion": "MITO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "120212",
                "descripcion": "NUEVE DE JULIO"
              },
              {
                "posicion": 12,
                "cod_Locacion": "120213",
                "descripcion": "ORCOTUNA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "120214",
                "descripcion": "SAN JOSE DE QUERO"
              },
              {
                "posicion": 14,
                "cod_Locacion": "120215",
                "descripcion": "SANTA ROSA DE OCOPA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1203",
            "descripcion": "CHANCHAMAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120301",
                "descripcion": "CHANCHAMAYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120302",
                "descripcion": "PERENE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120303",
                "descripcion": "PICHANAQUI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120304",
                "descripcion": "SAN LUIS DE SHUARO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120305",
                "descripcion": "SAN RAMON"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120306",
                "descripcion": "VITOC"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1204",
            "descripcion": "JAUJA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120401",
                "descripcion": "JAUJA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120402",
                "descripcion": "ACOLLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120403",
                "descripcion": "APATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120404",
                "descripcion": "ATAURA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120405",
                "descripcion": "CANCHAYLLO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120406",
                "descripcion": "CURICACA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120407",
                "descripcion": "EL MANTARO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120408",
                "descripcion": "HUAMALI"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120409",
                "descripcion": "HUARIPAMPA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "120410",
                "descripcion": "HUERTAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "120411",
                "descripcion": "JANJAILLO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "120412",
                "descripcion": "JULCAN"
              },
              {
                "posicion": 12,
                "cod_Locacion": "120413",
                "descripcion": "LEONOR ORDOÑEZ"
              },
              {
                "posicion": 13,
                "cod_Locacion": "120414",
                "descripcion": "LLOCLLAPAMPA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "120415",
                "descripcion": "MARCO"
              },
              {
                "posicion": 15,
                "cod_Locacion": "120416",
                "descripcion": "MASMA"
              },
              {
                "posicion": 16,
                "cod_Locacion": "120417",
                "descripcion": "MASMA CHICCHE"
              },
              {
                "posicion": 17,
                "cod_Locacion": "120418",
                "descripcion": "MOLINOS"
              },
              {
                "posicion": 18,
                "cod_Locacion": "120419",
                "descripcion": "MONOBAMBA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "120420",
                "descripcion": "MUQUI"
              },
              {
                "posicion": 20,
                "cod_Locacion": "120421",
                "descripcion": "MUQUIYAUYO"
              },
              {
                "posicion": 21,
                "cod_Locacion": "120422",
                "descripcion": "PACA"
              },
              {
                "posicion": 22,
                "cod_Locacion": "120423",
                "descripcion": "PACCHA"
              },
              {
                "posicion": 23,
                "cod_Locacion": "120424",
                "descripcion": "PANCAN"
              },
              {
                "posicion": 24,
                "cod_Locacion": "120425",
                "descripcion": "PARCO"
              },
              {
                "posicion": 25,
                "cod_Locacion": "120426",
                "descripcion": "POMACANCHA"
              },
              {
                "posicion": 26,
                "cod_Locacion": "120427",
                "descripcion": "RICRAN"
              },
              {
                "posicion": 27,
                "cod_Locacion": "120428",
                "descripcion": "SAN LORENZO"
              },
              {
                "posicion": 28,
                "cod_Locacion": "120429",
                "descripcion": "SAN PEDRO DE CHUNAN"
              },
              {
                "posicion": 29,
                "cod_Locacion": "120430",
                "descripcion": "SAUSA"
              },
              {
                "posicion": 30,
                "cod_Locacion": "120431",
                "descripcion": "SINCOS"
              },
              {
                "posicion": 31,
                "cod_Locacion": "120432",
                "descripcion": "TUNAN MARCA"
              },
              {
                "posicion": 32,
                "cod_Locacion": "120433",
                "descripcion": "YAULI"
              },
              {
                "posicion": 33,
                "cod_Locacion": "120434",
                "descripcion": "YAUYOS"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1205",
            "descripcion": "JUNIN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120501",
                "descripcion": "JUNIN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120502",
                "descripcion": "CARHUAMAYO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120503",
                "descripcion": "ONDORES"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120504",
                "descripcion": "ULCUMAYO"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "1206",
            "descripcion": "SATIPO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120601",
                "descripcion": "SATIPO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120602",
                "descripcion": "COVIRIALI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120603",
                "descripcion": "LLAYLLA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120604",
                "descripcion": "MAZAMARI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120605",
                "descripcion": "PAMPA HERMOSA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120606",
                "descripcion": "PANGOA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120607",
                "descripcion": "RIO NEGRO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120608",
                "descripcion": "RIO TAMBO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120609",
                "descripcion": "VIZCATAN DEL ENE"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "1207",
            "descripcion": "TARMA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120701",
                "descripcion": "TARMA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120702",
                "descripcion": "ACOBAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120703",
                "descripcion": "HUARICOLCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120704",
                "descripcion": "HUASAHUASI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120705",
                "descripcion": "LA UNION"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120706",
                "descripcion": "PALCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120707",
                "descripcion": "PALCAMAYO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120708",
                "descripcion": "SAN PEDRO DE CAJAS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120709",
                "descripcion": "TAPO"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "1208",
            "descripcion": "YAULI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120801",
                "descripcion": "LA OROYA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120802",
                "descripcion": "CHACAPALPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120803",
                "descripcion": "HUAY-HUAY"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120804",
                "descripcion": "MARCAPOMACOCHA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120805",
                "descripcion": "MOROCOCHA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120806",
                "descripcion": "PACCHA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120807",
                "descripcion": "SANTA BARBARA DE CARHUACAYAN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120808",
                "descripcion": "SANTA ROSA DE SACCO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120809",
                "descripcion": "SUITUCANCHA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "120810",
                "descripcion": "YAULI"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "1209",
            "descripcion": "CHUPACA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "120901",
                "descripcion": "CHUPACA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "120902",
                "descripcion": "AHUAC"
              },
              {
                "posicion": 2,
                "cod_Locacion": "120903",
                "descripcion": "CHONGOS BAJO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "120904",
                "descripcion": "HUACHAC"
              },
              {
                "posicion": 4,
                "cod_Locacion": "120905",
                "descripcion": "HUAMANCACA CHICO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "120906",
                "descripcion": "SAN JUAN DE ISCOS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "120907",
                "descripcion": "SAN JUAN DE JARPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "120908",
                "descripcion": "TRES DE DICIEMBRE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "120909",
                "descripcion": "YANACANCHA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 12,
        "cod_Locacion": "13",
        "descripcion": "LA LIBERTAD",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1301",
            "descripcion": "TRUJILLO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130101",
                "descripcion": "TRUJILLO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130102",
                "descripcion": "EL PORVENIR"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130103",
                "descripcion": "FLORENCIA DE MORA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130104",
                "descripcion": "HUANCHACO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130105",
                "descripcion": "LA ESPERANZA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130106",
                "descripcion": "LAREDO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "130107",
                "descripcion": "MOCHE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "130108",
                "descripcion": "POROTO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "130109",
                "descripcion": "SALAVERRY"
              },
              {
                "posicion": 9,
                "cod_Locacion": "130110",
                "descripcion": "SIMBAL"
              },
              {
                "posicion": 10,
                "cod_Locacion": "130111",
                "descripcion": "VICTOR LARCO HERRERA"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1302",
            "descripcion": "ASCOPE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130201",
                "descripcion": "ASCOPE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130202",
                "descripcion": "CHICAMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130203",
                "descripcion": "CHOCOPE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130204",
                "descripcion": "MAGDALENA DE CAO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130205",
                "descripcion": "PAIJAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130206",
                "descripcion": "RAZURI"
              },
              {
                "posicion": 6,
                "cod_Locacion": "130207",
                "descripcion": "SANTIAGO DE CAO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "130208",
                "descripcion": "CASA GRANDE"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1303",
            "descripcion": "BOLIVAR",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130301",
                "descripcion": "BOLIVAR"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130302",
                "descripcion": "BAMBAMARCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130303",
                "descripcion": "CONDORMARCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130304",
                "descripcion": "LONGOTEA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130305",
                "descripcion": "UCHUMARCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130306",
                "descripcion": "UCUNCHA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1304",
            "descripcion": "CHEPEN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130401",
                "descripcion": "CHEPEN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130402",
                "descripcion": "PACANGA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130403",
                "descripcion": "PUEBLO NUEVO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1305",
            "descripcion": "JULCAN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130501",
                "descripcion": "JULCAN"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130502",
                "descripcion": "CALAMARCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130503",
                "descripcion": "CARABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130504",
                "descripcion": "HUASO"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "1306",
            "descripcion": "OTUZCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130601",
                "descripcion": "OTUZCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130602",
                "descripcion": "AGALLPAMPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130604",
                "descripcion": "CHARAT"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130605",
                "descripcion": "HUARANCHAL"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130606",
                "descripcion": "LA CUESTA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130608",
                "descripcion": "MACHE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "130610",
                "descripcion": "PARANDAY"
              },
              {
                "posicion": 7,
                "cod_Locacion": "130611",
                "descripcion": "SALPO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "130613",
                "descripcion": "SINSICAP"
              },
              {
                "posicion": 9,
                "cod_Locacion": "130614",
                "descripcion": "USQUIL"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "1307",
            "descripcion": "PACASMAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130701",
                "descripcion": "SAN PEDRO DE LLOC"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130702",
                "descripcion": "GUADALUPE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130703",
                "descripcion": "JEQUETEPEQUE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130704",
                "descripcion": "PACASMAYO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130705",
                "descripcion": "SAN JOSE"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "1308",
            "descripcion": "PATAZ",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130801",
                "descripcion": "TAYABAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130802",
                "descripcion": "BULDIBUYO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130803",
                "descripcion": "CHILLIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130804",
                "descripcion": "HUANCASPATA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130805",
                "descripcion": "HUAYLILLAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130806",
                "descripcion": "HUAYO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "130807",
                "descripcion": "ONGON"
              },
              {
                "posicion": 7,
                "cod_Locacion": "130808",
                "descripcion": "PARCOY"
              },
              {
                "posicion": 8,
                "cod_Locacion": "130809",
                "descripcion": "PATAZ"
              },
              {
                "posicion": 9,
                "cod_Locacion": "130810",
                "descripcion": "PIAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "130811",
                "descripcion": "SANTIAGO DE CHALLAS"
              },
              {
                "posicion": 11,
                "cod_Locacion": "130812",
                "descripcion": "TAURIJA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "130813",
                "descripcion": "URPAY"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "1309",
            "descripcion": "SANCHEZ CARRION",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "130901",
                "descripcion": "HUAMACHUCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "130902",
                "descripcion": "CHUGAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "130903",
                "descripcion": "COCHORCO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "130904",
                "descripcion": "CURGOS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "130905",
                "descripcion": "MARCABAL"
              },
              {
                "posicion": 5,
                "cod_Locacion": "130906",
                "descripcion": "SANAGORAN"
              },
              {
                "posicion": 6,
                "cod_Locacion": "130907",
                "descripcion": "SARIN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "130908",
                "descripcion": "SARTIMBAMBA"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "1310",
            "descripcion": "SANTIAGO DE CHUCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "131001",
                "descripcion": "SANTIAGO DE CHUCO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "131002",
                "descripcion": "ANGASMARCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "131003",
                "descripcion": "CACHICADAN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "131004",
                "descripcion": "MOLLEBAMBA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "131005",
                "descripcion": "MOLLEPATA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "131006",
                "descripcion": "QUIRUVILCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "131007",
                "descripcion": "SANTA CRUZ DE CHUCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "131008",
                "descripcion": "SITABAMBA"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "1311",
            "descripcion": "GRAN CHIMU",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "131101",
                "descripcion": "CASCAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "131102",
                "descripcion": "LUCMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "131103",
                "descripcion": "MARMOT"
              },
              {
                "posicion": 3,
                "cod_Locacion": "131104",
                "descripcion": "SAYAPULLO"
              }
            ]
          },
          {
            "posicion": 11,
            "cod_Locacion": "1312",
            "descripcion": "VIRU",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "131201",
                "descripcion": "VIRU"
              },
              {
                "posicion": 1,
                "cod_Locacion": "131202",
                "descripcion": "CHAO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "131203",
                "descripcion": "GUADALUPITO"
              }
            ]
          }
        ]
      },
      {
        "posicion": 13,
        "cod_Locacion": "14",
        "descripcion": "LAMBAYEQUE",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1401",
            "descripcion": "CHICLAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "140101",
                "descripcion": "CHICLAYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "140102",
                "descripcion": "CHONGOYAPE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "140103",
                "descripcion": "ETEN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "140104",
                "descripcion": "ETEN PUERTO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "140105",
                "descripcion": "JOSE LEONARDO ORTIZ"
              },
              {
                "posicion": 5,
                "cod_Locacion": "140106",
                "descripcion": "LA VICTORIA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "140107",
                "descripcion": "LAGUNAS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "140108",
                "descripcion": "MONSEFU"
              },
              {
                "posicion": 8,
                "cod_Locacion": "140109",
                "descripcion": "NUEVA ARICA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "140110",
                "descripcion": "OYOTUN"
              },
              {
                "posicion": 10,
                "cod_Locacion": "140111",
                "descripcion": "PICSI"
              },
              {
                "posicion": 11,
                "cod_Locacion": "140112",
                "descripcion": "PIMENTEL"
              },
              {
                "posicion": 12,
                "cod_Locacion": "140113",
                "descripcion": "REQUE"
              },
              {
                "posicion": 13,
                "cod_Locacion": "140114",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "140115",
                "descripcion": "SAÑA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "140116",
                "descripcion": "CAYALTI"
              },
              {
                "posicion": 16,
                "cod_Locacion": "140117",
                "descripcion": "PATAPO"
              },
              {
                "posicion": 17,
                "cod_Locacion": "140118",
                "descripcion": "POMALCA"
              },
              {
                "posicion": 18,
                "cod_Locacion": "140119",
                "descripcion": "PUCALA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "140120",
                "descripcion": "TUMAN"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1402",
            "descripcion": "FERREÑAFE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "140201",
                "descripcion": "FERREÑAFE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "140202",
                "descripcion": "CAÑARIS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "140203",
                "descripcion": "INCAHUASI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "140204",
                "descripcion": "MANUEL ANTONIO MESONES MURO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "140205",
                "descripcion": "PITIPO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "140206",
                "descripcion": "PUEBLO NUEVO"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1403",
            "descripcion": "LAMBAYEQUE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "140301",
                "descripcion": "LAMBAYEQUE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "140302",
                "descripcion": "CHOCHOPE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "140303",
                "descripcion": "ILLIMO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "140304",
                "descripcion": "JAYANCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "140305",
                "descripcion": "MOCHUMI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "140306",
                "descripcion": "MORROPE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "140307",
                "descripcion": "MOTUPE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "140308",
                "descripcion": "OLMOS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "140309",
                "descripcion": "PACORA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "140310",
                "descripcion": "SALAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "140311",
                "descripcion": "SAN JOSE"
              },
              {
                "posicion": 11,
                "cod_Locacion": "140312",
                "descripcion": "TUCUME"
              }
            ]
          }
        ]
      },
      {
        "posicion": 14,
        "cod_Locacion": "15",
        "descripcion": "LIMA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1501",
            "descripcion": "LIMA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150101",
                "descripcion": "LIMA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150102",
                "descripcion": "ANCON"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150103",
                "descripcion": "ATE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150104",
                "descripcion": "BARRANCO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150105",
                "descripcion": "BREÑA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150106",
                "descripcion": "CARABAYLLO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150107",
                "descripcion": "CHACLACAYO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "150108",
                "descripcion": "CHORRILLOS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "150109",
                "descripcion": "CIENEGUILLA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "150110",
                "descripcion": "COMAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "150111",
                "descripcion": "EL AGUSTINO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "150112",
                "descripcion": "INDEPENDENCIA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "150113",
                "descripcion": "JESUS MARIA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "150114",
                "descripcion": "LA MOLINA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "150115",
                "descripcion": "LA VICTORIA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "150116",
                "descripcion": "LINCE"
              },
              {
                "posicion": 16,
                "cod_Locacion": "150117",
                "descripcion": "LOS OLIVOS"
              },
              {
                "posicion": 17,
                "cod_Locacion": "150118",
                "descripcion": "LURIGANCHO"
              },
              {
                "posicion": 18,
                "cod_Locacion": "150119",
                "descripcion": "LURIN"
              },
              {
                "posicion": 19,
                "cod_Locacion": "150120",
                "descripcion": "MAGDALENA DEL MAR"
              },
              {
                "posicion": 20,
                "cod_Locacion": "150121",
                "descripcion": "PUEBLO LIBRE"
              },
              {
                "posicion": 21,
                "cod_Locacion": "150122",
                "descripcion": "MIRAFLORES"
              },
              {
                "posicion": 22,
                "cod_Locacion": "150123",
                "descripcion": "PACHACAMAC"
              },
              {
                "posicion": 23,
                "cod_Locacion": "150124",
                "descripcion": "PUCUSANA"
              },
              {
                "posicion": 24,
                "cod_Locacion": "150125",
                "descripcion": "PUENTE PIEDRA"
              },
              {
                "posicion": 25,
                "cod_Locacion": "150126",
                "descripcion": "PUNTA HERMOSA"
              },
              {
                "posicion": 26,
                "cod_Locacion": "150127",
                "descripcion": "PUNTA NEGRA"
              },
              {
                "posicion": 27,
                "cod_Locacion": "150128",
                "descripcion": "RIMAC"
              },
              {
                "posicion": 28,
                "cod_Locacion": "150129",
                "descripcion": "SAN BARTOLO"
              },
              {
                "posicion": 29,
                "cod_Locacion": "150130",
                "descripcion": "SAN BORJA"
              },
              {
                "posicion": 30,
                "cod_Locacion": "150131",
                "descripcion": "SAN ISIDRO"
              },
              {
                "posicion": 31,
                "cod_Locacion": "150132",
                "descripcion": "SAN JUAN DE LURIGANCHO"
              },
              {
                "posicion": 32,
                "cod_Locacion": "150133",
                "descripcion": "SAN JUAN DE MIRAFLORES"
              },
              {
                "posicion": 33,
                "cod_Locacion": "150134",
                "descripcion": "SAN LUIS"
              },
              {
                "posicion": 34,
                "cod_Locacion": "150135",
                "descripcion": "SAN MARTIN DE PORRES"
              },
              {
                "posicion": 35,
                "cod_Locacion": "150136",
                "descripcion": "SAN MIGUEL"
              },
              {
                "posicion": 36,
                "cod_Locacion": "150137",
                "descripcion": "SANTA ANITA"
              },
              {
                "posicion": 37,
                "cod_Locacion": "150138",
                "descripcion": "SANTA MARIA DEL MAR"
              },
              {
                "posicion": 38,
                "cod_Locacion": "150139",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 39,
                "cod_Locacion": "150140",
                "descripcion": "SANTIAGO DE SURCO"
              },
              {
                "posicion": 40,
                "cod_Locacion": "150141",
                "descripcion": "SURQUILLO"
              },
              {
                "posicion": 41,
                "cod_Locacion": "150142",
                "descripcion": "VILLA EL SALVADOR"
              },
              {
                "posicion": 42,
                "cod_Locacion": "150143",
                "descripcion": "VILLA MARIA DEL TRIUNFO"
              },
              {
                "posicion": 43,
                "cod_Locacion": "160101",
                "descripcion": "IQUITOS"
              },
              {
                "posicion": 44,
                "cod_Locacion": "160102",
                "descripcion": "ALTO NANAY"
              },
              {
                "posicion": 45,
                "cod_Locacion": "160103",
                "descripcion": "FERNANDO LORES"
              },
              {
                "posicion": 46,
                "cod_Locacion": "160104",
                "descripcion": "INDIANA"
              },
              {
                "posicion": 47,
                "cod_Locacion": "160105",
                "descripcion": "LAS AMAZONAS"
              },
              {
                "posicion": 48,
                "cod_Locacion": "160106",
                "descripcion": "MAZAN"
              },
              {
                "posicion": 49,
                "cod_Locacion": "160107",
                "descripcion": "NAPO"
              },
              {
                "posicion": 50,
                "cod_Locacion": "160108",
                "descripcion": "PUNCHANA"
              },
              {
                "posicion": 51,
                "cod_Locacion": "160110",
                "descripcion": "TORRES CAUSANA"
              },
              {
                "posicion": 52,
                "cod_Locacion": "160112",
                "descripcion": "BELEN"
              },
              {
                "posicion": 53,
                "cod_Locacion": "160113",
                "descripcion": "SAN JUAN BAUTISTA"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1502",
            "descripcion": "BARRANCA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150201",
                "descripcion": "BARRANCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150202",
                "descripcion": "PARAMONGA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150203",
                "descripcion": "PATIVILCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150204",
                "descripcion": "SUPE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150205",
                "descripcion": "SUPE PUERTO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "160201",
                "descripcion": "YURIMAGUAS"
              },
              {
                "posicion": 6,
                "cod_Locacion": "160202",
                "descripcion": "BALSAPUERTO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "160205",
                "descripcion": "JEBEROS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "160206",
                "descripcion": "LAGUNAS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "160210",
                "descripcion": "SANTA CRUZ"
              },
              {
                "posicion": 10,
                "cod_Locacion": "160211",
                "descripcion": "TENIENTE CESAR LOPEZ ROJAS"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1503",
            "descripcion": "CAJATAMBO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150301",
                "descripcion": "CAJATAMBO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150302",
                "descripcion": "COPA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150303",
                "descripcion": "GORGOR"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150304",
                "descripcion": "HUANCAPON"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150305",
                "descripcion": "MANAS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "160301",
                "descripcion": "NAUTA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "160302",
                "descripcion": "PARINARI"
              },
              {
                "posicion": 7,
                "cod_Locacion": "160303",
                "descripcion": "TIGRE"
              },
              {
                "posicion": 8,
                "cod_Locacion": "160304",
                "descripcion": "TROMPETEROS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "160305",
                "descripcion": "URARINAS"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1504",
            "descripcion": "CANTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150401",
                "descripcion": "CANTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150402",
                "descripcion": "ARAHUAY"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150403",
                "descripcion": "HUAMANTANGA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150404",
                "descripcion": "HUAROS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150405",
                "descripcion": "LACHAQUI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150406",
                "descripcion": "SAN BUENAVENTURA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150407",
                "descripcion": "SANTA ROSA DE QUIVES"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1505",
            "descripcion": "CAÑETE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150501",
                "descripcion": "SAN VICENTE DE CAÑETE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150502",
                "descripcion": "ASIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150503",
                "descripcion": "CALANGO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150504",
                "descripcion": "CERRO AZUL"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150505",
                "descripcion": "CHILCA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150506",
                "descripcion": "COAYLLO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150507",
                "descripcion": "IMPERIAL"
              },
              {
                "posicion": 7,
                "cod_Locacion": "150508",
                "descripcion": "LUNAHUANA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "150509",
                "descripcion": "MALA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "150510",
                "descripcion": "NUEVO IMPERIAL"
              },
              {
                "posicion": 10,
                "cod_Locacion": "150511",
                "descripcion": "PACARAN"
              },
              {
                "posicion": 11,
                "cod_Locacion": "150512",
                "descripcion": "QUILMANA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "150513",
                "descripcion": "SAN ANTONIO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "150514",
                "descripcion": "SAN LUIS"
              },
              {
                "posicion": 14,
                "cod_Locacion": "150515",
                "descripcion": "SANTA CRUZ DE FLORES"
              },
              {
                "posicion": 15,
                "cod_Locacion": "150516",
                "descripcion": "ZUÑIGA"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "1506",
            "descripcion": "HUARAL",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150601",
                "descripcion": "HUARAL"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150602",
                "descripcion": "ATAVILLOS ALTO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150603",
                "descripcion": "ATAVILLOS BAJO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150604",
                "descripcion": "AUCALLAMA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150605",
                "descripcion": "CHANCAY"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150606",
                "descripcion": "IHUARI"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150607",
                "descripcion": "LAMPIAN"
              },
              {
                "posicion": 7,
                "cod_Locacion": "150608",
                "descripcion": "PACARAOS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "150609",
                "descripcion": "SAN MIGUEL DE ACOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "150610",
                "descripcion": "SANTA CRUZ DE ANDAMARCA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "150611",
                "descripcion": "SUMBILCA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "150612",
                "descripcion": "VEINTISIETE DE NOVIEMBRE"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "1507",
            "descripcion": "HUAROCHIRI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150701",
                "descripcion": "MATUCANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150702",
                "descripcion": "ANTIOQUIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150703",
                "descripcion": "CALLAHUANCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150704",
                "descripcion": "CARAMPOMA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150705",
                "descripcion": "CHICLA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150706",
                "descripcion": "CUENCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150707",
                "descripcion": "HUACHUPAMPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "150708",
                "descripcion": "HUANZA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "150709",
                "descripcion": "HUAROCHIRI"
              },
              {
                "posicion": 9,
                "cod_Locacion": "150710",
                "descripcion": "LAHUAYTAMBO"
              },
              {
                "posicion": 10,
                "cod_Locacion": "150711",
                "descripcion": "LANGA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "150712",
                "descripcion": "LARAOS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "150713",
                "descripcion": "MARIATANA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "150714",
                "descripcion": "RICARDO PALMA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "150715",
                "descripcion": "SAN ANDRES DE TUPICOCHA"
              },
              {
                "posicion": 15,
                "cod_Locacion": "150716",
                "descripcion": "SAN ANTONIO"
              },
              {
                "posicion": 16,
                "cod_Locacion": "150717",
                "descripcion": "SAN BARTOLOME"
              },
              {
                "posicion": 17,
                "cod_Locacion": "150718",
                "descripcion": "SAN DAMIAN"
              },
              {
                "posicion": 18,
                "cod_Locacion": "150719",
                "descripcion": "SAN JUAN DE IRIS"
              },
              {
                "posicion": 19,
                "cod_Locacion": "150720",
                "descripcion": "SAN JUAN DE TANTARANCHE"
              },
              {
                "posicion": 20,
                "cod_Locacion": "150721",
                "descripcion": "SAN LORENZO DE QUINTI"
              },
              {
                "posicion": 21,
                "cod_Locacion": "150722",
                "descripcion": "SAN MATEO"
              },
              {
                "posicion": 22,
                "cod_Locacion": "150723",
                "descripcion": "SAN MATEO DE OTAO"
              },
              {
                "posicion": 23,
                "cod_Locacion": "150724",
                "descripcion": "SAN PEDRO DE CASTA"
              },
              {
                "posicion": 24,
                "cod_Locacion": "150725",
                "descripcion": "SAN PEDRO DE HUANCAYRE"
              },
              {
                "posicion": 25,
                "cod_Locacion": "150726",
                "descripcion": "SANGALLAYA"
              },
              {
                "posicion": 26,
                "cod_Locacion": "150727",
                "descripcion": "SANTA CRUZ DE COCACHACRA"
              },
              {
                "posicion": 27,
                "cod_Locacion": "150728",
                "descripcion": "SANTA EULALIA"
              },
              {
                "posicion": 28,
                "cod_Locacion": "150729",
                "descripcion": "SANTIAGO DE ANCHUCAYA"
              },
              {
                "posicion": 29,
                "cod_Locacion": "150730",
                "descripcion": "SANTIAGO DE TUNA"
              },
              {
                "posicion": 30,
                "cod_Locacion": "150731",
                "descripcion": "SANTO DOMINGO DE LOS OLLEROS"
              },
              {
                "posicion": 31,
                "cod_Locacion": "150732",
                "descripcion": "SURCO"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "1508",
            "descripcion": "HUAURA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150801",
                "descripcion": "HUACHO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150802",
                "descripcion": "AMBAR"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150803",
                "descripcion": "CALETA DE CARQUIN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150804",
                "descripcion": "CHECRAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150805",
                "descripcion": "HUALMAY"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150806",
                "descripcion": "HUAURA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "150807",
                "descripcion": "LEONCIO PRADO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "150808",
                "descripcion": "PACCHO"
              },
              {
                "posicion": 8,
                "cod_Locacion": "150809",
                "descripcion": "SANTA LEONOR"
              },
              {
                "posicion": 9,
                "cod_Locacion": "150810",
                "descripcion": "SANTA MARIA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "150811",
                "descripcion": "SAYAN"
              },
              {
                "posicion": 11,
                "cod_Locacion": "150812",
                "descripcion": "VEGUETA"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "1509",
            "descripcion": "OYON",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "150901",
                "descripcion": "OYON"
              },
              {
                "posicion": 1,
                "cod_Locacion": "150902",
                "descripcion": "ANDAJES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "150903",
                "descripcion": "CAUJUL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "150904",
                "descripcion": "COCHAMARCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "150905",
                "descripcion": "NAVAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "150906",
                "descripcion": "PACHANGARA"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "1510",
            "descripcion": "YAUYOS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "151001",
                "descripcion": "YAUYOS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "151002",
                "descripcion": "ALIS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "151003",
                "descripcion": "ALLAUCA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "151004",
                "descripcion": "AYAVIRI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "151005",
                "descripcion": "AZANGARO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "151006",
                "descripcion": "CACRA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "151007",
                "descripcion": "CARANIA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "151008",
                "descripcion": "CATAHUASI"
              },
              {
                "posicion": 8,
                "cod_Locacion": "151009",
                "descripcion": "CHOCOS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "151010",
                "descripcion": "COCHAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "151011",
                "descripcion": "COLONIA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "151012",
                "descripcion": "HONGOS"
              },
              {
                "posicion": 12,
                "cod_Locacion": "151013",
                "descripcion": "HUAMPARA"
              },
              {
                "posicion": 13,
                "cod_Locacion": "151014",
                "descripcion": "HUANCAYA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "151015",
                "descripcion": "HUANGASCAR"
              },
              {
                "posicion": 15,
                "cod_Locacion": "151016",
                "descripcion": "HUANTAN"
              },
              {
                "posicion": 16,
                "cod_Locacion": "151017",
                "descripcion": "HUAÑEC"
              },
              {
                "posicion": 17,
                "cod_Locacion": "151018",
                "descripcion": "LARAOS"
              },
              {
                "posicion": 18,
                "cod_Locacion": "151019",
                "descripcion": "LINCHA"
              },
              {
                "posicion": 19,
                "cod_Locacion": "151020",
                "descripcion": "MADEAN"
              },
              {
                "posicion": 20,
                "cod_Locacion": "151021",
                "descripcion": "MIRAFLORES"
              },
              {
                "posicion": 21,
                "cod_Locacion": "151022",
                "descripcion": "OMAS"
              },
              {
                "posicion": 22,
                "cod_Locacion": "151023",
                "descripcion": "PUTINZA"
              },
              {
                "posicion": 23,
                "cod_Locacion": "151024",
                "descripcion": "QUINCHES"
              },
              {
                "posicion": 24,
                "cod_Locacion": "151025",
                "descripcion": "QUINOCAY"
              },
              {
                "posicion": 25,
                "cod_Locacion": "151026",
                "descripcion": "SAN JOAQUIN"
              },
              {
                "posicion": 26,
                "cod_Locacion": "151027",
                "descripcion": "SAN PEDRO DE PILAS"
              },
              {
                "posicion": 27,
                "cod_Locacion": "151028",
                "descripcion": "TANTA"
              },
              {
                "posicion": 28,
                "cod_Locacion": "151029",
                "descripcion": "TAURIPAMPA"
              },
              {
                "posicion": 29,
                "cod_Locacion": "151030",
                "descripcion": "TOMAS"
              },
              {
                "posicion": 30,
                "cod_Locacion": "151031",
                "descripcion": "TUPE"
              },
              {
                "posicion": 31,
                "cod_Locacion": "151032",
                "descripcion": "VIÑAC"
              },
              {
                "posicion": 32,
                "cod_Locacion": "151033",
                "descripcion": "VITIS"
              }
            ]
          }
        ]
      },
      {
        "posicion": 15,
        "cod_Locacion": "16",
        "descripcion": "LORETO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1604",
            "descripcion": "MARISCAL RAMON CASTILLA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "160401",
                "descripcion": "RAMON CASTILLA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "160402",
                "descripcion": "PEBAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "160403",
                "descripcion": "YAVARI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "160404",
                "descripcion": "SAN PABLO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1605",
            "descripcion": "REQUENA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "160501",
                "descripcion": "REQUENA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "160502",
                "descripcion": "ALTO TAPICHE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "160503",
                "descripcion": "CAPELO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "160504",
                "descripcion": "EMILIO SAN MARTIN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "160505",
                "descripcion": "MAQUIA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "160506",
                "descripcion": "PUINAHUA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "160507",
                "descripcion": "SAQUENA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "160508",
                "descripcion": "SOPLIN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "160509",
                "descripcion": "TAPICHE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "160510",
                "descripcion": "JENARO HERRERA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "160511",
                "descripcion": "YAQUERANA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1606",
            "descripcion": "UCAYALI",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "160601",
                "descripcion": "CONTAMANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "160602",
                "descripcion": "INAHUAYA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "160603",
                "descripcion": "PADRE MARQUEZ"
              },
              {
                "posicion": 3,
                "cod_Locacion": "160604",
                "descripcion": "PAMPA HERMOSA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "160605",
                "descripcion": "SARAYACU"
              },
              {
                "posicion": 5,
                "cod_Locacion": "160606",
                "descripcion": "VARGAS GUERRA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "1607",
            "descripcion": "DATEM DEL MARAÑON",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "160701",
                "descripcion": "BARRANCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "160702",
                "descripcion": "CAHUAPANAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "160703",
                "descripcion": "MANSERICHE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "160704",
                "descripcion": "MORONA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "160705",
                "descripcion": "PASTAZA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "160706",
                "descripcion": "ANDOAS"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "1608",
            "descripcion": "PUTUMAYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "160801",
                "descripcion": "PUTUMAYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "160802",
                "descripcion": "ROSA PANDURO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "160803",
                "descripcion": "TENIENTE MANUEL CLAVERO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "160804",
                "descripcion": "YAGUAS"
              }
            ]
          }
        ]
      },
      {
        "posicion": 16,
        "cod_Locacion": "17",
        "descripcion": "MADRE DE DIOS",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1701",
            "descripcion": "TAMBOPATA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "170101",
                "descripcion": "TAMBOPATA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "170102",
                "descripcion": "INAMBARI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "170103",
                "descripcion": "LAS PIEDRAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "170104",
                "descripcion": "LABERINTO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1702",
            "descripcion": "MANU",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "170201",
                "descripcion": "MANU"
              },
              {
                "posicion": 1,
                "cod_Locacion": "170202",
                "descripcion": "FITZCARRALD"
              },
              {
                "posicion": 2,
                "cod_Locacion": "170203",
                "descripcion": "MADRE DE DIOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "170204",
                "descripcion": "HUEPETUHE"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1703",
            "descripcion": "TAHUAMANU",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "170301",
                "descripcion": "IÑAPARI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "170302",
                "descripcion": "IBERIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "170303",
                "descripcion": "TAHUAMANU"
              }
            ]
          }
        ]
      },
      {
        "posicion": 17,
        "cod_Locacion": "18",
        "descripcion": "MOQUEGUA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1801",
            "descripcion": "MARISCAL NIETO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "180101",
                "descripcion": "MOQUEGUA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "180102",
                "descripcion": "CARUMAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "180103",
                "descripcion": "CUCHUMBAYA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "180104",
                "descripcion": "SAMEGUA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "180105",
                "descripcion": "SAN CRISTOBAL"
              },
              {
                "posicion": 5,
                "cod_Locacion": "180106",
                "descripcion": "TORATA"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1802",
            "descripcion": "GENERAL SANCHEZ CERRO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "180201",
                "descripcion": "OMATE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "180202",
                "descripcion": "CHOJATA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "180203",
                "descripcion": "COALAQUE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "180204",
                "descripcion": "ICHUÑA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "180205",
                "descripcion": "LA CAPILLA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "180206",
                "descripcion": "LLOQUE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "180207",
                "descripcion": "MATALAQUE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "180208",
                "descripcion": "PUQUINA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "180209",
                "descripcion": "QUINISTAQUILLAS"
              },
              {
                "posicion": 9,
                "cod_Locacion": "180210",
                "descripcion": "UBINAS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "180211",
                "descripcion": "YUNGA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1803",
            "descripcion": "ILO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "180301",
                "descripcion": "ILO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "180302",
                "descripcion": "EL ALGARROBAL"
              },
              {
                "posicion": 2,
                "cod_Locacion": "180303",
                "descripcion": "PACOCHA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 18,
        "cod_Locacion": "19",
        "descripcion": "PASCO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "1901",
            "descripcion": "PASCO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "190101",
                "descripcion": "CHAUPIMARCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "190102",
                "descripcion": "HUACHON"
              },
              {
                "posicion": 2,
                "cod_Locacion": "190103",
                "descripcion": "HUARIACA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "190104",
                "descripcion": "HUAYLLAY"
              },
              {
                "posicion": 4,
                "cod_Locacion": "190105",
                "descripcion": "NINACACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "190106",
                "descripcion": "PALLANCHACRA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "190107",
                "descripcion": "PAUCARTAMBO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "190108",
                "descripcion": "SAN FRANCISCO DE ASIS DE YARUSYACAN"
              },
              {
                "posicion": 8,
                "cod_Locacion": "190109",
                "descripcion": "SIMON BOLIVAR"
              },
              {
                "posicion": 9,
                "cod_Locacion": "190110",
                "descripcion": "TICLACAYAN"
              },
              {
                "posicion": 10,
                "cod_Locacion": "190111",
                "descripcion": "TINYAHUARCO"
              },
              {
                "posicion": 11,
                "cod_Locacion": "190112",
                "descripcion": "VICCO"
              },
              {
                "posicion": 12,
                "cod_Locacion": "190113",
                "descripcion": "YANACANCHA"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "1902",
            "descripcion": "DANIEL ALCIDES CARRION",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "190201",
                "descripcion": "YANAHUANCA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "190202",
                "descripcion": "CHACAYAN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "190203",
                "descripcion": "GOYLLARISQUIZGA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "190204",
                "descripcion": "PAUCAR"
              },
              {
                "posicion": 4,
                "cod_Locacion": "190205",
                "descripcion": "SAN PEDRO DE PILLAO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "190206",
                "descripcion": "SANTA ANA DE TUSI"
              },
              {
                "posicion": 6,
                "cod_Locacion": "190207",
                "descripcion": "TAPUC"
              },
              {
                "posicion": 7,
                "cod_Locacion": "190208",
                "descripcion": "VILCABAMBA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "1903",
            "descripcion": "OXAPAMPA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "190301",
                "descripcion": "OXAPAMPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "190302",
                "descripcion": "CHONTABAMBA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "190303",
                "descripcion": "HUANCABAMBA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "190304",
                "descripcion": "PALCAZU"
              },
              {
                "posicion": 4,
                "cod_Locacion": "190305",
                "descripcion": "POZUZO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "190306",
                "descripcion": "PUERTO BERMUDEZ"
              },
              {
                "posicion": 6,
                "cod_Locacion": "190307",
                "descripcion": "VILLA RICA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "190308",
                "descripcion": "CONSTITUCION"
              }
            ]
          }
        ]
      },
      {
        "posicion": 19,
        "cod_Locacion": "20",
        "descripcion": "PIURA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2001",
            "descripcion": "PIURA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200101",
                "descripcion": "PIURA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200104",
                "descripcion": "CASTILLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200105",
                "descripcion": "CATACAOS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200107",
                "descripcion": "CURA MORI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200108",
                "descripcion": "EL TALLAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200109",
                "descripcion": "LA ARENA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200110",
                "descripcion": "LA UNION"
              },
              {
                "posicion": 7,
                "cod_Locacion": "200111",
                "descripcion": "LAS LOMAS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "200114",
                "descripcion": "TAMBO GRANDE"
              },
              {
                "posicion": 9,
                "cod_Locacion": "200115",
                "descripcion": "VEINTISEIS DE OCTUBRE"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2002",
            "descripcion": "AYABACA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200201",
                "descripcion": "AYABACA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200202",
                "descripcion": "FRIAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200203",
                "descripcion": "JILILI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200204",
                "descripcion": "LAGUNAS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200205",
                "descripcion": "MONTERO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200206",
                "descripcion": "PACAIPAMPA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200207",
                "descripcion": "PAIMAS"
              },
              {
                "posicion": 7,
                "cod_Locacion": "200208",
                "descripcion": "SAPILLICA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "200209",
                "descripcion": "SICCHEZ"
              },
              {
                "posicion": 9,
                "cod_Locacion": "200210",
                "descripcion": "SUYO"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2003",
            "descripcion": "HUANCABAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200301",
                "descripcion": "HUANCABAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200302",
                "descripcion": "CANCHAQUE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200303",
                "descripcion": "EL CARMEN DE LA FRONTERA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200304",
                "descripcion": "HUARMACA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200305",
                "descripcion": "LALAQUIZ"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200306",
                "descripcion": "SAN MIGUEL DE EL FAIQUE"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200307",
                "descripcion": "SONDOR"
              },
              {
                "posicion": 7,
                "cod_Locacion": "200308",
                "descripcion": "SONDORILLO"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "2004",
            "descripcion": "MORROPON",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200401",
                "descripcion": "CHULUCANAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200402",
                "descripcion": "BUENOS AIRES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200403",
                "descripcion": "CHALACO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200404",
                "descripcion": "LA MATANZA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200405",
                "descripcion": "MORROPON"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200406",
                "descripcion": "SALITRAL"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200407",
                "descripcion": "SAN JUAN DE BIGOTE"
              },
              {
                "posicion": 7,
                "cod_Locacion": "200408",
                "descripcion": "SANTA CATALINA DE MOSSA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "200409",
                "descripcion": "SANTO DOMINGO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "200410",
                "descripcion": "YAMANGO"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "2005",
            "descripcion": "PAITA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200501",
                "descripcion": "PAITA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200502",
                "descripcion": "AMOTAPE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200503",
                "descripcion": "ARENAL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200504",
                "descripcion": "COLAN"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200505",
                "descripcion": "LA HUACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200506",
                "descripcion": "TAMARINDO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200507",
                "descripcion": "VICHAYAL"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "2006",
            "descripcion": "SULLANA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200601",
                "descripcion": "SULLANA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200602",
                "descripcion": "BELLAVISTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200603",
                "descripcion": "IGNACIO ESCUDERO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200604",
                "descripcion": "LANCONES"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200605",
                "descripcion": "MARCAVELICA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200606",
                "descripcion": "MIGUEL CHECA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "200607",
                "descripcion": "QUERECOTILLO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "200608",
                "descripcion": "SALITRAL"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "2007",
            "descripcion": "TALARA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200701",
                "descripcion": "PARIÑAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200702",
                "descripcion": "EL ALTO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200703",
                "descripcion": "LA BREA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200704",
                "descripcion": "LOBITOS"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200705",
                "descripcion": "LOS ORGANOS"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200706",
                "descripcion": "MANCORA"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "2008",
            "descripcion": "SECHURA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "200801",
                "descripcion": "SECHURA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "200802",
                "descripcion": "BELLAVISTA DE LA UNION"
              },
              {
                "posicion": 2,
                "cod_Locacion": "200803",
                "descripcion": "BERNAL"
              },
              {
                "posicion": 3,
                "cod_Locacion": "200804",
                "descripcion": "CRISTO NOS VALGA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "200805",
                "descripcion": "VICE"
              },
              {
                "posicion": 5,
                "cod_Locacion": "200806",
                "descripcion": "RINCONADA LLICUAR"
              }
            ]
          }
        ]
      },
      {
        "posicion": 20,
        "cod_Locacion": "21",
        "descripcion": "PUNO",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2101",
            "descripcion": "PUNO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210101",
                "descripcion": "PUNO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210102",
                "descripcion": "ACORA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210103",
                "descripcion": "AMANTANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210104",
                "descripcion": "ATUNCOLLA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210105",
                "descripcion": "CAPACHICA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210106",
                "descripcion": "CHUCUITO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210107",
                "descripcion": "COATA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210108",
                "descripcion": "HUATA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "210109",
                "descripcion": "MAÑAZO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "210110",
                "descripcion": "PAUCARCOLLA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "210111",
                "descripcion": "PICHACANI"
              },
              {
                "posicion": 11,
                "cod_Locacion": "210112",
                "descripcion": "PLATERIA"
              },
              {
                "posicion": 12,
                "cod_Locacion": "210113",
                "descripcion": "SAN ANTONIO"
              },
              {
                "posicion": 13,
                "cod_Locacion": "210114",
                "descripcion": "TIQUILLACA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "210115",
                "descripcion": "VILQUE"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2102",
            "descripcion": "AZANGARO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210201",
                "descripcion": "AZANGARO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210202",
                "descripcion": "ACHAYA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210203",
                "descripcion": "ARAPA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210204",
                "descripcion": "ASILLO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210205",
                "descripcion": "CAMINACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210206",
                "descripcion": "CHUPA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210207",
                "descripcion": "JOSE DOMINGO CHOQUEHUANCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210208",
                "descripcion": "MUÑANI"
              },
              {
                "posicion": 8,
                "cod_Locacion": "210209",
                "descripcion": "POTONI"
              },
              {
                "posicion": 9,
                "cod_Locacion": "210210",
                "descripcion": "SAMAN"
              },
              {
                "posicion": 10,
                "cod_Locacion": "210211",
                "descripcion": "SAN ANTON"
              },
              {
                "posicion": 11,
                "cod_Locacion": "210212",
                "descripcion": "SAN JOSE"
              },
              {
                "posicion": 12,
                "cod_Locacion": "210213",
                "descripcion": "SAN JUAN DE SALINAS"
              },
              {
                "posicion": 13,
                "cod_Locacion": "210214",
                "descripcion": "SANTIAGO DE PUPUJA"
              },
              {
                "posicion": 14,
                "cod_Locacion": "210215",
                "descripcion": "TIRAPATA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2103",
            "descripcion": "CARABAYA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210301",
                "descripcion": "MACUSANI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210302",
                "descripcion": "AJOYANI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210303",
                "descripcion": "AYAPATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210304",
                "descripcion": "COASA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210305",
                "descripcion": "CORANI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210306",
                "descripcion": "CRUCERO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210307",
                "descripcion": "ITUATA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210308",
                "descripcion": "OLLACHEA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "210309",
                "descripcion": "SAN GABAN"
              },
              {
                "posicion": 9,
                "cod_Locacion": "210310",
                "descripcion": "USICAYOS"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "2104",
            "descripcion": "CHUCUITO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210401",
                "descripcion": "JULI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210402",
                "descripcion": "DESAGUADERO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210403",
                "descripcion": "HUACULLANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210404",
                "descripcion": "KELLUYO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210405",
                "descripcion": "PISACOMA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210406",
                "descripcion": "POMATA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210407",
                "descripcion": "ZEPITA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "2105",
            "descripcion": "EL COLLAO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210501",
                "descripcion": "ILAVE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210502",
                "descripcion": "CAPAZO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210503",
                "descripcion": "PILCUYO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210504",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210505",
                "descripcion": "CONDURIRI"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "2106",
            "descripcion": "HUANCANE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210601",
                "descripcion": "HUANCANE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210602",
                "descripcion": "COJATA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210603",
                "descripcion": "HUATASANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210604",
                "descripcion": "INCHUPALLA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210605",
                "descripcion": "PUSI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210606",
                "descripcion": "ROSASPATA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210607",
                "descripcion": "TARACO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210608",
                "descripcion": "VILQUE CHICO"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "2107",
            "descripcion": "LAMPA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210701",
                "descripcion": "LAMPA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210702",
                "descripcion": "CABANILLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210703",
                "descripcion": "CALAPUJA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210704",
                "descripcion": "NICASIO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210705",
                "descripcion": "OCUVIRI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210706",
                "descripcion": "PALCA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210707",
                "descripcion": "PARATIA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210708",
                "descripcion": "PUCARA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "210709",
                "descripcion": "SANTA LUCIA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "210710",
                "descripcion": "VILAVILA"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "2108",
            "descripcion": "MELGAR",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210801",
                "descripcion": "AYAVIRI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210802",
                "descripcion": "ANTAUTA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210803",
                "descripcion": "CUPI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210804",
                "descripcion": "LLALLI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "210805",
                "descripcion": "MACARI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "210806",
                "descripcion": "NUÑOA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "210807",
                "descripcion": "ORURILLO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "210808",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "210809",
                "descripcion": "UMACHIRI"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "2109",
            "descripcion": "MOHO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "210901",
                "descripcion": "MOHO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "210902",
                "descripcion": "CONIMA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "210903",
                "descripcion": "HUAYRAPATA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "210904",
                "descripcion": "TILALI"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "2110",
            "descripcion": "SAN ANTONIO DE PUTINA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "211001",
                "descripcion": "PUTINA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "211002",
                "descripcion": "ANANEA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "211003",
                "descripcion": "PEDRO VILCA APAZA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "211004",
                "descripcion": "QUILCAPUNCU"
              },
              {
                "posicion": 4,
                "cod_Locacion": "211005",
                "descripcion": "SINA"
              }
            ]
          },
          {
            "posicion": 10,
            "cod_Locacion": "2111",
            "descripcion": "SAN ROMAN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "211101",
                "descripcion": "JULIACA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "211102",
                "descripcion": "CABANA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "211103",
                "descripcion": "CABANILLAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "211104",
                "descripcion": "CARACOTO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "211105",
                "descripcion": "SAN MIGUEL"
              }
            ]
          },
          {
            "posicion": 11,
            "cod_Locacion": "2112",
            "descripcion": "SANDIA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "211201",
                "descripcion": "SANDIA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "211202",
                "descripcion": "CUYOCUYO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "211203",
                "descripcion": "LIMBANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "211204",
                "descripcion": "PATAMBUCO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "211205",
                "descripcion": "PHARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "211206",
                "descripcion": "QUIACA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "211207",
                "descripcion": "SAN JUAN DEL ORO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "211208",
                "descripcion": "YANAHUAYA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "211209",
                "descripcion": "ALTO INAMBARI"
              },
              {
                "posicion": 9,
                "cod_Locacion": "211210",
                "descripcion": "SAN PEDRO DE PUTINA PUNCO"
              }
            ]
          },
          {
            "posicion": 12,
            "cod_Locacion": "2113",
            "descripcion": "YUNGUYO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "211301",
                "descripcion": "YUNGUYO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "211302",
                "descripcion": "ANAPIA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "211303",
                "descripcion": "COPANI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "211304",
                "descripcion": "CUTURAPI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "211305",
                "descripcion": "OLLARAYA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "211306",
                "descripcion": "TINICACHI"
              },
              {
                "posicion": 6,
                "cod_Locacion": "211307",
                "descripcion": "UNICACHI"
              }
            ]
          }
        ]
      },
      {
        "posicion": 21,
        "cod_Locacion": "22",
        "descripcion": "SAN MARTIN",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2201",
            "descripcion": "MOYOBAMBA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220101",
                "descripcion": "MOYOBAMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220102",
                "descripcion": "CALZADA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220103",
                "descripcion": "HABANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220104",
                "descripcion": "JEPELACIO"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220105",
                "descripcion": "SORITOR"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220106",
                "descripcion": "YANTALO"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2202",
            "descripcion": "BELLAVISTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220201",
                "descripcion": "BELLAVISTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220202",
                "descripcion": "ALTO BIAVO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220203",
                "descripcion": "BAJO BIAVO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220204",
                "descripcion": "HUALLAGA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220205",
                "descripcion": "SAN PABLO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220206",
                "descripcion": "SAN RAFAEL"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2203",
            "descripcion": "EL DORADO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220301",
                "descripcion": "SAN JOSE DE SISA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220302",
                "descripcion": "AGUA BLANCA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220303",
                "descripcion": "SAN MARTIN"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220304",
                "descripcion": "SANTA ROSA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220305",
                "descripcion": "SHATOJA"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "2204",
            "descripcion": "HUALLAGA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220401",
                "descripcion": "SAPOSOA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220402",
                "descripcion": "ALTO SAPOSOA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220403",
                "descripcion": "EL ESLABON"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220404",
                "descripcion": "PISCOYACU"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220405",
                "descripcion": "SACANCHE"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220406",
                "descripcion": "TINGO DE SAPOSOA"
              }
            ]
          },
          {
            "posicion": 4,
            "cod_Locacion": "2205",
            "descripcion": "LAMAS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220501",
                "descripcion": "LAMAS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220502",
                "descripcion": "ALONSO DE ALVARADO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220503",
                "descripcion": "BARRANQUITA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220504",
                "descripcion": "CAYNARACHI"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220505",
                "descripcion": "CUÑUMBUQUI"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220506",
                "descripcion": "PINTO RECODO"
              },
              {
                "posicion": 6,
                "cod_Locacion": "220507",
                "descripcion": "RUMISAPA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "220508",
                "descripcion": "SAN ROQUE DE CUMBAZA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "220509",
                "descripcion": "SHANAO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "220510",
                "descripcion": "TABALOSOS"
              },
              {
                "posicion": 10,
                "cod_Locacion": "220511",
                "descripcion": "ZAPATERO"
              }
            ]
          },
          {
            "posicion": 5,
            "cod_Locacion": "2206",
            "descripcion": "MARISCAL CACERES",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220601",
                "descripcion": "JUANJUI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220602",
                "descripcion": "CAMPANILLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220603",
                "descripcion": "HUICUNGO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220604",
                "descripcion": "PACHIZA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220605",
                "descripcion": "PAJARILLO"
              }
            ]
          },
          {
            "posicion": 6,
            "cod_Locacion": "2207",
            "descripcion": "PICOTA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220701",
                "descripcion": "PICOTA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220702",
                "descripcion": "BUENOS AIRES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220703",
                "descripcion": "CASPISAPA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220704",
                "descripcion": "PILLUANA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220705",
                "descripcion": "PUCACACA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220706",
                "descripcion": "SAN CRISTOBAL"
              },
              {
                "posicion": 6,
                "cod_Locacion": "220707",
                "descripcion": "SAN HILARION"
              },
              {
                "posicion": 7,
                "cod_Locacion": "220708",
                "descripcion": "SHAMBOYACU"
              },
              {
                "posicion": 8,
                "cod_Locacion": "220709",
                "descripcion": "TINGO DE PONASA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "220710",
                "descripcion": "TRES UNIDOS"
              }
            ]
          },
          {
            "posicion": 7,
            "cod_Locacion": "2208",
            "descripcion": "RIOJA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220801",
                "descripcion": "RIOJA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220802",
                "descripcion": "AWAJUN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220803",
                "descripcion": "ELIAS SOPLIN VARGAS"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220804",
                "descripcion": "NUEVA CAJAMARCA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220805",
                "descripcion": "PARDO MIGUEL"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220806",
                "descripcion": "POSIC"
              },
              {
                "posicion": 6,
                "cod_Locacion": "220807",
                "descripcion": "SAN FERNANDO"
              },
              {
                "posicion": 7,
                "cod_Locacion": "220808",
                "descripcion": "YORONGOS"
              },
              {
                "posicion": 8,
                "cod_Locacion": "220809",
                "descripcion": "YURACYACU"
              }
            ]
          },
          {
            "posicion": 8,
            "cod_Locacion": "2209",
            "descripcion": "SAN MARTIN",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "220901",
                "descripcion": "TARAPOTO"
              },
              {
                "posicion": 1,
                "cod_Locacion": "220902",
                "descripcion": "ALBERTO LEVEAU"
              },
              {
                "posicion": 2,
                "cod_Locacion": "220903",
                "descripcion": "CACATACHI"
              },
              {
                "posicion": 3,
                "cod_Locacion": "220904",
                "descripcion": "CHAZUTA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "220905",
                "descripcion": "CHIPURANA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "220906",
                "descripcion": "EL PORVENIR"
              },
              {
                "posicion": 6,
                "cod_Locacion": "220907",
                "descripcion": "HUIMBAYOC"
              },
              {
                "posicion": 7,
                "cod_Locacion": "220908",
                "descripcion": "JUAN GUERRA"
              },
              {
                "posicion": 8,
                "cod_Locacion": "220909",
                "descripcion": "LA BANDA DE SHILCAYO"
              },
              {
                "posicion": 9,
                "cod_Locacion": "220910",
                "descripcion": "MORALES"
              },
              {
                "posicion": 10,
                "cod_Locacion": "220911",
                "descripcion": "PAPAPLAYA"
              },
              {
                "posicion": 11,
                "cod_Locacion": "220912",
                "descripcion": "SAN ANTONIO"
              },
              {
                "posicion": 12,
                "cod_Locacion": "220913",
                "descripcion": "SAUCE"
              },
              {
                "posicion": 13,
                "cod_Locacion": "220914",
                "descripcion": "SHAPAJA"
              }
            ]
          },
          {
            "posicion": 9,
            "cod_Locacion": "2210",
            "descripcion": "TOCACHE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "221001",
                "descripcion": "TOCACHE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "221002",
                "descripcion": "NUEVO PROGRESO"
              },
              {
                "posicion": 2,
                "cod_Locacion": "221003",
                "descripcion": "POLVORA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "221004",
                "descripcion": "SHUNTE"
              },
              {
                "posicion": 4,
                "cod_Locacion": "221005",
                "descripcion": "UCHIZA"
              }
            ]
          }
        ]
      },
      {
        "posicion": 22,
        "cod_Locacion": "23",
        "descripcion": "TACNA",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2301",
            "descripcion": "TACNA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "230101",
                "descripcion": "TACNA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "230102",
                "descripcion": "ALTO DE LA ALIANZA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "230103",
                "descripcion": "CALANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "230104",
                "descripcion": "CIUDAD NUEVA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "230105",
                "descripcion": "INCLAN"
              },
              {
                "posicion": 5,
                "cod_Locacion": "230106",
                "descripcion": "PACHIA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "230107",
                "descripcion": "PALCA"
              },
              {
                "posicion": 7,
                "cod_Locacion": "230108",
                "descripcion": "POCOLLAY"
              },
              {
                "posicion": 8,
                "cod_Locacion": "230109",
                "descripcion": "SAMA"
              },
              {
                "posicion": 9,
                "cod_Locacion": "230110",
                "descripcion": "CORONEL GREGORIO ALBARRACIN LANCHIPA"
              },
              {
                "posicion": 10,
                "cod_Locacion": "230111",
                "descripcion": "LA YARADA LOS PALOS"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2302",
            "descripcion": "CANDARAVE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "230201",
                "descripcion": "CANDARAVE"
              },
              {
                "posicion": 1,
                "cod_Locacion": "230202",
                "descripcion": "CAIRANI"
              },
              {
                "posicion": 2,
                "cod_Locacion": "230203",
                "descripcion": "CAMILACA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "230204",
                "descripcion": "CURIBAYA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "230205",
                "descripcion": "HUANUARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "230206",
                "descripcion": "QUILAHUANI"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2303",
            "descripcion": "JORGE BASADRE",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "230301",
                "descripcion": "LOCUMBA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "230302",
                "descripcion": "ILABAYA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "230303",
                "descripcion": "ITE"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "2304",
            "descripcion": "TARATA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "230401",
                "descripcion": "TARATA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "230402",
                "descripcion": "HEROES ALBARRACIN"
              },
              {
                "posicion": 2,
                "cod_Locacion": "230403",
                "descripcion": "ESTIQUE"
              },
              {
                "posicion": 3,
                "cod_Locacion": "230404",
                "descripcion": "ESTIQUE-PAMPA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "230405",
                "descripcion": "SITAJARA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "230406",
                "descripcion": "SUSAPAYA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "230407",
                "descripcion": "TARUCACHI"
              },
              {
                "posicion": 7,
                "cod_Locacion": "230408",
                "descripcion": "TICACO"
              }
            ]
          }
        ]
      },
      {
        "posicion": 23,
        "cod_Locacion": "24",
        "descripcion": "TUMBES",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2401",
            "descripcion": "TUMBES",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "240101",
                "descripcion": "TUMBES"
              },
              {
                "posicion": 1,
                "cod_Locacion": "240102",
                "descripcion": "CORRALES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "240103",
                "descripcion": "LA CRUZ"
              },
              {
                "posicion": 3,
                "cod_Locacion": "240104",
                "descripcion": "PAMPAS DE HOSPITAL"
              },
              {
                "posicion": 4,
                "cod_Locacion": "240105",
                "descripcion": "SAN JACINTO"
              },
              {
                "posicion": 5,
                "cod_Locacion": "240106",
                "descripcion": "SAN JUAN DE LA VIRGEN"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2402",
            "descripcion": "CONTRALMIRANTE VILLAR",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "240201",
                "descripcion": "ZORRITOS"
              },
              {
                "posicion": 1,
                "cod_Locacion": "240202",
                "descripcion": "CASITAS"
              },
              {
                "posicion": 2,
                "cod_Locacion": "240203",
                "descripcion": "CANOAS DE PUNTA SAL"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2403",
            "descripcion": "ZARUMILLA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "240301",
                "descripcion": "ZARUMILLA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "240302",
                "descripcion": "AGUAS VERDES"
              },
              {
                "posicion": 2,
                "cod_Locacion": "240303",
                "descripcion": "MATAPALO"
              },
              {
                "posicion": 3,
                "cod_Locacion": "240304",
                "descripcion": "PAPAYAL"
              }
            ]
          }
        ]
      },
      {
        "posicion": 24,
        "cod_Locacion": "25",
        "descripcion": "UCAYALI",
        "lstUbigeo": [
          {
            "posicion": 0,
            "cod_Locacion": "2501",
            "descripcion": "CORONEL PORTILLO",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "250101",
                "descripcion": "CALLERIA"
              },
              {
                "posicion": 1,
                "cod_Locacion": "250102",
                "descripcion": "CAMPOVERDE"
              },
              {
                "posicion": 2,
                "cod_Locacion": "250103",
                "descripcion": "IPARIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "250104",
                "descripcion": "MASISEA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "250105",
                "descripcion": "YARINACOCHA"
              },
              {
                "posicion": 5,
                "cod_Locacion": "250106",
                "descripcion": "NUEVA REQUENA"
              },
              {
                "posicion": 6,
                "cod_Locacion": "250107",
                "descripcion": "MANANTAY"
              }
            ]
          },
          {
            "posicion": 1,
            "cod_Locacion": "2502",
            "descripcion": "ATALAYA",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "250201",
                "descripcion": "RAYMONDI"
              },
              {
                "posicion": 1,
                "cod_Locacion": "250202",
                "descripcion": "SEPAHUA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "250203",
                "descripcion": "TAHUANIA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "250204",
                "descripcion": "YURUA"
              }
            ]
          },
          {
            "posicion": 2,
            "cod_Locacion": "2503",
            "descripcion": "PADRE ABAD",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "250301",
                "descripcion": "PADRE ABAD"
              },
              {
                "posicion": 1,
                "cod_Locacion": "250302",
                "descripcion": "IRAZOLA"
              },
              {
                "posicion": 2,
                "cod_Locacion": "250303",
                "descripcion": "CURIMANA"
              },
              {
                "posicion": 3,
                "cod_Locacion": "250304",
                "descripcion": "NESHUYA"
              },
              {
                "posicion": 4,
                "cod_Locacion": "250305",
                "descripcion": "ALEXANDER VON HUMBOLDT"
              }
            ]
          },
          {
            "posicion": 3,
            "cod_Locacion": "2504",
            "descripcion": "PURUS",
            "lstUbigeo": [
              {
                "posicion": 0,
                "cod_Locacion": "250401",
                "descripcion": "PURUS"
              }
            ]
          }
        ]
      }
    ]
    return ubigeo;
  }
  public static get UBIGEOPORDEFECTO():any{
    let ubigeoServicio={
      departamento:"15",
      provincia:"1501",
      distrito:"150101"
    }
    return ubigeoServicio;
  }
  public static get PUBLICKEY():string{
    let key:string=
    // `
    //   -----BEGIN PUBLIC KEY-----
    //   MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCn5+fUqBtvkFkUlkhwGLOh3jhW
    //   en0fTtb4HHdv9kd/RsBZ1BIZZbiPUmb4vQ6KKA0k3LQJCFqPIQyT/RGnVXg8BlN1
    //   et1+bxNvxEQY1lYM6sfNFlzE1jWoUuv6A0cDwP0u2EBSaj6k9yLq01UVfcfmB2lV
    //   L0bSKFggN12hiFPQGQIDAQAB
    //   -----END PUBLIC KEY-----
    // `;

    //Integracion
    `
      -----BEGIN PUBLIC KEY-----
      MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCOIznPwZ8qBBz+lKeG1IUwz3f5
      YqJZ5YPmI3W7+1Ktwu8fOWCsAvjupGmOb1WcSgFL51qHU5a3igvm12A++YgeZ5E8
      VVTOJmiqUVobijwdI5aT0DPtfh8JIOWv4q2IFEYYGiZliowpLGz58iE9ykaaRsox
      Kp4oE6mgF7mcAiedWQIDAQAB
      -----END PUBLIC KEY-----
    `;
    return key;
  }
  public static get IDENTIFIERCOMERCE():string{
    let identificador:string='8461'; //Produccion'8926'; Integracion:8461
    return identificador;
  }
  public static get IGV():any{
    const IGV=0.18;
    return IGV;
  }

  // FrontEnd
  public static get pattern():any{
    let pattern:any={
      // password:'(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$'
      // email:/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
      email: /^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$/,
      password: /^(?=.*\d)(?=.*[\u0021-\u002F\u003a-\u0040\u005B-\u0060\u007B-\u007E\u00BF\u00A1])(?=.*[A-Z])(?=.*[a-z])\S{8,20}$/,
      alphanumeric:/^([A-Za-z0-9])+$/
      //  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&#?_*+.])[A-Za-z\d$@$!%*?&#?_*+.]{8,20}$/
    }
    return pattern
  }
  public static get colores():any{
    let colores:any={
      facturas:"#062a78", //azul
      boletas:"#2ECC71", //verde
      nc:"#F44437", //rojo
      nd:"#9B59B6", //morado
      gre:"#F5802D",
      dae:"#9DC1E0",
      cr:"#8080C0",
      cp:"brown",
      rc:"gray",
      cb:"yellow",
      rv:"orange"
    }
    return colores;
  }

  public static get coloresCpes(): any {
    let coloresCpes:any=[
      {
        name: "Factura",
        value: this.colores.facturas
      },
      {
        name: "Boleta",
        value: this.colores.boletas
      },
      {
        name: "Nota de Crédito",
        value: this.colores.nc
      },
      {
        name: "Nota de Débito",
        value: this.colores.nd
      },
      {
        name: "Guía de Remisión",
        value: this.colores.gre
      },
      {
        name: "Servicios Públicos",
        value: this.colores.dae
      },
      {
        name: "Retención",
        value: this.colores.cr
      },
      {
        name: "Percepción",
        value: this.colores.cp
      },
      {
        name: "Resumen Diario de Boletas",
        value: this.colores.rc
      },
      {
        name: "Comunicado de Bajas",
        value: this.colores.cb
      },
      {
        name: "Reversión",
        value: this.colores.rv
      }
    ];
    return coloresCpes;
  }




  // Metodos Ubigeos
  public static getNombreDepartamento(ubigeo) {
      let dept = ubigeo.substring(0, 2);
      let lsDepartamentos = this.UBIGEO;
      return this.getDescripcionUbigeo(lsDepartamentos,dept);
  }
  public static getNombreProvincia(ubigeo) {
      let dept = ubigeo.substring(0, 2);
      let prov = ubigeo.substring(0, 4);
      let lsProvincias = this.getListaProvincia(dept);
      return this.getDescripcionUbigeo(lsProvincias,prov);
  }
  public static getNombreDistrito(ubigeo) {
      let prov = ubigeo.substring(0, 4);
      let lsDistritos = this.getListaDistritos(prov);
      return this.getDescripcionUbigeo(lsDistritos,ubigeo);
  }
  public static getDescripcionUbigeo(lista,codigo) {
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].cod_Locacion == codigo) {
          return lista[i].descripcion;
      }
    }
  }
  public static getListaProvincia(ubigeoDepartamento) {
      let lsDepartamentos = this.UBIGEO;
      for (var i = 0; i < lsDepartamentos.length; i++) {
        if (lsDepartamentos[i].cod_Locacion == ubigeoDepartamento) {
            return lsDepartamentos[i].lstUbigeo;
        }
      }
  }
  public static getListaDistritos(ubigeoProvincia) {
      let dept = ubigeoProvincia.substring(0, 2);
      let lsProvincias = this.getListaProvincia(dept);
      for (var i = 0; i < lsProvincias.length; i++) {
        if (lsProvincias[i].cod_Locacion == ubigeoProvincia) {
            return lsProvincias[i].lstUbigeo;
        }
      }
  }

}
