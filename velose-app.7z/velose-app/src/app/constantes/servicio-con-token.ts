export class ServicioSinToken {
    public static get listadoServicioSinToken(): any[] {
        let listado=[
            ".*?\u002Fauth\u002F.*",
            ".*?\u002Fuser\u002F.*",
            ".*?\u002Fredirect\u002F.*",
            ".*?\u002Fpago\u002Fhash.*",
            ".*?\u002Fpago\u002FrespuestaAligned.*",
            ".*?\u002Fpago\u002Fplanes.*",
            ".*?\u002Fpago\u002Fplanes\u002FlistaCondiciones.*",
            ".*?\u002Fpago\u002FactivoRenovacion.*",
            ".*?\u002Fpago\u002FopcionPlan.*",
            ".*?\u002Fpse\u002FobtenerEmpresa.*", //servicio para obtener los datos de una empresa TCI que ya exista
            ".*?\u002Fpse\u002Fpadron.*",  //servicio para obtener los datos de una empresa TCI que ya exista
        ]
        return listado;
      };
}
