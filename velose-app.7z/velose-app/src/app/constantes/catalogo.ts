export class Catalogo {

  public static get TIPOEMISOR(){
    // No cambiar de orden
    enum tipoEmisor{
      emisorNuevo,
      emisorOtroPse,
      emisorTCI
    }
    return tipoEmisor;
  }
  public static get ICONORESPUESTA() {
    let iconoRespuesta = {
      aceptado: {
        icono: "check_circle",
        color: "color-velose"
      },
      rechazado: {
        icono: "info_outline",
        color: "color-warn"
      },
      advertencia: {
        icono: "info_outline",
        color: "color-ambar"
      }
    };
    return iconoRespuesta
  }
  public static get CPES(): Cpe[]{
    // No cambiar el orden
    let cpes:Cpe[]=[
      {
        nombre:"Factura",
        codigo:"01",
        nomenclatura:"F",
        esResumen:false
      },
      {
        nombre:"Boleta de venta",
        codigo:"03",
        nomenclatura:"B",
        esResumen:false
      },
      {
        nombre:"Nota de crédito",
        codigo:"07",
        nomenclatura:"NC",
        esResumen:false
      },
      {
        nombre:"Nota de débito",
        codigo:"08",
        nomenclatura:"ND",
        esResumen:false
      },
      {
        nombre:"Guía de remisión remitente",
        codigo:"09",
        nomenclatura:"T",
        esResumen:false
      },
      {
        nombre:"Comprobante de retención",
        codigo:"20",
        nomenclatura:"R",
        esResumen:false
      },
      {
        nombre:"Comprobante de percepción",
        codigo:"40",
        nomenclatura:"P",
        esResumen:false
      },
      {
        nombre:"Resumen diario Boletas",
        codigo:"RC",
        nomenclatura:"RC",
        esResumen:true
      },
      {
        nombre:"Comunicado de baja",
        codigo:"RA",
        nomenclatura:"RA",
        esResumen:true
      },
      {
        nombre:"Reversión",
        codigo:"RR",
        nomenclatura:"RR",
        esResumen:true
      }
    ]
    return cpes;
  }
  public static get MONEDAS(): Moneda[]{
    // No cambiar el orden
    let cpes:Moneda[]=[
      {
        codMoneda:"PEN",
        descripcion:"Soles",
        codigo:"604",
        simbolo:"S/"
      },
      {
        codMoneda:"USD",
        descripcion:"Dólares",
        codigo:"840",
        simbolo:"$"
      },
      {
        codMoneda:"EUR",
        descripcion:"Euro",
        codigo:"978",
        simbolo:"€"
      },
    ]
    return cpes;
  }
  public static get ESTADOSRESPUESTA():EstadoRpta[]{
    // No cambiar el orden
    let estados=[
      {
        codEstado:-1,
        descripcion:"Excepción",
      },
      {
        codEstado:0,
        descripcion:"Sin Procesar",
      },
      {
        codEstado:1,
        descripcion:"Válido",
      },
      {
        codEstado:2,
        descripcion:"Aceptado",
      }
    ]
    return estados;
  }
}

// Interfaces
export interface Cpe {
  nombre:string,
  codigo:string,
  nomenclatura:string,
  esResumen:boolean
}
export interface Moneda {
  codMoneda:string,
  descripcion:string,
  codigo:string
  simbolo:string
}
export interface EstadoRpta {
  codEstado:number,
  descripcion:string,
}

export interface Roles{
  codigo:number,
  nombre:string,
  descripcion:string,
}