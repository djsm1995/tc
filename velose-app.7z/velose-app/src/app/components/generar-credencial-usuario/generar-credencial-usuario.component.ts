import { Component, OnInit, ElementRef, ViewChild, isDevMode } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ReCaptcha2Component } from 'ngx-captcha';
import { environment } from '../../../environments/environment';
import { ReusableService } from '../../services/reusable.service';
import { Constante } from '../../constantes/constante';
import { MatDialog } from '@angular/material/dialog';
import { SharedDialogConfirmacionComponent, IDatosDialogConfirmacion, CDatosDialogConfirmacion } from '../shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';
import { SnackBarConfigurationSharedComponent } from '../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { GenerarCredencialUsuarioService } from '../../services/generar-credencial-usuario.service';
import { ErroresMensajes } from '../shared/validaciones';
@Component({
  selector: 'app-generar-credencial-usuario',
  templateUrl: './generar-credencial-usuario.component.html',
  styleUrls: ['./generar-credencial-usuario.component.css']
})
// @Injectable()
export class GenerarCredencialUsuarioComponent implements OnInit {

  public readonly siteKey = environment.apikeyGoogleRecaptcha;
  public captchaIsLoaded = false;
  public captchaSuccess = false;
  public captchaIsExpired = false;
  public captchaResponse?: string;

  public theme: 'light' | 'dark' = 'light';
  public size: 'compact' | 'normal' = 'normal';
  public lang = 'en';
  public type: 'image' | 'audio';
  public useGlobalDomain: boolean = false;

  
  usuarioFormGroup:FormGroup;
  token : string;
  errorMensaje : boolean;
  procesado: boolean;
  mostrarFormulario: boolean;
  // pendiente:boolean;
  enProcesoMatSpinner: boolean;
  matSpinnerFormulario:boolean;
  mensaje : string;
  idAuth: string;

  constructor(private _httpClient:HttpClient,
              private _reusableService:ReusableService,
              private _activatedRoute: ActivatedRoute,
              private  dialog: MatDialog,
              private router: Router,
              private _snackBarClassShared:SnackBarConfigurationSharedComponent,
              private _generarCredencialUsuarioService : GenerarCredencialUsuarioService,
              ) {
              //this.procesado = false;
              // this.pendiente = false;
              this.enProcesoMatSpinner=false;
              this.mostrarFormulario = false;
              this.matSpinnerFormulario=true;
                }

  @ViewChild('captchaElem',{static: false}) captchaElem: ReCaptcha2Component;
  @ViewChild('langInput',{static: false}) langInput: ElementRef;


  ngOnInit() {
      this.idAuth = null;
      this._activatedRoute.paramMap.subscribe(params => {
      this.token = params.get('token');
      this.errorMensaje=false;  
      this.mostrarForm();
    });

    this.usuarioFormGroup= new FormGroup({
      recaptcha : new FormControl(null),
      'passUsuarioFormControl':new FormControl('',[
                                                    Validators.required,
                                                    Validators.minLength(8),
                                                    this.validacionPassIguales.bind(this),
                                                    Validators.pattern(Constante.pattern.password)
                                                  ]),
      'confirmarPassUsuarioFormControl':new FormControl('',[
                                                    Validators.required,
                                                    Validators.minLength(8),
                                                    this.validacionPassIguales.bind(this),
                                                    Validators.pattern(Constante.pattern.password)
                                                    ]),
          });
  }

  validacionPassIguales(control:FormControl):{[s:string]:boolean}{
    if(this.usuarioFormGroup &&
      control.value!=this.usuarioFormGroup.controls['passUsuarioFormControl'].value)
      return{ passIguales:true}
    return null;
  }

  borrarPassConfirmacion(){
    this.usuarioFormGroup.controls['confirmarPassUsuarioFormControl'].setValue('');
  }
  // mensajeErrorNuevaPass(codNuevaClave:number){
  //   let nuevaPass = this.usuarioFormGroup.controls;
  //   switch (codNuevaClave) {
  //     case 1:
  //       nuevaPass = nuevaPass["nuevaPassUsuarioFormControl"].errors;
  //       break;
  //     case 2:
  //       nuevaPass = nuevaPass["confirmarNuevaPassUsuarioFormControl"].errors;
  //       break;

  //     default:
  //       break;
  //   }
  //   return nuevaPass == null
  //     ? null
  //     : ErroresMensajes.ERRORMESSAGENUEVAPASS(nuevaPass);
  // }
    // CAMBIAR CLAVE
    generarClave() {
    let dataInterfaz : IDatosDialogConfirmacion = new CDatosDialogConfirmacion();
    dataInterfaz.mensaje = `¿Está seguro de asociar esta clave a su usuario? `; 
    dataInterfaz.textoBotonCancelar = "No, todavía";
    dataInterfaz.textoBotonAceptar= "Si, estoy seguro";
    let dialogRef = this.dialog.open(SharedDialogConfirmacionComponent, {
      width: "400px",
      maxHeight: "80vh",
      data: dataInterfaz
    });
    dialogRef.afterClosed().subscribe(result =>{
      if(result){
        this.enProcesoMatSpinner=true;
        this.usuarioFormGroup.controls['recaptcha'].setValue(null);

        this._generarCredencialUsuarioService.generarCredencial(this.idAuth, this.usuarioFormGroup.controls['passUsuarioFormControl'].value)
        .subscribe((response: any) => {
          if (response && response.estado) {
            this.router.navigate(['/login']);
            this._snackBarClassShared.openSnackBar(
             "¡Felicidades! Su clave fue generada exitosamente, ahora puede ingresar al portal VelOSE.",
             9000,
             "OK"
            );
            this.reload();
            this.mensaje = 'Esta pagina ya no se encuentra disponible';
            this.mostrarFormulario = false;
            this.procesado = true;
            this.errorMensaje=false;
          }else{
            this.errorMensaje=true;
            this.usuarioFormGroup.controls['passUsuarioFormControl'].setValue("");
            this.usuarioFormGroup.controls['confirmarPassUsuarioFormControl'].setValue("");
            this.reload();
            this.mostrarFormulario = false;
          }
          this.enProcesoMatSpinner=false;
        });
      }
    });
  }
    
    mostrarForm() {
     return this._httpClient.post(`${environment.endpointVelose}/auth/crearClave/verificar`, {
         "token": this.token,
         //"token": "MmFkM2MzYjgtNzFmMy00NmFiLTkyNmYtZWNlODUwMTg2YzY4",
      })
      .subscribe(response=>{
            if ( response['estado'] === false ) {
              this.mensaje = 'Esta pagina ya no se encuentra disponible';
              this.procesado = true;
              this.matSpinnerFormulario = false;
            }else{
              this.mostrarFormulario = true;
              this.matSpinnerFormulario = false;
            }
            
            this.idAuth = response['idAuthUsuario'];
            // this.mensaje = response['mensaje'];
        },
        error => {
          this.procesado = true;
          this.matSpinnerFormulario = false;
          this.mensaje = "Ocurrió un inconveniente mientras se realizaba la transacción, verifique los datos enviados a su correo.";
        });
    }
//Metodos Captcha
    // /*TEMPORAL*/ validarFormularioAndCaptcha(){return false;}

    validarFormularioAndCaptcha(){
      let password = this.usuarioFormGroup.controls["passUsuarioFormControl"];
      let confirmacionPassword = this.usuarioFormGroup.controls["confirmarPassUsuarioFormControl"];
      
      if(password.value == "" || confirmacionPassword.value == "" || this.captchaSuccess == false){
        return true;
      }
      if(this.ocultarCaptcha()){
        return (password.invalid || confirmacionPassword.invalid) ? true : false;
      }
      return (this.usuarioFormGroup.invalid) ? true : false;
    }
    ocultarCaptcha(){
      return Constante.habilitarDeshabilitarCaptcha();
    }
    //Metodos Captcha
    onScriptLoad() {
      console.log('Google reCAPTCHA cargado y está listo para su uso!' )
    }
  
    onScriptError() {
      console.log('Algo se demoró al cargar el reCAPTCHA de Google.')
    }

    //Metodos Captcha
  handleReset(): void {
    this.captchaSuccess = false;
    this.captchaResponse = undefined;
    this.captchaIsExpired = false;
  }

  handleSuccess(captchaResponse: string): void {
    this.captchaSuccess = true;
    this.captchaResponse = captchaResponse;
    this.captchaIsExpired = false;
  }

  handleLoad(): void {
    this.captchaIsLoaded = true;
    this.captchaIsExpired = false;
  }

  handleExpire(): void {
    this.captchaSuccess = false;
    this.captchaIsExpired = true;
  }

  changeTheme(theme: 'light' | 'dark'): void {
    this.theme = theme;
  }

  changeSize(size: 'compact' | 'normal'): void {
    this.size = size;
  }

  changeType(type: 'image' | 'audio'): void {
    this.type = type;
  }

  setLanguage(): void {
    this.lang = this.langInput.nativeElement.value;//this.lang = 'en';
  }
  setUseGlobalDomain(use: boolean): void {
    this.useGlobalDomain = use;
  }

  getCurrentResponse(): void {
    const currentResponse = this.captchaElem.getCurrentResponse();
    if (!currentResponse) {
      alert('No hay una respuesta actual, ¿ha enviado captcha?');
    } else {
      alert(currentResponse);
    }
  }
  getResponse(): void {
    const response = this.captchaElem.getResponse();
    if (!response) {
      alert('No hay respuesta - ¿has enviado captcha?');
    } else {
      alert(response);
    }
  }
  reload(): void {
    this.captchaElem.reloadCaptcha();
  }
  getCaptchaId(): void {
    alert(this.captchaElem.getCaptchaId());
  }
  reset(): void {
    this.captchaElem.resetCaptcha();
  }




}
