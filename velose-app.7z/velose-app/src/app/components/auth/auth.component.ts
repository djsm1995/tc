import { Component, OnInit, ElementRef, ViewChild, isDevMode } from '@angular/core';
import { FormGroup, Validators,FormControl} from '@angular/forms';
import { Router, RouterOutlet } from '@angular/router';
import { Injectable,Inject } from '@angular/core';
import "rxjs/add/operator/takeWhile";
import { AuthService} from '../../services/auth.service';
import { Registro} from '../../services/register.service'; // interface
import { ReusableService } from '../../services/reusable.service';
import { TokenService } from '../../services/token.service';
 import { ROUTES } from "../../app.route";
import { Catalogo } from "../../constantes/catalogo";
import { rucTci } from '../../app.module';
// import { ReCaptcha2Component } from 'ngx-captcha';
import { environment } from '../../../environments/environment';
import { OpcionesMenu } from '../shared/navbar/opciones-menu';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  // public readonly siteKey = environment.apikeyGoogleRecaptcha;
  // public captchaIsLoaded = false;
  // public captchaSuccess = false;
  // public captchaIsExpired = false;
  // public captchaResponse?: string;

  public theme: 'light' | 'dark' = 'light';
  public size: 'compact' | 'normal' = 'normal';
  public lang = 'en';
  public type: 'image' | 'audio';
  public useGlobalDomain: boolean = false;


  isProcessing : boolean;
  public tipoUsuarioLogeado:number=0;
  mensajeLogin:string='';
  rptaLogin:string='';
  loginFormGroup:FormGroup;

  cargandoRedirect:boolean=false;

  constructor(
    private router:Router,
    public _authService: AuthService,
    private _reusable: ReusableService, 
    private tokenS: TokenService,
    @Inject('rucTci') private rucTci: number) {  
    }

  // @ViewChild('captchaElem') captchaElem: ReCaptcha2Component;
  @ViewChild('langInput',{static: false}) langInput: ElementRef;  


  ngOnInit() {
    // RedirectLogin
    // verificar si existe una session activa
    if(this._reusable.getToken()!=null){
      // cargando
      this.cargandoRedirect=true;
      this.tokenS.refreshToken().subscribe((response:any)=>{
        if(response.estado){
          this.tokenS.guardarNuevoToken(response.infoToken)
          this.redireccionamiento(this._reusable.getSessionUsuario())
        }
        this.cargandoRedirect=false;
      })
      
    }

      // Inicializar variables para login
    this.isProcessing = false;
    this.loginFormGroup=new FormGroup({
      // recaptcha : new FormControl(null),
      'correoLoginFormControl':new FormControl('',Validators.compose([
          Validators.required,
          Validators.email
      ])
      ),
      'passLoginFormControl':new FormControl('',[Validators.required]),
    });

  }
  

  logeo(){
    this.isProcessing = true;
    // this.loginFormGroup.controls['recaptcha'].setValue(null);

    let usuarioLogeado;
    if(this.loginFormGroup.valid){
      this._authService.verificarLogin(this.loginFormGroup)
        .subscribe((response: any) =>
          {
            this.isProcessing = false;
            if(response.estado){
              usuarioLogeado=response.detalleUsuario;
              this._reusable.setSessionUsuario(usuarioLogeado)
              this.redireccionamiento(usuarioLogeado)             
            }
            // this.captchaSuccess = false;
            this.validarFormularioAndCaptcha();
            this.rptaLogin=response.mensaje;
          },
          error=>{
            if(error.status == 0){
              this.rptaLogin="El servicio de VELOSE no se encuentra disponible."
              this.isProcessing = false;
            }
          })
    }else{
      this.rptaLogin="Introduce tus credenciales"
      this.isProcessing = false;
    }    
  }

  redireccionamiento(usuarioLogeado){
    //TipoRol = 1 Administrador
    //TipoRol = 0 Operador
    if(usuarioLogeado.tipoRol==2){ //soporte
      this.rutaAuth('soporte.comprobantes','consultaComprobantes')
      return;
    }   
    if (!usuarioLogeado.habilitarPagos || (usuarioLogeado.habilitarPagos && usuarioLogeado.empresa.ambienteActivo)) { 
      //this.rutaAuth("dashboard", "dashboard");
      let tieneRutaDashboard:boolean=false;
      usuarioLogeado.modulos.forEach(rutaUsuario => {
        if(rutaUsuario == "dashboard"){
          tieneRutaDashboard = true;
          this.rutaAuth("dashboard", "dashboard");
        }
      });
      if(!tieneRutaDashboard){
        let rutaUsuario = usuarioLogeado.modulos[0];
        this.router.config[0].children.forEach(element => { 
          if (rutaUsuario == element.data.identificador){
              this.rutaAuth(element.data.identificador, element.path);
            }
       });
      }
    }
    else{
      // Nuevo cliente
      this.rutaAuth("casoNegocio", "casoNegocio");
    }
  }

  verRegistro(){  this.router.navigate(['register']);  }

  rutaAuth(identificador:string,ruta:string) {
    let listaModulos: any[] = this._reusable.getSessionUsuario().modulos;
    if(listaModulos.length==0){
      if(isDevMode()) {console.log("No cuenta con acceso a ningun modulo");}
      this.tokenS.closeSession();
      return;
    }
  
    this.ruteo(identificador,ruta);

    
  }

  ruteo(identificador:string,ruta:string):void{
    let modulos: any[] = this._reusable.getSessionUsuario().modulos;
    
    this.router.navigate([`/home/${ruta}`]);


    // let findModulo = modulos.find((element) => {
    //   return element === identificador;
    // });
    // if (findModulo == undefined) {
    //   let firstModulo = modulos[0];
    //   let modulosHome = ROUTES[0].children.find((element) => {
    //     let modulo1: string = element.data.identificador
    //     let modulo2: string = firstModulo;
    //     return modulo1.toUpperCase() === modulo2.toUpperCase();
    //   });
    //   if(isDevMode()) {console.log(modulosHome);}
    //   this.router.navigate([`/home/${modulosHome.path}`]);
    //   // enviar a la primera ruta encontrada
    // }
    // else {
    //   this.router.navigate([`/home/${ruta}`]);
    // }
  }


  validarFormularioAndCaptcha(){
    let user = this.loginFormGroup.controls["correoLoginFormControl"];
    let password = this.loginFormGroup.controls["passLoginFormControl"];
    
    if(user.value == "" || password.value == "" 
    // || this.captchaSuccess == false
    ){
      return true;
    }

    return (this.loginFormGroup.invalid) ? true : false;
  }

  setCorreoLogin(event){
    this.loginFormGroup.controls['correoLoginFormControl'].setValue(event.target.value)
  }

  setPassLogin(event){
    this.loginFormGroup.controls['passLoginFormControl'].setValue(event.target.value)
  }

     //Metodos Captcha
    //  handleReset(): void {
    //   this.captchaSuccess = false;
    //   this.captchaResponse = undefined;
    //   this.captchaIsExpired = false;
    // }
  
    // handleSuccess(captchaResponse: string): void {
    //   this.captchaSuccess = true;
    //   this.captchaResponse = captchaResponse;
    //   this.captchaIsExpired = false;
    // }
  
    // handleLoad(): void {
    //   this.captchaIsLoaded = true;
    //   this.captchaIsExpired = false;
    // }
  
    // handleExpire(): void {
    //   this.captchaSuccess = false;
    //   this.captchaIsExpired = true;
    // }
  
    // changeTheme(theme: 'light' | 'dark'): void {
    //   this.theme = theme;
    // }
  
    // changeSize(size: 'compact' | 'normal'): void {
    //   this.size = size;
    // }
  
    // changeType(type: 'image' | 'audio'): void {
    //   this.type = type;
    // }
  
    // setLanguage(): void {
    //   this.lang = this.langInput.nativeElement.value;//this.lang = 'en';
    // }
    // setUseGlobalDomain(use: boolean): void {
    //   this.useGlobalDomain = use;
    // }
  
    // getCurrentResponse(): void {
    //   const currentResponse = this.captchaElem.getCurrentResponse();
    //   if (!currentResponse) {
    //     alert('No hay una respuesta actual, ¿ha enviado captcha?');
    //   } else {
    //     alert(currentResponse);
    //   }
    // }
    // getResponse(): void {
    //   const response = this.captchaElem.getResponse();
    //   if (!response) {
    //     alert('No hay respuesta - ¿has enviado captcha?');
    //   } else {
    //     alert(response);
    //   }
    // }
    // reload(): void {
    //   this.captchaElem.reloadCaptcha();
    // }
    // getCaptchaId(): void {
    //   alert(this.captchaElem.getCaptchaId());
    // }
    // reset(): void {
    //   this.captchaElem.resetCaptcha();
    // }

}
