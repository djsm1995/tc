import { Component, OnInit,Inject, isDevMode } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router} from '@angular/router';
import { BuscarPdfService} from '../../../services/buscar-pdf.service';

@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.css']
})
export class PdfViewerComponent implements OnInit {
  formatoPdf:any
  constructor( @Inject(MAT_DIALOG_DATA) public _data: any,
                private _router:Router,
                public _dialogRef: MatDialogRef<PdfViewerComponent>,
                private _buscarPdfService:BuscarPdfService,) {
      let id=_data.caso.idCasoDetalle;
      let version=_data.version

      this._buscarPdfService.buscarPdf(id,version)
          .subscribe((response:any)=>{
            if(isDevMode()) {console.log(response)}
            if(response && response.estado){
              let rpta=response.xml
              var binaryImg = atob(rpta.archivo);
              var length = binaryImg.length;
              var arrayBuffer = new ArrayBuffer(length);
              var uintArray = new Uint8Array(arrayBuffer);
              for (var i = 0; i < length; i++) {
              uintArray[i] = binaryImg.charCodeAt(i);
              }
              var currentBlob = new Blob([uintArray], {type: 'application/pdf'});
              this.formatoPdf = URL.createObjectURL(currentBlob);
              // this.formatoPdf=rpta.archivo
            }
          });


              }

  ngOnInit() {

    //llamar servicio
  }

}
