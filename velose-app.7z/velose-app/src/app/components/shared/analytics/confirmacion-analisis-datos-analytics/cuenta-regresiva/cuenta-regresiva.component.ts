import { Component, OnInit,  Input, Output, EventEmitter, isDevMode } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs/internal/Subscription';// import { Subscription } from 'rxjs';

@Component({
  selector: 'app-cuenta-regresiva',
  templateUrl: './cuenta-regresiva.component.html',
  styleUrls: ['./cuenta-regresiva.component.css']
})
export class CuentaRegresivaComponent implements OnInit {
  @Input ('inputDate') 
    set inputDate(value:Date) {
      this.future= value
      if(isDevMode()) {console.log(this.future)}
    }
  private future: Date;
  private diff: number;
  private $counter: Observable<number>;
  private subscription: Subscription;
  public message: string;
  public message2: string;

  // emitir datos
  @Output() terminoCuentaRegresiva = new EventEmitter()

  constructor() {
  }

  ngOnInit() {
    if(isDevMode()) {console.log(this.future)}
    if(this.future.toString() == "Invalid Date"){
      this.message=""
    }
    else{
      this.$counter = Observable.interval(1000).pipe(
        map((x) => {
          this.diff = Math.floor((this.future.getTime() - new Date().getTime()) / 1000);
          return x;
        })
      )
      
      this.subscription = this.$counter
          .subscribe((x) => {
          this.message = this.dhms(this.diff);
          })
    }
    
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }


  //#region Metodos 

  dhms(t:number):string {
    let days, hours, minutes, seconds;
    let arrayMessage:string[]=[]
    days = Math.floor(t / 86400);//1000*60*60*24
    t -= days * 86400;
    hours = Math.floor(t / 3600) % 24;
    t -= hours * 3600;
    minutes = Math.floor(t / 60) % 60;
    t -= minutes * 60;
    seconds = t % 60;


// mostrar mensaje
    arrayMessage=[
      `${days} días`,
      `${hours} horas`,
      `${minutes} minutos`,
      `${seconds} segundos`
    ]
    if(days<=0){
      arrayMessage.shift();
      if(hours<=0){
        arrayMessage.shift();
        if(minutes<=0){
          arrayMessage.shift();
          if(seconds<=0){
            this.terminoCuentaRegresiva.emit(true);
            this.subscription.unsubscribe();
          }
        }
      }
    }
    
    return arrayMessage.join('  ');
  }

  //#endregion
}
