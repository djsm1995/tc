import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AnalyticsService, dataResponseConfirmacionAnalisisDatosAnalytics } from '../../../../services/analytics.service';
import { ReusableService } from '../../../../services/reusable.service';
@Component({
  selector: 'app-confirmacion-analisis-datos-analytics',
  templateUrl: './confirmacion-analisis-datos-analytics.component.html',
  styleUrls: ['./confirmacion-analisis-datos-analytics.component.css']
})
export class ConfirmacionAnalisisDatosanalyticsComponent implements OnInit {
  
  pasoConfirmacion:boolean=true;
  mostrarDosImagenes:boolean = true;

  // background de confirmacion
  backgroundImageStep={
    stepConfirmacion:"../../../../../assets/img/analytics/confirmacion-fondo7.png",
    stepAnalisis:"../../../../../assets/img/analytics/confirmacion-fondo8.png",
  }
  backgroundImageStepSelected= this.backgroundImageStep.stepConfirmacion

  // variables de visualizacion
  rucUsuario:string;
  fechaAceptacionFutura:Date=null;
  cargandoRedirect:boolean = true;
  verificandoTiempoRestante:boolean =true;
  esAdmin:boolean=false;

  // emitir datos
  @Output() permisoVisualizacionAnalytics = new EventEmitter()

  constructor(
    public _analyticsService:AnalyticsService,
    public _reusableService:ReusableService,
    ) 
  {
      this.rucUsuario = _reusableService.getSessionUsuario().empresa.ruc;
      this.servicioConfirmacionAnalisisDatos(false);
   }

  ngOnInit() {
    this.esAdmin=this._reusableService.esAdministrador(this._reusableService.getSessionUsuario().tipoRol)
  }

  cargarImagenBackgroundAceptacion(){
    return `{'background-image': url('${this.backgroundImageStepSelected}')` 
  }

  confirmarAnalisisDatos(){
    this.servicioConfirmacionAnalisisDatos(true);
    this.pasoConfirmacion=false;
  
    setTimeout(() => {
      this.backgroundImageStepSelected=this.backgroundImageStep.stepAnalisis
    }, 2000);

  }

  servicioConfirmacionAnalisisDatos(estado:boolean){
    this.verificandoTiempoRestante=true;

    this._analyticsService
    .activarModuloAnalytics(estado, this.rucUsuario)
    .subscribe((response: dataResponseConfirmacionAnalisisDatosAnalytics) => {
      if (response && response.estado) {
        if(response.analisisDatos.confirmacion){
          this.mostrarDosImagenes=false;

          if( new Date(response.analisisDatos.fechaAceptacionFutura).getTime() >=  new Date().getTime()){
            this.verificandoTiempoRestante=false;
            this.cargandoRedirect=false;
            this.pasoConfirmacion=false;
            this.fechaAceptacionFutura= new Date(response.analisisDatos.fechaAceptacionFutura);
          
          }else{
            this.permisoVisualizacionAnalytics.emit(true);
            this.cargandoRedirect=false;
          }
        }
        else{
          this.cargandoRedirect=false;
          this.pasoConfirmacion=true;
        }
      }else {
        this.cargandoRedirect=false;
        this.pasoConfirmacion=true;
      }
    });
  }

}
