import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutorial',
  templateUrl: './tutorial.component.html',
  styleUrls: ['./tutorial.component.css']
})
export class TutorialComponent implements OnInit {

  habilitado:boolean;
  pasoFinal:number;
  pasoVisible:number;

  // Tutoriales - obtener de servicios --luego
  msgTutorial: MsgTutorial[];

  constructor() {
    //this.loadMsgTutorial();
    this.pasoVisible = -1;
    this.pasoFinal = -1;
  };

  ngOnInit() {
  };

  habilitarTurorial() {
    this.habilitado = true;
    if ( this.pasoVisible > -1 ) {
      this.mostrarPaso(this.pasoVisible,false);
    }
    this.pasoVisible = 0;
    this.mostrarPaso(0,true);
  };

  mostrarPaso(indexMsg,visible) {
    if ( Object.keys( this.msgTutorial ).length > 0 && indexMsg >= 0 && indexMsg <= this.pasoFinal ) {
      this.msgTutorial[indexMsg].visible = visible;
    }
  };

  siguientePaso() {
    if ( this.pasoVisible == this.pasoFinal ) {
      this.mostrarPaso(this.pasoVisible,false);
      this.pasoVisible = 0;
      this.mostrarPaso(this.pasoVisible,true);
    } else {
      this.mostrarPaso(this.pasoVisible,false);
      this.pasoVisible++;
      this.mostrarPaso(this.pasoVisible,true);
    }
  };

  anteriorPaso() {
    if ( this.pasoVisible == 0 ) {
      this.mostrarPaso(this.pasoVisible,false);
      this.pasoVisible = this.pasoFinal;
      this.mostrarPaso(this.pasoVisible,true);
    } else {
      this.mostrarPaso(this.pasoVisible,false);
      this.pasoVisible--;
      this.mostrarPaso(this.pasoVisible,true);
    }
  };

  siguientePasoByIndex(indexMsg) {
    this.mostrarPaso(this.pasoVisible,false);
    this.pasoVisible = indexMsg - 1;
    if ( this.pasoVisible == this.pasoFinal ) {
      this.pasoVisible = 0;
      this.mostrarPaso(this.pasoVisible,true);
    } else {
      this.mostrarPaso(this.pasoVisible,true);
    }
  };

  saltarTutorial() {
    this.mostrarPaso(this.pasoVisible,false);
    this.pasoVisible = -1;
  };

  pasoEsVisible(indexMsg) : boolean {
    if ( this.pasoFinal > -1 ) {
      return this.msgTutorial[indexMsg - 1].visible;
    } else {
      return false;
    }

  };

  // getMensaje(indexMsg) : MsgTutorial {
  //   return this.msgTutorial[indexMsg];
  // };

  getMensajeVisible() : MsgTutorial {
    if ( this.pasoVisible > -1 ) {
      return this.msgTutorial[this.pasoVisible];
    }
  };

  loadMsgTutorial(data) {
    this.msgTutorial = data;
    this.pasoVisible = -1;
    this.pasoFinal = Object.keys( data ).length - 1;
  };

}


/************************************************
DE HOMOLOGACION SERVICE
************************************************/
  //Tutorial Homologacion
    export interface MsgTutorial {
      paso:number;
      sobre:string;
      tag:string;
      titulo:string;
      btnSalir:string;
      btnAnterior:string;
      btnSiguiente:string;
      descripcion:string;
      visible:boolean;
    };
