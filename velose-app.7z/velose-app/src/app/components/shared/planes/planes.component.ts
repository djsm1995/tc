import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators,FormControl,FormGroupDirective} from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {PlanesService,Planes,planesResponse,listaCondicionesResponse} from '../../../services/planes.service';
import {DialogDatosTarjetaComponent} from '../../register/dialog-datos-tarjeta/dialog-datos-tarjeta.component';
import {MensajeGenericoComponent} from '../mensaje-generico/mensaje-generico.component';
import { Router } from '@angular/router';
import {RegisterService,clientePagoC} from '../../../services/register.service';
import {Registro,EmpresaR,UsuarioR,ClientePago} from '../../../services/register.service';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import {Constante} from '../../../constantes/constante';
import{ReusableService } from '../../../services/reusable.service'

@Component({
  selector: 'app-planes',
  templateUrl: './planes.component.html',
  styleUrls: ['./planes.component.css']
})
export class PlanesComponent implements OnInit {
  className:string="bgMasPopular";

  usuarioFormGroup:FormGroup; empresaFormGroup: FormGroup;
  usuarioLogeado:any;

  mostrarPlanes=false;
  planesPago:Planes[];
  listaCondiciones:string[];

  configSwiper={
    direction: 'horizontal',
    slidesPerView: 1,
    centeredSlides:true,
    initialSlide:0,
    mousewheel: true,
    navigation:false,
    // scrollbar: true,
    pagination: true
  }
  ubigeoSeleccionado={
    departamento:"Lima",
    provincia:"Lima"
  }

  dialogResult:string="";


  constructor(private _planesService:PlanesService,
              public _dialog:MatDialog,
              private router:Router,
              private sReusable:ReusableService) { 
                this.usuarioLogeado= this.sReusable.getSessionUsuario()
               }

  ngOnInit() {
    this.getPlanes(1);
    this.getListaCondiciones();
  }

  // Plan mas popular
  bgMasPopular(index:any){
     let className ="";
     className=(index==this.configSwiper.initialSlide)? this.className: className;
     return className;
   };



  getPlanes(cpesEnviados){
   this.mostrarPlanes=(this.mostrarPlanes)? !this.mostrarPlanes:this.mostrarPlanes;
   this._planesService.getPlanes(cpesEnviados)
         .subscribe((planes:planesResponse)=>{
            this.configSwiper.initialSlide= planes.planRecomendado;
            this.planesPago=planes.planes;
            this.mostrarPlanes=!this.mostrarPlanes;
          });

  }

    // Dialog Pago
    openDialog(plan:any){
          let dialogRef;
          setTimeout(() =>
          dialogRef = this._dialog.open(DialogDatosTarjetaComponent, {
            width: '400px',
            data: { tipoOperacion: 'C', //N: Nuevo Registro, C: Compra de Plan, V: Validaciones
              plan: plan,
              cliente:this.assembleUsuarioLogueado(),
              idPse: this.assembleEmpresaUsuarioLogueado()['idPse']
            }
          })
          , 0);
          setTimeout(()=>
            dialogRef.afterClosed().subscribe(result=>{
              this.dialogResult=result;
            }),0
          )
    }


    assembleUsuarioLogueado(){

        let usuarioLogeado = this.usuarioLogeado;

        let clientePago:ClientePago= new clientePagoC();
        let datosUsuario= usuarioLogeado;
        //let datosEmpresa= usuarioLogeado['empresa'];

        clientePago.nombre= usuarioLogeado['nombre'];
        clientePago.apellidos= usuarioLogeado['apellidoPaterno']+' '+usuarioLogeado['apellidoMaterno'];
        clientePago.correo=usuarioLogeado['correo'];

        clientePago.direccion=usuarioLogeado['empresa']['direccion'];
        clientePago.zip=usuarioLogeado['empresa']['ubigeo'];

        clientePago.ciudad=Constante.getNombreProvincia(usuarioLogeado['empresa']['ubigeo']) ;
        clientePago.estado=Constante.getNombreDepartamento(usuarioLogeado['empresa']['ubigeo']);

        // clientePago.ciudad=usuarioLogeado['empresa']['provincia'];
        // clientePago.estado=usuarioLogeado['empresa']['departamento'];
        clientePago.pais="Perú";
        clientePago.telefono= usuarioLogeado['empresa']['telefono'];

// console.log( "DEPARTAMENTOS: " )
// console.log( Constante.getNombreDepartamento("010203") )
// console.log( Constante.getNombreProvincia("010203") )
// console.log( Constante.getNombreDistrito("010203") )

        return clientePago;
      }

      assembleEmpresaUsuarioLogueado(){
        let usuarioLogeado = this.usuarioLogeado;
        let datosEmpresa= usuarioLogeado['empresa'];
        return datosEmpresa;
      }

      getListaCondiciones(){
        this._planesService.getListaCondiciones()
              .subscribe((condiciones:listaCondicionesResponse)=>{
                 if(condiciones.estado){
                   this.listaCondiciones=condiciones.condiciones;
                 }
               });
       }

}
