import {Component, HostBinding, Input, OnInit,Output,EventEmitter, isDevMode} from '@angular/core';
import {NavItem,Submodulos,MenuPrincipalService} from '../../../services/menu-principal.service';
import {Router} from '@angular/router';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-menu-list-item',
  templateUrl: './menu-list-item.component.html',
  styleUrls: ['./menu-list-item.component.css'],
  animations: [
    trigger('indicatorRotate', [
      state('collapsed', style({transform: 'rotate(0deg)'})),
      state('expanded', style({transform: 'rotate(180deg)'})),
      transition('expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4,0.0,0.2,1)')
      ),
    ])
  ]
})
export class MenuListItemComponent implements OnInit {
  expanded: boolean;
  @HostBinding('attr.aria-expanded') ariaExpanded = this.expanded;
  @Input() item: NavItem;
  @Input() depth: number;
  @Output() sideNav= new EventEmitter();


  constructor(public _menuS: MenuPrincipalService,
              public _router: Router) {
    if (this.depth === undefined) { this.depth = 0;}
  }

  onItemSelected(item: NavItem) {
    if (!item.submodulos || !item.submodulos.length) {
      if (item.pathRedirect == "$#grafana#$") {
        var win = window.open(environment.endpointGrafana, "_blank");
        win.focus();

      }
      else {
        this._router.navigate([item.pathRedirect]);
        this._menuS.closeNav();
      }
    }
    if (item.submodulos && item.submodulos.length) {
      this.expanded = !this.expanded;
    }
  }
  ngOnInit() {
  }

}
