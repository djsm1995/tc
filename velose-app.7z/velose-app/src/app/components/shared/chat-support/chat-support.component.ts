import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-support',
  templateUrl: './chat-support.component.html',
  styleUrls: ['./chat-support.component.css']
})
export class ChatSupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
this.loadScript();
  }

  public loadScript() {

    let script = 'window._chatlio = window._chatlio||[];';
    script = script + '!function(){ var t=document.getElementById("chatlio-widget-embed");if(t&&window.ChatlioReact&&_chatlio.init)return void _chatlio.init(t,ChatlioReact);for(var e=function(t){return function(){_chatlio.push([t].concat(arguments)) }},i=["configure","identify","track","show","hide","isShown","isOnline", "page", "open", "showOrHide"],a=0;a<i.length;a++)_chatlio[i[a]]||(_chatlio[i[a]]=e(i[a]));var n=document.createElement("script"),c=document.getElementsByTagName("script")[0];n.id="chatlio-widget-embed",n.src="https://w.chatlio.com/w.chatlio-widget.js",n.async=!0,n.setAttribute("data-embed-version","2.3");';
    script = script + "n.setAttribute('data-widget-id','f663ec9d-0e08-4272-68b5-03d9869a5bfd');";
    script = script + 'c.parentNode.insertBefore(n,c);';
    script = script + '}();';

    let body = <HTMLDivElement> document.body;
    let tag_script = document.createElement('script');
    tag_script.innerHTML = script; //'';
    tag_script.type="text/javascript";
    tag_script.id="chat";

    body.appendChild(tag_script);
    }

}
