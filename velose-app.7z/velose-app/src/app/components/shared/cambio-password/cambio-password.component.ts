import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cambio-password',
  templateUrl: './cambio-password.component.html',
  styleUrls: ['./cambio-password.component.css']
})
export class CambioPasswordComponent implements OnInit {

  passNueva={
    hide:true,
  };

  passConfirmar={
    hide:true,
  };
  constructor() { }

  ngOnInit() {
  }

  nextStep(){
    
  }

}
