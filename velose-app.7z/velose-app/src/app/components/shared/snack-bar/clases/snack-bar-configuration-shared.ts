import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
// import { snackBarMensajeComponent } from '../../../shared/snack-bar/snack-bar-mensaje.component';

export class SnackBarConfigurationShared {
    // constructor(public snackBarShared: MatSnackBar) { }

    // openSnackBar(texto:string, tiempo:number,textoButton:string) {
    //   const configSuccess: MatSnackBarConfig = {
    //     //panelClass: 'style-success',
    //     duration: tiempo,
    //     horizontalPosition: 'left',
    //     verticalPosition: 'bottom'
    //   };
    //  let respuesta = this.snackBarShared.openFromComponent(snackBarMensajeComponent,{       
    //     data:{
    //       mensaje:texto,
    //       button:textoButton
    //     } ,...configSuccess
    //     });
    // }
}
