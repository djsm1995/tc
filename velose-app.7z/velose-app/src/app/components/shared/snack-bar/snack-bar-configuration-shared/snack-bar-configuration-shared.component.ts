import { Component } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { snackBarMensajeComponent } from '../../../shared/snack-bar/snack-bar-mensaje.component';

@Component({
  selector: 'app-snack-bar-configuration-shared',
  templateUrl: './snack-bar-configuration-shared.component.html',
  styleUrls: ['./snack-bar-configuration-shared.component.css']
})
export class SnackBarConfigurationSharedComponent {

  constructor(public snackBarShared: MatSnackBar) { }

  openSnackBar(texto:string, tiempo:number,textoButton:string, position?) {
    position = position == null ? 'bottom' : position;
    // const configSuccess: MatSnackBarConfig = {
    //   //panelClass: 'style-success',
    //   duration: tiempo,
    //   horizontalPosition: 'center',//left
    //   verticalPosition: 'bottom'
    // };
    //  let respuesta = this.snackBarShared.openFromComponent(snackBarMensajeComponent,{       
    //     data:{
    //       mensaje:texto,
    //       button:textoButton
    //     } ,...configSuccess
    //     });
      this.snackBarShared.open(texto,textoButton,{ duration: tiempo, verticalPosition:position });
      //this.snackBar.open(mensaje, "OK", { duration: 5000,verticalPosition:'bottom' });
  }
}
