import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-externo',
  templateUrl: './navbar-externo.component.html',
  styleUrls: ['./navbar-externo.component.css']
})
export class NavbarExternoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
