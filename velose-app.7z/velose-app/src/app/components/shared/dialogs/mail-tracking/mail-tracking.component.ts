import { Component, OnInit, Inject, isDevMode} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MailForwardComponent } from './mail-forward/mail-forward.component';
import { MailTrackingService } from '../../../../services/mail-tracking.service';
import { Validaciones } from '../../../shared/validaciones';
import { ConfiguracionesGeneralesService } from '../../../../services/configuraciones-generales.service';

@Component({
  selector: 'app-mail-tracking',
  templateUrl: './mail-tracking.component.html',
  styleUrls: ['./mail-tracking.component.css']
})
export class MailTrackingComponent implements OnInit {

  displayedColumns: string[] = ['estado', 'fecha' ];
  listTracks : any = [];
  listEnvios : any = [];
  listReenvios : any = [];

  header : any = [];
  seguimiento: string;
  delivered : number;
  opened : number;
  processed : string;

  displayedColumnsHeader: string[] = ['key', 'value' ];

  // viewFormReenvio : boolean = false;

  correoNuevoFormControl : FormControl;
  mostrarPara:boolean =false;

  /*nuevo view*/
  solicitud : any;
  id_solicitud : string;

  isLoadingViewNotification : boolean;
  // isLoadingReenvio : boolean;
  isResponseError : boolean;
  isResponseErrorMessage : string;
  isReenvioActivo : boolean;

  constructor(
          private dialog: MatDialog,
          public _configuracionesGeneralesService: ConfiguracionesGeneralesService,
          private snackBar: MatSnackBar, private service: MailTrackingService, fb: FormBuilder,
          @Inject(MAT_DIALOG_DATA) public data: any) {
    this.id_solicitud = data.id_solicitud;
    // this.viewFormReenvio = false;
  }

  // #region metodos
  inicializarForm() {
    this.correoNuevoFormControl = new FormControl('',
        [Validators.email, Validaciones.NULL_O_VACIO]
        );
  }

  ngOnInit() {
    // this.isLoadingReenvio = false;
    this.isResponseError = false;
    this.isReenvioActivo = false;
    this.inicializarForm();
    this.habilitaReenvio();
    this.visualizationTrack(this.id_solicitud);
  }

  habilitaReenvio() {
    this._configuracionesGeneralesService.getDatosExcepcion()
    .subscribe((response: any) => {
      if (response.estado == true){
        this.isReenvioActivo =  response.datosNotificacionExcepcion.estadoReenvio;
      }
    });
  }

  // getReenvio(pos) {
  //   return this.listReenvios[pos];
  // }

  visualizationTrack(id_solicitud) {
    if ( id_solicitud == null || typeof id_solicitud === "undefined" ) {
      this.isResponseError = true;
      this.isResponseErrorMessage = "El codigo de notificación es invalido.";
    } else {
          this.isLoadingViewNotification = true;
          let messageResponse = this.service
                .retriveTrackingNotification(id_solicitud)
                .subscribe(response => {
                  if ( response.estado ) {
                    if ( response.lista.length > 0 )  {
                      if(isDevMode()){
                        console.log(this.service.view)
                        console.log(response)
                      }
                        
                      this.solicitud = this.service.convertToView(response["lista"]);
                      this.listEnvios = this.service.view.listEnvios;
                      this.listReenvios = this.service.view.listReenvios;
                      this.header = this.service.view.header;
                      this.seguimiento = this.service.view.seguimiento;
                      this.isLoadingViewNotification = false;
                    } else {
                      this.isLoadingViewNotification = false;
                      this.isResponseError = true;
                      this.isResponseErrorMessage = response.mensaje;
                    }
                  } else {
                    this.isLoadingViewNotification = false;
                    this.isResponseError = true;
                    this.isResponseErrorMessage = response.mensaje;
                  }
                });
        if ( messageResponse.error ) {
          this.isResponseError = true;
          this.isResponseErrorMessage = messageResponse.mensaje;
        }
    }

  }

  forwardNotification() {
    this.service
      .forwardNotification(this.id_solicitud,this.correoNuevoFormControl.value)
      .subscribe(response => {
          this.correoNuevoFormControl.reset();
          this.mostrarPara=!this.mostrarPara;
          this.snackBar.open("Notificación reenviada", "OK", {
             duration: 5000
          });
          this.visualizationTrack(this.id_solicitud);
      });
    }

    dialogViewFormReenvio() {
      let dialogRef = this.dialog.open( MailForwardComponent, {
        width: "450px",
        maxHeight: "80vh",
        data: {
          id_solicitud: this.id_solicitud
        }
      });

      dialogRef.afterClosed().subscribe(response => {
        if ( response ) {
          this.visualizationTrack(this.id_solicitud);
        }
      });

    }

}

export class TrackResponse {
  estado : boolean;
  count : number;
  lista : any;

  constructor() {
  }

}
