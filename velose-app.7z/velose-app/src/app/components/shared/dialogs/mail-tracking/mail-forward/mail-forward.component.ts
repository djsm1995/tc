import { Component, OnInit, Inject} from '@angular/core';
import { Validators, FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MailTrackingService } from '../../../../../services/mail-tracking.service';
import { Validaciones } from '../../../../shared/validaciones';

@Component({
  selector: 'app-mail-forward',
  templateUrl: './mail-forward.component.html',
  styleUrls: ['./mail-forward.component.css']
})
export class MailForwardComponent implements OnInit {

  id_solicitud : string;
  correoNuevoFormControl : FormControl;
  // closeDialog : boolean;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar, private service: MailTrackingService) {
    this.id_solicitud = data.id_solicitud;
  }

  ngOnInit() {
    this.inicializarForm();
  }


  inicializarForm() {
    this.correoNuevoFormControl = new FormControl('',
        [Validators.email, Validaciones.NULL_O_VACIO]
        );
  }

  forwardNotification() {
    this.service
      .forwardNotification(this.id_solicitud,this.correoNuevoFormControl.value)
      .subscribe(response => {
          this.correoNuevoFormControl.reset();
          this.snackBar.open("Notificación reenviada", "OK", {
             duration: 5000
          });
      });
    }

}
