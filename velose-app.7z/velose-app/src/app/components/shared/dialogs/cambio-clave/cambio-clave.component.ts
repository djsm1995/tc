import { Component, OnInit,Inject} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormGroup, Validators,FormControl} from '@angular/forms';
import {Constante} from '../../../../constantes/constante';
import { ProfileService } from '../../../../services/profile.service';
import {ErroresMensajes} from '../../validaciones';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-cambio-clave',
  templateUrl: './cambio-clave.component.html',
  styleUrls: ['./cambio-clave.component.css']
})
export class CambioClaveComponent implements OnInit {

  enProceso:boolean
  usuarioFormGroup:FormGroup;
  hide:any

  constructor(
    @Inject(MAT_DIALOG_DATA) public _data: any,
    private _perfilService: ProfileService,
    public snackBar: MatSnackBar,
    public dialog: MatDialog,

    )
    {
      this.inicializarVariables();
    }

  ngOnInit() {
    this.enProceso=false;

    this.usuarioFormGroup= new FormGroup({

      recaptcha : new FormControl(null),
      'passUsuarioFormControl':new FormControl('',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(Constante.pattern.password)
        ]
      ),
      'nuevaPassUsuarioFormControl':new FormControl('',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(Constante.pattern.password),
          this.validacionNuevayAntiguaPass.bind(this)
        ]
      ),
      'confirmarNuevaPassUsuarioFormControl':new FormControl('',
        [
          Validators.required,
          Validators.minLength(8),
          this.validacionPassIguales.bind(this),
          Validators.pattern(Constante.pattern.password),
          this.validacionNuevayAntiguaPass.bind(this)

        ]
      ),
    });

    this.usuarioFormGroup.controls["passUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data=>{
      this.usuarioFormGroup.controls["nuevaPassUsuarioFormControl"].updateValueAndValidity();
      this.usuarioFormGroup.controls["confirmarNuevaPassUsuarioFormControl"].updateValueAndValidity();
    })

    this.usuarioFormGroup.controls["nuevaPassUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data=>{
      this.usuarioFormGroup.controls["confirmarNuevaPassUsuarioFormControl"].updateValueAndValidity();
    })
    this.usuarioFormGroup.controls["confirmarNuevaPassUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data=>{
      this.usuarioFormGroup.controls["nuevaPassUsuarioFormControl"].updateValueAndValidity();
    })

  }

  //#region Validaciones
  validacionPassIguales(control:FormControl):{[s:string]:boolean}{
    if(this.usuarioFormGroup &&
      control.value!=this.usuarioFormGroup.controls['nuevaPassUsuarioFormControl'].value){

        return{ passIguales:true}
      }
    return null;
  }

  validacionNuevayAntiguaPass(control:FormControl):{[s:string]:boolean}{

    if(this.usuarioFormGroup && control.value!=null && control.value!="" &&
      control.value==this.usuarioFormGroup.controls['passUsuarioFormControl'].value)
      return{ nuevaPassIgualAntiguaPass:true}
    return null;
  }

  mensajeErrorNuevaPass(codNuevaClave:number){

    let nuevaPass = this.usuarioFormGroup.controls;
    switch (codNuevaClave) {
      case 1:
        nuevaPass = nuevaPass["nuevaPassUsuarioFormControl"].errors;
        break;
      case 2:
        nuevaPass = nuevaPass["confirmarNuevaPassUsuarioFormControl"].errors;
        break;

      default:
        break;
    }
    return nuevaPass == null
      ? null
      : ErroresMensajes.ERRORMESSAGENUEVAPASS(nuevaPass);
  }

  mensajeErrorFormatoPassActual(){
    let pass = this.usuarioFormGroup.controls["passUsuarioFormControl"].errors;
    return pass == null
    ? null
    : ErroresMensajes.ERRORMESSAGEPASS(pass);

  }
  //#endregion

  // #region Metodos
  cambiarClaveInterno(){
    this.enProceso=true;
    setTimeout(() => {
      this._perfilService.cambiarClaveInterno(
        this.usuarioFormGroup.controls['passUsuarioFormControl'].value,
        this.usuarioFormGroup.controls['nuevaPassUsuarioFormControl'].value).subscribe(
          (response:any)=>{
            if(response.estado){
              this.dialog.closeAll();
            }
            else if(response.claveActualErronea){
              setTimeout(()=>{
                this.usuarioFormGroup.controls['passUsuarioFormControl'].setErrors({claveActualErronea:true})
              },0)
            }


            //mostrar mensaje
            this.enProceso=false;

            this.snackBar.open(response.mensaje, "OK", { duration: 6000 });

          },
          error=>{
            this.enProceso=false;
            this.snackBar.open("Ocurrio un error inesperado", "OK", { duration: 6000 });

          }
        )

    }, 6000);
  }

  limpiarFormulario(){
    this.usuarioFormGroup.reset()
    this.usuarioFormGroup.markAsPristine();
    this.usuarioFormGroup.markAsUntouched();
  }

  inicializarVariables(){
    this.hide={
      passUsuarioFormControl:true,
      nuevaPassUsuarioFormControl:true,
      confirmarNuevaPassUsuarioFormControl:true,
    }
  }

}
