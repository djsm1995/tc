import { Component, OnInit, isDevMode } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.css']
})
export class ErrorPageComponent implements OnInit {
  redirigir:boolean = true;
  constructor(  private router:Router) { }

  ngOnInit() {
    if(isDevMode()) {console.log('ErrorPageComponent | ngOnInit...')}
    if(this.redirigir){
      setTimeout( () => {
        this.router.navigate(['/login']);
      }, 10000 );
    }
  }
  redirect(){
    this.redirigir= false;
    this.router.navigate(['/login']);
  }
}
