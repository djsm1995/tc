import { Component, OnInit, Inject, ViewChild, ElementRef, isDevMode } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RegisterService } from '../../../services/register.service'

@Component({
  selector: 'app-shared-dialog-confirmacion',
  templateUrl: './shared-dialog-confirmacion.component.html',
  styleUrls: ['./shared-dialog-confirmacion.component.css']
})
export class SharedDialogConfirmacionComponent implements OnInit {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data:IDatosDialogConfirmacion,
    public _dialog: MatDialog,
    public dialogRef: MatDialogRef<SharedDialogConfirmacionComponent>,
    public _registroS: RegisterService,
  ) {
  }

  ngOnInit() {
  }
  aceptar(){
    this.dialogRef.close(true);
  }
  cancelar(){
    this.dialogRef.close(false);
  }
}

export interface IDatosDialogConfirmacion{
    icono?:string;
    colorIcono?:string;
    mensaje:string;
    titulo:string;
    textoBotonAceptar:string;
    textoBotonCancelar:string;
}
export class CDatosDialogConfirmacion{
    icono:string;
    colorIcono:string;
    mensaje:string;
    titulo:string;
    textoBotonAceptar:string;
    textoBotonCancelar:string;

    constructor(){
      this.icono = "warning";
      this.colorIcono="color-ambar";
      this.mensaje = "¿Estas seguro de realizar la siguiente transacción?";
      this.titulo = "Mensaje de Confirmación";
      this.textoBotonAceptar="Si, acepto";
      this.textoBotonCancelar="No, gracias";
    }
}