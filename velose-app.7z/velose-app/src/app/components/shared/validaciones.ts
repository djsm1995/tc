import {FormBuilder, FormGroup, Validators,FormControl} from '@angular/forms';
import { Constante } from '../../constantes/constante';
import { isDevMode } from '@angular/core';


export class Validaciones {
         public static ES_NUMERO(control: FormControl): { [s: string]: boolean } {
           let numero = false;
           if (control.value != "") {
             numero = isNaN(control.value) ? true : false;
           }
           return numero ? { validacionNumero: true } : null;
         }
         public static NUMERO_CERO(control: FormControl): { [s: string]: boolean } {
           let numero = false;
           if (control.value != "") {
             numero = control.value == 0 ? true : false;
           }
           return numero ? { validacionNumeroCero: true } : null;
         }
         public static RUC_VALIDO(control: FormControl): { [s: string]: boolean } {
           let respuesta: any = { rucNoValido: true};
           if (control && control.value) {
             if (String(control.value).length != 11 || Validaciones.inicioNumeroRUC(control.value) || !Validaciones.validacionRUC(control.value)) {
               return respuesta;
             }
           }
           return null;
         }
          static inicioNumeroRUC(ruc) {
            if (!(ruc >= 1e10 && ruc < 11e9
              || ruc >= 15e9 && ruc < 18e9
              || ruc >= 2e10 && ruc < 21e9)) {
              return true;
            }
            return false;
          }
          static validacionRUC(valor) {
            valor = String(valor).trim()
            if (this.esnumero(valor)) {
              if (valor.length == 11) {
                let suma = 0;
                let x = 6;
                let zero = 0
                for (let i = 0; i < valor.length - 1; i++) {
                  if (i == 4) x = 8
                  let digito = valor.charAt(i) - zero;
                  x--
                  if (i == 0){suma += (digito * x)}
                  else suma += (digito * x)
                }
                let resto = suma % 11;
                resto = 11 - resto
        
                if (resto >= 10) resto = resto - 10;
                if (resto == valor.charAt(valor.length - 1) - zero) {
                  return true
                }
              }
            }
            return false
          }
          static esnumero(campo) { return (!(isNaN(campo))); }

         // Validaciones Solicitudes Filtros
         public static FORMATO(idCpe, control: FormControl): { [s: string]: boolean } {
           let numero = control.value == 0 ? true : false;
           return numero ? { validacionNumeroCero: true } : null;
         }

        //  Validaciones Null o ""
         public static NULL_O_VACIO(control: FormControl): { [s: string]: boolean } {
          // let numero = control.value == 0 ? true : false;
          return (control.value=="" ||control.value==null ||control.value==[]) ? { validacionNullOVacio: true } : null;
        }
       }


export class ErroresMensajes{
  // Mensaje Busqueda de Solicitudes
  public static ERRORMESSAGESERIE(error){
    // Mensajes Error Validaciones
    if(error.validacionFacturaF)
      return "La serie para factura electrónica debe comenzar con F. Ejemplo:F001"

    if(error.validacionBoletaF)
      return "La serie para boleta electrónica debe comenzar con B. Ejemplo:B001"

    if(error.validacionNotaCreditoODebitoF)
      return "La serie debe comenzar con F o B. Ejemplo:B001"

    if(error.validacionGuiaRemisionF)
      return "La serie debe comenzar con T. Ejemplo:T001"

    if(error.validacionRetencionF)
      return "La serie debe comenzar con R. Ejemplo:R001"

    if(error.validacionPercepciónF)
      return "La serie debe comenzar con P. Ejemplo:P001"

    if(error.validacionFormatoResumenes)
      return "La serie debe tener formato fecha: 20180411"

    if(error.minlength!=undefined)
      return `El campo debe tener ${error.minlength.requiredLength} dígitos`

    if(error.validacionAlfanumerico)
      return `El campo debe ser alfanumérico`

    return ""
  }
  public static ERRORMESSAGECORRELATIVO(error){
    // Mensajes Error Validaciones
    if(error.validacionNumero || (error.pattern && error.pattern.requiredPattern=="^[0-9]+$"))
      return "El correlativo debe ser numérico. Ejemplo: 00001, 3."

    if(error.validacionNumeroCero)
      return "El valor del correlativo debe ser mayor a cero. Ejemplo: 00001,3"

    return ""
  }

  // Mensajes Password
  // mensajeErrorNuevaPass

  public static ERRORMESSAGENUEVAPASS(error){
    if(error.nuevaPassIgualAntiguaPass)
      return "Nueva clave igual que clave actual."
      
    if(error.passIguales)
      return "Las nuevas claves deben ser iguales."

    if( error.pattern && error.pattern.requiredPattern==Constante.pattern.password)
      return "Clave con formato incorrecto"

    return ""

  }

  public static ERRORMESSAGEPASS(error){    
    if(error.pattern && error.pattern.requiredPattern== Constante.pattern.password)
      return "Clave con formato incorrecto."
      
    if(error.claveActualErronea)
      return "Clave incorrecta."

    return ""

  }

  public static ERRORFILTROSERIEPADRONES(error){
    // Mensajes Error Validaciones
    if(error.pattern && error.pattern.requiredPattern=="^[0-9]*$")
      return "El número de serie debe ser numérico. Ejemplo: 0001,1,3,etc."

      if(error.minlength){
        return "El número de serie debe tener 4 dígitos de longitud. Ejemplo: 0001, 1234, etc."
      }
    // if(error.validacionNumeroCero)
    //   return "El valor del correlativo debe ser mayor a cero. Ejemplo: 00001,3"

    return ""
  }
}
