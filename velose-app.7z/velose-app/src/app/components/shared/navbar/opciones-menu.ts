import { NavItem } from '../../../services/menu-principal.service';


const opciones:NavItem[]=[
    {
        descripcion:"Dashboard",
        pathRedirect:"home/dashboard",
        icon:"assessment",
        identificador:"dashboard"
    },
    {
        descripcion:"Búsqueda de comprobantes",
        pathRedirect:"home/transacciones",
        icon:"assignment_turned_in",
        identificador:"comprobantes"
    },
    {
        descripcion:"Analytics",
        pathRedirect:null,
        icon:"bubble_chart",
        identificador:"analytics",
        submodulos:[
            {
                descripcion:"Dashboard",
                pathRedirect:"home/analytics",
                icon:"dashboard",
                identificador:"analytics.charts"//se debe cambiar el identificador para que no exista duplicado
            },
            {
                descripcion:"Configuracion",
                pathRedirect:"home/configuracionAnalytics",
                icon:"settings",
                identificador:"analytics.configuracion"
            },
        ]
    },
    {
        descripcion:"Plataforma de pruebas",
        pathRedirect:null,
        icon:"swap_vertical_circle",
        identificador:"plataformaPruebas",
        submodulos:[
            {
                descripcion:"Caso de negocios",
                pathRedirect:"home/casoNegocio",
                icon:"dns",
                identificador:"plataformaPruebas.casoNegocios"
            },
            {
                descripcion:"Ambiente beta",
                pathRedirect:"home/homologacion",
                icon: "insert_drive_file",
                identificador:"plataformaPruebas.ambienteBeta"
            },
        ]
    },
    {
        descripcion:"Soporte",
        pathRedirect:null,
        icon:"swap_vertical_circle",
        identificador:"soporte",
        submodulos:[
            {
                descripcion:"Consulta de comprobantes",
                pathRedirect:"home/consultaComprobantes",
                icon:"assignment_turned_in",
                identificador:"soporte.comprobantes"
            },
            {
                descripcion:"Listado de padrones",
                pathRedirect:"home/padrones",
                icon: "layers",
                identificador:"soporte.listadoPadrones"
            },
        ]
    },
    {
        descripcion:"Mi Plan",
        pathRedirect:"home/miPlan",
        icon:"shopping_cart",
        identificador:"miPlan"
    },
    {
        descripcion:"Usuarios",
        pathRedirect:"home/usuario",
        icon:"supervisor_account",
        identificador:"usuarios"
    },
    {
        descripcion:"Roles",
        pathRedirect:"home/roles",
        icon:"extension",
        identificador:"roles"
    },
    {
        descripcion:"Mi perfil",
        pathRedirect:"home/profile",
        icon:"account_box",
        identificador:"perfil"
    },
    {
        descripcion:"Configuraciones generales",
        pathRedirect:"home/configuracionesGenerales",
        icon:"settings",
        identificador:"configuraciones"
    },

    
    
]

export const OpcionesMenu:NavItem[] = opciones
