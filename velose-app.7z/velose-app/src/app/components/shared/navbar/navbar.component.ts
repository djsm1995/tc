import { Component, OnInit,ViewChild, ElementRef,ChangeDetectorRef } from '@angular/core';
import { MenuPrincipalService, NavItem } from '../../../services/menu-principal.service';
import { ReusableService } from '../../../services/reusable.service';
import { TokenService } from '../../../services/token.service';
import { ROUTES } from '../../../app.route';
import { Router } from '@angular/router';
import { RolesService } from '../../../services/roles.service';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  permisoProfile: string[];
  @ViewChild('sidenav',{static: false}) sidenav: ElementRef;
  avatarUsuario:any;
  menuNav:NavItem[]=[];
  clientePrepago = false;
  razonSocial : string = "";
  usuarioLogeado:any;
  rolName:string="";
  constructor(private router:Router,
              private _menuPrincipalService:MenuPrincipalService,
              private _sReusable:ReusableService,
              private cd:ChangeDetectorRef,
              private tokenS:TokenService,
              private _rolesService:RolesService

              ) {
                
        //this.usuarioLogeado = this._sReusable.getSessionUsuario();
        //this.razonSocial = this.usuarioLogeado.empresa.razonSocial;
        this.permisoProfile = this._sReusable.obtenerPermisos("perfil");
        this.getSessionUsuario();
        this.obtenerAvatarUsuarios();
        this.getRol()

  }

  obtenerAvatarUsuarios(){
    let imagen = this._sReusable.getSessionUsuario().imagenUsuario;
    if(imagen != null){
     return  this.avatarUsuario = this._sReusable.getSessionUsuario().imagenUsuario; 
    }else{
     return this.avatarUsuario = "../../../../assets/img/avatar3.png";
    }
  }

  ngOnInit() {
    this.menuNav = this._menuPrincipalService.getMenuNav();
    this.clientePrepago= this._sReusable.esClientePrepago(this.usuarioLogeado);
  }
  ngAfterViewInit() {
    this._menuPrincipalService.sidenav = this.sidenav;
  }
  ngOnDestroy() {
    this.cd.detach();
    // unsubscribe
  }


  quitarDatosSession(){
    this.tokenS.closeSession();
    this.eliminarChatlio();
  }

  
  eliminarChatlio(){
    var elem = document.getElementById('chatlio-widget');
    if(elem==null){return;}
    document.body.removeChild(elem);
  }

  getRol(){
   this._rolesService.obtenerRol().subscribe((response:any)=>{
    this.rolName=response.nombreRol;
   });
  }

  formatString(someString:string){
  if(someString.length>=20){
    return someString.substring(0,20)+"..."
  }else{
    return someString
  }
  }

  // Reutilizables
  public getSessionUsuario(){
    this.usuarioLogeado = this._sReusable.getSessionUsuario();
    return this.usuarioLogeado;
  }
  nombreApellidoUsuario(){
  let usuarionombreApellido= `${this.getSessionUsuario().nombre} ${this.getSessionUsuario().apellidos}`
  return usuarionombreApellido;
  }

  tooltipMenuUsuario(){
    // let data= `${this.nombreApellidoUsuario()} \n ${this.getSessionUsuario().correo}`
    let data= `${this.nombreApellidoUsuario()} (${this.getSessionUsuario().correo})`
    return data;
  }


  isAnalytic(){
    const ANALYTIC='/home/analytics';
    let existeAnalytic = ROUTES[0].children.find
    (element => {
      return element.path == 'analytics';
    });    
    return (existeAnalytic && this.router.url == ANALYTIC )?true:false
  }
  
}
