import {
  Component,
  ChangeDetectorRef,
  OnInit,
  OnDestroy,
  ViewRef,
  ViewChild
} from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MensajeGenericoComponent} from '../shared/mensaje-generico/mensaje-generico.component';
import { TokenService} from '../../services/token.service';
import { Constante} from '../../constantes/constante';
import { Router } from '@angular/router';
import { ReusableService} from '../../services/reusable.service';
import { UserIdleService } from "angular-user-idle";
import { tap } from "rxjs/operators";
import { DashboardOperadorComponent } from '../layout/dashboard-operador/dashboard-operador.component';
import 'rxjs/add/observable/fromEvent';//Si se quita esto cambia la posicion de los iconos del menu 
import { Subscription } from 'rxjs/internal/Subscription';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit, OnDestroy  {
  messageIdle: string;
  isWatching: boolean = false;
  isTimer: boolean;
  timeIsUp: boolean;
  timerCount: number;
  private timerStartSubscription: Subscription;
  private timeoutSubscription: Subscription;

  private activityEvents$: Observable<any>;
  private idle$: Subscription;
  private ngUnsubscribe = new Subject();

  @ViewChild("isDashboardOperador",{static: false})
  isDashboardOperador: DashboardOperadorComponent;
  constructor(
    private tokenS: TokenService,
    private router: Router,
    public _dialog: MatDialog,
    private _reusable: ReusableService,
    private cd: ChangeDetectorRef,
    private userIdle: UserIdleService
  ) {}

  ngOnInit() {
    this.activityEvents$ = Observable.from(
      Observable.merge(
        Observable.fromEvent(window, "mousemove"),
        Observable.fromEvent(window, "resize"),
        Observable.fromEvent(document, "keydown")
      )
    );
    this.onStartWatching();
  }
  ngOnDestroy() {
    this.onStopTimer();
    this.onStopWatching();
  }

  //#region user-Idle
  onStartWatching() {
    this.isWatching = true;
    this.timerCount = Constante.INACTIVIDAD.timeOut;
      // Start watching for user inactivity.
      this.userIdle.startWatching();
      // Start watching when user idle is starting.
      this.timerStartSubscription = this.userIdle
        .onTimerStart()
        .pipe(tap(() => (this.isTimer = true)))
        .subscribe(count => {
          if (this.router.url != "/home/dashboardOperador" && this.isTimer) {
            this.messageIdle =
              "Tu sesion expirará en " +
              (Constante.INACTIVIDAD.timeOut - count) +
              " segundos!";
            this.timerCount = count;
    
            this.idle$ = this.activityEvents$
              .takeUntil(this.ngUnsubscribe)
              .subscribe((event: any) => {
                if (event && event.isTrusted) {
                  this.onResetTimer();
                  // unsubscribe;
                }
              });
          }
          else{
            this.onResetTimer(); 
            // this.onStopWatching();
          }
        });
  

    // Start watch when time is up.
    this.timeoutSubscription = this.userIdle.onTimeout().subscribe(() => {
      this.timeIsUp = true;
      let dialogRef;
      setTimeout(
        () =>
          (dialogRef = this._dialog.open(MensajeGenericoComponent, {
            width: "400px",
            data: {
              icon: "sentiment_very_dissatisfied",
              color: "#062a78",
              titulo: "Desconectado",
              mensaje: `Has sido desconectado del servidor de Velose, debido a tu inactividad prolongada. `
            }
          })),
        0
      );
      // this.showIdle = false;
      this.tokenS.closeSession();
    });
  }
  onStopWatching() {
    this.userIdle.stopWatching();
    this.timerStartSubscription.unsubscribe();
    this.timeoutSubscription.unsubscribe();
    this.isWatching = false;
    this.isTimer = false;
    this.timeIsUp = false;
  }
  onStopTimer() {
    this.userIdle.stopTimer();
    this.isTimer = false;
  }
  onResetTimer() {
    this.userIdle.resetTimer();
    this.isTimer = false;
    this.timeIsUp = false;
    this.ngUnsubscribe.next(false);
    this.ngUnsubscribe.complete;
    this.idle$.unsubscribe;
  }
  //#endregion

  rutasPermitidasActivas() {
    let rpta: boolean = false;
    let ruta: string = this.router.url;
    const RUTAHOME: string = "/home";
    if (
      (ruta != null || ruta != undefined) &&
      ruta.substr(0, RUTAHOME.length) == RUTAHOME
    ) {
      rpta = !rpta;
    }
    return rpta;
  }
}
