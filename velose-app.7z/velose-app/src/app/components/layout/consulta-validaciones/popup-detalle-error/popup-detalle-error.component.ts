import { Component, OnInit ,Inject} from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { ReusableService} from '../../../../services/reusable.service';
import { MensajeGenericoComponent} from '../../../shared/mensaje-generico/mensaje-generico.component';
import { HomologacionService } from '../../../../services/homologacion.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Constante} from '../../../../constantes/constante';
import { ReprocesarConsultaComprobantesService } from "../../../../services/reprocesar-consulta-comprobantes.service";
import { environment } from '../../../../../environments/environment';

@Component({
  selector: "app-popup-detalle-error",
  templateUrl: "./popup-detalle-error.component.html",
  styleUrls: ["./popup-detalle-error.component.css"]
})
export class PopupDetalleErrorComponent implements OnInit {
  // resultado : any = new  Resultado();
  resultado: any = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: {comprobante:any,error:boolean},
    private _httpClient: HttpClient,
    private _reusableService: ReusableService,
    private _reprocesarConsultaComprobanteService: ReprocesarConsultaComprobantesService,
    public _snackbar: MatSnackBar,
    public _dialogRef: MatDialogRef<PopupDetalleErrorComponent>
  ) {
    
    if (data.error) {
      this.getDataDeclaraciones(data.comprobante.idComprobante).subscribe(
        (response: ResultadoI) => {
          this.resultado = response.listaComprobantesPorId;
        }
      );
    }

  }

  ngOnInit() {}
  getDataDeclaraciones(data) {
    return (
      this._httpClient.post(`${environment.endpointVelose}/declaracion/obtenerComprobantesPorId`, { "idComprobante":data})
        .catch((error: any) => {
          return this._reusableService.getCatch(error);
        })
    );
  }
  test(data) {
    let rpta;
    rpta = data == null ? {} : data;
    return rpta;
  }

  reprocesar() {
    let data = {
      idComprobante: this.resultado[0].idComprobante,
      estadoDeclare: this.resultado[0].estadoDeclare
    };
    this._reprocesarConsultaComprobanteService.reprocesar(data).subscribe((response: any) => {
      if (response) {
        // llamr snackbar
        this._snackbar.open(response.mensaje, "OK", { duration: 6000 });
      }
      if (response.estado == true) {
        this._dialogRef.close();
      }
      return;
    });
  }
}

export interface ResultadoI
{
  estado:boolean;
  mensaje:string;
  total:string;
  listaComprobantesPorId:any[];
 }

export class Resultado
{
  estado:boolean;
  mensaje:string;
  total:string;
  listaComprobantesPorId:any[];
  constructor(){
    this.estado=false;
    this.mensaje="";
    this.total="";
    this.listaComprobantesPorId=[{
      idComprobante:"",
      nombreZip:"",
      fechaRegistro:"",
      estadoDeclare:"",
      mensajeError:"",
      fechaError:"",
    }
    ];
  }
 }



export class ListaComprobantesPorId{
    idComprobante:string;
    nombreZip:string;
    fechaRegistro:string;
    estadoDeclare:string;
    mensajeError:string;
    fechaError:string;
}

export interface ListaComprobantes{
    idComprobante:string;
    nombreZip:string;
    fechaRegistro:string;
    estadoDeclare:string;
    mensajeError:string;
    fechaError:string;
}
