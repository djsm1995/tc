import { Component, OnInit, ElementRef, AfterContentInit, ViewChild } from '@angular/core';
import { PopupDetalleErrorComponent } from './popup-detalle-error/popup-detalle-error.component';
// import { MatMenuModule } from '@angular/material/menu';
// import { MatInputModule } from '@angular/material/input';
// import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { FormGroup, Validators, FormControl, FormGroupDirective } from '@angular/forms';
import { ConsultaValidacionesService } from '../../../services/consulta-validaciones.service';
import { ReprocesarConsultaComprobantesService } from '../../../services/reprocesar-consulta-comprobantes.service';

import { merge } from 'rxjs/observable/merge';
import { of as observableOf } from 'rxjs/observable/of';
import { Observable } from 'rxjs/Observable';

import { startWith } from 'rxjs/operators/startWith';
import { switchMap } from 'rxjs/operators/switchMap';
import { map } from 'rxjs/operators/map';
import { catchError } from 'rxjs/operators/catchError';
import { ReusableService } from '../../../services/reusable.service';
import { Validaciones } from '../../shared/validaciones';
import { Catalogo } from '../../../constantes/catalogo';
// import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
// import { MatChipInputEvent } from '@angular/material/chips';
import {DatosRucService,datosRucResponse} from '../../../services/datos-ruc.service';

@Component({
  selector: "app-consulta-validaciones",
  templateUrl: "./consulta-validaciones.component.html",
  styleUrls: ["./consulta-validaciones.component.css"]
})

export class ConsultaValidacionesComponent implements OnInit,AfterContentInit {
  //Variables Generales
  filtroBusquedaFG: FormGroup;
  rangoFechas: any[] = [
    {
      descripcion: "Fecha de registro",
      codigo: "0"
    },
    {
      descripcion: "Fecha de emisión",
      codigo: "1"
    }
  ];
  estadoLstDeclare: any[] = [];
  //coloresChip = [ "primary", "warn", "accent" ];

  step = 0;
  fechaInicioValor: Date;
  fechaFinValor: Date;
  idComprobanteValor: string;
  estadoDeclareValor: string;
  expandedElement: any;
  detailError: any;
  catalogoCPES: any[] = [];

  // Tabla Resultados
  resultsLength = 0;
  resultRptaCount: string = "";
  isLoadingResults = true;
  displayedColumns = [
    "nombreComprobante",
    "nombreZip",
    "fechaRegistro",
    "estadoDeclare",
    "mensajeError"
  ];
  dataSource = new MatTableDataSource();
  maxResult = 10;
  @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
  @ViewChild(MatSort,{static: false}) sort: MatSort = new MatSort();
  mensajeBusqueda: string = null;

  // Tutoriales
  // 1 FILTRO DE BUSQUEDA
  tutorialFiltro: any = [
    {
      Paso: 1,
      Sobre: "CONSULTA DE COMPROBANTES",
      Tag: "Title",
      Titulo: "Consulta de comprobantes",
      Descripcion:
        "Aquí podrás ver todas las validaciones realizadas por VelOSE.",
      Boton1: "¡Empecemos!",
      Boton2: "Saltar Tutorial"
    },
    {
      Paso: 2,
      Sobre: "Filtros de comprobantes",
      Tag: "Panel",
      Titulo: "Filtros de comprobantes",
      Descripcion:
        "Te permite filtrar los comprobantes que fueron validados correctamente.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 3,
      Sobre: "Rango de búsqueda",
      Tag: "Panel",
      Titulo: "Rango de búsqueda",
      Descripcion:
        "Aquí elige el rango de búsqueda de tus comprobantes, el rango máximo es de un mes.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 4,
      Sobre: "Buscar",
      Tag: "boton",
      Titulo: "Buscar",
      Descripcion:
        'Seleccionar "Buscar" y verás los resultados en la parte inferior.',
      Boton1: "¡Mi turno!",
      Boton2: "Anterior"
    }
  ];

  tutorialFiltroSteps = {
    step1: false,
    step2: false,
    step3: false,
    step4: false
  };

  tutorialTable: any = [
    {
      Paso: 1,
      Sobre: "ID COMPROBANTE",
      Tag: "Column",
      Titulo: "Id del comprobante",
      Descripcion:
        'Muestra ID con que fue registrado el comprobante en OSE',
      Boton1: "Siguiente",
      Boton2: "Saltar Tutorial"
    },
    {
      Paso: 2,
      Sobre: "NOMBRE COMPROBANTE",
      Tag: "Column",
      Titulo: "Nombre del comprobante",
      Descripcion:
        "Muestra el nombre del comprobante, que tiene el siguiente formato:",
      Boton1: "Siguiente",
      Boton2: "Anterior",
      Adicionales: [
        { dato: "[RUC]-[TIPO DE COMPROBANTE]-[SERIE]-[CORRELATIVO].zip" }
      ]
    },
    {
      Paso: 3,
      Sobre: "FECHA TRANSMISIÓN",
      Tag: "Column",
      Titulo: "Fecha de transmisión",
      Descripcion: "Muestra la fecha en la que se ejecutó la validación.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 4,
      Sobre: "ESTADO DECLARE",
      Tag: "Column",
      Titulo: "Estado declare",
      Descripcion: "Muestra los estados de declaración del comprobante y estos pueden ser:",
      Boton1: "Siguiente",
      Boton2: "Anterior",
      Adicionales: [
        { dato: "ACEPTADO" },
        { dato: "ACEPTADO CON OBSERVACIONES" },
        { dato: "ANULADO" }
      ]
    },
    {
      Paso: 5,
      Sobre: "Ver Detalle",
      Tag: "Column",
      Titulo: "Detalle",
      Descripcion:
        'Si quieres ver mas detalles de la validación, selecciona el botón "!"',
      Boton1: "OK",
      Boton2: "Anterior"
    }
  ];

  tutorialTableSteps = {
    step1: false,
    step2: false,
    step3: false,
    step4: false,
    step5: false
  };

  constructor(
    private _DeclaracionS: ConsultaValidacionesService,
    private _reprocesarS: ReprocesarConsultaComprobantesService,
    public snackBar: MatSnackBar,
    private dialog: MatDialog,
    private reusable: ReusableService,
    private _datosRucService:DatosRucService
  ) {
    this.catalogoCPES = Catalogo.CPES;
    this.estadoLstDeclare = this._reprocesarS.getListaestadoDeclare();
  }


  ngAfterContentInit(){
  }
  ngOnInit() {
      if (this.dataSource) {
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
      }
      this.filtroBusquedaFG = new FormGroup({
        tipoFecha: new FormControl(0, [Validators.required]),
        fechaInicio: new FormControl({ value: new Date(), disabled: true }, [
          Validators.required
        ]),
        fechaFin: new FormControl({ value: new Date(), disabled: true }, [
          Validators.required
        ]),
        idComprobante: new FormControl("", [Validators.maxLength(100)]),
        tipoComprobante: new FormControl("0", [Validators.required]),
        nombreZip: new FormControl("", [Validators.maxLength(50)]),
        rucEmpresaEmisora: new FormControl("",
                                [ Validators.maxLength(11),
                                  Validaciones.RUC_VALIDO,
                                  this.limpiarRazonSocial.bind(this)
                                ],
                                this.buscarRuc.bind(this) ),
        razonSocialEmpresaEmisora: new FormControl({value:"",disabled:true}, []),
        estadoDeclare: new FormControl([])
      });
  }

  getChipsColor(est) {
      let color = "warn";
      switch(est) {
          case 2:
              color = "primary";
              break;
          case 3:
              color = "warn";
              break;
          case 4:
              color = "warn";
              break;
          case 8:
              color = "primary";
              break;
          case 6:
              color =  "warn";
              break;
          case 7:
              color = "warn";
              break;
          case 9:
              color = "warn";
              break;
      }
      return color;
  }

  getChipsDescription(est) {
      let description = "";
      for (let estDeclare of this.estadoLstDeclare) {
          if ( estDeclare.codigo == est ) {
              description = estDeclare.descripcion;
          }
      }
      return description;
  }

  buscarRuc(control:FormControl) : Promise<any> | Observable<any> {
      let datosWS : datosRucResponse;
      let rpta = this._datosRucService.VerificacionRuc(control.value).map(
              (response:datosRucResponse)=>{
                    if(response && response.estado){
                        datosWS = response;
                        this.filtroBusquedaFG.controls["razonSocialEmpresaEmisora"].setValue(datosWS.datosRuc.razonSocial);
                    } else {
                        this.filtroBusquedaFG.controls["razonSocialEmpresaEmisora"].setValue("");
                    }
              }
              );
      return rpta;
  }


  limpiarRazonSocial(control:FormControl) {
      if ( control.value && control.value.length < 11 ) {
          this.filtroBusquedaFG.controls["razonSocialEmpresaEmisora"].setValue("");
      }
  }

  assembleData() {
    let valueFiltro = this.filtroBusquedaFG.controls;
    let fechaInicioValor = valueFiltro["fechaInicio"].value;
    let fechaFinValor = valueFiltro["fechaFin"].value;
    let idComprobanteValor = valueFiltro["idComprobante"].value;
    let estadoDeclareValor = valueFiltro["estadoDeclare"].value;
    let empresaEmisora = valueFiltro["rucEmpresaEmisora"].value;
    // let razonSocialEmisora = valueFiltro["razonSocialEmpresaEmisora"].value;
    var nomZip = valueFiltro["nombreZip"].value;
    var tipoComprobante = valueFiltro["tipoComprobante"].value;
    var tipoFecha = valueFiltro["tipoFecha"].value;
    let data = {
      fechaInicio: fechaInicioValor,
      fechaFin: fechaFinValor,
      nomZip: nomZip,
      idComprobante: idComprobanteValor,
      estDeclare: estadoDeclareValor,
      rucEmpresaEmisora: empresaEmisora,
      // razonSocialEmpresaEmisora: razonSocialEmisora,
      tipoComprobante: tipoComprobante,
      tipoFecha: tipoFecha,
      page: this.paginator.pageIndex + 1,
      maxResult: this.maxResult
    };
    return data;
  }

  // steps panel accordion
  setStep(index: number) {
    this.step = index;
    this.setDisplayError(index);
  }
  setDisplayError(index: number) {
    if (index == 0) {
      this.detailError = false;
      this.expandedElement = null;
    } else {
      this.detailError = true;
    }
  }

  BuscarDeclaraciones() {
    // Nos fijamos que el paso 1 este validado
    if (this.filtroBusquedaFG.valid) {
      this.paginator.pageIndex = 0;
      //Servicio para contar
      this._DeclaracionS
        .countDeclaraciones(this.assembleData())
        .subscribe((response: any) => {
          if (response && response.estado) {
            if (response.count >= 1) {
              this.resultsLength = response.count;
              this.resultRptaCount = response.rptaCount!=null? response.rptaCount:response.count;
              this.mensajeBusqueda = null;
              this.serviceBusqueda();
            } else {
              this.resultsLength = 0;
              this.resultRptaCount = "0 resultados (0.0 segundos)";
              this.isLoadingResults = false;
              this.mensajeBusqueda =
                "No se encontraron datos con los filtros proporcionados";
              // llamr snackbar
              this.snackBar.open(this.mensajeBusqueda, "OK", {
                duration: 5000
              });
            }
          }
        });
    }
  }

  serviceBusqueda() {
    // Servicio de búsqueda
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          return this._DeclaracionS.getDataDeclaraciones(this.assembleData());
        }),
        map((data: any) => {
          this.isLoadingResults = false;
          return data;
        }),
        catchError(() => {
          this.isLoadingResults = false;
          return observableOf([]);
        })
      )
      .subscribe(data => {
        this.dataSource.data = data.listaComprobantes;
      });
  }

  buscarDetalleError(row) {
    let error: boolean = this.mostrarDetalleError(row);
    let dialogRef = this.dialog.open(PopupDetalleErrorComponent, {
      width: "400px",
      maxHeight: "80vh",
      data: {
        comprobante: row,
        // idComprobante: id,
        error:error
      }
    });
  }

  //Formato de la respuesta en la tabla
  getFormatoFecha(fecha) {
    let fechaN = new Date(fecha);
    return this.reusable.getFormatoFecha(fechaN, 2);
  }

  mostrarDetalleError(estadoDeclare) {
    let mostrarError: any;
    mostrarError = this.estadoLstDeclare.find(element => {
      return element.codigo == estadoDeclare.estadoDeclare && element.reprocesar;
    });
    return mostrarError == undefined ? false : true;
  }

  // Tutorial Filtro
  resetTutorial() {
    this.goTutorial();
  }
  goTutorial() {
    this.saltarTutorial();
    this.tutorialFiltroSteps.step1 = true;
  }
  cnStep1() {
    this.saltarTutorial();
    this.tutorialFiltroSteps.step2 = true;
  }
  cnStep2() {
    this.saltarTutorial();
    this.tutorialFiltroSteps.step3 = true;
  }
  cnStep3() {
    this.saltarTutorial();
    this.tutorialFiltroSteps.step4 = true;
  }

  cnStep4() {
    this.saltarTutorial();
  }
  saltarTutorial() {
    this.tutorialFiltroSteps = {
      step1: false,
      step2: false,
      step3: false,
      step4: false
    };
  }

  //Tutorial tabla
  resetTutorialTable() {
    this.goTutorialTable();
  }
  goTutorialTable() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step1 = true;
  }

  tableStep1() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step2 = true;
  }
  tableStep2() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step3 = true;
  }
  tableStep3() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step4 = true;
  }
  tableStep4() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step5 = true;
  }
  tableStep5() {
    this.saltarTutorialTable();
  }

  saltarTutorialTable() {
    this.tutorialTableSteps = {
      step1: false,
      step2: false,
      step3: false,
      step4: false,
      step5: false
    };
  }

}
