import { Component, OnInit,OnDestroy, Inject, isDevMode } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TransaccionesService } from '../../../../services/transacciones.service';
import { Catalogo } from '../../../../constantes/catalogo';
import { Subject } from 'rxjs/Subject';
import { takeUntil } from 'rxjs/operators';
import { ConsultaValidacionesService } from '../../../../services/consulta-validaciones.service';

import { ReusableService } from '../../../../services/reusable.service';

const MENSAJESERROR=[3,4,6,7]
@Component({
  selector: "app-estado-sunat",
  templateUrl: "./estado-sunat.component.html",
  styleUrls: ["./estado-sunat.component.css"]
})
export class EstadoSUNATComponent implements OnInit, OnDestroy {
  private unsubscribe: Subject<void> = new Subject();
  iconoRespuesta: { icono: string; color: string };
  //mensajeRespuesta: any = null;
  errores:any[]=[]
  responseComprobante:any[]=[]
  resultado: any[] = [];
  sinReprocesamientos:boolean;
  sinDetalle:boolean;


  dataComprobante: any;
  isLoadingResults = true;
  constructor(
    public _reusableS: ReusableService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public _dialogRef: MatDialogRef<EstadoSUNATComponent>,
    public _transaccionS: TransaccionesService,
    private _DeclaracionS: ConsultaValidacionesService,

  ) {
    let variable = {
      tipo: this.data.data.tipo,
      fecRegistro:this.data.data.fecRegistro, 
      idComprobante: this.data.data.idTrace,
      nombreComprobante: this.data.data.nombreSolicitud,
      estadoSunat: this.data.data.estadoSunat,
      estado:null,
      tituloSunat:null,
      mensajeSunat:null,
      respuestaSunat:null
      
    };
    this.dataComprobante = variable;

        // El comprobante tiene una validacion de Velose
        if (data.data.estadoDocumento == 2) {
          this._DeclaracionS.getDataDeclaraciones(this.assembleData())
          .subscribe((response: any) => {
            if (response.estado === true && response.listaComprobantes.length == 1) {
              this.responseComprobante = response.listaComprobantes[0];
              if (this.mostrarDetalleError(this.responseComprobante)) {
                  this._DeclaracionS.getDataDeclaracionesxId(response.listaComprobantes[0].idComprobante)
                    .subscribe((responsexId: ResultadoI) => {
                      console.log(responsexId)
                      this.resultado = responsexId.listaComprobantesPorId
                       if(this.resultado.length==0){
                         this.sinReprocesamientos=true;
                       }
                      this.isLoadingResults = false;  
                    })
                }else {
                  if(isDevMode()) {console.log("no se encontro detalle del error");}
                  this.isLoadingResults = false;
                  this.resultado = [];
                }
              }else {
                //mostrar mensaje de que no se encontro datadedeclaraciones
                if(isDevMode()) {console.log("no se encontro data para mostrar en el detalle");}
                this.sinDetalle = true;
                this.isLoadingResults = false;
                
              }
            })
            
        }
        else {
          this.isLoadingResults = false;
          //error xq no se encontrara en la tabla estadoDeclare
        }
  }

  ngOnInit() {
    // Carga iconos
    this.iconoRespuesta = Catalogo.ICONORESPUESTA.advertencia;
    this._transaccionS
      .getEstadoSunat(this.data.data.idTrace)
      .pipe(takeUntil(this.unsubscribe)) // unsubscribe
      .subscribe((response: any) => { 
        if (response.estado === false) {
          this.isLoadingResults = false;
          return;
        }
        switch (this.dataComprobante.estadoSunat) {
          case 3: //caso 1033
            //this.reusable(response);
            this.iconoRespuesta = Catalogo.ICONORESPUESTA.aceptado;
            this.tituloEstado("Informacion de declaracion de CPE", "Aceptado", null);
            break;
          case 2:
            this.setFechaTipo(response);
            this.iconoRespuesta = Catalogo.ICONORESPUESTA.aceptado;
            this.tituloEstado("Informacion de declaracion de CPE", "Aceptado", null);
              break;
          case -1:
            this.iconoRespuesta = Catalogo.ICONORESPUESTA.rechazado;
            if (response.listaComprobantes.length >= 1) {
              this.errores = response.listaComprobantes
              this.dataComprobante.respuestaSunat="mostrar";
              this.tituloEstado("Informacion de declaracion de CPE", "Rechazado", null);
            }
            else {
              //mostrar mensaje de que no se ecnontro data n el servicio
              this.tituloEstado("Informacion de declaracion de CPE", "Pendiente","El estado de Sunat del comprobante no se encuentra actualizado. Por favor vuelva a consultar en unos minutos.");
            }
            break;
          case 0:
            this.iconoRespuesta = Catalogo.ICONORESPUESTA.advertencia;
            this.tituloEstado("Informacion de declaracion de CPE", "En proceso", "En proceso respuesta SUNAT, Por favor vuelva a consultar en unos minutos.");
            break;
          default:
            this.tituloEstado("Informacion de declaracion de CPE", "En proceso", "En proceso respuesta SUNAT, Por favor vuelva a consultar en unos minutos.");
            break;
        }         
      });
  }

  mostrarDetalleError(rowData) {
    if(isDevMode()) {console.log(rowData);}
    return (this.data.data.estadoSunat == -1 || this.data.data.estadoSunat == 2|| this.data.data.estadoSunat == 3)? true:false
  }

  assembleData() {
    let data = {
      fechaInicio: null,
      fechaFin: null,
      nomZip: null,
      idComprobante: this.data.data.idTrace,
      estDeclare: null,
      rucEmpresaEmisora: null,
      tipoComprobante: null,
      tipoFecha: null,
      page: 1, // debe ser un numero mayor a 0
      maxResult: 10 // debe ser un numero mayor a 0
    };
    return data;
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
  onClosedCancel() {
    this._dialogRef.close("Cancel");
  }

  test(data) {
    let rpta;
    rpta = data == null ? {} : data;
    return rpta;
  }
  tituloEstado(titulo, estado, descripcion){
    this.dataComprobante.tituloSunat=titulo;
    this.dataComprobante.estado=estado;
    this.dataComprobante.mensajeSunat=descripcion;
    this.isLoadingResults = false;  
  }

  
  //#region Reusable
  setFechaTipo(response:any){
    if(response.listaComprobantes.length > 0){
      if(response.listaComprobantes[0].fechaRegistro!=null && response.listaComprobantes[0].tipoComprobante!=null){
        this.dataComprobante.fecRegistro = this._reusableS.getFormatoFecha(new Date(response.listaComprobantes[0].fechaRegistro), 2);
        this.dataComprobante.tipo = (response.listaComprobantes[0].tipoComprobante);
      }
    }
  }
  //#endregion
}

export interface ResultadoI {
  estado: boolean;
  mensaje: string;
  total: string;
  listaComprobantesPorId: any[];
}