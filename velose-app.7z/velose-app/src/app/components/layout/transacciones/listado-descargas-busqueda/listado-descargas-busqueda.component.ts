import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { DescargaBusquedaCpesService, IListadoSolicitudDescargaCpe, ISolicitudDescargaCpe, CMostrarFiltrosBusqueda, IMostrarFiltrosBusqueda } from '../../../../services/descarga-busqueda-cpes.service';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { TransaccionesService } from '../../../../services/transacciones.service';
import { environment } from '../../../../../environments/environment';
@Component({
  selector: 'app-listado-descargas-busqueda',
  templateUrl: './listado-descargas-busqueda.component.html',
  styleUrls: ['./listado-descargas-busqueda.component.css']
})
export class ListadoDescargasBusquedaComponent implements OnInit {
  
  readonly displayedColumns:string[]=["fechaExportacion","PesoArchivo","filtroBusqueda","estado"]
  resultsLength:number;
  isLoadingResults:boolean;
  dataSource: MatTableDataSource<any>;

  ambientePermitido:boolean

  constructor(
    private _descargaBusquedaCpesService: DescargaBusquedaCpesService,
    private _transaccionesService: TransaccionesService,
    private _snackBarClassShared: SnackBarConfigurationSharedComponent,
  ) { }

  ngOnInit() {
    this.cargarVariables();
    this.obtenerListaDescargaBusqueda();

    this.ambientePermitido=(environment.ambiente=="beta")?false:true
  }


  cargarVariables(){
    this.resultsLength=0;
    this.isLoadingResults=true
    this.dataSource = new MatTableDataSource()
  }

  obtenerListaDescargaBusqueda(){
    this.isLoadingResults=true
    this._descargaBusquedaCpesService.getListadoDescargasBusquedaCpe().subscribe(
      (response:IListadoSolicitudDescargaCpe)=>{
        if (response.estado){
          this.dataSource.data= response.listado
        }
        else{
          this._snackBarClassShared.openSnackBar(response.mensaje, 5000, "OK");
        }
        this.isLoadingResults=false;
      }
    )
  }
}
