import { Component, OnInit, ViewChild, isDevMode, ViewChildren } from '@angular/core';
import { FormGroup, Validators, FormControl, PatternValidator } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';

import { merge } from 'rxjs/observable/merge';
import { of as observableOf } from 'rxjs/observable/of';
import { catchError, distinctUntilChanged } from 'rxjs/operators';
import { map} from 'rxjs/operators';
import { startWith} from 'rxjs/operators';
import { switchMap} from 'rxjs/operators';
import { FileSaverService  } from 'ngx-filesaver';

import { Catalogo,Cpe,Moneda} from '../../../constantes/catalogo';
import { TransaccionesService, IRequestBusquedaComprobantes,IRequestBusquedaComprobantes2, CRequestBusquedaComprobantes,
  permisosComprobanteUsuario, permisosComprobanteUsuarioClass,  RequestBusquedaComprobantes} from '../../../services/transacciones.service';
import { ReusableService, IResponseService } from '../../../services/reusable.service';
import { Validaciones,ErroresMensajes} from '../../shared/validaciones';
import { EstadoSUNATComponent } from './estado-sunat/estado-sunat.component';
import { MailTrackingComponent } from '../../shared/dialogs/mail-tracking/mail-tracking.component';
import { Constante } from '../../../constantes/constante';
import { SnackBarConfigurationSharedComponent } from '../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';

import { DialogReprocesoComprobanteComponent } from "../consulta-comprobantes/dialog-reproceso-comprobante/dialog-reproceso-comprobante.component";
import { IDatosDialogConfirmacion, CDatosDialogConfirmacion, SharedDialogConfirmacionComponent } from '../../shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';
import { DescargaBusquedaCpesService, ICantidadMaximaSolicitudExportacion } from '../../../services/descarga-busqueda-cpes.service';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: "app-transacciones",
  templateUrl: "./transacciones.component.html",
  styleUrls: ["./transacciones.component.css"],
  animations: [
    trigger("detailExpand", [
      state(
        "collapsed",
        style({ height: "0px", minHeight: "0", visibility: "hidden" })
      ),
      state("expanded", style({ height: "*", visibility: "visible" })),
      transition(
        "expanded <=> collapsed",
        animate("225ms cubic-bezier(0.4, 0.0, 0.2, 1)")
      )
    ])
  ]
})
export class TransaccionesComponent implements OnInit {
  //Metodos verifyErrorSerieCorrelativo()
  inputSerieCorrecto:boolean;
  inputCorrelativoCorrecto:boolean;
  matTooltipSerie:string;
  matTooltipCorrelativo:string;
  // step for panels
  step = 0;
  catalogoCPES: Cpe[];
  catalogoMONEDAS: Moneda[];
  rangoEstadoValidacionesOSE: any;
  rangoEstadoSunat: any;
  rangoFechas: any;
  filtroBusquedaFG: FormGroup;
  disabledDatePicker: boolean = true;
  indiceTempOpenRow: number = null;
  bloquearBusqueda = false;
  usuarioLogeado:any;

  // #region tutoriales
  tutorialValidaciones: any = [
    {
      Paso: 1,
      Sobre: "VALIDACIONES",
      Tag: "Title",
      Titulo: "Validaciones",
      Descripcion:
        "Aquí podrás ver todas las validaciones realizadas por velOSE, también puedes ver los CDRs, XMLs y estados de tus comprobantes.",
      Boton1: "¡Empecemos!",
      Boton2: "Saltar Tutorial"
    },
    {
      Paso: 2,
      Sobre: "Incluir validaciones erróneas",
      Tag: "Column",
      Titulo: "Incluir validaciones erróneas",
      Descripcion:
        "Selecciona si quieres incluir validaciones erróneas, esto deshabilitará los filtros de comprobantes.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 3,
      Sobre: "Filtros de comprobantes",
      Tag: "Panel",
      Titulo: "Filtros de comprobantes",
      Descripcion:
        "Te permite filtrar los comprobantes que fueron validados correctamente.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 4,
      Sobre: "Rango de búsqueda",
      Tag: "Panel",
      Titulo: "Rango de búsqueda",
      Descripcion:
        "Aquí elige el rango de búsqueda de tus comprobantes, el rango máximo es de un mes.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 5,
      Sobre: "Buscar",
      Tag: "boton",
      Titulo: "Buscar",
      Descripcion:
        'Seleccionar "Buscar" y verás los resultados en la parte inferior.',
      Boton1: "¡Mi turno!",
      Boton2: "Anterior"
    }
  ];

  tutorialTable: any = [
    {
      Paso: 1,
      Sobre: "VALIDACIÓN",
      Tag: "Column",
      Titulo: "Validación",
      Descripcion:
        'Muestra si la validación es "Correcta" o "Incorrecta", solo si es correcta es un comprobante válido.',
      Boton1: "Siguiente",
      Boton2: "Saltar Tutorial"
    },
    {
      Paso: 2,
      Sobre: "NOMBRE COMPROBANTE",
      Tag: "Column",
      Titulo: "Nombre del comprobante",
      Descripcion:
        "Muestra el nombre del comprobante, que tiene el siguiente formato:",
      Boton1: "Siguiente",
      Boton2: "Anterior",
      Adicionales: [
        { dato: "[RUC]-[TIPO DE COMPROBANTE]-[SERIE]-[CORRELATIVO].zip" }
      ]
    },
    {
      Paso: 3,
      Sobre: "DESCARGAR XML",
      Tag: "Column",
      Titulo: "Descargar XML",
      Descripcion: "Opción para descargar XML enviado en la solicitud.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 4,
      Sobre: "FECHA TRANSMISIÓN",
      Tag: "Column",
      Titulo: "Fecha de transmisión",
      Descripcion: "Muestra la fecha en la que se ejecutó la validación.",
      Boton1: "Siguiente",
      Boton2: "Anterior"
    },
    {
      Paso: 5,
      Sobre: "ESTADO velOSE",
      Tag: "Column",
      Titulo: "Estado velOSE",
      Descripcion:
        "Muestra los estados del comprobante declarado en OSE y estos pueden ser:",
      Boton1: "Siguiente",
      Boton2: "Anterior",
      Adicionales: [
        { dato: "Aceptado" },
        { dato: "Aceptado con observaciones" },
        { dato: "Anulado" }
      ]
    },
    {
      Paso: 6,
      Sobre: "ESTADO SUNAT",
      Tag: "Column",
      Titulo: "Estado SUNAT",
      Descripcion:
        "Muestra los estados del comprobante declarado en SUNAT y estos pueden ser:",
      Boton1: "Siguiente",
      Boton2: "Anterior",
      Adicionales: [
        { dato: "Aceptado" },
        { dato: "En proceso" },
        { dato: "Error" }
      ]
    },
    {
      Paso: 7,
      Sobre: "Ver Detalle",
      Tag: "Column",
      Titulo: "Detalle",
      Descripcion: 'Para mayor detalle, selecciona el botón "v"',
      Boton1: "OK",
      Boton2: "Anterior"
    }
  ];

  tutorialDetalle: any = [
    {
      Paso: 1,
      Sobre: "Correcta",
      Tag: "Detalle",
      Titulo: "Validación correcta",
      Descripcion:
        "Aquí se muestra la información del comprobante generado, tanto XML como CDR.",
      Boton: "OK"
    },
    {
      Paso: 2,
      Sobre: "Incorrecta",
      Tag: "Detalle",
      Titulo: "Validación incorrecta",
      Descripcion:
        "Aquí se muestra la excepción de la validación, asi como el código y mensaje de error.",
      Boton: "OK"
    }
  ];

  tutorialSteps = {
    step1: false,
    step2: false,
    step3: false,
    step4: false,
    step5: false
  };

  tutorialTableSteps = {
    step1: false,
    step2: false,
    step3: false,
    step4: false,
    step5: false,
    step6: false,
    step7: false,
    detalleCorrecta: false,
    detalleIncorrecta: false
  };
  //#endregion
  // Tabla Resultados
  resultsLength = 0;
  resultRptaCount: string = "";
  isLoadingResults = true;
  displayedColumns = [
    "transaccion",
    "nombreSolicitud",
    "xml",
    "fechaTransmicion",
    //"notificacion.estado",
    "estado",
    "estadoSUNAT",
    "verMas"
  ]; //'factoring',
  Database: any;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
  @ViewChild(MatSort,{static: false}) sort: MatSort = new MatSort();
  mensajeBusqueda: string = null;
  isExpansionDetailRow = (i: number, row: Object) =>
    row.hasOwnProperty("detailRow");

  expandedElement: any;
  detailError: any;
  arrayTempOpenRow = [];
  // Filtro Fechas 1 mes como Maximo
  fechaInicio = {
    max: this._reusableService.getToday()
  };
  fechaFin = {
    min: this._reusableService.getToday(),
    max: new Date(this._reusableService.getToday().getTime() + 24 * 60 * 60 * 1000 * 2)
  };
  // Filtro formBusquedaSolicitudes
  correlativoBusqueda = 8;
  serieBusqueda = 4;
  //#region areaFactoring
  arrayTempFactoring = [];
  //#endregion
  
  // assembledataBusqueda
  cpeAceptadoConObservaciones=null;
  cpeAnulado=null;
  cpeReversado=null;

  //Permisos
  listaPermisosBD: string[] = this._transaccionService.obtenerPermisos("comprobantes");
  permiso = new permisosComprobanteUsuario();
  tienePermiso = new permisosComprobanteUsuarioClass();

  filtrosBusquedaTemp:IRequestBusquedaComprobantes;
  filtrosBusquedaTemp2:IRequestBusquedaComprobantes2;
  puedeExportarResultadosBusquedaCpe:boolean;
  spinnerPuedeExportarResultadosBusquedaCpe:boolean=true;
  mensajeExportarResultadosBusquedaCpe:string;
  puedeVisualizarListadoExportaciones:boolean;
  mensajeVisualizarListadoExportaciones:string;

  paginatorSubscribe:Subscription;

  constructor(
    private _transaccionService: TransaccionesService,
    private _descargaBusquedaCpesService: DescargaBusquedaCpesService,
    private _reusableService: ReusableService,
    private _FileSaverService: FileSaverService,
    private _snackBarClassShared: SnackBarConfigurationSharedComponent,
    private dialog: MatDialog,
    private router:Router,
    private datepipe:DatePipe
  ) {

    this.obtenerPermisos();
    this.usuarioLogeado=this._reusableService.getSessionUsuario();
    this.cargarCatalogos();
    this.setEnableListadoExportaciones();
  }
  
  obtenerPermisos(){
    for(let permiso of this.listaPermisosBD){      
      if(permiso === this.permiso.comprobantes_notificaciones){
        this.tienePermiso.comprobantes_notificaciones = true;
        this.displayedColumns.splice(4,0,"notificacion.estado");
      }
    }
  }
  cargarCatalogos() {
    this.catalogoCPES = Catalogo.CPES;
    this.catalogoMONEDAS = Catalogo.MONEDAS;
    this.rangoEstadoValidacionesOSE = this._transaccionService.getFiltrosEstadoValidacionesOSE();
    this.rangoEstadoSunat = this._transaccionService.getFiltrosEstadoSunat();
    this.rangoFechas = this._transaccionService.getFiltrosFechas();

  }
  ngOnInit() {

    this.detailError = true;
    this.setExportarResultadosBusquedaCpe(false,"")

    if (this.dataSource) {
      this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
    }

    this.filtroBusquedaFG = new FormGroup({
      nombreComprobante: new FormControl("", [Validators.maxLength(250)]),
      tipoCpe: new FormControl("00", [Validators.required]), //cpe todos x defecto
      serie: new FormControl({ value: "", disabled: true }, [
        this.FORMATO.bind(this)
      ]),
      correlativo: new FormControl({ value: "", disabled: true }, []),
      filtroEstadoValidacionOSE:new FormControl("00", Validators.required),//filtroEstadoValidacionOSE:new FormControl(0, Validators.required),
      filtroEstadoSunat: new FormControl("00", Validators.required),//filtroEstadoSunat: new FormControl(0, Validators.required),
      filtroFechas: new FormControl("1", Validators.required),
      fechaInicio: new FormControl(
        {
          value: this._reusableService.getToday(),
          disabled: true
        },
        [Validators.required]
      ),
      fechaFin: new FormControl(
        {
          value: this._reusableService.getToday(),
          disabled: true
        },
        [Validators.required]
      )
    });
    //#region Metodos en los input
    this.filtroBusquedaFG.controls["tipoCpe"].valueChanges.pipe(distinctUntilChanged()).subscribe(
      (codigo:string)=>{
      this.verificarDatos(codigo);
      this.rangoEstadoValidacionesOSE[4].disabled = false
      this.rangoEstadoValidacionesOSE[5].disabled = false

      let form = this.filtroBusquedaFG.controls["filtroEstadoValidacionOSE"];
      if(codigo != ""){
        if(codigo == "01" || codigo == "03" || codigo == "07" || codigo == "08" || codigo == "09"){
          if(form && form.value == "2-3"){
            form.setValue("00");
          }
          this.rangoEstadoValidacionesOSE[5].disabled = true;//Reversado
        }
        if(codigo == "20" || codigo == "40"){
          if(form && form.value == "2-2"){
            form.setValue("00");
          }
          this.rangoEstadoValidacionesOSE[4].disabled = true;//Anulado
        }
        if(codigo == "RC" || codigo == "RA" || codigo == "RR"){//RC=Resumen_Diario_Boletas/RA=Comunicado_Baja/RR=Reversion
          if(form && form.value == "2-2" || form.value == "2-3"){
            form.setValue("00");
          }
          this.rangoEstadoValidacionesOSE[4].disabled = true;//Anulado
          this.rangoEstadoValidacionesOSE[5].disabled = true;//Reversado
        }
      }
    });

    this.filtroBusquedaFG.controls["serie"].valueChanges.subscribe(data =>{
      this.inputSerieCorrecto = false;
      if(data != ""){
        this.verifyErrorSerieCorrelativo();
        this.messageErrorSerieCorrelativo();
      }
    });
    this.filtroBusquedaFG.controls["correlativo"].valueChanges.subscribe(data =>{
      this.inputCorrelativoCorrecto = false;
      if(data != ""){
        this.verifyErrorSerieCorrelativo(true);
        this.messageErrorSerieCorrelativo(true);
      }
    });
    // this.filtroBusquedaFG.controls["tipoCpe"].valueChanges.subscribe(data => {
    //   this.verificarDatos(data);
    // });
    this.filtroBusquedaFG.controls["filtroFechas"].valueChanges.subscribe(
      data => {this.verificarFiltrosFechas(data);}
    );

    this.filtroBusquedaFG.controls["filtroEstadoValidacionOSE"].valueChanges.pipe(distinctUntilChanged()).subscribe(
      (codigo:string)=>{
        this.cpeAceptadoConObservaciones=null;
        this.cpeAnulado=null;
        this.cpeReversado=null;
        var activarControls=false;
        switch (codigo) {

          case "-1":
            activarControls=!activarControls;
            break;

          case "2-1": //Aceptado con observaciones
            this.cpeAceptadoConObservaciones=1            
            break;

          case "2-2"://Anulado 
            this.cpeAnulado=1          
            break;

          case "2-3"://reversado
            this.cpeReversado=1          
            break;
        
          default:
            break;
        }
        this.seleccionarValidacionesErroneas(activarControls)
      }
    );
    this.filtroBusquedaFG.controls["fechaInicio"].valueChanges.subscribe(
      data => {
        this.fechaFin = {
          min: data,
          max: new Date(data.getTime() + 24 * 60 * 60 * 1000 * 60)
        };
        if (this.filtroBusquedaFG.controls["filtroFechas"].value == 4 && this._reusableService.compararFechaMenor(this.fechaFin.max)){
          this.filtroBusquedaFG.controls["fechaFin"].setValue(this.fechaFin.max);
        }
      }
    );
    //#endregion
  }

  limpiarFormularioResultado(){
    this.filtroBusquedaFG.reset({
      tipoCpe: "00",
      serie: { value: "", disabled: true },
      correlativo:{ value: "", disabled: true },
      filtroEstadoValidacionOSE:"00",
      filtroEstadoSunat:"00",
      filtroFechas: "1",
      fechaInicio: { value: this._reusableService.getToday(),disabled: true},
      fechaFin:{value: this._reusableService.getToday(),disabled: true}
    })


    this.rangoFechas = this._transaccionService.getFiltrosFechas();
    this.resultsLength=0
    this.dataSource.data=[];
    this.filtrosBusquedaTemp2=undefined
    this.puedeExportarResultadosBusquedaCpe=false;
    this.spinnerPuedeExportarResultadosBusquedaCpe=true;
  }

  BuscarSolicitudes() {
    //this.limpiarFormularioResultado();
    this.bloquearBusqueda = true;
    this.spinnerPuedeExportarResultadosBusquedaCpe = true;
    this.puedeExportarResultadosBusquedaCpe = false;
    if (this.filtroBusquedaFG.valid && this.sort != undefined) {
      this.paginator.pageIndex = 0;
      if(this.paginatorSubscribe!=undefined) this.paginatorSubscribe.unsubscribe()
      this.assembleData()
      // servicio para contar
      this._transaccionService
        .buscarSolicitudes(this.filtrosBusquedaTemp2)  // .countSolicitudes(this.filtrosBusquedaTemp2)
        .subscribe((response: any) => {
          if (response && response.estado) {
            if (response.totalPaginas >= 1) { // if (response.count >= 1) {
              
              this.resultsLength = response.totalElementos;
              this.resultRptaCount = response.mensajeBusqueda;
              //this.resultsLength = response.count;
              //this.resultRptaCount = response.rptaCount;
              this.mensajeBusqueda = null;

              this.serviceBusqueda();
              this.puedeExportarResultadoBusquedaCpe();
            
            } else {
              this.resultsLength = 0;
              this.resultRptaCount = "0 resultados (0 segundos)";
              this.isLoadingResults = false;
              this.mensajeBusqueda =
                "No se encontraron datos con los filtros proporcionados";
              // llamr snackbar
              this._snackBarClassShared.openSnackBar(this.mensajeBusqueda, 5000, "OK");
            }
          }else{
            if(isDevMode){console.log(response.mensaje)}
            this.resultsLength = 0;
              this.resultRptaCount = "0 resultados (0 segundos)";
              this.isLoadingResults = false;
              this.mensajeBusqueda =
                "No se encontraron datos con los filtros proporcionados";
              // llamr snackbar
              this._snackBarClassShared.openSnackBar(this.mensajeBusqueda, 5000, "OK");
          }
          this.bloquearBusqueda = false;
        });
    }
    this.saltarTutorial();
    this.saltarTutorialTable();
//#region antiguo metodo de llamar al servicio buscar
    // this.bloquearBusqueda = true;
    // this.spinnerPuedeExportarResultadosBusquedaCpe = true;
    // this.puedeExportarResultadosBusquedaCpe = false;
    // if (this.filtroBusquedaFG.valid && this.sort != undefined) {
    //   this.paginator.pageIndex = 0;
    //   if(this.paginatorSubscribe!=undefined) this.paginatorSubscribe.unsubscribe()
    //   this.assembleData()
    //   // servicio para contar
    //   this._transaccionService
    //     .countSolicitudes(this.filtrosBusquedaTemp2)
    //     .subscribe((response: any) => {
    //       if (response && response.estado) {
    //         if (response.count >= 1) {
    //           this.resultsLength = response.count;
    //           this.resultRptaCount = response.rptaCount;
    //           this.mensajeBusqueda = null;
    //           this.serviceBusqueda();
    //           this.puedeExportarResultadoBusquedaCpe();
    //         } else {
    //           this.resultsLength = 0;
    //           this.resultRptaCount = "0 resultados (0 segundos)";
    //           this.isLoadingResults = false;
    //           this.mensajeBusqueda =
    //             "No se encontraron datos con los filtros proporcionados";
    //           // llamr snackbar
    //           this._snackBarClassShared.openSnackBar(this.mensajeBusqueda, 5000, "OK");
    //         }
    //       }else{
    //         if(isDevMode){console.log(response.mensaje)}
    //         this.resultsLength = 0;
    //           this.resultRptaCount = "0 resultados (0 segundos)";
    //           this.isLoadingResults = false;
    //           this.mensajeBusqueda =
    //             "No se encontraron datos con los filtros proporcionados";
    //           // llamr snackbar
    //           this._snackBarClassShared.openSnackBar(this.mensajeBusqueda, 5000, "OK");
    //       }
    //       this.bloquearBusqueda = false;
    //     });
    // }
    // this.saltarTutorial();
    // this.saltarTutorialTable();
    //#endregion
  }

  serviceBusqueda() {
    // Servicio de búsqueda
    this.paginatorSubscribe = merge(this.paginator.page)
      .pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          this.actualizarPaginatorRequest()
          //return this._transaccionService.getData(this.filtrosBusquedaTemp2);
          this.filtrosBusquedaTemp2.paginar = false;
          return this._transaccionService.buscarSolicitudes(this.filtrosBusquedaTemp2);
          //return data
        }),
        map((data: any) => {
          if (this.indiceTempOpenRow != null)
            this.arrayTempOpenRow[this.indiceTempOpenRow] = "expand_more";

          // Flip flag to show that loading has finished.
          this.isLoadingResults = false;
          if (data && data.estado) this.setStep(1);
          // Cargar data de detailrow
          let resultadoConDetailRow = [];
          data.solicitudes.forEach(elemento => {

          if (!elemento.notificacion) {
            elemento.notificacion = { "id_solicitud": "", "estado": "0", "mensaje": "No enviado" };
          }
          resultadoConDetailRow.push(elemento, { detailRow: true, elemento });
          });
          return resultadoConDetailRow;
        }),
        catchError(() => {
          this.isLoadingResults = false;
          return observableOf([]);
        })
      )
      .subscribe(data => {
        this.dataSource.data = data;
        for (let i = 0; i < data.length; i++) {
          this.arrayTempOpenRow.push("expand_more");
          this.arrayTempFactoring.push({
            colores: {
              verde: false,
              amarillo: false,
              azul: true
            },
            mensaje: "Vender Factura"
          });
        }
      });
  }

  actualizarPaginatorRequest(){
    this.filtrosBusquedaTemp2.resultados=this.paginator.pageSize;// this.filtrosBusquedaTemp.maxResults=this.paginator.pageSize;
    this.filtrosBusquedaTemp2.pagina=this.paginator.pageIndex; // this.filtrosBusquedaTemp.page=this.paginator.pageIndex+1;
  }

  assembleData() {
    //#region Nuevo Servicio
    let dato :RequestBusquedaComprobantes = new RequestBusquedaComprobantes();
    let valueFiltro = this.filtroBusquedaFG.controls;
    
    dato.filtro.nombreCpe =  valueFiltro["nombreComprobante"].value;
    dato.filtro.ruc = this._reusableService.getSessionUsuario().empresa.ruc;
    dato.resultados = this.paginator.pageSize;
    dato.pagina = this.paginator.pageIndex;
    dato.paginar = true;
    if ( dato.filtro.nombreCpe != "" &&  dato.filtro.nombreCpe != null){
      dato.filtro.nombreCpe =  dato.filtro.nombreCpe.indexOf('.zip') != -1? dato.filtro.nombreCpe.split(".zip",1)[0]: dato.filtro.nombreCpe;
      this.filtrosBusquedaTemp2 = dato;
      return;
    }
    
    let valueFiltroTipoCpe  = valueFiltro["tipoCpe"].value;
    let valueFiltroSerie = valueFiltro["serie"].value;
    let valueFiltroCorrelativo = valueFiltro["correlativo"].value;

    
    dato.filtro.tipoComprobante = this.validacionesIncorrectasSeleccionadas()? "00": valueFiltroTipoCpe == "00" ? "00": valueFiltroTipoCpe;
    dato.filtro.serie = this.valueControlSerie(valueFiltroTipoCpe,valueFiltroSerie);
    dato.filtro.correlativo = this.valueControlNumero(valueFiltroCorrelativo);

    dato.filtro.fechaInicio = this.datepipe.transform(this.filtroBusquedaFG.controls["fechaInicio"].value,'yyy-MM-dd 00:00:00');
    dato.filtro.fechaFin = this.datepipe.transform(this.filtroBusquedaFG.controls["fechaFin"].value,'yyy-MM-dd 23:59:59');

    dato.filtro.estadoSunat = valueFiltro["filtroEstadoSunat"].value;
    dato.filtro.estadoVelose = valueFiltro["filtroEstadoValidacionOSE"].value;
    dato.filtro.tipoRol= this._reusableService.getSessionUsuario().tipoRol;
    this.filtrosBusquedaTemp2= dato;
    return dato;
    //#endregion

    //#region Antiguo Servicio
    //let data :IRequestBusquedaComprobantes= new CRequestBusquedaComprobantes();
    //let valueFiltro = this.filtroBusquedaFG.controls;
    // let valueFiltroTipoCpe = valueFiltro["tipoCpe"].value;
    // let valueFiltroSerie = valueFiltro["serie"].value;
    // let valueFiltroCorrelativo = valueFiltro["correlativo"].value;
    // let valueNombreComprobante =  valueFiltro["nombreComprobante"].value;

    // data.ruc= this._reusableService.getSessionUsuario().empresa.ruc;
    // data.maxResults=this.paginator.pageSize;
    // data.page=this.paginator.pageIndex+1;

    // if (valueNombreComprobante != "" && valueNombreComprobante != null){
    //   data.nomCPE = valueNombreComprobante.indexOf('.zip') != -1?valueNombreComprobante.split(".zip",1)[0]:valueNombreComprobante;
    //   this.filtrosBusquedaTemp = data;
    //   return;
    // }

    // let fechaInicio = this._reusableService.setHoraFecha( this.filtroBusquedaFG.controls["fechaInicio"].value);
    // let fechaFin = this._reusableService.setHoraFecha(this.filtroBusquedaFG.controls["fechaFin"].value ,"23:59:59");
    // let valueEstadoSunat= valueFiltro["filtroEstadoSunat"].value;
    // let valueEstadoValidacionOSE= valueFiltro["filtroEstadoValidacionOSE"].value;

    // //------let nombreComprobanteZip = valueNombreComprobante!= null && valueNombreComprobante!=""?valueNombreComprobante.split(".zip",1)[0]:valueNombreComprobante;
    // //------data.nomCPE = nombreComprobanteZip;
    // data.estadoSunat= this.validacionesIncorrectasSeleccionadas()?null:this.verificacionValueEstadoSunat(valueEstadoSunat);
    // data.tipo=this.validacionesIncorrectasSeleccionadas()? null: valueFiltroTipoCpe == 0 ? null: valueFiltroTipoCpe;
    // data.fecha= this.valueControlFecha(valueFiltroTipoCpe,valueFiltroSerie);
    // data.serie= this.valueControlSerie(valueFiltroTipoCpe,valueFiltroSerie);
    // data.numero= this.valueControlNumero(valueFiltroCorrelativo);

    // //Validar que busqueda de observaciones anulados o reversas debe ser una validacion correcta
    // data.estadoDoc= this.valueEstadoDoc(valueEstadoValidacionOSE); //2:Comprobante -1 excepcion , null: todos
    // data.tipoFecha=1;//fecha de registro
    // data.fechaInicio=this._reusableService.getFormatoFecha(fechaInicio, 1);
    // data.fechaFin=this._reusableService.getFormatoFecha(fechaFin, 1);
    // data.estadoAceptadoObs=this.cpeAceptadoConObservaciones;
    // data.estadoAnulado=this.cpeAnulado;
    // data.estadoReversa=this.cpeReversado;
    // data.tipoRol= this._reusableService.getSessionUsuario().tipoRol;
    // this.filtrosBusquedaTemp= data;
    // return dato;
    //#endregion

  }
  
//#region metodos que iran al backend
  validacionesIncorrectasSeleccionadas():boolean{
    let valueEstadoValidacionOSE:string= this.filtroBusquedaFG.controls["filtroEstadoValidacionOSE"].value;
    return (valueEstadoValidacionOSE=="-1")?true:false;
  }

  verificacionValueEstadoSunat(valueEstadoSunat:string):string{
    if (valueEstadoSunat == undefined || valueEstadoSunat == "00"){
      return "00";
    }

    // let estadoSunat:string[]=[]
    // if(valueEstadoSunat==2){
    //   estadoSunat.push("3")
    // }
    // estadoSunat.push(valueEstadoSunat)

    return valueEstadoSunat;
    // return (valueEstadoSunat == undefined || valueEstadoSunat == "00")?null:valueEstadoSunat
  }

  valueControlFecha(valueFiltroTipoCpe,valueFiltroSerie){
    let respuesta:string=null
    return (this.getTipoCpeResumenes(valueFiltroTipoCpe) && valueFiltroSerie != "")?
            valueFiltroSerie:
            respuesta
  }

  valueControlSerie(valueFiltroTipoCpe,valueFiltroSerie):string{
    let respuesta:string=null
    if(this.filtroBusquedaFG.controls["serie"].disabled)
      return respuesta;
    
    // if(this.getTipoCpeResumenes(valueFiltroTipoCpe) && valueFiltroSerie != "")
    //   return respuesta

    if(this.getTipoCpeResumenes(valueFiltroTipoCpe) && valueFiltroSerie != "")
      return valueFiltroSerie;
      //respuesta  

    return (valueFiltroSerie=="")?null:valueFiltroSerie
  }

  valueControlNumero(valueFiltroCorrelativo){
    let respuesta:string=null
    if(this.filtroBusquedaFG.controls["correlativo"].disabled)
      return respuesta
    
    return (valueFiltroCorrelativo=="")?respuesta:valueFiltroCorrelativo
  }

  valueEstadoDoc(valueEstadoValidacionOSE){
    if(valueEstadoValidacionOSE == undefined || valueEstadoValidacionOSE == "00")
      return null

    if(this.cpeAceptadoConObservaciones!=null || this.cpeAnulado!=null ||  this.cpeReversado!=null)
      return "2"//para busqueda de observaciones anulados o reversas debe ser una validacion correcta
    
    return valueEstadoValidacionOSE
  }

  getTipoCpeResumenes(data) {
    return data == Catalogo.CPES[7].codigo || //resumen diario de boletas
      data == Catalogo.CPES[8].codigo || // Comunicado de baja y reversion
      data == Catalogo.CPES[9].codigo ? true : false;
  }
//#endregion

 // #region reproceso
    reprocesar(row){
      let dialogRef = this.dialog.open(DialogReprocesoComprobanteComponent, {
        width: "460px",
        maxHeight: "80vh",
        data: {
          row: row,
          error:true
        }
      });
    }
  
  //#endregion
  //Validaciones
  FORMATO(control: FormControl): { [s: string]: boolean } {
    if (this.filtroBusquedaFG && control.value != "") {
      
      if(control.value.match(Constante.pattern.alphanumeric)==null){
        return { validacionAlfanumerico: true };
      }

      let idCpe = this.filtroBusquedaFG.value.tipoCpe;
      let valueControl = control.value.substr(0, 1);
      switch (idCpe) {
        case Catalogo.CPES[0].codigo:
          if(valueControl.match("[a-zA-Z]+") != null){
            if (valueControl != Catalogo.CPES[0].nomenclatura)//Factura
            return { validacionFacturaF: true };
          }
          break;

        case Catalogo.CPES[1].codigo:
          if(valueControl.match("[a-zA-Z]+") != null){
            if (valueControl != Catalogo.CPES[1].nomenclatura)//Boleta
              return { validacionBoletaF: true };
          }
          break;

        case Catalogo.CPES[2].codigo://NOTA DE CREDITO && NOTA DE DEBITO
        case Catalogo.CPES[3].codigo:
          // if(valueControl.match("[a-zA-Z]+") != null){if (valueControl == Catalogo.CPES[0].nomenclatura) {break;}}
          if(valueControl.match("[a-zA-Z]+") != null){
          if (valueControl == Catalogo.CPES[0].nomenclatura) {break;}
          else if(valueControl == Catalogo.CPES[1].nomenclatura) {break;}
            else { return { validacionNotaCreditoODebitoF: true }; }
          }
          break;
        case Catalogo.CPES[4].codigo:
          if (valueControl != Catalogo.CPES[4].nomenclatura)//Guia
            return { validacionGuiaRemisionF: true };
          break;

        case Catalogo.CPES[5].codigo:
          if (valueControl != Catalogo.CPES[5].nomenclatura)//Retencion
            return { validacionRetencionF: true };
          break;

        case Catalogo.CPES[6].codigo:
          if (valueControl != Catalogo.CPES[6].nomenclatura)//percepción
            return { validacionPercepciónF: true };
          break;

        case Catalogo.CPES[7].codigo:
        case Catalogo.CPES[8].codigo:
        case Catalogo.CPES[9].codigo:
          let valueC = String(control.value);
          if (valueC.length != 8 && isNaN(control.value))//Resumen diario Boletas
            return { validacionFormatoResumenes: true };
          break;
      }    
    }
    return null;
  }
  //#region metodos de las validacion inputs
  verificarFiltrosFechas(data) {
    let fechaInicio = this._reusableService.getToday();
    let fechaFin = this._reusableService.getToday();
    switch (data) {
      case this.rangoFechas[1].codigo: //ultima semana
        fechaInicio = new Date(fechaInicio.getTime() - 24 * 60 * 60 * 1000 * 7);
        break;
      case this.rangoFechas[2].codigo: //ultimo mes
        fechaInicio = new Date(
          fechaInicio.getTime() - 24 * 60 * 60 * 1000 * 30 
        );
        break;
    }
    if(data == this.rangoFechas[3].codigo){
      this.disabledDatePicker=false
    }
    else{
      this.disabledDatePicker=true
      this.filtroBusquedaFG.controls["fechaFin"].setValue(fechaFin);
      this.filtroBusquedaFG.controls["fechaInicio"].setValue(fechaInicio);
    }
  }

  verificarDatos(data:any) {
    this.filtroBusquedaFG.controls["serie"].enable();
    if (
      data == Catalogo.CPES[7].codigo || //resumen diario de boletas
      data == Catalogo.CPES[8].codigo || // Comunicado de baja
      data == Catalogo.CPES[9].codigo//reversion
    ) {
      this.actualizarSerie(8); // serie
      this.actualizarCorrelativo(5); //correlativo
    } else {
      this.actualizarSerie(4); // serie
      this.actualizarCorrelativo(8); //correlativo
    }

    if (data == 0) {
      this.filtroBusquedaFG.controls["serie"].disable();
      this.filtroBusquedaFG.controls["correlativo"].disable();
    } else {
      // this.filtroBusquedaFG.controls["serie"].enable();
      this.filtroBusquedaFG.controls["correlativo"].enable();
    }
  }

  actualizarCorrelativo(length:number) {
    let arrayValidators: any[] = [
      Validators.maxLength(length),
      Validaciones.ES_NUMERO,
      Validaciones.NUMERO_CERO,
      Validators.pattern("[0-9]+")
    ];

    this.filtroBusquedaFG.controls["correlativo"].clearValidators();
    this.filtroBusquedaFG.controls["correlativo"].setValidators(
      arrayValidators
    );
    this.filtroBusquedaFG.controls["correlativo"].updateValueAndValidity();
    this.correlativoBusqueda = length;
  }
  actualizarSerie(length:number) {
    let arrayValidators: any[] = [
      Validators.maxLength(length),
      Validators.minLength(length),
      this.FORMATO.bind(this)
    ];

    this.filtroBusquedaFG.controls["serie"].clearValidators();
    this.filtroBusquedaFG.controls["serie"].setValidators(arrayValidators);
    this.filtroBusquedaFG.controls["serie"].updateValueAndValidity();
    this.serieBusqueda = length;
  }
//#endregion

  // steps panel accordion
  setStep(index: number) {
    this.step = index;
    this.setDisplayError(index);
  }

  setDisplayError(index: number) {
    if (index == 0) {
      this.detailError = false;
      this.expandedElement = null;
    } else {
      this.detailError = true;
    }
  }

  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }
  // Reusable

  validardespliegueRow(row, i) {
    if (
      !(row.estadoDocumento == -1 && row.codigoError == null) ||
      row.estadoDocumento == 2
    ) {
      if (this.indiceTempOpenRow != null) {
        this.arrayTempOpenRow[this.indiceTempOpenRow] = "expand_more";
        this.indiceTempOpenRow = this.indiceTempOpenRow == i ? null : i;
      } else {
        this.indiceTempOpenRow = i;
      }
      // this.arrayTempOpenRow.forEach((element, i) => { this.arrayTempOpenRow[i] = "expand_more"});
      this.arrayTempOpenRow[i] =
        this.expandedElement === row ? "expand_more" : "expand_less";
      this.expandedElement = this.expandedElement === row ? null : row;
    } else {
      return;
    }
  }

  seleccionarValidacionesErroneas(activar) {
    if (activar) {
      this.filtroBusquedaFG.controls["filtroEstadoSunat"].setValue("00");
      this.filtroBusquedaFG.controls["filtroEstadoSunat"].disable();
      this.filtroBusquedaFG.controls["tipoCpe"].setValue("00");
      this.filtroBusquedaFG.controls["tipoCpe"].disable();
    } else {
      this.filtroBusquedaFG.controls["filtroEstadoSunat"].enable();
      this.filtroBusquedaFG.controls["tipoCpe"].enable();
    }
  }

  mensajeError(data) {
     let rpta =
      data.elemento.mensajeError == null
        ? {}
        : JSON.parse(data.elemento.mensajeError);
    // rpta={"codigo":3025,"tipo":"ERROR","descripcion":"El dato ingresado en factor de cargo o descuento global no cumple con el formato establecido.","descripcion-adicional":{"mensaje-adicional":"Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal positivo de 3 enteros y hasta 2 decimales","campos-invalidos":{"//cac:AllowanceCharge/cbc:MultiplierFactorNumeric":"0.3333"}}}
    return rpta;
  }
  toolTipDescripcionEstado(row) {
    let rpta = "";
    if (row.estadoAnulado == 1 || row.estadoReversa == 1) {
      rpta =
        row.estadoAnulado == 1 ? "Anulado"
          : row.estadoReversa == 1 ? "Reversado"
          : "";
    }
    return rpta;
  }
  descargarCdr(idTrace:number, fechaEmision:Date) {
    this._transaccionService.getCdr(idTrace, fechaEmision).subscribe((response: any) => {
      if (response && response.estado) {
        let comprobanteCdr = response.comprobanteCdr;
        var dataCdr = atob(comprobanteCdr.xmlCdrBase64);
        var byteNumbers = new Array(dataCdr.length);
        for (var i = 0; i < dataCdr.length; i++) {
          byteNumbers[i] = dataCdr.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var txtBlob = new Blob([byteArray], { type: "zip" });
        this._FileSaverService.save(txtBlob, comprobanteCdr.nameXml);
      }else{
        if(isDevMode()){console.log(response.mensaje);}
      }
    });
  }

  descargarXML(idTrace:number, fechaEmision:Date) {
    this._transaccionService.getXML(idTrace, fechaEmision).subscribe((response: any) => {
      if (response && response.estado) {
        let comprobanteXML = response.comprobanteXML;
        let dataXML= atob(comprobanteXML.xmlCdr);
        let byteNumbers= new Array(dataXML.length);
        for (var i = 0; i < dataXML.length; i++) {
          byteNumbers[i] = dataXML.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        const txtBlob = new Blob([byteArray], { type: "xml; charset:utf-18" });
        this._FileSaverService.save(txtBlob, comprobanteXML.nameXml);
        // +".xml";
      }else{
        if(isDevMode()){console.log(response.mensaje);}
      }
    });
}

  // Verificacion de error Serie y Correlativo
  verifyErrorSerieCorrelativo(flagCorrelativo?:boolean) {
    if (flagCorrelativo) {
      let correlativo = this.filtroBusquedaFG.controls["correlativo"];
      correlativo.errors == null ? this.inputCorrelativoCorrecto = false : this.inputCorrelativoCorrecto = true;//return correlativo.errors == null ? responseverify : !responseverify;
    } else {
      let serie = this.filtroBusquedaFG.controls["serie"]; 
      serie.errors == null ?  this.inputSerieCorrecto = false :  this.inputSerieCorrecto = true;//return serie.errors == null ? responseverify : !responseverify;
    }
  }

  messageErrorSerieCorrelativo(flagCorrelativo?:boolean) {
    let correlativo = this.filtroBusquedaFG.controls["correlativo"];
    let serie = this.filtroBusquedaFG.controls["serie"];
    if (flagCorrelativo) {
      let errors = correlativo.errors;
      return errors == null
        ? this.matTooltipCorrelativo = ""
        : this.matTooltipCorrelativo = ErroresMensajes.ERRORMESSAGECORRELATIVO(errors);
    } else {
      let errors = serie.errors;
      return errors == null
        ? this.matTooltipSerie = ""
        : this.matTooltipSerie = ErroresMensajes.ERRORMESSAGESERIE(errors);
    }
  }

  //#region Tutorial Validaciones 
  resetTutorial() {
    this.goTutorial();
  }
  goTutorial() {
    this.saltarTutorial();
    this.tutorialSteps.step1 = true;
  }
  cnStep1() {
    this.saltarTutorial();
    this.tutorialSteps.step2 = true;
  }
  cnStep2() {
    this.saltarTutorial();
    this.tutorialSteps.step3 = true;
  }
  cnStep3() {
    this.saltarTutorial();
    this.tutorialSteps.step4 = true;
  }
  cnStep4() {
    this.saltarTutorial();
    this.tutorialSteps.step5 = true;
  }
  cnStep5() {
    this.saltarTutorial();
  }
  saltarTutorial() {
    this.tutorialSteps = {
      step1: false,
      step2: false,
      step3: false,
      step4: false,
      step5: false
    };
  }
  //#endregion
  
  //#region Tutorial tabla validaciones

  resetTutorialTable() {
    this.goTutorialTable();
  }
  goTutorialTable() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step1 = true;
  }

  tableStep1() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step2 = true;
  }
  tableStep2() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step3 = true;
  }
  tableStep3() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step4 = true;
  }
  tableStep4() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step5 = true;
  }
  tableStep5() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step6 = true;
  }
  tableStep6() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.step7 = true;
  }
  tableStep7() {
    this.saltarTutorialTable();
  }

  saltarTutorialTable() {
    this.tutorialTableSteps = {
      step1: false,
      step2: false,
      step3: false,
      step4: false,
      step5: false,
      step6: false,
      step7: false,
      detalleCorrecta: false,
      detalleIncorrecta: false
    };
  }
  //#endregion
  
  tableDetalleCorrecto() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.detalleCorrecta = true;
  }

  tableDetalleIncorrecto() {
    this.saltarTutorialTable();
    this.tutorialTableSteps.detalleIncorrecta = true;
  }

  consultarEstadoSUNAT(row:any) {
    this.dialog.open(EstadoSUNATComponent, {
      width: "460px",
      maxHeight: "80vh",
      data: { data: row }
    });
  }

  validarFiltrosFechas() {
    return this.verificarAntiguedad(
      this.filtroBusquedaFG.controls["fechaInicio"].value
    );
  }

  verificarAntiguedad(fechaRegistro) {
    const treintaDias = 1000 * 60 * 60 * 24 * 30;
    const resta = new Date().getTime() - treintaDias;
    const fechaHaceTreintaDias = new Date(resta);

    return new Date(fechaRegistro).getTime() < fechaHaceTreintaDias.getTime() ? true : false;

    // let mesAtras = new Date(
    //   this._reusableService.getToday().getTime() - 24 * 60 * 60 * 1000 * 31
    // ); //treinta dias atras, el dia 31 ya no hay data
    // return new Date(fechaRegistro).getTime() < mesAtras.getTime()
    //   ? true
    //   : false;
  }

  // #region Factoring
  coloresFactoring(i) {
    let valor = this.arrayTempFactoring[i].colores;

    if (valor.azul == true) {
      this.arrayTempFactoring[i].colores.azul = false;
      this.arrayTempFactoring[i].colores.amarillo = true;
      this.arrayTempFactoring[i].colores.verde = false;
      this.arrayTempFactoring[i].mensaje = "Esperando cotización";
      return;
    }
    if (valor.amarillo == true) {
      this.arrayTempFactoring[i].colores.azul = false;
      this.arrayTempFactoring[i].colores.amarillo = false;
      this.arrayTempFactoring[i].colores.verde = true;
      this.arrayTempFactoring[i].mensaje = "Factura aprobada";
      return;
    }
    if (valor.verde == true) {
      this.arrayTempFactoring[i].colores.azul = true;
      this.arrayTempFactoring[i].colores.amarillo = false;
      this.arrayTempFactoring[i].colores.verde = false;
      this.arrayTempFactoring[i].mensaje = "Vender Factura";
      return;
    }
  }
  //#endregion

  dialogViewTracking(id_Solicitud) {
    let dialogRef = this.dialog.open( MailTrackingComponent, {
      width: "580px",
      maxHeight: "80vh",
      data: {
        id_solicitud: id_Solicitud
      }
    });
  }

  //#region  exportar busqueda de comprobantes
  puedeExportarResultadoBusquedaCpe(){
    // if(this.filtrosBusquedaTemp.nomCPE==null || this.filtrosBusquedaTemp.nomCPE==""){
    if(this.filtrosBusquedaTemp2.filtro.nombreCpe==null || this.filtrosBusquedaTemp2.filtro.nombreCpe==""){
      this.maximaExportacionBusquedaCpe()
    }
    else{
      this.spinnerPuedeExportarResultadosBusquedaCpe = false;
      this.setExportarResultadosBusquedaCpe(false,"No se puede exportar la búsqueda realizada, elija otros criterios de búsqueda")
    }
  }

  maximaExportacionBusquedaCpe(){
    this._descargaBusquedaCpesService.getMaximaSolicitudExportacionCpe().subscribe(
      (response:ICantidadMaximaSolicitudExportacion)=>{
        this.spinnerPuedeExportarResultadosBusquedaCpe = false;
        if(response && response.estado){
            (response.reporteSolicitud.cantidadUtilizada>=response.reporteSolicitud.cantidadMaxima)?
              this.setExportarResultadosBusquedaCpe(false,"Excedio el límite de exportaciones diarias"):
              this.setExportarResultadosBusquedaCpe(true,`Cuenta con ${response.reporteSolicitud.cantidadMaxima - response.reporteSolicitud.cantidadUtilizada} exportacion(es) restantes`)
        }
        else{
          this.setExportarResultadosBusquedaCpe(false,"")
          if(isDevMode()){console.log(response.mensaje)}
        }
      }
    )
  }

  exportarBusqueda(){
    //obtener filtros busqueda guardados
    // mostrar mensaje de confirmacion
    // si acepta ir a listado de descarga de busqueda de comprobantesk
    // if(this.resultsLength>=1 && this.filtrosBusquedaTemp!=undefined){
      this.setExportarResultadosBusquedaCpe(false)

      let dataDialogConfirmacion : IDatosDialogConfirmacion = new CDatosDialogConfirmacion();
      dataDialogConfirmacion.mensaje = `¿Estás seguro que deseas exportar la búsqueda actual?, recuerda que las exportaciones son limitadas. ${this.mensajeExportarResultadosBusquedaCpe}`; 
      dataDialogConfirmacion.textoBotonCancelar = "No, todavía";
      dataDialogConfirmacion.textoBotonAceptar= "Si, estoy seguro";
      let dialogRef = this.dialog.open(SharedDialogConfirmacionComponent, {
        width: "400px",
        maxHeight: "80vh",
        data: dataDialogConfirmacion
      });
  
      dialogRef.afterClosed().subscribe(result =>{
        // if(result!=true){
        if(!result){
          this.setExportarResultadosBusquedaCpe(true)
          return;
        }
  
        this._snackBarClassShared.openSnackBar(`Generando archivo con los resultados de su búsqueda...`,6000,"OK")
        // si acepta ir a listado de descarga de busqueda de comprobantesk       
        //this.filtrosBusquedaTemp.estadoCpe = this.filtrosBusquedaTemp.estadoDoc;
        this._descargaBusquedaCpesService.exportarBusquedaCpe(this.filtrosBusquedaTemp2)
        .subscribe(
          (response:IResponseService)=>{
            this._snackBarClassShared.openSnackBar(response.mensaje,5000,"OK")
            if(response.estado){
              this.router.navigate(["home/descargaBusquedaComprobantes"]);
            }
            this.puedeExportarResultadosBusquedaCpe=true;
            //this.spinnerPuedeExportarResultadosBusquedaCpe=true;
          }
        )
  
      });

    // }
    // else{
    //   this._snackBarClassShared.openSnackBar("Primero debe realizar una búsqueda.",5000,'OK')
    // }

  }

  setExportarResultadosBusquedaCpe(puedeExportar:boolean, mensajeTooltip?:string){
    if( environment.ambiente=="beta"){
      this.puedeExportarResultadosBusquedaCpe=false;
      this.mensajeExportarResultadosBusquedaCpe="Esta funcionalidad no esta permitida para el ambiente actual.";
      return;
    }

    this.puedeExportarResultadosBusquedaCpe=puedeExportar;
    if(mensajeTooltip!=undefined){
      this.mensajeExportarResultadosBusquedaCpe=mensajeTooltip;}
  }

  setEnableListadoExportaciones(){
    if( environment.ambiente=="beta"){
      this.puedeVisualizarListadoExportaciones=false;
      this.mensajeVisualizarListadoExportaciones="Esta funcionalidad no esta permitida para el ambiente actual."
    }
    else{
      this.puedeVisualizarListadoExportaciones=true;
      this.mensajeVisualizarListadoExportaciones=""
    }
  }
  //#endregion
}

// function add(): void {
//   for(let permiso of this.listaPermisosBD){      
//     if(permiso === this.permiso.comprobantes_notificaciones){
//       this.tienePermiso.comprobantes_notificaciones = true;
//       this.displayedColumns.splice(4,0,"notificacion.estado");
//     }
//   }
// }