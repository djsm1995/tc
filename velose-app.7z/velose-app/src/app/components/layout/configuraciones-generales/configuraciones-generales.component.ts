import { Component, OnInit } from '@angular/core';
import { ConfiguracionesGeneralesService,permisosConfiguraciones,permisosConfiguracionesClass } from '../../../services/configuraciones-generales.service';

@Component({
  selector: 'app-configuraciones-generales',
  templateUrl: './configuraciones-generales.component.html',
  styleUrls: ['./configuraciones-generales.component.css']
})
export class ConfiguracionesGeneralesComponent implements OnInit {

//Permisos
listaPermisosBD: string[] = this._configuracionesGeneralesService.obtenerPermisos();
permiso = new permisosConfiguraciones();
tienePermiso = new permisosConfiguracionesClass();

constructor(private _configuracionesGeneralesService:ConfiguracionesGeneralesService) {
  this.obtenerPermisos();
 }


  ngOnInit() {
  }
  obtenerPermisos(){
    for(let permiso of this.listaPermisosBD){
      if(permiso === this.permiso.confi_notifi){
        this.tienePermiso.confi_notifi = true;
      }
    }
  }

  
}
