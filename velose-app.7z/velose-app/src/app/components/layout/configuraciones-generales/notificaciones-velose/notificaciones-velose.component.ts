import { Component, OnInit, Input } from '@angular/core';
import { ConfiguracionesGeneralesService,permisosConfNotificacionIncidencia,permisosConfNotificacionIncidenciaClass } from '../../../../services/configuraciones-generales.service';

@Component({
  selector: 'app-notificaciones-velose',
  templateUrl: './notificaciones-velose.component.html',
  styleUrls: ['./notificaciones-velose.component.css']
})
export class NotificacionesVeloseComponent implements OnInit {
   //Permisos
   listaPermisosBD: string[] = this._configuracionesGeneralesService.obtenerPermisos();
   permisoUsuario = new permisosConfNotificacionIncidencia();
   tienePermiso = new permisosConfNotificacionIncidenciaClass();

  constructor(private _configuracionesGeneralesService:ConfiguracionesGeneralesService) {
    this.obtenerPermisos();
   }

  ngOnInit() {
  }
  obtenerPermisos(){
    for(let permisoBD of this.listaPermisosBD){
      if(permisoBD === this.permisoUsuario.confi_notifi_incidencias){
        this.tienePermiso.confi_notifi_incidencias = true;
      }
      if(permisoBD === this.permisoUsuario.confi_notifi_incidencias_activarNotificacion){
        this.tienePermiso.confi_notifi_incidencias_activarNotificacion = true;
      }
      if(permisoBD === this.permisoUsuario.confi_notifi_incidencias_activarReenvio){
        this.tienePermiso.confi_notifi_incidencias_activarReenvio = true;
      } 
    }
  }
}
