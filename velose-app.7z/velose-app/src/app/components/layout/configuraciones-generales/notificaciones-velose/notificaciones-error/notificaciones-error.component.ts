import { Component, OnInit, isDevMode, Input } from '@angular/core';
import { FormGroup, Validators,FormControl } from '@angular/forms';
import { ConfiguracionesGeneralesService, interfaceDatosNotificacionExcepcion } from '../../../../../services/configuraciones-generales.service';
import { SnackBarConfigurationSharedComponent } from '../../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { Constante } from '../../../../../constantes/constante';
import { Validaciones } from '../../../../shared/validaciones';

@Component({
  selector: 'app-notificaciones-error',
  templateUrl: './notificaciones-error.component.html',
  styleUrls: ['./notificaciones-error.component.css']
})
export class NotificacionesErrorComponent implements OnInit {

  notificacionExcepcionesFormGroup:FormGroup;
  spinnerGuardando:boolean=false;
  spinnerConstructor:boolean=false;
  //PERMISOS
  @Input() confi_notifi_incidencias:boolean = false;
  @Input() confi_notifi_inciden_activarNotificacion:boolean = false;
  @Input() confi_notifi_inciden_activarReenvio:boolean = false;
  
  constructor(
    public _configuracionesGeneralesService: ConfiguracionesGeneralesService,
    public _snackBarClassShared: SnackBarConfigurationSharedComponent,
  ) 
  {
    this.spinnerConstructor=true;
    this.inicializarForm();
    this._configuracionesGeneralesService.getDatosExcepcion()
    .subscribe((response: any) => {
      if(isDevMode()) {console.log(JSON.stringify(response));}
      if (response.estado === true){
        this.setFormNotificacionIncidencias(response.datosNotificacionExcepcion);
        this.spinnerConstructor=false
      }
    });
    
  }

  // #region metodos
  inicializarForm(){
    this.notificacionExcepcionesFormGroup = new FormGroup({
      'estadoNotificacion':new FormControl(),
      'emailTo':new FormControl(
        {value:'',disabled: true },
        Validators.compose([
          Validators.email
        ])
      ),
      'estadoReenvio':new FormControl( {value:false,disabled: true }),
    });
    

    this.notificacionExcepcionesFormGroup.controls['estadoNotificacion'].valueChanges.subscribe(
      (data:boolean)=>{
        this.validatorsEmail(data);
        if(data){  
          this.notificacionExcepcionesFormGroup.controls['emailTo'].enable();
          this.notificacionExcepcionesFormGroup.controls['estadoReenvio'].enable()
        }
        else{
          this.notificacionExcepcionesFormGroup.controls['emailTo'].disable();
          this.notificacionExcepcionesFormGroup.controls['estadoReenvio'].disable()
        }
      }
    )
  }

  validatorsEmail(data:boolean){
    this.notificacionExcepcionesFormGroup.controls["emailTo"].clearValidators();
    if(data){
      this.notificacionExcepcionesFormGroup.controls["emailTo"].setValidators([Validators.email, Validaciones.NULL_O_VACIO])
    }
    else{
      this.notificacionExcepcionesFormGroup.controls["emailTo"].setValidators([Validators.email])
    }
    this.notificacionExcepcionesFormGroup.controls["emailTo"].markAsDirty();
    this.notificacionExcepcionesFormGroup.controls["emailTo"].markAsTouched();
    this.notificacionExcepcionesFormGroup.controls["emailTo"].updateValueAndValidity();

  }

  setFormNotificacionIncidencias(form: interfaceDatosNotificacionExcepcion){
    this.notificacionExcepcionesFormGroup.setValue(form)
  }

  ngOnInit() {
  }

  guardarNotificaciones(){
    if(this.notificacionExcepcionesFormGroup.valid && this.confi_notifi_inciden_activarNotificacion){
      this.spinnerGuardando=true;
      this._configuracionesGeneralesService.saveCorreo(this.notificacionExcepcionesFormGroup.value) 
      .subscribe((response: any) => {
        if (response.estado === true) {
          this.setFormNotificacionIncidencias(response.datosNotificacionExcepcion);
          this._snackBarClassShared.openSnackBar(
            (response.datosNotificacionExcepcion.estadoNotificacion)?
              "Se habilito correctamente el envío de notificaciones por incidencias":
              "Se inhabilito correctamente el envío de notificaciones por incidencias",
            6000,
            "OK"
          )
        }
      this.spinnerGuardando=false;
      });
    }
  }

  limpiarFormulario(){
    this.notificacionExcepcionesFormGroup.reset();
    this.notificacionExcepcionesFormGroup.updateValueAndValidity();
  }
  //#endregion

}
