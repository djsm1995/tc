import { Component, OnInit, ViewChild, isDevMode,AfterViewInit } from '@angular/core';
import { FiltrosBusquedaPadronesComponent } from './filtros-busqueda-padrones/filtros-busqueda-padrones.component';
import { ListadoPadronesComponent } from './listado-padrones/listado-padrones.component';
import { IRequestListadoPadrones, IDataListadoPadrones } from '../../../services/padrones.service';

@Component({
  selector: 'app-padrones',
  templateUrl: './padrones.component.html',
  styleUrls: ['./padrones.component.css']
})
export class PadronesComponent implements OnInit {

  step:number;
  nombreRazonSocial:string;

  busqueda:{estaBuscando:boolean, resultadosCantidad:number,mensajeRespuesta:string };

  @ViewChild('filtrosBusqueda',{static:false}) filtrosBusqueda:FiltrosBusquedaPadronesComponent;
  @ViewChild('listadoPadrones',{static:false}) listadoPadrones:ListadoPadronesComponent;

  constructor() { 
    this.inicializarVariables()

  }

  inicializarVariables():void{
    this.step=0;
    this.nombreRazonSocial=""
    this.busqueda={
      estaBuscando:false,
      resultadosCantidad:0,
      mensajeRespuesta:"",
    }
  }

  busquedaListado():void{
    this.filtrosBusqueda.emitEvent.subscribe((data:IDataListadoPadrones)=>{
      if(data!=null){   
        this.busqueda.resultadosCantidad= data.countResultados
        if(data.countResultados>0){
          this.step=1
          this.listadoPadrones.filtrosBusqueda=data
        }
      }
    })

    this.listadoPadrones.emitEvent.subscribe((data:boolean)=>{
      this.busqueda.estaBuscando=data
    })
  }


  ngOnInit() {
  }
  ngAfterViewInit(): void {
    this.busquedaListado();
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    
  }


  setStep(step:number){
    this.step=step
  }

}
