import { Component, OnInit, Input, ViewChild, isDevMode, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { switchMap, map, catchError, startWith } from 'rxjs/operators';
import { merge } from 'rxjs/observable/merge';
import { of as observableOf } from 'rxjs/observable/of';
import { DsComprobantesContingenciaComponent } from './datasource/ds-comprobantes-contingencia/ds-comprobantes-contingencia.component';
import { DsContribuyentesComponent } from './datasource/ds-contribuyentes/datasource-contribuyentes.component';
import { DsContrbuyenteAsociadoOseOPseComponent } from './datasource/ds-contrbuyente-asociado-ose-opse/ds-contrbuyente-asociado-ose-opse.component';
import { DsCertificadoEmisorComponent } from './datasource/ds-certificado-emisor/ds-certificado-emisor.component';
import { DsComprobantesComponent } from './datasource/ds-comprobantes/ds-comprobantes.component';
import { DsComprobantesFisicosComponent } from './datasource/ds-comprobantes-fisicos/ds-comprobantes-fisicos.component';
import { DsPadronContribuyenteComponent } from './datasource/ds-padron-contribuyente/ds-padron-contribuyente.component';
import { IRequestListadoPadrones, IDataListadoPadrones, PadronesService } from '../../../../services/padrones.service';

@Component({
  selector: 'app-listado-padrones',
  templateUrl: './listado-padrones.component.html',
  styleUrls: ['./listado-padrones.component.css']
})
export class ListadoPadronesComponent implements OnInit {

  @Input()
    set filtrosBusqueda(data:IDataListadoPadrones) {
      this.filtros=data.dataFiltros;
      this.countResultados=data.countResultados;
      this.getVariablesPaginacion();
    }
  filtros:IRequestListadoPadrones
  countResultados:number
  estaCargandoResultados:boolean

  @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;

  @ViewChild('dsContribuyentes',{static:false}) dsContribuyentes:DsContribuyentesComponent;
  @ViewChild('dsPadronContribuyentes',{static:false}) dsPadronContribuyentes:DsPadronContribuyenteComponent;
  @ViewChild('dsContribuyenteAsociadoOseOPse',{static:false}) dsContribuyenteAsociadoOseOPse:DsContrbuyenteAsociadoOseOPseComponent;
  @ViewChild('dsCertificadoEmisor',{static:false}) dsCertificadoEmisor:DsCertificadoEmisorComponent;
  @ViewChild('dsComprobantes',{static:false}) dsComprobantes:DsComprobantesComponent;
  @ViewChild('dsComprobantesFisicos',{static:false}) dsComprobantesFisicos:DsComprobantesFisicosComponent;
  @ViewChild('dsComprobantesContingencia',{static:false}) dsComprobantesContingencia:DsComprobantesContingenciaComponent;

  @Output() emitEvent:EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private _padronesService:PadronesService) { }

  ngOnInit() {
    this.inicializarVariables();
    
  }

  inicializarVariables(){
    this.emitirCargandoResultados(false)

    // this.estaCargandoResultados=false;
    this.filtros=null
    this.countResultados=0
  }
  getVariablesPaginacion(){
    

    this.paginator.pageIndex=0;
    this.paginator.pageSize=10;
    merge(this.paginator.page,this.paginator.initialized)
      .pipe(
      // startWith({}),
      switchMap(()=>{
        if(isDevMode()){
          console.log("switchmap")
        }
        this.filtros.page=this.paginator.pageIndex+1;
        this.filtros.num= this.paginator.pageSize;
        this.emitirCargandoResultados(true)
        return  this._padronesService.listadoBusquedaPadrones(this.filtros)
      }),
      map(data=>{
        this.emitirCargandoResultados(false)
        return data
      }),
      catchError(()=>{
        this.emitirCargandoResultados(false)
        return observableOf([])
      })
    ).subscribe((data:any[])=>{
      
      let nuevaData=[]
      if(data.length==undefined){
        nuevaData.push(data)
      }
      else{
        nuevaData=data
      }
      if(isDevMode()){
        console.log(data)
        console.log(data.length)
      }
      // if(data.length==0)
      this.setDataSource(nuevaData)
    })

  }

  setDataSource(data){
    switch (this.filtros.type) {
      case 1:
        this.dsContribuyentes.dataSource.data=data;
        break;
      case 2:
        this.dsPadronContribuyentes.dataSource.data=data;
        break;
      case 3:
        this.dsContribuyenteAsociadoOseOPse.dataSource.data=data;
        break;
      case 4:
        this.dsCertificadoEmisor.dataSource.data=data;
        break;
      case 5:
        this.dsComprobantes.dataSource.data=data;
        break;
      case 6:
        this.dsComprobantesFisicos.dataSource.data=data;
        break;
      case 7:
        this.dsComprobantesContingencia.dataSource.data=data;
        break;
    
      default:
        break;
    }
  }

  emitirCargandoResultados(estaCargando:boolean){
    this.estaCargandoResultados = estaCargando;
    this.emitEvent.emit(this.estaCargandoResultados);
  }

}

