import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-ds-comprobantes-fisicos',
  templateUrl: './ds-comprobantes-fisicos.component.html',
  styleUrls: ['./ds-comprobantes-fisicos.component.css']
})
export class DsComprobantesFisicosComponent implements OnInit {
  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {

  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","codigoComprobante","serie","inicioCpe","finCpe"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }

  sortData(sort:Sort){
    const data = this.dataSource.data;

    if (!sort.active || sort.direction === '') {
      this.dataSource.data = data
      return;
    }

this.dataSource.data=data.sort(
  (a,b)=>{
    const isAsc = sort.direction === 'asc';
    return  this.compare(a.codigo,b.codigo,isAsc)
  }
)
  }
  
  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
}
