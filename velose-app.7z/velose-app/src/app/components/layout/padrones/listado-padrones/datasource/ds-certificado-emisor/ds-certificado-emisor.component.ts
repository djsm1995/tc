import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-ds-certificado-emisor',
  templateUrl: './ds-certificado-emisor.component.html',
  styleUrls: ['./ds-certificado-emisor.component.css']
})
export class DsCertificadoEmisorComponent implements OnInit {

  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {

  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","idCd","fechaAlta","fechaBaja"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }

}
