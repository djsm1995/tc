import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-ds-contribuyentes',
  templateUrl: './datasource-contribuyentes.component.html',
  styleUrls: ['./datasource-contribuyentes.component.css']
})
export class DsContribuyentesComponent implements OnInit {

  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {

  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","estado","condicion"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }
}
