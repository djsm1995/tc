import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-ds-comprobantes',
  templateUrl: './ds-comprobantes.component.html',
  styleUrls: ['./ds-comprobantes.component.css']
})
export class DsComprobantesComponent implements OnInit {

  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {

  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","tipoComprobante","serie","numero","estadoCpe","moneda","importe","fechaEmision"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }
}
