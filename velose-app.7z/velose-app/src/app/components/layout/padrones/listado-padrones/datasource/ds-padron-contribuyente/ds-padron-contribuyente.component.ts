import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-ds-padron-contribuyente',
  templateUrl: './ds-padron-contribuyente.component.html',
  styleUrls: ['./ds-padron-contribuyente.component.css']
})
export class DsPadronContribuyenteComponent implements OnInit {


  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {
  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","padron"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }

}
