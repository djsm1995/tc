import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-ds-contrbuyente-asociado-ose-opse',
  templateUrl: './ds-contrbuyente-asociado-ose-opse.component.html',
  styleUrls: ['./ds-contrbuyente-asociado-ose-opse.component.css']
})
export class DsContrbuyenteAsociadoOseOPseComponent implements OnInit {

  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  constructor() { 
    this.inicializarVariables()
  }

  ngOnInit() {

  }
  inicializarVariables(){
    this.displayedColumns=[ "ruc","razonSocial","rucAsociado","tipoAsociacion","fechaInicio","fechaFin"];
    this.dataSource=new MatTableDataSource()
    this.dataSource.data=[]

  }

}
