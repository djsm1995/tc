import { Component, OnInit, isDevMode, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { IOpcionListadoPadrones, PadronesService, IRequestListadoPadrones, CRequestListadoPadrones, IDataListadoPadrones } from '../../../../services/padrones.service';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER} from '@angular/cdk/keycodes';
import { requestBusqueda } from '../../../../services/credenciales-homologacion.service';
import { distinctUntilChanged } from 'rxjs/operators';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { Catalogo, Cpe } from '../../../../constantes/catalogo';
import {Constante} from '../../../../constantes/constante';
import { Validaciones, ErroresMensajes } from '../../../shared/validaciones';


@Component({
  selector: 'app-filtros-busqueda-padrones',
  templateUrl: './filtros-busqueda-padrones.component.html',
  styleUrls: ['./filtros-busqueda-padrones.component.css']
})
export class FiltrosBusquedaPadronesComponent implements OnInit {
  busquedaComprobantes:boolean=false;
  busquedaComprobantesFisicosOContingencia:boolean=false;
 tooltipNombreComprobante:string="";
  filtroBusquedaFG:FormGroup;
  catalogoCPES: Cpe[];
  serieBusqueda = 4;

  
  opcionesListadoPadrones:IOpcionListadoPadrones[]
  nombreCpes:string[]
  disabledChipListNombreComprobantes:boolean

  // requestCount:IRequestListadoPadrones
  @Output() emitEvent:EventEmitter<IDataListadoPadrones> = new EventEmitter<IDataListadoPadrones>();

  @ViewChild("tooltipfield",{static:false}) tooltipField;

  constructor(private _padronesService:PadronesService,
    private _snackBarClassShared:SnackBarConfigurationSharedComponent) {
      this.cargarCatalogos();

     }

  ngOnInit() {
    this.cargarVariablesIniciales();
    this.filtroBusquedaFG = new FormGroup({
      listadoPadrones:new FormControl(1),
      serie: new FormControl({ value: "", disabled: false },[Validators.maxLength(4),Validators.minLength(4),Validators.pattern("^[0-9]*$")]),
      tipoCpe: new FormControl("0", [Validators.required]), //cpe todos x defecto
      rucEmisor: new FormControl("",[ Validaciones.NULL_O_VACIO,Validaciones.ES_NUMERO,Validaciones.RUC_VALIDO]),
      nombreComprobante: new FormControl(this.nombreCpes),
    });

    
    this.filtroBusquedaFG.controls["nombreComprobante"].valueChanges.subscribe(
     (data:any[]) =>{
if (data.length<10)   this.tooltipNombreComprobante=""
      }
    )
    this.filtroBusquedaFG.controls["listadoPadrones"].valueChanges.subscribe(
      (data:number)=>{
        if(isDevMode()){
          console.log(this.filtroBusquedaFG)
        }
        if(data==5){
          this.busquedaComprobantesFisicosOContingencia=false;
          this.filtroBusquedaFG.controls["rucEmisor"].disable()
          this.disabledChipListNombreComprobantes=false;
          this.filtroBusquedaFG.controls["rucEmisor"].clearValidators();
          this.filtroBusquedaFG.controls["nombreComprobante"].setValidators([Validaciones.NULL_O_VACIO])
          this.busquedaComprobantes=true;
        }
        else{
          this.busquedaComprobantesFisicosOContingencia=false;
          this.filtroBusquedaFG.controls["serie"].disable()
          this.filtroBusquedaFG.controls["tipoCpe"].disable()
          if(data==6 || data==7){
            this.busquedaComprobantesFisicosOContingencia=true;
            this.filtroBusquedaFG.controls["serie"].enable()
            this.filtroBusquedaFG.controls["tipoCpe"].enable()
          }
          this.busquedaComprobantes=false;
          this.filtroBusquedaFG.controls["rucEmisor"].enable()
          this.disabledChipListNombreComprobantes=true
          this.filtroBusquedaFG.controls["nombreComprobante"].clearValidators();
          this.filtroBusquedaFG.controls["rucEmisor"].setValidators([Validaciones.NULL_O_VACIO,Validaciones.ES_NUMERO,Validaciones.RUC_VALIDO])
        }
        this.filtroBusquedaFG.controls["rucEmisor"].updateValueAndValidity();
        this.filtroBusquedaFG.controls["nombreComprobante"].updateValueAndValidity();
      }
    )
  }

  cargarVariablesIniciales(){
    this.opcionesListadoPadrones=this._padronesService.getOpcionesListadoPadrones();
    this.cargarVariablesInicialesChips()
  }

  cargarVariablesInicialesChips():void{
    this.nombreCpes=[];
    this.disabledChipListNombreComprobantes=true
  }
  
  // #region filtros Formulario
  eliminarNombreCpe(cpe:string):void{
      const index = this.nombreCpes.indexOf(cpe);
  
      if (index >= 0) {
        this.nombreCpes.splice(index, 1);
        this.actualizarFCNombreComprobante()
      }
  }


  cargarCatalogos() {
    this.catalogoCPES = Catalogo.CPES.slice(0,7);
  }

    // Verificacion de error Serie y Correlativo
    verifyErrorSerieCorrelativo() {
      let responseverify = false;
  
         let serie = this.filtroBusquedaFG.controls["serie"];
        return serie.errors == null ? responseverify : !responseverify;
      //return false
      
    }

  messageErrorSerieCorrelativo(flagCorrelativo?) {
    let response = "";

    let serie = this.filtroBusquedaFG.controls["serie"];

      let errors = serie.errors;
      return errors == null
        ? response
        : ErroresMensajes.ERRORFILTROSERIEPADRONES(errors);
    
  }
  

  adicionarNombreCpe(event: MatChipInputEvent):void{
    const input = event.input;
    const value = event.value;

    if(isDevMode()){
      console.log(input)
      console.log(value)
    }    

    if ((value || '').trim()) {
   
      value.trim().split(/\s|,/).forEach((element)=>{
        if(this.nombreCpes.length>=10){
          this.tooltipNombreComprobante="La consulta se limita a 10 nombres de comprobante como maximo"
          this.tooltipField.show();
          return;
          }else {
            if(element.charAt(0)=="" || element.charAt(0)==" "){return}
            this.nombreCpes.push(element.trim())
            this.tooltipNombreComprobante=""
            this.tooltipField.hide()
          }
      })
      this.actualizarFCNombreComprobante()
    }

    if (input) {
      input.value = '';
    }
  }

  actualizarFCNombreComprobante(){
    this.filtroBusquedaFG.get("nombreComprobante").setValue(this.nombreCpes)

  }
  //#endregion


  // #region Metodos()
  BuscarPadrones(){
    this._padronesService.countBusquedaPadrones(this.requestFiltros()).subscribe((response:number)=>{
      if(isDevMode()){
        console.log(response)
      }
      if(response==0){
        this._snackBarClassShared.openSnackBar(
          "No se encontraron datos con los filtros proporcionados ",
          5000, "OK"
        )
      }

      let data:IDataListadoPadrones={
        countResultados:response,
        dataFiltros:this.requestFiltros()
      }
      this.emitEvent.emit(data);
      // this.requestCount=this.requestFiltros()
     
    })
  }

  limpiarFormularioResultado(){
    this.cargarVariablesInicialesChips()
    this.filtroBusquedaFG.reset({
      listadoPadrones:1,
      rucEmisor: "",
      serie:"",
      tipoCpe:"0",
      nombreComprobante: this.nombreCpes,
    })
    let data:IDataListadoPadrones={
      countResultados:0,
      dataFiltros:new CRequestListadoPadrones().base
    }
    this.filtroBusquedaFG.markAsPristine();
    this.filtroBusquedaFG.markAsUntouched();
    this.emitEvent.emit(data);
  }

  requestFiltros():IRequestListadoPadrones{
    let form= this.filtroBusquedaFG.value
    let request:IRequestListadoPadrones= new CRequestListadoPadrones().base

    request.type= form.listadoPadrones

    if(request.type==5){
      request.searchParam={nomCpe:form.nombreComprobante}
    }
    else if(request.type==6 || request.type==7){
      request.searchParam={ruc:form.rucEmisor}
      if(form.serie!="" && form.tipoCpe!=0 ){
        request.searchParam={ruc:form.rucEmisor,serie:form.serie,tipoCpe:form.tipoCpe}
      }else if(form.serie!=""){
        request.searchParam={ruc:form.rucEmisor,serie:form.serie}
      }else if(form.tipoCpe!=0){
        request.searchParam={ruc:form.rucEmisor,tipoCpe:form.tipoCpe}
      }
    }
    else{
      request.searchParam= {ruc:form.rucEmisor}
    }
  
    return request;
  }

  //#endregion
  

}
