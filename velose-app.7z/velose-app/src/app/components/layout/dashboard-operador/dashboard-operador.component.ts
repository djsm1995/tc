import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { DashboardOperadorService,  baseGraficoSeriesC } from '../../../services/dashboard-operador.service';
import {ReusableService} from '../../../services/reusable.service';
import {CorreosService} from '../../../services/correos.service';
import {Constante} from '../../../constantes/constante';
import {trigger,style,animate,transition} from '@angular/animations';
import { Subject } from 'rxjs/Subject';
import { interval } from "rxjs/observable/interval";
import { untilDestroyed } from "ngx-take-until-destroy";
import { environment } from '../../../../environments/environment';

const REFRESHDASHBOARD=5000 //segundos
const MAXIMO={ //SEGUNDOS
        metodosRecibidos:40000,
        comprobantesDeclarados:40000,
}
const TIEMPOENVIOCORREO=20000000 // SEGUNDOS
const CORREO="mery.santos@tci.net.pe" // "jmendoza@tci.net.pe"

@Component({
  selector: "app-dashboard-operador",
  templateUrl: "./dashboard-operador.component.html",
  styleUrls: ["./dashboard-operador.component.css"],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger("animationState", [
      transition(":leave", [
        style({
          opacity: 1
        }),
        animate(
          100,
          style({
            opacity: 0
          })
        )
      ])
    ])
  ]
})
export class DashboardOperadorComponent implements OnInit, OnDestroy {
  configuraciones = {
    comprobantesxDeclarar: {
      refreshDashboard: REFRESHDASHBOARD,
      maximo: MAXIMO.comprobantesDeclarados,
      tiempoEnvioCorreo: TIEMPOENVIOCORREO,
      correo: CORREO
    }
  };
  metodosRecibidos = {
    data: [
      {
        name: "SendBill",
        series: [
          {
            name: "09:19:47",
            value: 0
          },
          {
            name: "09:19:48",
            value: 0
          },
          {
            name: "09:19:49",
            value: 0
          },
          {
            name: "09:19:50",
            value: 0
          },
          {
            name: "09:19:51",
            value: 0
          },
          {
            name: "09:19:52",
            value: 0
          },
          {
            name: "09:19:53",
            value: 0
          },
          {
            name: "09:19:54",
            value: 0
          },
          {
            name: "09:19:55",
            value: 0
          },
          {
            name: "09:19:56",
            value: 0
          },
          {
            name: "09:19:57",
            value: 0
          },
          {
            name: "09:19:58",
            value: 0
          },
          {
            name: "09:19:59",
            value: 0
          },
          {
            name: "09:20:00",
            value: 0
          },
          {
            name: "09:20:01",
            value: 0
          }
        ]
      }
    ],
    colors: {},
    contador: 0,
    contadorNumero: 0,
    reference: [
      {
        name: "Umbral",
        value: MAXIMO.metodosRecibidos
      }
    ],
    contadorAlertas: 0,
    dataReporteAlertas: [],
    acumuladorSegundos: 0,
    correo: {
      template: "257f8665-2398-44ad-801b-05f8cb6c2766",
      subject: "[VelOSE] Comprobantes recibidos fuera del promedio"
    },
    firstLoad: true
  };
  comprobantesDeclarados = {
    data: [new baseGraficoSeriesC()],
    colors: {},
    contador: 0,
    contadorNumero: 0,
    reference: [
      {
        name: "Encolamiento",
        value: this.configuraciones.comprobantesxDeclarar.maximo
      }
    ],
    contadorAlertas: 0,
    dataReporteAlertas: [],
    acumuladorSegundos: 0,
    correo: {
      template: "e4d2c711-94f5-4647-9faf-ced443a88f62",
      subject: "[VelOSE] Encolamiento de comprobantes por declarar"
    },
    firstLoad: true
  };

  alertas = {
    metodosRecibidos: false,
    comprobantesDeclarados: false
  };
  ngUnsubscribe: Subject<boolean> = new Subject();
  private metodosRecibidos2 = [
    {
      name: "SendBill",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "SendSummary",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];

  //#region SendBill & SendSummary
  comprobantesXSegundoSendBill = {
    data: [],
    colors: Constante.coloresCpes,
    contador: 0,
    umbral: 40000,
    reference: [
      {
        name: "Umbral",
        value: MAXIMO.comprobantesDeclarados
      }
    ],
    dataAVisualizar: [],
    filtro: "All",
    contadorNumero: 0
  };
  comprobantesXSegundoSendSummary = {
    data: [],
    colors: Constante.coloresCpes,
    contador: 0,
    umbral: 40000,
    dataAVisualizar: [],
    filtro: "All",
    contadorNumero: 0
  };
  //#endregion
  // #region Data
  metodosRecibidosData = [
    {
      name: "SendBill",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "SendSummary",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesDeclaradosData = [
    {
      name: "SendBill",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "SendSummary",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesXSegundoSendBillData = [
    {
      name: "Factura",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Boleta",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Nota de Crédito",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Nota de Débito",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Servicios Públicos",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Retención",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Guía de Remisión",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesXSegundoSendSummaryData = [
    {
      name: "Resumen Diario de Boletas",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Comunicado de Bajas",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Reversión",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];

  //#endregion
  constructor(
    private _reusableService: ReusableService,
    private _correoService: CorreosService,
    private _dashboardService: DashboardOperadorService,
    private _changeDetector: ChangeDetectorRef
  ) {  }

  ngOnInit() {
    this.getDataDashboard();
  }
  ngOnDestroy() {
    this._changeDetector.detach();
    console.log("Destroyed");
  }

  // Carga Inicial
  getDataDashboard() {
    // COMPROBANTES RECIBIDOS
    let domainMR;
    this.metodosRecibidos.data = this.metodosRecibidosData;
    // interval(REFRESHDASHBOARD)
    //   .pipe(untilDestroyed(this))
    //   .subscribe(val => {
    //     let ultimaHora = this.getDataUltimaHora();
    //     this.generarDataGraficos(1, ultimaHora);
    //     // Cada tantos seg enviar correo si ocurrio alguna alerta.
    //     if (
    //       this.metodosRecibidos.acumuladorSegundos >= TIEMPOENVIOCORREO &&
    //       this.metodosRecibidos.contadorAlertas > 0
    //     ) {
    //       // Enviar correo
    //       this.sCorreo
    //         .sendCorreoComprobantesRecibidos(
    //           this.assembleDataCorreo(
    //             1,
    //             this.metodosRecibidos.correo.template,
    //             this.metodosRecibidos.correo.subject
    //           )
    //         )
    //         .pipe(untilDestroyed(this))
    //         .subscribe((response: any) => {
    //           // Enviando correo.
    //           console.log(
    //             "Correos: " +
    //               JSON.stringify(this.metodosRecibidos.dataReporteAlertas)
    //           );
    //           // REstaurar variables
    //           this.restaurarVariables(1);
    //         });
    //     }
    //     this.metodosRecibidos.acumuladorSegundos += REFRESHDASHBOARD;
    //   });
    domainMR = [Constante.colores.facturas, Constante.colores.boletas];
    this.metodosRecibidos.colors = { domain: domainMR };

    // COMPROBANTES x DECLARAR
    let comprobantesDeclarados, domainCD;
    this._dashboardService
      .getComprobantesxDeclarar(this.assembleRequestComprobantesXDeclarar())
      .subscribe((response: any) => {
        if (response && response.estado) {
          this.comprobantesDeclarados.data = response.Encolados;
          this.configuraciones.comprobantesxDeclarar = response.Configuraciones;

          this._changeDetector.detectChanges();
          // this.comprobantesDeclarados.reference[0].value= response.configuraciones.maximo
          this.comprobantesDeclarados.firstLoad = false;
          // console.log(this.configuraciones);

          interval(this.configuraciones.comprobantesxDeclarar.refreshDashboard)
            .pipe(untilDestroyed(this))
            .subscribe(val => {
              this.generarDataGraficos(2);
              // Cada tantos seg enviar correo si ocurrio alguna alerta.
              if (
                this.comprobantesDeclarados.acumuladorSegundos >=
                  this.configuraciones.comprobantesxDeclarar
                    .tiempoEnvioCorreo &&
                this.comprobantesDeclarados.contadorAlertas > 0
              ) {
                // Enviar correo
                this._correoService
                  .sendCorreoComprobantesRecibidos(
                    //reutilizando
                    this.assembleDataCorreo(
                      2,
                      this.comprobantesDeclarados.correo.template,
                      this.comprobantesDeclarados.correo.subject
                    )
                  )
                  .pipe(untilDestroyed(this))
                  .subscribe((response: any) => {
                    // Enviando correo.
                    console.log(
                      "Correos: " +
                        JSON.stringify(
                          this.comprobantesDeclarados.dataReporteAlertas
                        )
                    );
                    // REstaurar variables
                    this.restaurarVariables(2);
                  });
              }
              this.comprobantesDeclarados.acumuladorSegundos += this.configuraciones.comprobantesxDeclarar.refreshDashboard;
            });
        } else {
          // console.log(response)
          console.log("No response service Data x Delarar");
          //mostrar pantalla de error de carga
        }
      });
    domainCD = [Constante.colores.facturas, Constante.colores.boletas];
    this.comprobantesDeclarados.colors = { domain: domainCD };

    // COMPROBANTES X SEGUNDO SENDBILL
    this.comprobantesXSegundoSendBill.data = this.comprobantesXSegundoSendBillData;
    // this.comprobantesXSegundoSendBill.dataAVisualizar = this.comprobantesXSegundoSendBill.data;
    // interval(REFRESHDASHBOARD)
    //   .pipe(untilDestroyed(this))
    //   .subscribe(val => {
    //     let ultimaHora = this.getDataUltimaHora();
    //     this.generarDataGraficos(3, ultimaHora);
    //   });

    // COMPROBANTES X SEGUNDO SENDSUMMARY
    this.comprobantesXSegundoSendSummary.data = this.comprobantesXSegundoSendSummaryData;
    // this.comprobantesXSegundoSendSummary.dataAVisualizar = this.comprobantesXSegundoSendSummary.data;
    // interval(REFRESHDASHBOARD)
    //   .pipe(untilDestroyed(this))
    //   .subscribe(val => {
    //     let ultimaHora = this.getDataUltimaHora();
    //     this.generarDataGraficos(4, ultimaHora);
    //   });
  }
  generarDataGraficos(grafico, fecha?) {
    // Leyenda:
    // 1:comprobantesRecibidos
    // 2:comprobantes x declarar
    // 3:COMPROBANTES X SEGUNDO SENDBILL
    // 4:COMPROBANTES X SEGUNDO SendSummary

    let self = this;
    let alerta: boolean = false;
    switch (grafico) {
      case 1:
        if (this.metodosRecibidos.data && this.metodosRecibidos.data[0]) {
          // Agregar adicional y eliminar el primer dato para [0] y
          this.metodosRecibidos.contador = 0;
          this.metodosRecibidos.data.forEach(function(element, index) {
            let data = self.randomData(fecha);
            alerta = data.value >= MAXIMO.metodosRecibidos ? true : alerta;
            self.metodosRecibidos.data[index].series.push(data); //adicionar ultimo dato
            self.metodosRecibidos.data[index].series.shift(); //eliminar el primer dato
            if (data.value >= MAXIMO.metodosRecibidos) {
              self.metodosRecibidos.contadorAlertas++; //enviar correo cuando sucedio alguna alerta.
              // Creando dataReporte
              let dataReporte: any = {
                fecha: data.name,
                metodo: self.metodosRecibidos.data[index].name,
                valor: data.value
              };
              self.metodosRecibidos.dataReporteAlertas.push(dataReporte);
            }
            self.metodosRecibidos.contador += data.value; //prueba para miles
          });
          // Formato K y M
          this.metodosRecibidos.contadorNumero = this.metodosRecibidos.contador;
          this.metodosRecibidos.contador = this._reusableService.getFormatoMiles(
            self.metodosRecibidos.contador, 2
          );
          this.alertas.metodosRecibidos = alerta;
          this.metodosRecibidos.data = [...this.metodosRecibidos.data]; //atachar datos
        }
        break;
      case 2:
        if (
          this.comprobantesDeclarados.data &&
          this.comprobantesDeclarados.data[0]
        ) {
          // Agregar adicional y eliminar el primer dato para [0] y
          this._dashboardService
            .getComprobantesxDeclarar(
              this.assembleRequestComprobantesXDeclarar()
            )
            .pipe(untilDestroyed(this))
            .subscribe((response: any) => {
              if (response.estado) {
                this.comprobantesDeclarados.contador = 0;
                let encolados = response.Encolados;
                this.comprobantesDeclarados.data.forEach(function(
                  element,
                  index
                ) {
                  let data = encolados[index];
                  // console.log("data: " + data.series[0].value)

                  alerta =
                    data.series[0].value >=
                    self.configuraciones.comprobantesxDeclarar.maximo
                      ? true
                      : alerta;
                  // console.log(self.configuraciones.comprobantesxDeclarar.maximo)
                  // console.log("data.value: " + JSON.stringify( data))
                  // console.log("alerta: " + alerta)

                  self.comprobantesDeclarados.data[index].series.push(data.series[0]); //adicionar ultimo dato
                  self.comprobantesDeclarados.data[index].series.shift(); //eliminar el primer dato
                  if (
                    data.value >=
                    self.configuraciones.comprobantesxDeclarar.maximo
                  ) {
                    self.comprobantesDeclarados.contadorAlertas++; //enviar correo cuando sucedio alguna alerta.
                    // Creando dataReporte
                    let dataReporte: any = {
                      fecha: data.name,
                      metodo: self.comprobantesDeclarados.data[index].name,
                      valor: data.value
                    };
                    self.comprobantesDeclarados.dataReporteAlertas.push(
                      dataReporte
                    );
                  }
                  self.comprobantesDeclarados.contador += data.series[0].value; //prueba para miles
                });
                // Formato K y M
                self.comprobantesDeclarados.contadorNumero = self.comprobantesDeclarados.contador;
                this.comprobantesDeclarados.contador = this._reusableService.getFormatoMiles(
                  self.comprobantesDeclarados.contador, 2
                );
                //   this.alertas.metodosRecibidos = alerta ? alerta : false;
                this.alertas.comprobantesDeclarados = alerta;
                this.comprobantesDeclarados.data = [
                  ...this.comprobantesDeclarados.data
                ]; //atachar datos
              } else {
                console.log("Servicio erróneo NO first load");
              }
            });
        } else {
          console.log("Data incorrecta. Servicio Inicial");
        }
        break;
      case 3:
        if (
          this.comprobantesXSegundoSendBill.data &&
          this.comprobantesXSegundoSendBill.data[0]
        ) {
          // Agregar adicional y eliminar el primer dato para [0] y
          self.comprobantesXSegundoSendBill.contador = 0;
          this.comprobantesXSegundoSendBill.data.forEach(function(
            element,
            index
          ) {
            let data = self.randomData(fecha);
            // alerta= (data.value>=MAXIMO.comprobantesDeclarados)?true:alerta
            self.comprobantesXSegundoSendBill.data[index].series.push(data);
            self.comprobantesXSegundoSendBill.data[index].series.shift();
            self.comprobantesXSegundoSendBill.contador += data.value; //prueba para miles
          });
          // Formato K y M
          this.comprobantesXSegundoSendBill.contadorNumero = this.comprobantesXSegundoSendBill.contador;
          this.comprobantesXSegundoSendBill.contador = this._reusableService.getFormatoMiles(
            self.comprobantesXSegundoSendBill.contador, 2
          );
          // this.alertas.comprobantesDeclarados=(alerta)?alerta:false;
          this.comprobantesXSegundoSendBill.data = [
            ...this.comprobantesXSegundoSendBill.data
          ];
          this.filtroDataSendBill(this.comprobantesXSegundoSendBill.filtro);
        }
        break;
      case 4:
        if (
          this.comprobantesXSegundoSendSummary.data &&
          this.comprobantesXSegundoSendSummary.data[0]
        ) {
          // Agregar adicional y eliminar el primer dato para [0] y
          self.comprobantesXSegundoSendSummary.contador = 0;
          this.comprobantesXSegundoSendSummary.data.forEach(function(
            element,
            index
          ) {
            let data = self.randomData(fecha);
            // alerta= (data.value>=MAXIMO.comprobantesDeclarados)?true:alerta
            self.comprobantesXSegundoSendSummary.data[index].series.push(data);
            self.comprobantesXSegundoSendSummary.data[index].series.shift();
            self.comprobantesXSegundoSendSummary.contador += data.value; //prueba para miles
          });
          // Formato K y M
          this.comprobantesXSegundoSendSummary.contadorNumero = this.comprobantesXSegundoSendSummary.contador;
          this.comprobantesXSegundoSendSummary.contador = this._reusableService.getFormatoMiles(
            self.comprobantesXSegundoSendSummary.contador, 2
          );
          // this.alertas.comprobantesDeclarados=(alerta)?alerta:false;
          this.comprobantesXSegundoSendSummary.data = [
            ...this.comprobantesXSegundoSendSummary.data
          ];
          this.filtroDataSendSummary(
            this.comprobantesXSegundoSendSummary.filtro
          );
        }
        break;
    }
    // Actualizar
    this._changeDetector.markForCheck();
  }

  //#region Utilitarios
  restaurarDatos() {
    this.metodosRecibidos.data = [];
  }
  restaurarVariables(grafico) {
    switch (grafico) {
      case 1:
        this.metodosRecibidos.contadorAlertas = 0;
        this.metodosRecibidos.acumuladorSegundos = 0;
        this.metodosRecibidos.dataReporteAlertas = [];
        break;
      case 2:
        this.comprobantesDeclarados.contadorAlertas = 0;
        this.comprobantesDeclarados.acumuladorSegundos = 0;
        this.comprobantesDeclarados.dataReporteAlertas = [];
        break;
    }
  }
  getDataUltimaHora() {
    let fecha = new Date();
    let horas, minutos, segundos;
    horas = this._reusableService.padLeft(fecha.getHours());
    minutos = this._reusableService.padLeft(fecha.getMinutes());
    segundos = this._reusableService.padLeft(fecha.getSeconds());
    let rpta = `${horas}:${minutos}:${segundos}`;
    return rpta;
  }
  randomData(fecha) {
    let data;
    data = {
      name: fecha,
      value: this._reusableService.getRndInteger(1, 50000)
    };
    return data;
  }
  assembleDataCorreo(tipo, template, subject) {
    // Obtener data a enviar
    let dataComprobantes: string = "";
    switch (tipo) {
      case 1:
        this.metodosRecibidos.dataReporteAlertas.forEach(element => {
          let data = `<tr>
                  <td class="medColumna">${element.fecha}</td>
                  <td class="medColumna">${element.metodo}</td>
                  <td class="medColumna"> ${element.valor}</td>
                </tr>`;
          dataComprobantes += data;
        });
        break;
      case 2:
        this.comprobantesDeclarados.dataReporteAlertas.forEach(element => {
          let data = `<tr>
                  <td class="medColumna">${element.fecha}</td>
                  <td class="medColumna">${element.metodo}</td>
                  <td class="medColumna"> ${element.valor}</td>
                </tr>`;
          dataComprobantes += data;
        });
        break;
    }

    let parametros = {
      template: template,
      to: CORREO,
      // "cc": ["rymesz@gmail.com"],
      parameters: [
        {
          fieldName: "urlVelose",
          fieldValue: `${environment.endpointVelose}`
        },
        {
          fieldName: "dataComprobantes",
          fieldValue: dataComprobantes
        }
      ],
      subject: subject
    };
    return parametros;
  }
  assembleRequestComprobantesXDeclarar() {
    return { idPse: null, firstLoad: this.comprobantesDeclarados.firstLoad };
  }
  //#endregion

  //#region SendBill
  filtroDataSendBill(value: any) {
    if (value == "All") {
      this.comprobantesXSegundoSendBill.dataAVisualizar = [];
      this.comprobantesXSegundoSendBill.dataAVisualizar = this.comprobantesXSegundoSendBill.data;
    } else {
      this.comprobantesXSegundoSendBill.dataAVisualizar = [
        this.comprobantesXSegundoSendBill.data[value]
      ];
    }
    this._changeDetector.detectChanges();
  }

  filtroDataSendSummary(value: any) {
    if (value == "All") {
      this.comprobantesXSegundoSendSummary.dataAVisualizar = [];
      this.comprobantesXSegundoSendSummary.dataAVisualizar = this.comprobantesXSegundoSendSummary.data;
    } else {
      this.comprobantesXSegundoSendSummary.dataAVisualizar = [
        this.comprobantesXSegundoSendSummary.data[value]
      ];
    }
    this._changeDetector.detectChanges();
  }
  //#endregion
}
