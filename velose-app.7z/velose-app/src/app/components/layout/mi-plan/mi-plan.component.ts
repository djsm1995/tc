import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import {FormGroup, Validators,FormControl} from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {baseGraficoValue,baseGraficoValueC}from '../../../services/dashboard.service';
import {DashboardService,responseCpesDisponibles}  from '../../../services/dashboard.service';
import {MiplanService,responseMiPlan,miPlanC,MiPlan}  from '../../../services/miplan.service';
import {ReusableService} from '../../../services/reusable.service';
import {ConfirmacionCompraComponent} from './confirmacion-compra/confirmacion-compra.component';
import {RegisterService,clientePagoC,ClientePago} from '../../../services/register.service';

const coloresCpes={
  facturas:"#062a78", //azul
  boletas:"#2ECC71", //verde
  nc:"#F44437", //rojo
  nd:"#9B59B6", //morado
  gre:"#F5802D",
  dae:"#9DC1E0",
  rc:"gray",
  cb:"yellow",
  rv:"orange",
  plomo:"#DEDEDE"
}

@Component({
  selector: 'app-mi-plan',
  templateUrl: './mi-plan.component.html',
  styleUrls: ['./mi-plan.component.css']
})


export class MiPlanComponent implements OnInit {
  datosCpesDisponibles:baseGraficoValue[]= [new baseGraficoValueC()];
  colorSchemeCpesDisponibles ={domain:[coloresCpes.facturas]};
  validacionesUtilizadas = 0;

  dataMiPlan= new miPlanC();
  mensajePlanNoActivo="No cuentas con un plan activo.";
  activaCompraPlan : boolean;
  activaCompraDiasPrevios : number;

  validacionCtrl: FormControl;
  isLoadingDatosCpesDisponibles:boolean;
  esPlanIlimitado=false;

  constructor(private _datosDashboard:DashboardService,
              private _miPlan:MiplanService,
              private sReusable:ReusableService,
              public _dialog:MatDialog,
              private cd:ChangeDetectorRef,

              )
  {
    //console.log(this.datosCpesDisponibles)
    let idPse=this.sReusable.getSessionUsuario().empresa.idPse
    this._miPlan.getMiPlan( idPse ) //416 344 idPse
        .subscribe((response:responseMiPlan)=>{

          if(response && response.estado){
            this.dataMiPlan=response.datos
            this.activaCompraPlan = this.dataMiPlan['activaCompraPlan'];
            this.activaCompraDiasPrevios = this.dataMiPlan['activaCompraDiasPrevios'];
            
            if(this.planActivo()) {
              //console.log("Plan Activo:  " + JSON.stringify(this.dataMiPlan))

            } else {
              this.activaCompraPlan = true;
              this.dataMiPlan= new miPlanC();
              //console.log("No hay plan activo");
            }
          };
        });
  }

  ngOnInit() {
    // Doughnout cpes dispoj
    let idPse=this.sReusable.getSessionUsuario().empresa.idPse
    this.validacionCtrl= new FormControl(10000,[Validators.required,Validators.maxLength(10)])
    this.isLoadingDatosCpesDisponibles=true;

    this._datosDashboard.getCpesDisponiblesD( idPse )
        .subscribe((response:responseCpesDisponibles)=>{
          if(response && response.estado){
            let disponibles = response.cpesDisponibles
            this.validacionesUtilizadas = disponibles.validacionUtilizadas;
            this.esPlanIlimitado = (disponibles.planIlimitado)?true:false;

            if(disponibles.dataValidaciones!= null && disponibles.dataValidaciones.length>0){
              this.datosCpesDisponibles= disponibles.dataValidaciones
            }
            this.colorSchemeCpesDisponibles.domain.push(coloresCpes.plomo)

            this.isLoadingDatosCpesDisponibles=false;
            this.cd.detectChanges();

          };
        });
  }
  ngOnDestroy() {
    this.cd.detach();
    // unsubscribe
  }
  // cpesDisponibles
  getCpeDisponibleValue(){
    // [0]:Utilizados
    // [1]:Disponibles

    if(this.datosCpesDisponibles[1]!=undefined )
      return this.datosCpesDisponibles[1].value
    else{
      return (this.datosCpesDisponibles[0].name=="Disponibles")?
               this.datosCpesDisponibles[0].value:0;
    }

  }
  getTotalCpeValue(){
    let acumulado:number=0;
    this.datosCpesDisponibles.forEach(
      function(data){
          acumulado+=Number(data.value)
    });
    return acumulado
  }
  getcostoValidaciones(validaciones,valorunitario){
      let value=validaciones*valorunitario
      const f = Math.pow(10, 2);
      return (Math.trunc(value*f)/f).toFixed(2);
   }
  getFechasPlanes():any{
    let rpta:any={}
    if(this.dataMiPlan){
      rpta={
        fechaInicio:this.sReusable.getFormatoFecha(new Date(this.dataMiPlan.fechaInicio),4),
        fechaFin:this.sReusable.getFormatoFecha(new Date(this.dataMiPlan.fechaFin),4),
        fechaProximoCiclo:(this.dataMiPlan.proximoCiclo)?
                            this.sReusable.getFormatoFecha(new Date(this.dataMiPlan.fechaProximoCiclo),4):
                            null,
      }
    }
    return rpta;
  }
  getFechaValidacion(){
    let cantidadValidaciones=this.dataMiPlan.validacionAdicional
    if(cantidadValidaciones!= undefined && cantidadValidaciones>0)
      return this.sReusable.getFormatoFecha(new Date(this.dataMiPlan.lstPqtAdicional[0].fechaFin),4)
    else
      return "--"
  }
  getValidacion(){
    let cantidadValidaciones=this.dataMiPlan.validacionAdicional
    if(cantidadValidaciones!= undefined)
      return cantidadValidaciones
    else
      return "0"
  }

  // PlanActivo y proximo Ciclo
  planActivoIlimitado(){return this.planActivo() && !this.dataMiPlan.ilimitado }
  planActivo(){ return this.dataMiPlan.planActivo }

  // Confirmar Compra
  confirmarCompra(){
    let dialogRef;
    let nombre="dfsdf"
    setTimeout(() =>
          dialogRef = this._dialog.open(ConfirmacionCompraComponent, {
            width: '400px',
            data: {
              validaciones:this.assembleValidaciones(),
              plan: this.assemblePlan(),
              facturacion: this.assembleFacturacion()
            }
          })
          , 0);
  }
  assembleValidaciones(){
    let validaciones:any;
    let precioUnitario= this.dataMiPlan.adicional.precioUnitario;
    // let costoPago:number=Number(this.sReusable.toFixedTrunc(this.validacionCtrl.value * precioUnitario,2));
    let costoPago:number=Number(this.validacionCtrl.value * precioUnitario);
    let montoIgv:number= costoPago * Number(this.dataMiPlan.adicional.igv);
    let totalPago:number= costoPago + montoIgv

    validaciones={
      cantidad:this.validacionCtrl.value,//1000
      precioUnitario:precioUnitario,//0.01
      costoPago: this.sReusable.Redondeo2Decimales(costoPago),//10
      montoIgv: this.sReusable.Redondeo2Decimales(montoIgv),//1.80
      // totalPago:this.sReusable.toFixedTrunc(totalPago,2),//11.8
      totalPago:this.sReusable.Redondeo2Decimales(totalPago),//11.8
      moneda:this.dataMiPlan.adicional.moneda,//
      codMoneda:this.dataMiPlan.adicional.codMoneda,
      validoHasta:this.sReusable.getFormatoFecha(
                  new Date(this.dataMiPlan.adicional.fechaFin),4),
    }
    //console.log(validaciones)
    return validaciones;
  }
  assemblePlan(){

    let plan:any;
    plan={
      idPlan:this.dataMiPlan.adicional.idPlan,
      id:this.dataMiPlan.adicional.id,
      descripcion:`${this.dataMiPlan.adicional.nombrePlan} x ${ this.validacionCtrl.value} validaciones`  ,
    }
    return plan;
  }
  assembleFacturacion(){
    let facturacion:any;
    facturacion={
      correo:this.dataMiPlan.correoFact,
      nombre:this.dataMiPlan.nombreContactoFact,
      apellido:this.dataMiPlan.apellidoContactFact,
    }
    return facturacion;
  }

  controlNumeroValidaciones(){
    if (String(this.validacionCtrl.value).length > 10){
      this.validacionCtrl.setValue(String(this.validacionCtrl.value).slice(0,10));
    }
  }

}
