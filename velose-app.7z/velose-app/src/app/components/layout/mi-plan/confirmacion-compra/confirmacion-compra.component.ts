import { Component, OnInit,Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {Validators,FormControl,FormGroup} from '@angular/forms';
import {Constante} from '../../../../constantes/constante';
import {Observable} from 'rxjs/Observable';
import {PagoService} from '../../../../services/pago.service';
import {PlanesService} from '../../../../services/planes.service';
import {MiplanService} from '../../../../services/miplan.service';
import {RegisterService,operacionPagoC,Pago,PagoRC,rptaPagoAlignedC,rptaPagoAligned} from '../../../../services/register.service';
import {Router } from '@angular/router';
import {ReusableService} from '../../../../services/reusable.service';


declare var PF:any;
@Component({
  selector: 'app-confirmacion-compra',
  templateUrl: './confirmacion-compra.component.html',
  styleUrls: ['./confirmacion-compra.component.css']
})
export class ConfirmacionCompraComponent implements OnInit {
  confirmacionFG: FormGroup;
  step={
    confirmacion:true,
    pago:false
  }
  operacionActual:any;
  transaccionPagoOK=false;
  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
              public _pago:PagoService, public _planes:PlanesService,
              public _registroS:RegisterService,
              private sReusable:ReusableService,
              private _miPlan:MiplanService,
              private router:Router) { }

  ngOnInit() {
    let facturacion=this.data.facturacion
    this.confirmacionFG=new FormGroup({
      'nombreFacturacion':new FormControl(facturacion.nombre,
                                          [ Validators.required,
                                            Validators.maxLength(80)]
                                          ),
      'apellidoFacturacion':new FormControl(facturacion.apellido,
                                            [ Validators.required,
                                              Validators.maxLength(80)]
                                            ),
      'correoFacturacion':new FormControl(facturacion.correo,
                                          [ Validators.required,
                                            Validators.maxLength(250),
                                            Validators.email]
                                          ),
    });
  }

  comprarValidaciones(){
    this.activacionPasos();
    console.log(Math.round(this.data.validaciones.totalPago*100)/100)
    // Llamada Alignet
    this._pago.getNroOperacionHash(this.assembleDatoPagoService())
    .subscribe(rpta=>{

      let rptaC:any = rpta;
      console.log(rpta)
      if(rptaC.estado=!null && rptaC.estado){
        this.operacionActual=rpta;
        let precioPlan=Math.round(this.data.validaciones.totalPago*100)/100
        console.log(this.data.validaciones.codMoneda)
        var self=this;
        var session=self.sReusable.getSessionUsuario()
        var resultadoDepartamento=self.onSelectDepartamento(session.empresa.ubigeo);
        var resultadoProvincia=self.onSelectProvincia(session.empresa.ubigeo,resultadoDepartamento.posicion);
        PF.Init.execute({
          data: {
            operation: {
              operationNumber:String(this.operacionActual.idOperation), //100009
              // amount: String(this.sReusable.toFixedTrunc(precioPlan,2)),
              amount: String(this.sReusable.Redondeo2Decimales(precioPlan)),
              currency: {
                code: this.data.validaciones.codMoneda,//'PEN',
                symbol: this.data.validaciones.moneda //'S/.'
              },
              productDescription: this.data.plan.descripcion// 'Plan 8 x 1000 val'
            },
            customer: {
              name: session.nombre,//'Jonatham',
              lastname:`${session.apellidoPaterno} ${session.apellidoMaterno}`,// 'Mendoza Vasquez',
              email: session.correo,//'jonatham.mendoza@gmail.com',
              address:session.empresa.direccion,// 'Av Casimiro Ulloa 333',
              zip: session.empresa.ubigeo,//'051 42',
              city: resultadoDepartamento.descripcion,//'Lima',
              state: resultadoProvincia.descripcion,//'Lima',
              country: "Perú",//'Peru',
              phone: session.empresa.telefono,//'997558332'
            },
            signature: this.operacionActual.signature//'1b48272013d9c74d06f737fcbf54f82aff24fbe33b4222575b6a1d58d62bde3b4de6fd6071398c1f302872e313fdd3af17b08a5704db40f9b83035be50326181'
          },
          listeners: {
            afterPay: function(response){

              console.log( response);
              self.rptaCompra(response);
              // self.rptaRegistro(response);
            }
          },
          settings:{
            key:Constante.PUBLICKEY,
            locale: 'es_PE',
            identifier: Constante.IDENTIFIERCOMERCE,
            brands: ['VISA','AMEX','MSCD','DINC'],
            responseType:'extended'
          }
        });
      }
    });
  }

  rptaCompra(rptaPago){
    console.log(rptaPago)
    if(rptaPago.success=="true" && rptaPago.payment.accepted=="true"){
    // let valor=true
    // if(valor){
      console.log("Payment:" +rptaPago.payment.accepted )
      this.transaccionPagoOK= !this.transaccionPagoOK;
      this.registrarPagoAlignet(rptaPago);
      this.registrarCompra(rptaPago);
      // else: A futuro enviar servicio de venta que enviara objeto pago

    }
    else{
      this.registrarPagoAlignet(rptaPago);
    }
  }
  registrarPagoAlignet(rptaPago){
    this._registroS.registroPagoAlignet(this.assemblePagoAlignet(rptaPago))
      .subscribe(rpta=>{
        console.log(rpta)
      });
  }
  registrarCompra(rptaPago){
    this._miPlan.comprarPaqueteAdicional(this.assemblecomprarPaqueteAdicional(rptaPago))
      .subscribe((response:any)=>{
        console.log(response)
        if(response && response.estado){
          console.log("dato")
          this.router.navigate(['home/dashboard'])
          // this.router.navigate(['home/miPlan'])
        }
      });
  }
  assemblePagoAlignet(rptaPago){
    let datos= new rptaPagoAlignedC();
    datos.idOperacion=this.operacionActual.idOperation;
    datos.eci=(rptaPago.features==null)?null:rptaPago.features.authentication.eci;
    datos.vci=(rptaPago.features==null)?null:rptaPago.features.authentication.vci;
    datos.messageCode=rptaPago.messageCode;
    datos.message=rptaPago.message;
    if (rptaPago.payment != null){
      datos.pasarelaResultRequest={
        nombreTitular:`${rptaPago.payment.cardholderInformation.lastname} ${rptaPago.payment.cardholderInformation.name}`,
        digitosTarjeta:(rptaPago.payment.lastPan==undefined)?null:rptaPago.payment.lastPan,
        codigoResultado:rptaPago.payment.resultCode,
        mensajeResultado:rptaPago.payment.resultMessage,
        tipoTarjeta:(rptaPago.payment.creditDebit==undefined)?null:rptaPago.payment.creditDebit,
        estado:rptaPago.payment.accepted,
        bin:(rptaPago.payment.bin==undefined)?null:rptaPago.payment.bin,
      }
    }
    return datos;
  }
  assembleDatoPagoService(){
    let datos=new operacionPagoC();
    let session=this.sReusable.getSessionUsuario()
    datos={
      nombreUsuario:session.nombre,
      correo:session.correo,
      telefono:session.empresa.telefono,
      monto:Number(this.sReusable.toFixedTrunc(this.data.validaciones.totalPago,2)),
      simboloMoneda:this.data.validaciones.moneda,
      codigoMoneda:this.data.validaciones.codMoneda,
      ubigeo:session.empresa.ubigeo,
      direccion:session.empresa.direccion,
      idPlan:this.data.plan.idPlan
    }
    console.log(datos.monto);
    // datos.nombreUsuario=session.nombre;
    // datos.correo=session.correo;
    // datos.telefono=session.empresa.telefono;
    // datos.monto=Number(this.sReusable.toFixedTrunc(this.data.validaciones.totalPago,2));
    // datos.simboloMoneda=this.data.validaciones.moneda;
    // datos.codigoMoneda=this.data.validaciones.codMoneda;
    // datos.ubigeo=session.empresa.ubigeo;
    // datos.direccion=session.empresa.direccion;
    // datos.idPlan=this.data.plan.idPlan;
    // console.log(datos.monto);
    // console.log(datos.codigoMoneda);

    return datos;
  }
  assemblecomprarPaqueteAdicional(rptaPago){
    let rpta
    rpta={
      "idPlan" : this.data.plan.idPlan,
      "idPlanOpcion": this.data.plan.id,
      "idOperacion": this.operacionActual.idOperation,
      "idPse": this.sReusable.getSessionUsuario().empresa.idPse,
      "cantidad" : this.data.validaciones.cantidad,
      "precio" : this.data.validaciones.totalPago,
      "correoFact" : this.data.facturacion.correo,
      "nombreContactoFact" : this.data.facturacion.nombre,
      "apellidoContactFact" : this.data.facturacion.apellido
    }
    console.log(rpta)
    return rpta
  }

  onSelectDepartamento(zip){
    let zipDepartamento= zip.substring(0,2);
    let ubigeo= Constante.UBIGEO;
    let rpta={
      posicion:0,
      descripcion:"department"
    };
    for (var i = 0; i < ubigeo.length; i++) {
      if (zipDepartamento==ubigeo[i].cod_Locacion){
        rpta.descripcion=ubigeo[i].descripcion;
        rpta.posicion=i;
        break;
      }
    }
    return rpta
  }
  onSelectProvincia(zip,posicion){
    let zipDepartamento= zip.substring(0,4);
    let ubigeo= Constante.UBIGEO[posicion].lstUbigeo;

    let rpta={
      posicion:0,
      descripcion:"state"
    };
    for (var i = 0; i < ubigeo.length; i++) {
      console.log[i]
      if (zipDepartamento==ubigeo[i].cod_Locacion){

        rpta.descripcion=ubigeo[i].descripcion;
        rpta.posicion=i;
        break;
      }
    }
    return rpta
  }

  getTotales(){
    let rpta={
      costoPago: this.data.validaciones.costoPago,
      igv: this.data.validaciones.montoIgv,
      totalPago:this.data.validaciones.totalPago,
    }
    console.log(rpta);
    return  rpta;
  }
  // Steps
  activacionPasos(){
    this.step.confirmacion=!this.step.confirmacion
    this.step.pago=!this.step.pago
  }


}
