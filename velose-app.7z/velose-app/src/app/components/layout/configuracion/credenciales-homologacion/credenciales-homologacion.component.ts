import { Component, OnInit, isDevMode } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Validaciones } from '../../../shared/validaciones';
import { CredencialesHomologacionService, requestBusqueda, responseCrearCredencial } from '../../../../services/credenciales-homologacion.service';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { servicesVersion } from 'typescript';


@Component({
  selector: "app-credenciales-homologacion",
  templateUrl: "./credenciales-homologacion.component.html",
  styleUrls: ["./credenciales-homologacion.component.css"]
})
export class CredencialesHomologacionComponent implements OnInit {
  // #region Variables
  rucGeneracion: FormControl;
  rucBusqueda: FormControl;
  result = {
    length: 0,
    rptaCount: "",
    max:10
  };
  dataSource = new MatTableDataSource();
  displayedColumns = ['ruc,razonSocial,claveGenerada', 'acciones']
  //#endregion

  constructor(
    private _credencialesHomologacion: CredencialesHomologacionService,
    public snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.rucGeneracion = new FormControl("", [
      Validators.required,
      Validaciones.ES_NUMERO,
      Validaciones.RUC_VALIDO
    ]);
    this.rucBusqueda = new FormControl("");

    // this.rucBusqueda.valueChanges.subscribe(
    //   (data:string)=>{
    //     console.log(data.length);
    //     if(data && data.length>=1){
    //       this.rucBusqueda.setValidators([
    //         Validators.required,
    //         Validaciones.ES_NUMERO,
    //         Validaciones.RUC_VALIDO
    //       ])
    //     }
    //     else{
    //       this.rucBusqueda.setValidators([]);
    //     }
    //     this.rucBusqueda.updateValueAndValidity();
    //   });
  }

  GenerarClave() {
    // enviar ruc y flagconfirmacion
    let request = new requestBusqueda();
    request.ruc = this.rucGeneracion.value;
    this._credencialesHomologacion
      .generarCredenciales(request)
      .subscribe((response: responseCrearCredencial) => {
        if(isDevMode()) {console.log(response);}
        if (response.estado && response.flagConfirmacion) {
          // mostrar mensaje
          let mensajeAdicional: string =
            " ¿Quiere generar una nueva clave? Recuerde que el cliente esta en producción.";
          let snackbar = this.snackBar.open(
            response.mensaje + mensajeAdicional,
            "Si,quiero",
            { duration: 8000 }
          );
          snackbar.onAction().subscribe(() => {
            // aprueba que se cambie la contraseña aun cuando esta en produccion
            request.flagConfirmacion = true;
            this._credencialesHomologacion
              .generarCredenciales(request)
              .subscribe((response: responseCrearCredencial) => {
                if (response.estado) {
                  this.mostrarMensaje(response.mensaje);
                }
              });
          });
        } else {
          this.mostrarMensaje(response.mensaje);
        }
      });
  }
  BusquedaRuc() {
    // llamar servicio de listado.
    // contar dataServicio
    // paginar
  }
  mostrarMensaje(mensaje) {
    let snackbar = this.snackBar.open(mensaje, "OK", { duration: 5000 });
  }
}
