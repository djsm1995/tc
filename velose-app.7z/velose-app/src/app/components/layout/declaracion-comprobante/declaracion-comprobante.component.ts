import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-declaracion-comprobante',
  templateUrl: './declaracion-comprobante.component.html',
  styleUrls: ['./declaracion-comprobante.component.css']
})
export class DeclaracionComprobanteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
