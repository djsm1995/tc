import { Component, OnInit, Inject, isDevMode } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Constante } from '../../../../constantes/constante';
import { ReprocesarConsultaComprobantesService } from "../../../../services/reprocesar-consulta-comprobantes.service";
import { ConsultaValidacionesService } from '../../../../services/consulta-validaciones.service';
import { ListaComprobantes } from '../../consulta-validaciones/popup-detalle-error/popup-detalle-error.component';
import { Catalogo } from '../../../../constantes/catalogo';
import { ReusableService } from "../../../../services/reusable.service";

@Component({
  selector: 'app-dialog-reproceso-comprobante',
  templateUrl: './dialog-reproceso-comprobante.component.html',
  styleUrls: ['./dialog-reproceso-comprobante.component.css']
})
export class DialogReprocesoComprobanteComponent implements OnInit {

  isLoadingResults = true;
  resultado: any[] = [];
  estadoLstDeclare: any[] = [];
  responseComprobante:any[]=[]
  iconoRespuesta: { icono: string; color: string };
  sinDetalle:boolean;
  estadoSunatMessage:string;
  fechaRegistroMessage:any;
  sinReprocesamientos:boolean;
  esUsuarioSoporteTCI:boolean;

  constructor(@Inject(MAT_DIALOG_DATA) public data: { row: any, error: boolean },
    private _reprocesarS: ReprocesarConsultaComprobantesService,
    public snackBar: MatSnackBar,
    public _dialogRef: MatDialogRef<DialogReprocesoComprobanteComponent>,
    private _DeclaracionS: ConsultaValidacionesService,
    private _reusableService: ReusableService

  ) {
    this.esUsuarioSoporteTCI=this.isUsuarioSoporteTCI();
    this.sinDetalle = false;
    this.estadoLstDeclare = this._reprocesarS.getListaestadoDeclare();
    if(isDevMode()) { console.log(data.row)}
    if(data.row.estadoSunat==2 ){
      if(isDevMode()) {console.log("aceptado")}
      this.estadoSunatMessage="Aceptado"
      this.iconoRespuesta = Catalogo.ICONORESPUESTA.aceptado;
    }
     else if(data.row.estadoCpe==1 && data.row.estadoAceptadoObs==1 && data.row.fecRespuestaOse != null){
      if(isDevMode()) {console.log("observacion")}
      this.iconoRespuesta = Catalogo.ICONORESPUESTA.advertencia;
    }
     else if((data.row.estadoSunat==-1 ||data.row.estadoSunat==3)){
      this.iconoRespuesta = Catalogo.ICONORESPUESTA.rechazado;
      this.estadoSunatMessage="Excepción"
      if(isDevMode()) {console.log("rechazado")}
    }
    
    // El comprobante tiene una validacion de Velose
    if (data.row.estadoDocumento == 2) {
      this._DeclaracionS.getDataDeclaraciones(this.assembleData())
      .subscribe((response: any) => {
        if(isDevMode()) {console.log(JSON.stringify(response));}  
        if (response.estado === true && response.listaComprobantes.length == 1) {
          this.responseComprobante = response.listaComprobantes[0];
          if (this.mostrarDetalleError(this.responseComprobante)) {
            this.setFecha(response.listaComprobantes[0].fechaRegistro)
              this._DeclaracionS.getDataDeclaracionesxId(response.listaComprobantes[0].idComprobante)
                .subscribe((responsexId: ResultadoI) => {
                  if(isDevMode()) { console.log(responsexId)}
                  this.resultado = responsexId.listaComprobantesPorId
                   if(this.resultado.length==0){
                     this.sinReprocesamientos=true;
                   }
                  this.isLoadingResults = false;  
                })
            }else {
              if(isDevMode()) {console.log("no se encontro detalle del error");}
              this.isLoadingResults = false;
              this.resultado = [];
            }
          }else {
            //mostrar mensaje de que no se encontro datadedeclaraciones
            if(isDevMode()) {console.log("no se encontro data para mostrar en el detalle");}
            this.sinDetalle = true;
            this.isLoadingResults = false;
            
          }
        })
        
    }
    else {
      this.isLoadingResults = false;
      //error xq no se encontrara en la tabla estadoDeclare
    }
    // llamar service soporte tomar idComprobante que es el idTrace
    //a partir de la rpta verificar el estado declare para mostrar log de errores y reprocesar

   }

  ngOnInit() {  
  //  this.iconoRespuesta = Catalogo.ICONORESPUESTA.rechazado;
  }
  cerrarDialog(){
    this._dialogRef.close();
  }
  assembleData() {
    let data = {
      fechaInicio: null,
      fechaFin: null,
      nomZip: null,
      idComprobante: this.data.row.idTrace,
      estDeclare: null,
      rucEmpresaEmisora: null,
      tipoComprobante: null,
      tipoFecha: null,
      page: 1, // debe ser un numero mayor a 0
      maxResult: 10 // debe ser un numero mayor a 0
    };
    return data;
  }

  mostrarDetalleError(rowData) {
    if(isDevMode()) {console.log(rowData);}
    return (this.data.row.estadoSunat == -1 || this.data.row.estadoSunat == 2|| this.data.row.estadoSunat == 3)? true:false
  }

  test(data) {
    let rpta;
    rpta = data == null ? {} : data;
    return rpta;
  }

  reprocesar() {
    let data = {
      idComprobante: this.resultado[0].idComprobante,
      estadoDeclare: this.resultado[0].estadoDeclare
    };
    this._reprocesarS.reprocesar(data).subscribe((response: any) => {
      if (response) {
        if(isDevMode()) console.log(response.mensaje);
        // llamr snackbar
        this.snackBar.open(response.mensaje, "OK", { duration: 6000 });
      }
      if (response.estado === true) {
        this._dialogRef.close();
      }
      return;
    });
  }

  isUsuarioSoporteTCI(){
    if(isDevMode()) {console.log(JSON.stringify(this._reusableService.getSessionUsuario().tipoRol));}
    if(this._reusableService.getSessionUsuario().tipoRol===2){
    return   true;
    }else return false;
  }
  
  setFecha(fechaRegistro:any){
        this.fechaRegistroMessage = this._reusableService.getFormatoFecha(new Date(fechaRegistro), 2);    
  }
}

export interface ResultadoI {
  estado: boolean;
  mensaje: string;
  total: string;
  listaComprobantesPorId: any[];
}
