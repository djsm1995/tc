import { Component, ViewChild, ElementRef, Inject, isDevMode, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxFileDropEntry, FileSystemFileEntry, FileSystemDirectoryEntry } from 'ngx-file-drop';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { ProfileService, responseMiProfile } from '../../../../services/profile.service';
import { ReusableService } from '../../../../services/reusable.service';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';

const maxMedidaPermitidaImagen=3145728 //3MB

@Component({
  selector: 'app-popup-cargar-imagen',
  templateUrl: './popup-cargar-imagen.component.html',
  styleUrls: ['./popup-cargar-imagen.component.css']
})


export class PopupCargarImagenComponent {
  deshabilitarBotton:boolean = false;
  imageChangedEvent: any = null;
  imagenRecortada:any = null;
  public files: NgxFileDropEntry[] = [];
  fileFotoUsuario: File;
  mensajeMedidaPermitida:string

  @ViewChild('fileElem',{static:false} ) fileElemChild :ElementRef
  
  constructor
  (
    public _reusableService: ReusableService,
    private _perfilService: ProfileService,
    public snackBar: SnackBarConfigurationSharedComponent,
    public dialogRef: MatDialogRef<PopupCargarImagenComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) 
  {  
    this.mensajeMedidaPermitida=`La imagen no debe exceder la siguiente medida: ${this._reusableService.toFixedTrunc(maxMedidaPermitidaImagen/1024/1024,2)}Mb`
  }

@ViewChild("fileElem",{static: false})fileElement:ElementRef;
  
//#region Arrastrar y soltar Imagen
public dropped(files:NgxFileDropEntry[]) {    
  this.files = files;
  const droppedFile = files[0];
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          if(isDevMode()) {console.log(file);}
          //Varificamos tamaño y asignamos la variable a guardar
          if(this.validarDocumento(file)){
              //Para visualizar imagen Drag and Drop
              this.imageChangedEvent = {target: {files: [file]}}
          }
        });
      } else {
        // It was a directory (empty directories are added, otherwise only files)
      }    
  }
  
  public fileOver(event){
    //Evento que se lanza al momento de pasar el mouse
    //console.log("fileOver: " + JSON.stringify(event));
    //this.imageDropped(event);
  }
  public fileLeave(event){
    //console.log("fileLeave: " + event);
    //this.imageDropped(event);
  }

//#endregion

//#region Recortar imagen
  fileChangeEvent(event: any): void {
    if (event.target.files && event.target.files[0]) { 
      //Varificamos tamaño y asignamos la variable a guardar
      if(this.validarDocumento(event.target.files[0])){
        this.imageChangedEvent = event;
      }
      else{
        this.fileElemChild.nativeElement.value=""
      }
    }
  }
  imageCropped(event: ImageCroppedEvent) {
    //if(isDevMode) console.log("events " + JSON.stringify(event.base64));
    this.imagenRecortada = event.base64;
  }
  imageLoaded() {
    // show cropper
  }
  cropperReady() {
    // cropper ready
  }
  loadImageFailed() {
    // show message
  }
//#endregion

  guardarFotoUsuario(){
    if(this.imagenRecortada != null){
      this.mostrarMensaje("Actualizando foto de perfil...",3500);
      this.deshabilitarBotton = true;
      this._perfilService.saveFotoUsuario(this.imagenRecortada)
            .subscribe((response:responseMiProfile)=>{
              if(response && response.estado){
                this.mostrarMensaje("Se ha actualizado su foto de perfil",2000);
                this.actualizarDatosProfile(this.imagenRecortada);
                //this.avatarNavbar.actualizarDatos();
                this.onNoClick();
                this.cancelar();
              }
        });
    }else{
      this.mostrarMensaje("No ha seleccionado imagen",1000);
    }
  }

//#region Utilitario
  actualizarDatosProfile(imagen:string){   
    this._reusableService.actualizarDatosProfile(3,imagen);
  }

  validarDocumento(file){
    let extension=file.name.split('.').pop()
    if( extension== 'png' || extension == 'jpg' ){
      if( this._reusableService.validarMedidaArchivo(maxMedidaPermitidaImagen,file.size)){
        this.fileFotoUsuario = file;
        return true;
      }
      else{
         //Enviar un mensaje que imagen exede lo permitido
        this.mostrarMensaje(this.mensajeMedidaPermitida,5000);
        return false;
      }
    }else{
      this.mostrarMensaje("Formato incorrecto",4000);
      return false;
    }
  }
  cancelar(){
    this.imagenRecortada= null;
    this.imageChangedEvent= null;
    if(this.fileElement!=undefined){
      this.fileElement.nativeElement.value="";
    }
  } 
  mostrarMensaje(mensaje:string, tiempo:number) {
    this.snackBar.openSnackBar(mensaje, tiempo,"OK",'bottom');
  }
  onNoClick() {
    this.dialogRef.close(this.imagenRecortada);
  }
//#endregion
}

export interface DialogData {
  imagenUsuario: string;
}
