import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, Renderer2, isDevMode } from '@angular/core';
import { Validators,FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { PopupCargarImagenComponent } from './popup-cargar-imagen/popup-cargar-imagen.component';
import { CambioClaveComponent } from '../../shared/dialogs/cambio-clave/cambio-clave.component';
import { ProfileService, responseMiProfile, permisosPerfil,permisosPerfilClass } from '../../../services/profile.service';
import { ReusableService } from '../../../services/reusable.service';

const usuarioDemoId="3c699f3e-c1cd-44bb-b68a-b285d0e8525f";
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  //Datos del Formulario - Modificables
  nombres = new FormControl; 
  apellidos = new FormControl;

  //Datos del Formulario - No Modificables
  direccion = new FormControl;
  ruc = new FormControl;
  razonSocial = new FormControl;
  correo = new FormControl;
  
  //Otros
  changeImage: boolean;
  changeTextNom: boolean;
  changeTextApe: boolean;
  focusTextNom: boolean;
  focusTextApe: boolean;

  //Imagen USuario
  image : string = null;
  //dato si es necesario mandar al servicio o no
  constanteServio:string;
  @Output() propagar = new EventEmitter<string>();
  // deshabilitar cambioclave usuario demo
  mensajeCambioClave:string;
  usuarioDemoBeta:boolean=true;

  //Permisos
  listaPermisosBD: string[] = this._perfilService.obtenerPermisos();
  permiso = new permisosPerfil();
  tienePermiso = new permisosPerfilClass();
    
  constructor
  (
    private _reusableService: ReusableService,
    private _dialog: MatDialog,
    private _perfilService: ProfileService,
    private _router:Router,
  ) 
  {
    this.obtenerPermisos();
    this.changeTextNom = false;
    this.changeTextApe = false;
    this.changeImage = false;
    this.focusTextNom = true;
    this.focusTextApe = true;
  }
  //Para controlar el focus
  @ViewChild("nombre",{static: false}) nomField:ElementRef;
  @ViewChild("apellido",{static: false}) apeField:ElementRef;

  ngOnInit() {
    this.nombres = new FormControl({value:"",disabled:true},[Validators.required,Validators.maxLength(250)]); 
    this.apellidos = new FormControl({value:"",disabled:true}, [Validators.required,Validators.maxLength(250)]);

    this.ruc = new FormControl({value:'', disabled: true},[]);
    this.razonSocial = new FormControl({value:'', disabled:true},[]);
    this.correo = new FormControl({value:'', disabled:true},[]);
    this.direccion = new FormControl({value:'', disabled:true},[]);
    this.traerDatos(null);

    this.usuarioDemoBeta= this.esUsuarioDemoBeta();
    if(this.usuarioDemoBeta)
      this.mensajeCambioClave= 'Este usuario no puede realizar el cambio de clave, por favor comunicarse con su asesor comercial.'
  } 

  cargarNuevaImagen() : void{
    if(this.tienePermiso.cambiarImagen){
      const dialogRef  = this._dialog.open( PopupCargarImagenComponent, {
        width: "650px",
        maxHeight: "80vh",
        data: { imagenUsuario: this.image }
      });
      
      dialogRef.afterClosed().first().subscribe(result => {
        if(result != undefined && result != null){
            this.traerDatos(6);
            //this.propagar.emit('Este dato viajara');
        }
      });
    }
  }

  habilitarInput(identificador:number){
    if(this.tienePermiso.editarNombreApellido){
      switch (identificador) {
        case 1:
          this.constanteServio = this.nombres.value;
          this.focusTextNom = false;
          this.nombres.enable();
          this.nomField.nativeElement.focus()
          break;
        case 2:
          this.constanteServio = this.apellidos.value;
          this.focusTextApe = false;
          this.apellidos.enable();
          this.apeField.nativeElement.focus()
          break;
        default:
          break;
      }
    }
  }

  focusOutEditarInput(dato , identificador:number){
    switch (identificador) {
      case 1:
        if(dato.value=="" || dato.value ==null){
          this.traerDatos(identificador);
          this.nombres.disable();
          this.focusTextNom = true;
          return;
        }
        this.nombres.disable();
        this.focusTextNom = true;
        break;
      case 2:
        if(dato.value=="" || dato.value ==null){
          this.traerDatos(identificador);
          this.apellidos.disable();
          this.focusTextApe = true;
          return;
        }
        this.apellidos.disable();
        this.focusTextApe = true;  
        break;
      default:
        break;
    }
    this.servicioGuardarDato(dato, identificador);
  }
  

  servicioGuardarDato(dato , identificador:number){
    if(this.constanteServio != dato.value ){
        this._perfilService.saveDatoUsuario(dato.value , identificador)
        .subscribe((response:responseMiProfile)=>{
          if(response && response.estado){
            this.actualizarDatosProfile(identificador,dato.value)
            this.traerDatos(identificador);
          }
      });
    }
  }

//#region Reusables traer datos, actualizar datos
  actualizarDatosProfile(identificador:number, value:string){
    this._reusableService.actualizarDatosProfile(identificador,value);
  }
  traerDatos(identificador:number){
    let datoUsuario = this._reusableService.getSessionUsuario();
    if(identificador == 1){
      this.nombres.setValue(datoUsuario.nombre);
    }
    if(identificador == 2){
      this.apellidos.setValue(datoUsuario.apellidos);
    }
    if(identificador == 6){//imagen
      this.image = datoUsuario.imagenUsuario;
    }
    if(identificador == null){
      this.nombres.setValue(datoUsuario.nombre);
      this.apellidos.setValue(datoUsuario.apellidos);
  
      this.razonSocial.setValue(datoUsuario.empresa.razonSocial);
      this.ruc.setValue(datoUsuario.empresa.ruc);
      this.correo.setValue(datoUsuario.correo);
      this.direccion.setValue(datoUsuario.empresa.direccion);
      if(datoUsuario.imagenUsuario!= null){
         this.image = datoUsuario.imagenUsuario;
      }else{
        this.image = "../../../../assets/img/avatar3.png";
      }
    }
  }

  //#endregion

  // #region cambiarClave
  private esUsuarioDemoBeta(){
    let usuarioActual:string = this._reusableService.getTokenJson().sub;
    return (usuarioActual==usuarioDemoId)?true:false;
  }


  cambiarClave(){
    if(this.tienePermiso.cambiarClave){
      // open dialog
      this._dialog.open(CambioClaveComponent, {
        width: '400px',
        data: { 
          idUsuario: this._reusableService.getTokenJson().sub
        }
      });
    }
    
  }
  //#endregion

  obtenerPermisos(){
    for(let permiso of this.listaPermisosBD){
      if(permiso === this.permiso.cambiarClave){
        this.tienePermiso.cambiarClave = true;
      }
      if(permiso === this.permiso.editarNombreApellido){
        this.tienePermiso.editarNombreApellido = true;
      }
      if(permiso === this.permiso.cambiarImagen){
        this.tienePermiso.cambiarImagen = true;
      } 
    }
  }

}
