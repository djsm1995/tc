import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {ReusableService} from '../../../../services/reusable.service';
import {MensajeGenericoComponent} from '../../../shared/mensaje-generico/mensaje-generico.component';
import {HomologacionService } from '../../../../services/homologacion.service';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';


@Component({
  selector: 'app-confirmacion-reenvio',
  templateUrl: './confirmacion-reenvio.component.html',
  styleUrls: ['./confirmacion-reenvio.component.css']
})
export class ConfirmacionReenvioComponent implements OnInit {

  constructor(private sHomologacion:HomologacionService,
              private reusable:ReusableService,
              private dialog:MatDialog,
              private router:Router) { }

  ngOnInit() {
  }

  openDialogMensajeReenvio(){
    // enviar correo de datos produccion
    let ruc= this.reusable.getSessionUsuario().empresa.ruc
    this.sHomologacion.correoDatosProduccion(ruc,"R");
    this.dialog.closeAll();

    let dialogRef = this.dialog.open(
      MensajeGenericoComponent,
      {
        width: '400px',
        data: { icon:"email",
                color:"#062a78",
                titulo:"Reenvío datos de producción ",
                mensaje:`${this.reusable.getSessionUsuario().nombre}, hemos enviado un correo electrónico a ${this.reusable.getSessionUsuario().correo}
                 con los nuevos datos para que te conectes al webservice de producción.`
              }
    });
    //dialogRef.close(".")
    // Redireccionar a homologacion
    this.router.navigate(['/home/homologacion'])
  }
}
