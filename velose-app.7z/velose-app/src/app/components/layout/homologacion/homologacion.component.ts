import {Component, ViewChild,OnInit,ChangeDetectorRef, isDevMode  } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {casoNegocio} from '../../../services/casos-de-negocios.service';
import {HomologacionService,casos,homologacion,datosWsC,datosWs } from '../../../services/homologacion.service';
import {ReusableService} from '../../../services/reusable.service';
import {HighlightJsModule} from 'angular2-highlight-js';
import {HomologacionLineaComponent} from './homologacion-linea/homologacion-linea.component';
import {ConfirmacionProduccionComponent} from './confirmacion-produccion/confirmacion-produccion.component';
import {PdfViewerComponent} from '../../shared/pdf-viewer/pdf-viewer.component';
import {ErroresHomologacionComponent} from './errores-homologacion/errores-homologacion.component';
import {HttpErrorResponse} from '@angular/common/http';
import { Router } from '@angular/router';
import {MensajeGenericoComponent} from '../../shared/mensaje-generico/mensaje-generico.component';
import {TutorialComponent} from '../../shared/tutorial/tutorial.component';

import {ConfirmacionReenvioComponent} from './confirmacion-reenvio/confirmacion-reenvio.component';
import { ConfiguracionesEmpresAmbienteBetaComponent} from './configuraciones-empres-ambiente-beta/configuraciones-empres-ambiente-beta.component';

@Component({
  selector: 'app-homologacion',
  templateUrl: './homologacion.component.html',
  styleUrls: ['./homologacion.component.css'],

})
export class HomologacionComponent implements OnInit{
    displayedColumns = [ 'tipoOperacion','tipoAfectacion','nombreCaso','2Cero','2Uno'];
    dataSource: MatTableDataSource<casos>;
    homologacionData=false;
    filtrotipoCpe:homologacion[];
    lenguajesProgramacion=[];
    avanceHomologacion:number=80;
    colorAvanceHomologacion:string="warn";
    estadoPSEProduccion:boolean=false;
    correoPSE:string="";
    usuarioLogeado:any;
    // restantesObligatorios=false;
    passWs={
      hide:true,
      datos: new datosWsC()
    };

    // Tutorial
    tutorialHomologacion = new TutorialComponent();

    // step for panels
    step = 0;
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    @ViewChild(MatSort,{static: false}) sort: MatSort;

    constructor(private sHomologacion:HomologacionService,
                private reusable:ReusableService,
                private cdRef:ChangeDetectorRef,
                private dialog:MatDialog,
                private router:Router) {
        
    this.usuarioLogeado= this.reusable.getSessionUsuario()
                }
     // tutoriales adicionales falta implementar interfaces...
    ngOnInit(){
      this.sHomologacion.getListaCasosNegocio(this.assembleAmbientBeta(null))
          .subscribe((response:any)=>{
            // console.log(response)
            if(response && response.estado){
              this.homologacionData=true;
              this.cdRef.detectChanges();
              let rpta=response.respuesta
              this.filtrotipoCpe=rpta.tiposComprobantes;
              this.CNHomologacion(rpta);
            }
          });
      this.sHomologacion.consultarInformacionPSE(this.reusable.getSessionUsuario().empresa.idPse)
        .subscribe((response:any)=>{
          if(response && response.estado){
              this.estadoPSEProduccion=response.respuesta.produccion;
              this.correoPSE=this.reusable.getSessionUsuario().correo;
          }
        });

      this.sHomologacion.getdatosconexionWsHomologacion(this.assembleWsAmbientBeta())
      .subscribe(
        (response: any) => {
          if(isDevMode()) {console.log(response);}
          if(response &&response.estado)
            this.passWs.datos= response.respuesta;
        },
        (error:HttpErrorResponse)=>{
          if(isDevMode()) {console.log(error);}
        });
      this.lenguajesProgramacion= this.sHomologacion.getlistaLenguajeProgramacion();

      //Tutorial Homolocación carga los mensajes y habilita el tutorial
      this.loadTutorialHomologacion();
      //this.tutorialHomologacion.habilitarTurorial();
      
    }

    mostrarTooltipPass(passWs){
      return passWs.hide? "Mostrar contraseña" : "Ocultar contraseña"
    }

    verificacionHomologacion(){
      let rpta=false;
      if(this.filtrotipoCpe && this.filtrotipoCpe.length>=1)
        rpta=!rpta;
      return rpta;

    }

    assembleWsAmbientBeta(){
      let rpta;
      rpta={

        idPSE:this.reusable.getSessionUsuario().empresa.idPse,
        correo:this.reusable.getSessionUsuario().correo
      }
      return rpta;
    }
    assembleAmbientBeta(idComprobante){
      let rpta;
      rpta={
        idPSE:this.reusable.getSessionUsuario().empresa.idPse,
        idComprobante:idComprobante
      }
      return rpta;
    }
    ngAfterViewInit() {
        this.updatetabledatasource();
    }
    avancePorcentajeHomologacion(){
      let lengthTipoCpe=this.filtrotipoCpe.length
      let acumulado=0;
      this.filtrotipoCpe.forEach(
        function(cpe){
            acumulado+=cpe.avance
      });

      return acumulado/lengthTipoCpe;
    }
    equals(o1: any, o2: any) {
       return o1.id === o2.id;
    }
    getSessionUsuario(){
      return this.usuarioLogeado
      }

    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
      this.dataSource.filter = filterValue;
      // this.updatetabledatasource();
    }
    updatetabledatasource(){
      if(this.dataSource){
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.cdRef.detectChanges();
      }
    }
    CNHomologacion(rpta){
      this.dataSource = new MatTableDataSource(rpta.casosDeNegocio);
      this.dataSource.filterPredicate = ((data: casos, filter: string) => {
        if(isDevMode()) {console.log("filter predicate");}
          if (data == undefined)
            return false;
          if (data.nombreCaso.trim().toLowerCase().match(filter) ||
            data.tipoAfectacion.trim().toLowerCase().match(filter) ||
            data.tipoAfectacion.trim().toLowerCase().match(filter) ) {
            return true
          }
        })
      this.updatetabledatasource();
    }
    changeFiltroCpe(cpe){
      this.sHomologacion.getListaCasosNegocio(this.assembleAmbientBeta(cpe))
          .subscribe((response:any)=>{
            if(response && response.estado){
              let rpta=response.respuesta
              this.CNHomologacion(rpta);
            }
          });
    }

    // tutorial homologacion
    saltarTutorial(){
      // False todas las etapas del tutorialSession
      // this.tutorialSteps={
      //   step1:false,
      //   step2:false,
      //   step3:false,
      //   step4:false,
      // }
    }

    // steps panel accordion
    setStep(index: number) {
      this.step = index;
    }
    nextStep() {
      if( this.step==2 && !this.passWs.datos.conectado)
        return;
      this.step++;
    }
    prevStep() { this.step--; }

    homologacionLinea(idTipoCpe){
      let dialogRef = this.dialog.open(
        HomologacionLineaComponent,
        {
            width: '600px',
            height:'50%',
            data: { tipoCpe: idTipoCpe }
        });
    }

    // visualizadorPdf
    visualizadorPdf(cn,version){


      let dialogRef = this.dialog.open(
        PdfViewerComponent,
        {
            width: '75%',
            height:'95%',
            data: { caso: cn,
                    version:version}
        });


    }
    erroresHomologacion(){
      let cn
      let dialogRef = this.dialog.open(
        ErroresHomologacionComponent,
        {
            width: '350px',
            height:'350px',
            data: { caso: cn }
        });

    }
    openDialogTerminosCondiciones(){
      if(isDevMode()) {console.log("test");}
    }
    openDialogMensajeProduccion(){
      // enviar correo de datos produccion
      let ruc= this.reusable.getSessionUsuario().empresa.ruc
      //this.sHomologacion.correoDatosProduccion( ruc);

      let dialogRef = this.dialog.open(
        ConfirmacionProduccionComponent,
        {
          width: '500px',
          data: { icon:"email",
                  color:"#062a78",
                  titulo:"Datos Producción",
                  mensaje:`${this.reusable.getSessionUsuario().nombre}, hemos enviado un correo electrónico a ${this.reusable.getSessionUsuario().correo}
                   con los datos para que te conectes al webservice de producción.`
                }
      });


  }

  openDialogReenvioCredencial(){
    // enviar correo de datos produccion
    let ruc= this.reusable.getSessionUsuario().empresa.ruc
    //this.sHomologacion.correoDatosProduccion( ruc);

    let dialogRef = this.dialog.open(
      ConfirmacionReenvioComponent,
      {
        width: '400px',
        data: { icon:"email",
                color:"#062a78",
                titulo:"Abrir confirmacion reenvio",
                mensaje:`Reenvio de credencial.`
              }
    });


}

  openPDFManual(){
    // Visualizar PDF
    // let dialogRef = this.dialog.open(
    //   PdfViewerComponent,
    //   {
    //       width: '75%',
    //       height:'95%',
    //       data: { caso: cn,
    //               version:version}
    //   });
    //
  }

  loadTutorialHomologacion() {
    var data = [
                {
                  paso:1,
                  sobre:"Sobre",
                  tag:"",
                  titulo:"Plataforma de pruebas",
                  btnSalir:"Saltar Tutorial",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Empieza aquí",
                  descripcion:"Con la finalidad de minimizar errores de producción, aquí podrás conectarte a nuestro servicio web (WSDL) para mostrarte ejemplos de casos reales de UBL 2.O Y UBL 2.1.",
                  visible: false
                },
                {
                  paso:2,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Acceso al ambiente de pruebas",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"Usa este URL para configurar tu sistema y datos de usuario para empezar la integración con nuestro ambiente de pruebas.",
                  visible: false
                },
                {
                  paso:4,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Manual de Integración",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"En el cual te explicaremos todos los métodos del servicio web (WSDL).",
                  visible: false
                },
                {
                  paso:5,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Ejemplos",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"Aquí tienes ejemplos de código para que te guíes en la implementación.",
                  visible: false
                },
                {
                  paso:5,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Selecciona el Tipo de comprobante",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"Aquí se muestran los tipos de comprobantes que seleccionaste en la pantalla de casos de negocios.",
                  visible: false
                },{
                  paso:6,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Prueba tu XML en línea",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"En el caso tengas un XML generado por tu sistema puedes probarlo aquí.",
                  visible: false
                },
                {
                  paso:7,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Ejemplos de XML por casos de negocio",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"También te mostramos ejemplos de los XML según los casos de negocios que seleccionaste. Haz clic para verlos aquí.",
                  visible: false
                },
                {
                  paso:8,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Filtrar Búsqueda",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"Puedes especificar tu búsqueda mediante el siguiente filtro.",
                  visible: false
                },

                {
                  paso:9,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Ver Manual",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"Siguiente",
                  descripcion:"Aquí puedes acceder al manual que te ayudará seleccionar a TCI como OSE en el portal de la SUNAT.",
                  visible: false
                },
                {
                  paso:10,
                  sobre:"Sobre",
                  tag:"Tab",
                  titulo:"Términos y condiciones",
                  btnSalir:"Salir",
                  btnAnterior:"Anterior",
                  btnSiguiente:"¡Mi turno!",
                  descripcion:"Debes leer con atención este documento donde se indica los términos y condiciones que aceptas al usar este servicio.",
                  visible: false
                }
              ];

    this.tutorialHomologacion.loadMsgTutorial(data);
  }
  
  rutaCasoNegocio() {
    this.router.navigate(["/home/casoNegocio", { hom_ambienteBeta:true }]);
  }

  mostrarDialogConfiguracion() {
    let dialogRef = this.dialog.open(
      ConfiguracionesEmpresAmbienteBetaComponent,
      {
        width: "600px",
        height: "50%",
        data: {}
      }
    );
  }

}
