import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errores-homologacion',
  templateUrl: './errores-homologacion.component.html',
  styleUrls: ['./errores-homologacion.component.css']
})
export class ErroresHomologacionComponent implements OnInit {
  errores:any={"codigo":2325,"tipo":"ERROR","descripcion":"El certificado usado no es el comunicado a SUNAT","descripcion-adicional":{"mensaje-adicional":"[ose-persistencelist-service] Listado de certificados del emisor se encuentra nulo o vacio","campos-invalidos":{"RUC del emisor":"null"}}}
  constructor() { }

  ngOnInit() {
  }
  onClosedCancel(){
    
  }

}
