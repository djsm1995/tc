import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfiguracionesEmpresAmbienteBetaComponent } from './configuraciones-empres-ambiente-beta.component';

describe('ConfiguracionesEmpresAmbienteBetaComponent', () => {
  let component: ConfiguracionesEmpresAmbienteBetaComponent;
  let fixture: ComponentFixture<ConfiguracionesEmpresAmbienteBetaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfiguracionesEmpresAmbienteBetaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfiguracionesEmpresAmbienteBetaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
