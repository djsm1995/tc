import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, Validators, FormControl, FormGroupDirective, NgForm, FormArray, FormBuilder } from '@angular/forms';
// import { ConfiguracionService } from '../../../service/configuracion.service';
import { ConfigurarEmpresaAmbienteBetaService } from "../../../../services/configurar-empresa-ambiente-beta.service";



@Component({
  selector: "app-configuraciones-empres-ambiente-beta",
  templateUrl: "./configuraciones-empres-ambiente-beta.component.html",
  styleUrls: ["./configuraciones-empres-ambiente-beta.component.css"]
})
export class ConfiguracionesEmpresAmbienteBetaComponent implements OnInit {
  // Formulario
  modificarConfiguracionEmpresa: FormGroup;
  // configuraciones = this.serviceConfiguracion.configuraciones;
  esModificar: boolean = false;

  constructor(
    private cd: ChangeDetectorRef,
    private serviceConfiguracion: ConfigurarEmpresaAmbienteBetaService
  ) {}

  ngOnInit() {
    let a = ConfigurarEmpresaAmbienteBetaService;
  }
}
