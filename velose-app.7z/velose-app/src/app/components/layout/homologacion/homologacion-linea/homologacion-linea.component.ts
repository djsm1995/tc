import { Component, OnInit,Inject } from '@angular/core';
import { FileSelectDirective, FileDropDirective, FileUploader } from 'ng2-file-upload/ng2-file-upload';
import {HomologacionService,casos,homologacion} from '../../../../services/homologacion.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {responseXML,responseXMLC,pruebatuXML,pruebatuXMLC,PruebatuXMLC,consultaTicket,consultaTicketC} from '../../../../services/homologacion.service';
import {ReusableService} from '../../../../services/reusable.service';
import { FileSaverService  } from 'ngx-filesaver';


const URL = '';
@Component({
  selector: 'app-homologacion-linea',
  templateUrl: './homologacion-linea.component.html',
  styleUrls: ['./homologacion-linea.component.css']

})
export class HomologacionLineaComponent implements OnInit {
  public uploader:FileUploader = new FileUploader({url: URL});
  xml:any
  responseXml:responseXML=new responseXMLC();
  respuestaTicket:consultaTicket=new consultaTicketC();
  iconExpandido=true;
  showSpinner= false
  showProgressBar=false;
  showCDR=false;
  showErrorServicio=false;
  fileName:any
  cpeNeedTicket=[15,16,17];
  constructor(private sHomologacion:HomologacionService,
              @Inject(MAT_DIALOG_DATA) public _data: any,
              private reusable:ReusableService,
              private _FileSaverService: FileSaverService) { }

  ngOnInit() {
    // this.responseXml.estado=""
  }
  changeXML(input: HTMLInputElement){
    this.fileName = input.files.item(0).name
    // console.log(input.files.item(0))
    if (this.fileName) {
      // extensiones permitidas xml
      let extensionesPermitidas=['.xml'];
      let extension=this.fileName.substring(this.fileName.lastIndexOf('.')).toLowerCase();
      let permitida=false;
      for (var i =0; i<extensionesPermitidas.length;i++){
        if(extensionesPermitidas[i]==extension){
          permitida=true;
          break;
        }
      }
      if(permitida){
        var myReader:FileReader = new FileReader();
        var self = this;
        myReader.onloadend =
          function(e){
            try {
              self.xml=btoa(self.reusable.utf8Encode(myReader.result));
              console.log("ok")
            }
            catch(error) {
              console.log(error)
              // self.xml=btoa(self.utf8Encode(myReader.result))
            }
            console.log(self.xml)
            self.reloadVariables()

            // Enviar dato por servicio para evaluar la rpta q da.
            self.showProgressBar=!self.showProgressBar
            self.sHomologacion.pruebaXml(self.assembleDataValidaXml())
              .subscribe((response:PruebatuXMLC)=>{
                if(response && response.estado){
                  let validacion:pruebatuXML=response.respuetaValidacion

                  self.validacionEstado(validacion);
                  console.log(validacion)

                  // Si es aceptado o aceptado con observaciones
                  if(validacion.estado<=1 || validacion.estado==4){
                    self.responseXml.respuesta=validacion.mensaje
                    self.responseXml.cdr=validacion.archivoXml
                    self.showCDR=!self.showCDR;
                  }
                  else{
                    self.responseXml.respuesta=JSON.parse(validacion.mensaje)
                  }
                  // self.responseXml.respuesta=(validacion.estado<=1 || validacion.estado==4)?validacion.mensaje:JSON.parse(validacion.mensaje);

                  // Extraemos ticket
                  self.responseXml.load="indeterminate"
                  if(validacion.estado==0){
                    self.responseXml.ticket= validacion.ticketSunat
                    self.consultarTicket();
                  }
                }
                else{
                  // Mostrar mensaje Ups
                  self.showErrorServicio=true;
                }

                // Terminar carga
                self.responseXml.load="determinate"
                self.showProgressBar=!self.showProgressBar
              });
          }
        myReader.readAsText(input.files.item(0));
        console.log(this.xml)
      }
    }
  }

  consultarTicket(){
    let contador=0
    this.showSpinner=true;
    // Maximo de 5 intentos, sino volver a probar con un boton
    let getRpta= setInterval(()=>
      this.sHomologacion.consultarTicket(this.responseXml.ticket)
          .subscribe((response:any)=>{
            console.log(response)
            if(response && response.estado){
              console.log(this.respuestaTicket);
              this.respuestaTicket= response.respuestaTicket;
              this.validacionEstado(this.respuestaTicket);
              if(this.respuestaTicket.estado!=0){
                this.clearTicket()
                clearInterval(getRpta)
              }
              else
                contador++
              if(contador>5){
                this.clearTicket()
                clearInterval(getRpta)
              }
            }
          }),2000);
  }
  clearTicket(){
    this.showSpinner=false;
    this.responseXml.respuesta=JSON.parse(this.respuestaTicket.mensaje);
  }
  validacionEstado(validacion:any){
    console.log(validacion)
    switch(validacion.estado) {
      case 0: //PorEnviar:  Procesando resumenes (Wait please)
        this.responseXml.estado="Procesando"
        break;
      case 1: //Aceptado: Aceptado sin observaciones , trae cdr
        this.responseXml.estado="Aceptado"
        break;
      case 2: //ExcepcionSunat : Excepciones que se dan luego de evaluarse un xml (Trae json con los errores)
        this.responseXml.estado="Con Excepciones"
        break;
      case 3: //ExcepcionWS: Falta definir (Diego)
        this.responseXml.estado="Con Excepciones"
        break;
      case 4: //Observado : Aceptado con observaciones , trae cdr
        this.responseXml.estado="Aceptado con Observaciones"
        break;
    }
  }
  obtieneTicket(){
    if(this.responseXml.ticket!=null){
      for (var i =0; i<this.cpeNeedTicket.length;i++){
        if(this._data.tipoCpe==this.cpeNeedTicket[i])
        return true;
      }
    }
    return false;
  }

  reloadVariables(){
    this.responseXml=new responseXMLC()
    this.responseXml.load="indeterminate"
    this.respuestaTicket=new consultaTicketC()
    this.iconExpandido=false
    this.showCDR=false
    this.showErrorServicio=false
  }
  // assembleData
  assembleDataValidaXml(){
    let data;
    data={
      tipoComprobante:"tipo", //cambiar por tipocpe
      nombreXML:this.fileName,
      xmlBase64:this.xml
    }

    // console.log(data)
    return data
  }
  downloadCdr(){
    let dataCdr;
    // Doble conversion por que viene dentro de un xml
    dataCdr= atob(this.responseXml.cdr);
    dataCdr= atob(dataCdr);
    console.log(dataCdr)
    // obtengo cdr pero esta en zip
    const txtBlob = new Blob([dataCdr], { type: "xml" });
    let nombreXML="R-"+ this.fileName;
    this._FileSaverService.save(txtBlob, nombreXML);//dato viene con .xml
  }
}
