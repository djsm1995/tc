import { Component, OnInit,AfterContentInit,OnDestroy, isDevMode } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { MensajeFinalCnComponent} from './mensaje-final-cn/mensaje-final-cn.component';
import { InformacionInicialComponent} from '../dashboard/informacion-inicial/informacion-inicial.component';
import { TutorialComponent} from '../../shared/tutorial/tutorial.component';
import { CasosDeNegociosService,casoNegocio,responseCasoNegocio} from '../../../services/casos-de-negocios.service';
import { ReusableService} from '../../../services/reusable.service';
import { MensajeGenericoComponent} from '../../shared/mensaje-generico/mensaje-generico.component';

@Component({
  selector: "app-caso-negocio",
  templateUrl: "./caso-negocio.component.html",
  styleUrls: ["./caso-negocio.component.css"]
})
export class CasoNegocioComponent implements OnInit, AfterContentInit {
  listaCasoNegocios: casoNegocio[] = [];
  usuarioLogeado :any;
  rutaHomologacion:boolean=false;
  // Tutorial
  tutorial = new TutorialComponent();
  tutorialSteps = {
    step1: false,
    step2: false,
    step3: false,
    step4: false
  };

  constructor(
    private _casoNegocioService: CasosDeNegociosService,
    public dialog: MatDialog,
    private _router: Router,
    private route: ActivatedRoute,
    private reusable: ReusableService,
    public snackBar: MatSnackBar
  ) {
    this.usuarioLogeado= this.reusable.getSessionUsuario()
    this.route.params.subscribe(params => {
      if(isDevMode()) {console.log(params)}
      this.rutaHomologacion = (params['hom_ambienteBeta'] != undefined) ? true : false;
    });
  }
  // Lifecycle
  ngOnInit() {
    this.getCasosNegocio();

    //Tutorial Caso Negocio carga los mensajes y habilita el tutorial
    this.loadTutorialCasoNegocio();
    //this.tutorialHomologacion.habilitarTurorial();
  }
  ngAfterContentInit() {
    this.dialogCN();
  }

  getCasosNegocio() {
    let empresa = this.reusable.getSessionUsuario().empresa.idPse;
    this._casoNegocioService
      .getListaCasosNegocio(empresa)
      .subscribe((rpta: responseCasoNegocio) => {
        if (rpta.estado) {
          this.listaCasoNegocios = rpta.listaCasoNegocios;
        }
      });
  }

  // Obteniendo lista para guardar
  changeSeleccion(elemento, CPE, TO, TA?) {
    let casosNegociosEscogidos = this.listaCasoNegocios;
    if (TA != undefined) {
      // Modificar Tipo de afectacion
      casosNegociosEscogidos[CPE].lstOperacion[TO].lstAfectacion[
        TA
      ].seleccionado = elemento.checked;
    } else {
      // Modificar Tipo de Operacion
      casosNegociosEscogidos[CPE].lstOperacion[TO].seleccionado =
        elemento.checked;
      // quitar datos de check en TA segun TO
      if (elemento.checked == false) {
        casosNegociosEscogidos[CPE].lstOperacion[TO].lstAfectacion.forEach(
          function(element) {
            element.seleccionado = false;
          }
        );
      } else {
        casosNegociosEscogidos[CPE].lstOperacion[TO].seleccionado = true;
      }
    }
    this.listaCasoNegocios = casosNegociosEscogidos;
  }
  GrabarTiposOperacion() {
    if (this.verificarChecks()) {
      let dialogRef = this.dialog.open(MensajeFinalCnComponent, {
        width: "450px",
        panelClass: "contenedorConfirmacion",
        data: { listaCasoNegocios: this.listaCasoNegocios }
      });
    } else {
      this.snackBar.open(
        "Debes seleccionar al menos un caso de negocio",
        "OK",
        { duration: 5000 }
      );
      // let nombre= this.reusable.getSessionUsuario().nombre;
      // let dialogRef = this.dialog.open(MensajeGenericoComponent,
      //   {
      //       width: '450px',
      //       data: { icon:"sentiment_satisfied_alt",
      //               color:"#062a78",
      //               titulo:"Selección Caso de Negocio",
      //               mensaje:`Hola ${nombre}, debes seleccionar por lo menos un caso de negocio `
      //       }
      //   });
    }
  }
  verificarChecks() {
    let casosNegociosEscogidos = this.listaCasoNegocios;
    let contadorTOSeleccionados: number = 0;
    casosNegociosEscogidos.forEach(function(element) {
      element.lstOperacion.forEach(function(element) {
        if (element.seleccionado) {
          let tipoAfectacionNoSeleccionado: boolean = true;
          for (var i = 0; i < element.lstAfectacion.length; i++) {
            if (element.lstAfectacion[i].seleccionado) {
              tipoAfectacionNoSeleccionado = !tipoAfectacionNoSeleccionado;
              break;
            }
          }
          if (tipoAfectacionNoSeleccionado) {
            element.seleccionado = false;
          }
          if (element.seleccionado) {
            contadorTOSeleccionados += 1;
          }
        }
      });
    });
    this.listaCasoNegocios = casosNegociosEscogidos;
    return contadorTOSeleccionados >= 1 ? true : false;
  }

  // firstTime
  dialogCN(): void {
    // Asincrono para que no muestre error
    let dialogRef;
    if (this.usuarioLogeado.firstTime) {
      setTimeout(
        () =>
          (dialogRef = this.dialog.open(InformacionInicialComponent, {
            width: "440px",
            data: { name: "name" }
          })),
        0
      );
      setTimeout(
        () =>
          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              // cambiar variable para que se muestre el tutorial
              this.goTutorial();
            }
            this.usuarioLogeado.firstTime = false;
            this.reusable.setSessionUsuario(this.usuarioLogeado)
            if(isDevMode()) {console.log("Close dialog CN" + result);}
          }),
        0
      );
    }
  }

  // Tutorial Caso Negocio
  goTutorial() {
    this.tutorialSteps.step1 = true;
  }
  cnStep1() {
    this.tutorialSteps.step2 = true;
    this.tutorialSteps.step1 = false;
    // this.
  }
  cnStep2() {
    this.tutorialSteps.step3 = true;
    this.tutorialSteps.step2 = false;
  }
  cnStep3() {
    this.tutorialSteps.step4 = true;
    this.tutorialSteps.step3 = false;
  }
  cnStep4() {
    this.saltarTutorial();
  }
  saltarTutorial() {
    // False todas las etapas del tutorialSession
    this.tutorialSteps = {
      step1: false,
      step2: false,
      step3: false,
      step4: false
    };
  }

  /*
{
  paso:1,
  sobre:"Sobre",
  tag:"",
  titulo:"Homologación",
  btnSalir:"Saltar Tutorial",
  btnAnterior:"Anterior",
  btnSiguiente:"Empezar",
  descripcion:"Aquí aprenderás como conectarte a nuestro servicio web (WSDL), además te mostramos ejecmplos de casos reales en UBL2.0 y UBL2.1, todo esto con el fin de minimizar los errores en producción.",
  visible: false
},

*/
  loadTutorialCasoNegocio() {
    var data = [
      {
        paso: 1,
        sobre: "Iniciar proceso",
        tag: "Tabs",
        titulo: "Iniciar proceso",
        btnSalir: "Saltar Tutorial",
        btnAnterior: "Anterior",
        btnSiguiente: "Empecemos",
        descripcion:
          'Selecciona un comprobante electrónico con el que trabaje tu empresa. Por ejemplo: "Boleta".',
        visible: false
      },
      {
        paso: 2,
        sobre: "Tipo Operacion",
        tag: "Slide Toogle",
        titulo: "Tipo Operación",
        btnSalir: "Salir",
        btnAnterior: "Anterior",
        btnSiguiente: "Siguiente",
        descripcion:
          'Marca el tipo de operación de la venta que realizas. Por ejemplo: "Venta Interna-Nacional".',
        visible: false
      },
      {
        paso: 3,
        sobre: "Tipo Afectacion",
        tag: "checkbox",
        titulo: "Tipo Afectación",
        btnSalir: "Salir",
        btnAnterior: "Anterior",
        btnSiguiente: "Siguiente",
        descripcion:
          "Elige los tipos de afectación de acuerdo a tu operación seleccionada. ",
        visible: false
      },
      {
        paso: 4,
        sobre: "Finalizar",
        tag: "boton",
        titulo: "Finalizar",
        btnSalir: "Ver nuevamente",
        btnAnterior: "Anterior",
        btnSiguiente: "Siguiente",
        descripcion:
          'Repite los pasos anteriores con todos los comprobantes que tu empresa emite. Al terminar, dale clic al botón: "Finalizar".',
        visible: false
      }
    ];

    this.tutorial.loadMsgTutorial(data);
  }
}
