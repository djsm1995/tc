import { Component, Inject,AfterContentInit,OnInit, isDevMode} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {ReusableService} from '../../../../services/reusable.service';
import {CasosDeNegociosService,casoNegocio,responseCasoNegocio} from '../../../../services/casos-de-negocios.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-mensaje-final-cn',
  templateUrl: './mensaje-final-cn.component.html',
  styleUrls: ['./mensaje-final-cn.component.css']
})
export class MensajeFinalCnComponent implements OnInit {
  dataListaCN=this._data.listaCasoNegocios;
  acumulado=false;
  constructor(  @Inject(MAT_DIALOG_DATA) public _data: any,
                private _router:Router,
                public _dialogRef: MatDialogRef<MensajeFinalCnComponent>,
                private _casoNegocioService:CasosDeNegociosService,
                private reusable:ReusableService) {
              }


  ngOnInit() {}

  grabarListaCasoNegocio(){
    let empresa=this.reusable.getSessionUsuario().empresa.idPse;
    this._casoNegocioService.guardarCNSeleccionados(empresa,this.dataListaCN)
    .subscribe((rpta:any)=>{
      if(isDevMode()) {console.log(rpta);}
      if(rpta.estado){
        this._router.navigate(['/home/homologacion']);
      }
      this._dialogRef.close();
    });

  }

  verificacionCasosActivos(TO:any[]){
    let response=false;
    TO.forEach(
      function(element){
        if(element.seleccionado==true){
           return response=true;
          // TO.length=0;
        }
      }
    );
    return response;

  }


}
