import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-no-encontrada',
  templateUrl: './data-no-encontrada.component.html',
  styleUrls: ['./data-no-encontrada.component.css']
})
export class DataNoEncontradaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
