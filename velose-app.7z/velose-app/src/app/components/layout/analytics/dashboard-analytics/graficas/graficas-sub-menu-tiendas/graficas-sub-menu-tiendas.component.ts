import { Component, OnInit, Input } from '@angular/core';
import { AnalyticsService, dataKPIVentasFiltroInterface } from '../../../../../../services/analytics.service';

@Component({
  selector: 'app-graficas-sub-menu-tiendas',
  templateUrl: './graficas-sub-menu-tiendas.component.html',
  styleUrls: ['./graficas-sub-menu-tiendas.component.css']
})
export class GraficasSubMenuTiendasComponent implements OnInit {
  @Input ('formatoMoneda')formatoMoneda? :"S/"|"$";
  @Input ('dataGraficaSubMenuFiltro') 
  set filtroVentas(value:dataKPIVentasFiltroInterface) {
    this.dataGraficaSubMenuFiltro=value
    this.getDataTiendas();
  }

  dataGraficaSubMenuFiltro:dataKPIVentasFiltroInterface; 

  spinnerSalesCity: boolean = false;
  mostrarDistritosSubMenu: boolean = true;
  dataSalesCity: any=[];


  constructor(
    private _analyticsService: AnalyticsService,

  ) { }

  ngOnInit() {
  }

  getDataTiendas(){
    this.spinnerSalesCity = true;
    this._analyticsService.getDataSubMenuGraficosSeries(this.dataGraficaSubMenuFiltro)
       .subscribe((response:any) => {
         if (response.length > 0) {
           this.dataSalesCity = response;
           this.mostrarDistritosSubMenu=true
         }
         else {
           this.mostrarDistritosSubMenu=false
         }
         this.spinnerSalesCity = false;
       });
  }

}
