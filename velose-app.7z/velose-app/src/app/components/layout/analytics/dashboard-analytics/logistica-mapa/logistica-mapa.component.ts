import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logistica-mapa',
  templateUrl: './logistica-mapa.component.html',
  styleUrls: ['./logistica-mapa.component.css']
})
export class LogisticaMapaComponent implements OnInit {

     //#region mapa
     lat: number = -12.0750295; // LINCE
     lng: number = -77.0435289;
   
     dirOrigen = { latitude: -11.846519, longitude: -77.098414 };
     dirDestino = { latitude: -11.9594023, longitude: -77.0760457 };
   
     warning = { latitude: -11.9594023, longitude: -77.0760457 };
   
     selectStore = false;
   
     single = [
       {
         name: "Ventas",
         value: "200"
       },
       {
         name: "# Clientes",
         value: "20"
       },
       {
         name: "# Comprobantes",
         value: "200"
       },
       {
         name: "Tiendas",
         value: "7"
       }
     ];
     storeList = [
       {
         lat: -11.846519,
         lng: -77.098414
       },
       {
         lat: -12.184403,
         lng: -76.946841
       },
       {
         lat: -12.03,
         lng: -76.982514
       }
     ];
   
     activeSelect = false;
     siteSelected = [];
   
   
     //mapa
     markerMap = [];
     circleMap = [];
   
     viewMarkerMap = [];
     viewCircleMap = [];
   
     markerMapVisible = true;
     circleMapVisible = true;
     markerMapAllSelect = true;
   
     kpiVentas = 0;
     kpiClientes = 0;
     kpiComprobantes = 0;
     kpiTiendas = 0;
     kpiVendedores = 0;
   
     kpiListaMap = [];
   
     warning_icono_unselected =
       "http://maps.google.com/mapfiles/ms/icons/red.png";
     warning_icono_selected =
       "http://maps.google.com/mapfiles/ms/icons/red-pushpin.png";
   
     normal_icono_selected =
       "http://maps.google.com/mapfiles/ms/icons/grn-pushpin.png";
     normal_icono_unselected =
       "http://maps.google.com/mapfiles/ms/icons/red-pushpin.png";
   
     normal_color_selected = "#FF0000";
     normal_color_unselected = "#00FF00";
   
     siteData = [
       {
         ubigeo: "150117",
         name: "Los Olivos",
         color: this.normal_color_selected,
         lat: -11.9594023,
         lng: -77.0760457,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150110",
         name: "Comas",
         color: this.normal_color_selected,
         lat: -11.9299805,
         lng: -77.053541,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150119",
         name: "Lurin",
         color: this.normal_color_selected,
         lat: -12.2526278,
         lng: -76.884032,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150132",
         name: "San Juan Lurigancho",
         color: this.normal_color_selected,
         lat: -11.9689301,
         lng: -76.9939836,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150103",
         name: "Ate",
         color: this.normal_color_selected,
         lat: -12.0266998,
         lng: -76.8895843,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150108",
         name: "Chorrillos",
         color: this.normal_color_selected,
         lat: -12.1876499,
         lng: -77.0077636,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150104",
         name: "Barranco",
         color: this.normal_color_selected,
         lat: -12.143831,
         lng: -77.020759,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150105",
         name: "Breña",
         color: this.normal_color_selected,
         lat: -12.0584783,
         lng: -77.0506617,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150120",
         name: "Magdalena",
         color: this.normal_color_selected,
         lat: -12.0904353,
         lng: -77.069999,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150116",
         name: "Lince",
         color: this.normal_color_selected,
         lat: -12.0853194,
         lng: -77.0357761,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       },
       {
         ubigeo: "150113",
         name: "Jesus Maria",
         color: this.normal_color_selected,
         lat: -12.0750295,
         lng: -77.0435289,
         cantidad: this.getRndInteger(100, 500),
         venta: this.getRndInteger(1000, 5000),
         clientes: this.getRndInteger(10, 50),
         comprobantes: this.getRndInteger(10, 50),
         tiendas: this.getRndInteger(1, 5),
         vendedores: this.getRndInteger(1, 10),
         icono: this.normal_icono_selected,
         label: "",
         selected: true,
         warning: false,
         viewInfoWindow: false
       }
     ];
     //#endregion
 
     
  constructor() { }

  ngOnInit() {
    this.viewMap();
  }

  viewMap() {
    this.kpiVentas = 0;
    this.kpiClientes = 0;
    this.kpiComprobantes = 0;
    this.kpiTiendas = 0;
    this.kpiVendedores = 0;

    this.circleMap = [];
    this.markerMap = [];
    let sites = this.siteData;
    for (var site in sites) {
      let tCircle = {
        latitude: sites[site].lat,
        longitude: sites[site].lng,
        color: sites[site].color,
        radius: sites[site].cantidad * 2,
        icono: sites[site].icono,
        label: sites[site].label
      };
      let tMarker = {
        latitude: sites[site].lat,
        longitude: sites[site].lng,
        color: sites[site].color,
        radius: sites[site].cantidad * 2,
        icono: sites[site].icono,
        label: sites[site].label,

        venta: sites[site].venta,
        clientes: sites[site].clientes,
        comprobantes: sites[site].comprobantes,
        tiendas: sites[site].tiendas,
        vendedores: sites[site].vendedores
      };

      this.circleMap.push(tCircle);
      this.markerMap.push(tMarker);

      this.viewCircleMap = this.circleMap;
      this.viewMarkerMap = this.markerMap;

      this.kpiVentas = this.kpiVentas + sites[site].venta;
      this.kpiClientes = this.kpiClientes + sites[site].clientes;
      this.kpiComprobantes = this.kpiComprobantes + sites[site].comprobantes;
      this.kpiTiendas = this.kpiTiendas + sites[site].tiendas;
      this.kpiVendedores = this.kpiVendedores + sites[site].vendedores;
    }

    this.setViewPKIs();
  }

  mapClicked(event) {
  }

  setViewPKIs() {
    this.kpiListaMap = [];
    // this.kpiListaMap.push( { "name": "Ventas", "value": this.kpiVentas } )
    // this.kpiListaMap.push( { "name": "# Clientes", "value": this.kpiClientes } )
    this.kpiListaMap.push({ name: "# Guias", value: this.kpiComprobantes });
    //this.kpiListaMap.push( { "name": "Centros de<br>Distribución", "value": this.kpiTiendas } )
    // this.kpiListaMap.push( { "name": "Vendedores", "value": this.kpiVendedores } )
    this.kpiListaMap.push({ name: "Puntos de<br>Distribución", value: 11 });
  }

    // setViewPKIs() {
    //
    //   this.service
    //     .getDataKPILogChart(
    //       this.idDashboard,
    //       52,
    //       this.ruc,
    //       this.moneda,
    //       this.periodo,
    //       this.unidad,
    //       this.top,
    //       this.receptor
    //     )
    //     .subscribe(response => {
    //       this.dataKPIGuias = response;
    //       //this.spinnerKPIVentas = false;
    //     });
    //
    //     this.service
    //       .getDataKPILogChart(
    //         this.idDashboard,
    //         53,
    //         this.ruc,
    //         this.moneda,
    //         this.periodo,
    //         this.unidad,
    //         this.top,
    //         this.receptor
    //       )
    //       .subscribe(response => {
    //         this.dataKPIPuntos = response;
    //         //this.spinnerKPIVentas = false;
    //       });
    //
    //     this.kpiListaMap = [];
    //     this.kpiListaMap.push(this.dataKPIGuias);
    //     this.kpiListaMap.push(this.dataKPIPuntos);
    // }



  //interaccionMapa
 
  getViewInfoWindow(index) {
    return this.siteData[index].viewInfoWindow;
  }

  setSelectAllMarker() {
    this.selectSites(this.markerMapAllSelect);
    this.calculateKPIs();
  }

  selectSites(select) {
    let tmpColor = this.normal_color_unselected;
    if (select) {
      tmpColor = this.normal_color_selected;
    }

    for (var site in this.siteData) {
      this.siteData[site].color = tmpColor;
      this.siteData[site].selected = select;
    }
    this.viewMap();
  }

  //cambios mapa
  viewZoomCircle(index) {
    this.markerMapAllSelect = false;
    for (var site in this.siteData) {
      this.siteData[site].color = this.normal_color_unselected;
      this.siteData[site].selected = false;
    }
    // this.setSelectAllMarker()
    this.siteData[index].color = this.normal_color_selected;
    this.siteData[index].selected = true;
    this.lat = this.siteData[index].lat;
    this.lng = this.siteData[index].lng;
    this.calculateKPIs();
  }

    // Reusable
    getRndInteger(min, max) {
      return Math.floor(Math.random() * (max - min)) + min;
    }

    calculateKPIs() {
      this.kpiVentas = 0;
      this.kpiClientes = 0;
      this.kpiComprobantes = 0;
      this.kpiTiendas = 0;
      this.kpiVendedores = 0;
      for (var site in this.siteData) {
        if (this.siteData[site].selected) {
          this.kpiVentas = this.kpiVentas + this.siteData[site].venta;
          this.kpiClientes = this.kpiClientes + this.siteData[site].clientes;
          this.kpiComprobantes =
            this.kpiComprobantes + this.siteData[site].comprobantes;
          this.kpiTiendas = this.kpiTiendas + this.siteData[site].tiendas;
          this.kpiVendedores =
            this.kpiVendedores + this.siteData[site].vendedores;
        }
      }
  
      this.setViewPKIs();
    }

    //No se usa
    getRndBoolean() {
      var y = Math.random();
      if (y < 0.5) {
        y = Math.floor(y);
      } else {
        y = Math.ceil(y);
      }
      let retorno = true;
      if (y == 0) {
        retorno = false;
      }
      return retorno;
    }
  
    getLatLon(ubigeo) {
      let LatLon = {
        "150117": { lat: -11.9648541, lng: -77.0688082 },
        "150110": { lat: -11.9325314, lng: -77.0661822 },
        "150119": { lat: -12.2348348, lng: -76.8667463 },
        "150132": { lat: -11.9760645, lng: -77.0630761 },
        "150116": { lat: -12.0773242, lng: -77.0679484 },
        "150113": { lat: -12.0788272, lng: -77.0685802 },
        "150120": { lat: -12.088819, lng: -77.0681358 },
        "150105": { lat: -12.0596291, lng: -77.0601778 },
        "150103": { lat: -12.0389338, lng: -76.9602228 },
        "150108": { lat: -12.1927504, lng: -77.0414269 },
        "150104": { lat: -12.1443461, lng: -77.0385215 }
      };
      return LatLon[ubigeo];
    }

    clickedMarker(index, site, infoWindow) {
      if (this.activeSelect) {
        let icono_selected = this.normal_icono_selected;
        let icono_unselected = this.normal_icono_unselected;
        if (this.siteData[index].warning) {
          icono_selected = this.warning_icono_selected;
          icono_unselected = this.warning_icono_unselected;
        }
  
        if (this.siteData[index].selected) {
          this.siteData[index].icono = icono_unselected;
          this.siteData[index].selected = false;
        } else {
          this.siteData[index].icono = icono_selected;
          this.siteData[index].selected = true;
        }
  
        this.viewMap();
        this.calculateKPIs();
      }
    }

    clickedMarkerStore(event, site, infoWindow) {
      //[iconUrl]="'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'"
    }

    dobleClickedCircle(index, site) {
    }

    selectedSites() {
      for (var site in this.siteData) {
        if (this.siteData[site].selected) {
          this.siteSelected.push(site);
        }
      }
    }

    clickedCircle(index, site) {
      if (this.siteData[index].selected) {
        this.siteData[index].color = this.normal_color_unselected;
        this.siteData[index].selected = false;
      } else {
        this.siteData[index].color = this.normal_color_selected;
        this.siteData[index].selected = true;
      }
  
      this.viewMap();
      this.calculateKPIs();
    }

    setViewMarker() {
      if (this.markerMapVisible) {
        this.viewMarkerMap = this.markerMap;
        //this.markerMapVisible = false
      } else {
        this.viewMarkerMap = [];
        //this.markerMapVisible = true
      }
    }

    setViewInfoWindow(index) {
      this.siteData[index].viewInfoWindow = !this.siteData[index].viewInfoWindow;
    }



}
