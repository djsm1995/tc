import { Component, OnInit, ViewChild,  isDevMode } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmacionAnalisisDatosanalyticsComponent } from '../../../shared/analytics/confirmacion-analisis-datos-analytics/confirmacion-analisis-datos-analytics.component';
import { AnalyticsService, dataKPIVentasFiltroInterface, dataKPIVentasFiltroClass, permisosAnalyticsChartClass, permisosAnalyticsChart } from '../../../../services/analytics.service';
import { ReusableService } from '../../../../services/reusable.service';

const dominioColores=[ "#062a78", "#2ECC71", "#F44437", "#9B59B6", "#F5802D", "#9DC1E0", "#8080C0", "brown", "gray", "yellow", "orange" ];
const idDashboard=1;
@Component({
  selector: 'app-dashboard-analytics',
  templateUrl: './dashboard-analytics.component.html',
  styleUrls: ['./dashboard-analytics.component.css'],
})
export class DashboardAnalyticsComponent implements OnInit {

  // #region Variables

  //  Filtros Principales
   menuPeriodos: any [];
   menuMonedas: any[];
   menuTop: number[];
 
  // SubMenu
   indicadores;
   menuKpisVentas:number;
   mostrarClientesSubMenu: boolean = true;
 
  // clientes seleccionados
   levelSelecteds:string[]
 
  //  filtrosServiciosKpisVentas
    ruc: string;
    moneda:any;
    periodo: string ;
    top: number;
    receptor: string ;
    receptorSubMenuClientes: string ;
    
  //Kpis y Graficos 
   kpiTotalVentasFiltro:dataKPIVentasFiltroInterface;
   kpiClientesFiltro:dataKPIVentasFiltroInterface;
   kpiNroComprobantesFiltro:dataKPIVentasFiltroInterface;
   kpiTiendasFiltro:dataKPIVentasFiltroInterface;
   kpiPromedioVentasXComprobanteFiltro:dataKPIVentasFiltroInterface;
   kpiGastoPromedioXClienteFiltro:dataKPIVentasFiltroInterface;
   kpiProductosDistintosFiltro:dataKPIVentasFiltroInterface;
   kpiPromedioVentasXTiendaFiltro:dataKPIVentasFiltroInterface;

   graficoSubmenuProductosFiltro:dataKPIVentasFiltroInterface;
   graficoSubmenuTiendasFiltro:dataKPIVentasFiltroInterface;
   graficoSubmenuClienteFiltro: dataKPIVentasFiltroInterface;

    //confirmacion analisis de datos.
    varConfirmacionAnalisisDatos:any
    habilitarAnalytics:any=0;
    @ViewChild(ConfirmacionAnalisisDatosanalyticsComponent,{static: false})hijo:ConfirmacionAnalisisDatosanalyticsComponent;
  
   // #endregion

    //Permisos
    listaPermisosBD: string[] = this._analyticsService.obtenerPermisos("analytics","charts");
    permiso = new permisosAnalyticsChart();
    tienePermiso = new permisosAnalyticsChartClass();
   constructor(private _analyticsService: AnalyticsService,
               private sReusable:ReusableService,
               public router:Router,
   ) {
      this.obtenerPermisos();
      this.varConfirmacionAnalisisDatos= false;
      this.cargarFiltrosInicializado()
     }

    cargarFiltrosInicializado(){
      //
      this.menuPeriodos = this._analyticsService.getMenuPeriodos(this.tienePermiso.filtroFechaHoy,this.tienePermiso.filtroFechaSemana,this.tienePermiso.filtroFecha15,this.tienePermiso.filtroFechaMes);
      this.menuPeriodos.length > 0 ? this.periodo = this.menuPeriodos[0].option : this.periodo = "1";//cual estara seleccionada por defecto(COMPROBANTES EMITIDOS)
      //
      this.indicadores = this._analyticsService.getIndicadoresSubmenu(this.tienePermiso.submenuClientes,this.tienePermiso.submenuProductos,this.tienePermiso.submenuTiendas);
      this.indicadores.length > 0  ? this.menuKpisVentas =  this.indicadores[0].value : this.menuKpisVentas = 1;//cual estara seleccionada por defecto
      //
      this.menuMonedas = this._analyticsService.getMenuMonedas(this.tienePermiso.filtroMonedaSoles, this.tienePermiso.filtroMonedaDolares);
      this.menuMonedas.length > 0 ? this.moneda = this.menuMonedas[0] : this.moneda = { siglas: "PEN", simbolo: "S/" };// this.moneda= { siglas: "PEN", simbolo: "S/" };
      //
      this.ruc= this.sReusable.getSessionUsuario().empresa.ruc;
      //
      this.menuTop = this._analyticsService.getMenuTop(this.tienePermiso.filtroTop5,this.tienePermiso.filtroTop10,this.tienePermiso.filtroTop20);
      this.menuTop.length > 0  ? this.top =  this.menuTop[0] : this.top = 5;// this.top=5;
      //
      this.receptor="";
      this.receptorSubMenuClientes="";

      
     }
 

  //  #region lifecycle
    ngOnInit() {
 
      
     }

    //#endregion
 
 
  //  #region Eventos Formularios

  changeCurrency(currancy) {
    this.moneda = currancy;
    this.inicializarVariablesDashboard()
  }

  changePeriod(period) {
    this.periodo = period;
    this.inicializarVariablesDashboard()
  }

  changeTop(top) {
    this.top = top;
    this.graficosSubMenu();
  }

  reenderizarIndicadores(value) {
    this.menuKpisVentas = value;
  }

  returnLevelTreeMap() {
    this.receptorSubMenuClientes="";
    this.resetBreadcrumbsClientes();
    this.graficosSubMenu();
   }

  //#endregion

  
  // #region metodos reusables
  
  inicializarVariablesDashboard(){
    this.kpiTotalVentasFiltro=this.inicializandoKpiVentas(4)
    this.kpiClientesFiltro=this.inicializandoKpiVentas(5)
    this.kpiNroComprobantesFiltro=this.inicializandoKpiVentas(6)
    this.kpiTiendasFiltro=this.inicializandoKpiVentas(7)
    this.kpiPromedioVentasXComprobanteFiltro=this.inicializandoKpiVentas(9)
    this.kpiGastoPromedioXClienteFiltro=this.inicializandoKpiVentas(11)
    this.kpiProductosDistintosFiltro=this.inicializandoKpiVentas(8)
    this.kpiPromedioVentasXTiendaFiltro=this.inicializandoKpiVentas(10)
  
    this.graficosSubMenu()
  }

  graficosSubMenu(){
    this.graficoSubmenuClienteFiltro= this.graficoSubMenuClientes(this.levelSelecteds.length, this.receptorSubMenuClientes)
    this.graficoSubmenuProductosFiltro=this.inicializandoKpiVentas(2) 
    this.graficoSubmenuTiendasFiltro=this.inicializandoKpiVentas(3) 
  }

  graficoSubMenuClientes(nivelSeleccionado:number,receptorClientes:string) :dataKPIVentasFiltroInterface{
    let filtrosServicio:dataKPIVentasFiltroInterface;
    filtrosServicio= (nivelSeleccionado==1)?this.inicializandoKpiVentas(1):this.inicializandoKpiVentas(2)
    filtrosServicio.receptor=receptorClientes

    return filtrosServicio;
  } 

  resetBreadcrumbsClientes(){
   const nameLevel="Clientes";
   this.levelSelecteds = [nameLevel];
  }

  inicializandoKpiVentas(idCardChart:number):dataKPIVentasFiltroInterface {
    let kpi= new dataKPIVentasFiltroClass();
    kpi.idDashboard=idDashboard;
    kpi.idCardChart=idCardChart;
    kpi.moneda= this.moneda.siglas;
    kpi.periodo=this.periodo;
    kpi.ruc=this.ruc;
    kpi.receptor=this.receptor;
    kpi.top= this.top
    return kpi
   }

//#endregion
 
  
  //  #region Inputs Componentes
  changelevelSelected(event){
    this.levelSelecteds=event;
  }

  changeReceptorSelected(event){
    this.receptorSubMenuClientes=event
    //isDevMode()
      //console.log(event)

  }

  confirmacionVisualizacionAnalytics(event){
    this.resetBreadcrumbsClientes()
    this.inicializarVariablesDashboard()
    this.varConfirmacionAnalisisDatos=event;

  }

  //#endregion
  obtenerPermisos(){
    for(let permisoBD of this.listaPermisosBD){
      
      // if(permiso === this.permiso.analytics_charts){//Permiso al submodulo dashboard
      //   this.tienePermiso.analytics_charts = true;
      // }
      if(permisoBD === this.permiso.confirmacion){
        this.tienePermiso.confirmacion = true;
      }
      // Modulo Principal ventas
      // if(permisoBD === this.permiso.opcVentas){
      //   this.tienePermiso.opcVentas = true;
      // }
       ////*Sub Menu 1 / filtros fechas
      // if(permisoBD === this.permiso.filtroFechaHoy){ //por defecto
      //   this.tienePermiso.filtroFechaHoy = true;
      // } 
      if(permisoBD === this.permiso.filtroFechaSemana){
        this.tienePermiso.filtroFechaSemana = true;
      } 
      if(permisoBD === this.permiso.filtroFecha15){
        this.tienePermiso.filtroFecha15 = true;
      } 
      if(permisoBD === this.permiso.filtroFechaMes){
        this.tienePermiso.filtroFechaMes = true;
      } 
       ////*Sub Menu 1 / filtros tipo moneda
      if(permisoBD === this.permiso.filtroMonedaDolares){
        this.tienePermiso.filtroMonedaDolares = true;
      } 
      // if(permisoBD === this.permiso.filtroMonedaSoles){ //por defecto
      //   this.tienePermiso.filtroMonedaSoles = true;
      // } 
      ////*Sub Menu 2 / filtros top de ventas
      if(permisoBD === this.permiso.filtroTop10){
        this.tienePermiso.filtroTop10 = true;
      } 
      if(permisoBD === this.permiso.filtroTop20){
        this.tienePermiso.filtroTop20 = true;
      } 
      // if(permisoBD === this.permiso.filtroTop5){ //Por defecto true
      //   this.tienePermiso.filtroTop5 = true;
      // } 
      ////*Menu 2 
      if(permisoBD === this.permiso.submenuClientes){
        this.tienePermiso.submenuClientes = true;
      } 
      if(permisoBD === this.permiso.submenuProductos){
        this.tienePermiso.submenuProductos= true;
      } 
      if(permisoBD === this.permiso.submenuTiendas){
        this.tienePermiso.submenuTiendas= true;
      } 
    }
  }
}