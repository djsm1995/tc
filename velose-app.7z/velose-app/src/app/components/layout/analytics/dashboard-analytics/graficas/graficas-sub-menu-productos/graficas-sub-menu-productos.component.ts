import { Component, OnInit, Input } from '@angular/core';
import { ReusableService } from '../../../../../../services/reusable.service';
import { AnalyticsService, dataKPIVentasFiltroInterface } from '../../../../../../services/analytics.service';


@Component({
  selector: 'app-graficas-sub-menu-productos',
  templateUrl: './graficas-sub-menu-productos.component.html',
  styleUrls: ['./graficas-sub-menu-productos.component.css']
})
export class GraficasSubMenuProductosComponent implements OnInit {
  @Input ('formatoMoneda')formatoMoneda? :"S/"|"$";
  @Input ('dataGraficaSubMenuFiltro') 
    set filtroVentas(value:dataKPIVentasFiltroInterface) {
      this.dataGraficaSubMenuFiltro=value
      this.getDataProductos();
    }
  
    dataGraficaSubMenuFiltro:dataKPIVentasFiltroInterface;
  
  spinnerSalesProduct: boolean = false;
  mostrarProductosSubMenu: boolean = true;
  dataSalesProduct: any;
  
  constructor(
    private _reusableService:ReusableService,
    private _analyticsService: AnalyticsService,
  ) { }

  ngOnInit() {
  }

  // #region metodos
  getDataProductos(){
    this.spinnerSalesProduct = true;
    this._analyticsService.getDataSubMenuGraficos(this.dataGraficaSubMenuFiltro)
       .subscribe((response:any) => {
         if (response.length > 0) {
           this.dataSalesProduct = response;
           this.mostrarProductosSubMenu=true
         }
         else {
           this.mostrarProductosSubMenu=false
         }
         this.spinnerSalesProduct = false;
       });
  }
  //#endregion







  setLabelFormatting(c): string[] {
    return c;
  }


}
