import { Component, OnInit, Input, Output, EventEmitter, isDevMode } from '@angular/core';
import { ReusableService } from '../../../../../../services/reusable.service';
import { dataKPIVentasFiltroInterface, AnalyticsService } from '../../../../../../services/analytics.service';

@Component({
  selector: 'app-graficas-sub-menu-clientes',
  templateUrl: './graficas-sub-menu-clientes.component.html',
  styleUrls: ['./graficas-sub-menu-clientes.component.css']
})

export class GraficasSubMenuClientesComponent implements OnInit {
  @Input ('formatoMoneda')formatoMoneda :"S/"|"$";
  @Input ('nivelClienteSeleccionados')
    set filtroLevelSeleccionados(value:string[]) {
      this.nivelClienteSeleccionados=value
    }
  @Input ('dataGraficaSubMenuFiltro')
    set filtroVentas(value:dataKPIVentasFiltroInterface) {
      this.dataGraficaSubMenuFiltro=value
      this.getDataClientes();
    }
  @Output() clientesSeleccionados = new EventEmitter()
  @Output() receptorSeleccionado = new EventEmitter()

  dataGraficaSubMenuFiltro:dataKPIVentasFiltroInterface
  spinnerSalesCustomer: boolean = true;
  mostrarClientesSubMenu: boolean = true;
  dataSalesCustomer: any;
  nivelClienteSeleccionados:string[]


  constructor(private _reusableService:ReusableService,
    private _analyticsService: AnalyticsService,) { }

  ngOnInit() {
  }

  // #region metodos
  getDataClientes(){
    this._analyticsService
       .getDataSubMenuGraficos(this.dataGraficaSubMenuFiltro)
       .subscribe((response: any) => {
         // let newData = [];
         let index = 0;

        // response.forEach(function (value) {
        //
        //     if ( value.porcent_acum > 70 ) {
        //       let shortName = "";
        //       let longName = value.name;
        //       value.name.split(" ").forEach(function (value) {
        //         shortName = shortName + value.slice(0,1);
        //       })
        //
        //       // newData.push( { name: shortName, value: response[index].value, receptor: response[index].receptor, label: response[index].name } );
        //
        //       response[index].label = longName; //response[index].name;
        //       response[index].name = shortName;
        //
        //       console.log( longName );
        //       console.log( shortName );
        //       console.log( value.porcent_acum  );
        //
        //     }
        //
        //
        //
        //     index++;
        // });
        if(isDevMode()){
          console.log(this.dataGraficaSubMenuFiltro)
          console.log(response)
        }
         if (response.length > 0) {
           this.mostrarClientesSubMenu = true;   
           this.dataSalesCustomer = response;
         } else {
           this.mostrarClientesSubMenu = false;
         }
         this.spinnerSalesCustomer = false;
       });
  }
  //Seleccion de cliente
  changeLevelTreeMap(event) {

    const idCardProductos=2
    if (this.nivelClienteSeleccionados != [] && this.nivelClienteSeleccionados.length < 2) {
      this.mostrarClientesSubMenu = false;
      this.spinnerSalesCustomer = true;
      let obj = this.searchByName(this.dataSalesCustomer, event.name);
      this.dataGraficaSubMenuFiltro.receptor=obj.receptor
      this.dataGraficaSubMenuFiltro.idCardChart=idCardProductos

      this.getDataClientes();
     // this.nameLevel = event.name; //descomentar y luego emitir
      this.nivelClienteSeleccionados.push(event.name);
      this.clientesSeleccionados.emit(this.nivelClienteSeleccionados)
      this.receptorSeleccionado.emit(this.dataGraficaSubMenuFiltro.receptor)

    }
    if(isDevMode()){
      console.log(this.nivelClienteSeleccionados)

    }
  }

  getDataSubMenuGraficos(){

  }

  searchByName(data, name) {
    for (let item of data) {
      if (item["name"] === name) {
        return item;
      }
    }
  }

  //visualizacion
  getLabelFormatting = c => {
    return this.getFormatoLabel(c); //this.getFormatoLabel(c);
  };

  //visualizacion
  getValueFormatting = c => {
    return this.getFormatoTooltipMoneda(c);
  };

  getFormatoTooltipMoneda(valor) {
    return this._reusableService.getFormatoMilesDecimalesMoneda(valor, this.formatoMoneda);
  }

  getFormatoLabel(item) {
    item.label = this.getLabelClearCharacters(item.label);

    let shortName = "";
    if ( ( ( item.label.length > 24 || ( item.label.split(" ").length >= 2 && item.data.height <= 50 ) ) || this.getBigWord(item.label,7) ) && ( item.data.width <= 167 || item.data.height <= 70 ) ) {
      item.label.split(" ").forEach(function (value) {
        shortName = shortName + value.slice(0,1) + ".";
      });
      item.label = shortName;
    }
    return item.label;
  }

  getLabelClearCharacters(text) {
    text = text.replace(".","");
    return text;
  }

  getBigWord(text,length) {
    let arrText = text.split(" ");
    let bigWord = 0;
    let isBig = false;
    arrText.forEach(function (word) {
      if ( word.length >= length ) { isBig = true; }
    });
    return isBig;
  }

  //#endregion

}
