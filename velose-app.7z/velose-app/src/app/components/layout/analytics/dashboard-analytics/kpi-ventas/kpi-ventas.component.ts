import { Component, OnInit, Input } from '@angular/core';
import { ReusableService } from '../../../../../services/reusable.service';
import { AnalyticsService, dataKPIVentasServiceInterface, dataKPIVentasServiceClass, dataKPIVentasFiltroInterface } from '../../../../../services/analytics.service';

@Component({
  selector: 'app-kpi-ventas',
  templateUrl: './kpi-ventas.component.html',
  styleUrls: ['./kpi-ventas.component.css']
})
export class KpiVentasComponent implements OnInit {
  @Input ('showFormatoMoneda')showFormatoMoneda:boolean = false;
  @Input ('formatoMoneda')formatoMoneda :"S/"|"$" ="S/";
  @Input ('dataKPIVentasFiltro') 
    set filtroVentas(value:dataKPIVentasFiltroInterface) {
      this.dataKPIVentasFiltro=value
      this.getDataKpiVentas()
    }
    
  dataKPIVentasFiltro:dataKPIVentasFiltroInterface;
  dataKPIVentas:dataKPIVentasServiceInterface
  spinnerKPIVentas:boolean=false

  constructor ( private _reusableService:ReusableService,
    private service: AnalyticsService, ) 
    { 
      this.dataKPIVentas= new dataKPIVentasServiceClass();
    }

  ngOnInit() {   
       
  }

  // #region Metodos
  getDataKpiVentas(){
    this.spinnerKPIVentas=true
    this.service
    .getDataKPIChartVentas( this.dataKPIVentasFiltro)
    .subscribe((response:dataKPIVentasServiceInterface) => {
      this.dataKPIVentas = response;
      this.dataKPIVentas.format=this.getKpiFormat();
      this.spinnerKPIVentas = false;
    });
  }


  getKpiFormat():string{
    // con formato moneda o sin moneda
    return (this. showFormatoMoneda)?this.getFormatoMilesMonedas():this.getFormatoMiles()
  }

  getFormatoMiles(){
    return (this.dataKPIVentas.value!=null)? this._reusableService.getFormatoMiles(this.dataKPIVentas.value,0):""
  }

  getFormatoMilesMonedas(){
    return (this.dataKPIVentas.value !=null)? this._reusableService.getFormatoMilesMoneda(this.dataKPIVentas.value,this.formatoMoneda):"" //variable a cambiar
  }
  //#endregion


}




