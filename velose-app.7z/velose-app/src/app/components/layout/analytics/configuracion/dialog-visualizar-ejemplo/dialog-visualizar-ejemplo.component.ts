import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-visualizar-ejemplo',
  templateUrl: './dialog-visualizar-ejemplo.component.html',
  styleUrls: ['./dialog-visualizar-ejemplo.component.css']
})
export class DialogVisualizarEjemploComponent implements OnInit {
  //Productos = 0
  //Tiendas = 1
  tooltipMensaje:string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { row: any }
  ) { 
    this.tipoPantalla(data.row);
  }

  ngOnInit() {
  }

  tipoPantalla(identificador){
    this.tooltipMensaje=(identificador == 0 ) ? 
      "Recordar que el archivo debe contener la extension .csv":
      "Recordar que los metros cuadrados deben estar indicados en decimales con ' . ' como el ejemplo mostrado."
  }
  
}
