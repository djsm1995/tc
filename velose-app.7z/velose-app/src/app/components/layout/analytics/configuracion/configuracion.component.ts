import { Component, OnInit, isDevMode } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';

import { DialogVisualizarEjemploComponent } from '../../analytics/configuracion/dialog-visualizar-ejemplo/dialog-visualizar-ejemplo.component';
import { MensajeGenericoComponent } from '../../../shared/mensaje-generico/mensaje-generico.component';
import { ReusableService } from "../../../../services/reusable.service";
import { AnalyticsService, permisosAnalyticsConfiguracion, permisosAnalyticsConfiguracionClass } from "../../../../services/analytics.service";

@Component({
  selector: 'app-configuracion',
  templateUrl: './configuracion.component.html',
  styleUrls: ['./configuracion.component.css']
})
export class ConfiguracionComponent implements OnInit {
  catalogoProductos: catalogoAnalyticsInterface;
  catalogoTiendas: catalogoAnalyticsInterface;

  // confirmacion analisis datos analytics
  varConfirmacionAnalisisDatos:boolean;

  //Permisos
  listaPermisosBD: string[] = this._analyticsService.obtenerPermisos("analytics", "configuracion");
  permiso = new permisosAnalyticsConfiguracion();
  tienePermiso = new permisosAnalyticsConfiguracionClass();

  constructor(
    private route: ActivatedRoute, 
    private reusable:ReusableService,
    private _analyticsService:AnalyticsService,
    private dialog: MatDialog,
    public snackBar: MatSnackBar,
  ) { 
    this.obtenerPermisos();
    this.catalogoProductos=new catalogoAnalyticsClass();
    this.catalogoTiendas=new catalogoAnalyticsClass();

    this.varConfirmacionAnalisisDatos=false;
  }

  ngOnInit() {
    //Ver pestañas a activar
    this.activarTabConfiguracion();
  }
  

  // #region metodos
  changeCsv(input: HTMLInputElement,tipoCatalogo){
    //1: productos - 2:Tiendas
    let catalogoCSV:catalogoAnalyticsInterface = null;
    switch(tipoCatalogo){
      case 1:
        this.catalogoProductos=new catalogoAnalyticsClass();
        catalogoCSV = this.catalogoProductos;
        break;

      case 2:
        this.catalogoTiendas=new catalogoAnalyticsClass();
        catalogoCSV= this.catalogoTiendas;
        break;
    }

    if(catalogoCSV==null){
      if(isDevMode())console.log("Tipo de catalogo no existee")
      return;
    }

    catalogoCSV.evaluandoArchivo=true;
    catalogoCSV.fileName = input.files.item(0).name;
    if (catalogoCSV.fileName) {
      // Verificacion de extension permitida
      catalogoCSV.evaluandoArchivo=true;
      const EXTENSIONCSV='.csv';
      let extension=catalogoCSV.fileName.substring(catalogoCSV.fileName.lastIndexOf('.')).toLowerCase();
      let extensionPermitida =(extension==EXTENSIONCSV)?true:false;

      if(extensionPermitida){
        let file = input.files.item(0);
        let tamañoMegas = file.size/1024/1024;
        const MAXIMOMEDIDAARCHIVO= 35;
        if(this.reusable.validarMedidaArchivo(MAXIMOMEDIDAARCHIVO,tamañoMegas)){
          
          //#Enviar en Base 64
          var myReader:FileReader = new FileReader();
          var self = this;
          myReader.onloadend=
            function(e){
              catalogoCSV.file = btoa(self.reusable.utf8Encode(myReader.result))
              self._analyticsService.subirCatalogoAnalytics(tipoCatalogo,self.assembleDataCargaCatalogo(tipoCatalogo))
              .subscribe((response:any)=>{
                if(response.status){
                  catalogoCSV.evaluandoArchivo=false;
                  self.mensajeConfiguracion(response.message);
                }
                else{
                  self.mensajeConfiguracion("Archivo con errores");

                  // Mostrar mensaje de error
                  self.dialog.open(
                    MensajeGenericoComponent,
                    {
                      width: "400px",
                      data: {
                        icon: "warning",
                        color: "red",
                        titulo: "Reporte de errores",
                        mensaje: response.message
                      }
                    }
                  );
                }
                
                catalogoCSV.file=null;
                catalogoCSV.fileName=null;
                catalogoCSV.evaluandoArchivo=false;
                catalogoCSV.size=null;
                
              });
            }
          myReader.readAsText(file);        

        }else{
          catalogoCSV= new catalogoAnalyticsClass();
          this.mensajeConfiguracion("El archivo pesa más de lo indicado");
        }
      }
      else{
        catalogoCSV.evaluandoArchivo=false;
        catalogoCSV.fileName="";
        this.mensajeConfiguracion("Formato Incorrecto");
      }
    }
  }

  activarTabConfiguracion(){
    this.route.params.subscribe(params=>{
      if(params['producto']!=undefined){
        //mostrar primera pestaña
      }
    })
  }

  // Reusables
  assembleDataCargaCatalogo(tipoCatalogo){
    let data:catalogo_AnalyticsServiceInterface =new catalogo_AnalyticsServiceClass();
    data.ruc= this.reusable.getSessionUsuario().empresa.ruc
    switch(tipoCatalogo){
      case 1:
        data.nameFile= this.catalogoProductos.fileName
        data.contentFile64= this.catalogoProductos.file
        break;
      case 2:
        data.nameFile= this.catalogoTiendas.fileName
        data.contentFile64= this.catalogoTiendas.file
        break;

    }
    
    return data;
  }
  //#endregion
  
  dialogVisualizarEjemplo(identificador){
    let dialogRef = this.dialog.open( DialogVisualizarEjemploComponent, {
      width: "580px",
      maxHeight: "80vh",
      data: {
        row: identificador,
      }
    });
  }
  mensajeConfiguracion(mensaje){
    this.snackBar.open(mensaje, "OK", {
      duration: 5000
    });
  }

  //  #region Cargar confirmacion de analisis de datos
  
  confirmacionVisualizacionAnalytics(event){
    // this.resetBreadcrumbsClientes()
    // this.inicializarVariablesDashboard()
    this.varConfirmacionAnalisisDatos=event;

  }

  //#endregion

  obtenerPermisos(){
    for(let permisoBD of this.listaPermisosBD){      
      if(permisoBD === this.permiso.analytics_configuracion){
        this.tienePermiso.analytics_configuracion = true;
      }
      if(permisoBD === this.permiso.catalogoProductos){
        this.tienePermiso.catalogoProductos = true;
      }
      if(permisoBD === this.permiso.catalogoTiendas){
        this.tienePermiso.catalogoTiendas = true;
      }
      
    }
  }

}
// ===================================================================================================================

interface catalogoAnalyticsInterface{
  fileName: string;
  size: string;
  file:string;
  evaluandoArchivo:boolean
}

interface catalogo_AnalyticsServiceInterface{
  ruc: number;
  nameFile: string;
  contentFile64:string;
}

class catalogo_AnalyticsServiceClass{
  ruc: number;
  nameFile: string;
  contentFile64:string;


  constructor(){
    this.ruc=null;
    this.nameFile=null;
    this.contentFile64=null;
  }
}

class catalogoAnalyticsClass{
  fileName: string;
  size: string;
  file:string;
  evaluandoArchivo:boolean


  constructor(){
    this.fileName=null;
    this.size=null;
    this.file=null;
    this.evaluandoArchivo=false;

  }
}
