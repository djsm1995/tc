import { Component, Inject,AfterContentInit,OnInit} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReusableService} from '../../../../services/reusable.service'

@Component({
  selector: 'app-informacion-inicial',
  templateUrl: './informacion-inicial.component.html',
  styleUrls: ['./informacion-inicial.component.css']
})
export class InformacionInicialComponent implements OnInit{
tipoUsuarioLogeado:number=0; //nuevo cliente
sessionActual:any;
datosMostrar:any[]=[
  {
    id:1,
    titulo:"Bienvenido a Velose",
    contenido:"Ya formas parte de VelOSE, solución de TCI S.A, la cual te ayudará a mejorar tu productividad  y optimizar tus costos. Revisa nuestro tutorial para empezar a validar tus comprobantes electrónicos.",
  },
  {
    id:2,
    titulo:"Bienvenido a Velose",
    contenido:"Estamos felices de trabajar contigo. Hemos preparado un corto tutorial para mostrarte como realizar busqueda de comprobantes.",
  },
  {
    id:3,
    titulo:"Bienvenido a Velose",
    contenido:"Estamos felices de que sigas trabajando con nosotros. Hemos preparado un corto tutorial para mostrarte como realizar búsqueda de comprobantes.",
  }
];
usuarioLogeado:any;

  constructor(public _dialogRef: MatDialogRef<InformacionInicialComponent>,
              @Inject(MAT_DIALOG_DATA) public _data: any,
              @Inject('rucTci') private rucTci: number,
              private sReusable:ReusableService

              ) {
            }
    ngOnInit(){
      this.usuarioLogeado= this.sReusable.getSessionUsuario()
      if(this.usuarioLogeado.firstTime){
        setTimeout(() =>
            this.getTipoUsuarioLogeado()
            , 0);
      }
    }
  getTipoUsuarioLogeado() {
    this.usuarioLogeado=(this.usuarioLogeado.habilitarPago)?0:1
    // if (this.usuarioLogeado.empresa.tipoEmisor == null) {
    //   this.tipoUsuarioLogeado = 0;
    //   return;
    // }
    // this.usuarioLogeado = this.usuarioLogeado.empresa.tipoEmisor;
    }

}
