import { Component, OnInit,ViewChild,ElementRef,AfterContentInit,Renderer2,
          ChangeDetectorRef,ChangeDetectionStrategy,Inject} from '@angular/core';
// import {NgxChartsModule} from '@swimlane/ngx-charts';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {InformacionInicialComponent} from './informacion-inicial/informacion-inicial.component';
import {PlanesComponent} from '../../shared/planes/planes.component';

// Servicios
import {DashboardService,MultiCpes,ResponseMultiCpes,
        responsePeriodoFacturacion,periodoFacturacion,periodoFacturacionC,
        baseGraficoSeries,baseGraficoSeriesC,baseGraficoValue,baseGraficoValueC,
        responseAcumuladoCPESEnviados,responseCPESEnviados,responseCpesCantidadesFiltro,
        responseCpesDisponibles, permisosDashboardClass,permisosDashboard}
        from '../../../services/dashboard.service';
import { ReusableService } from '../../../services/reusable.service';
import { Catalogo } from '../../../constantes/catalogo';
// Constantes
const color_accent="#FEA501";
const coloresCpes={
  facturas:"#062a78", //azul
  boletas:"#2ECC71", //verde
  nc:"#F44437", //rojo
  nd:"#9B59B6", //morado
  gre:"#F5802D",
  dae:"#9DC1E0",
  cr:"#8080C0",
  cp:"brown",
  rc:"gray",
  cb:"yellow",
  rv:"orange"
}
const color_velose="#673AB7";
const color_plomo = "#DEDEDE";

// Componente
@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit, AfterContentInit {
  // Variables Diseño
  tipoEmisor = Catalogo.TIPOEMISOR;
  customColors = [];
  customColorsDetalleValidacion = [];

  datosCpesFacturados: any = new baseGraficoSeriesC();
  colorSchemeCpesDisponibles = { domain: [coloresCpes.facturas] };
  datosCpesDisponibles: baseGraficoValue[] = [new baseGraficoValueC()];
  datosDetalleValidacion: baseGraficoValue[] = [new baseGraficoValueC()];
  colorSchemeDetalleValidacion = { domain: [coloresCpes.facturas] };

  // Doughnout disponibles vs utilizados
  colorSchemeCpesEnviadosRechazados = {
    domain: [coloresCpes.facturas, "#DEDEDE"]
  };
  // Cpes Facturados Cantidades barras
  colorSchemeCpesFacturados = {
    domain: [
      coloresCpes.facturas,
      coloresCpes.boletas,
      coloresCpes.nc,
      coloresCpes.nd,
      coloresCpes.gre,
      coloresCpes.dae,
      coloresCpes.cr,
      coloresCpes.cp,
      coloresCpes.rc,
      coloresCpes.cb,
      coloresCpes.rv
    ]
  };

  colorSchemeCpesEnviados = { domain: [coloresCpes.facturas] };

  filtroTiempoSelected = "34";
  datosCpesCantidadesFiltro: any = [];
  date = new Date();
  // datosCpesFacturadosPC:any;
  datosCpesEnviados: baseGraficoValue[] = [new baseGraficoValueC()];
  periodoFacturacionProgressBar = {
    value: 0,
    color: "warn"
  };
  planFacturacion = new periodoFacturacionC();
  // Variables FirstLine
  cpesEnviadosHoy = 0;
  cpesRechazadosHoy = 0;
  cpesValidados = {
    validacionesExitosas: 0,
    validacionesConExcepciones: 0,
     //fechaInicio: this.getdiaActual()
    fechaInicio: this.sReusable.getFormatoFecha(new Date(this.date.getFullYear(), this.date.getMonth(), 1), 4)
  };
  // variables nuevousuario
  nuevoUsuario: boolean = true;
  tutorialInicial: boolean = false;
  usuarioLogeado :any;

  // Plan planIlimitado
  esPlanIlimitado = false;
  validacionesUtilizadas = 0;
  //Desplegar Graficos
  displayDatosCpesCantidadesFiltro: boolean;
  displayDatosCpesFacturados: boolean;
  displayDatosCpesEnviados: boolean;
  //Desplegar cargando en Graficos
  isLoadingDatosCpesDisponibles: boolean;
  isLoadingPeriodoFacturacionProgressBar: boolean;
  isLoadingCpesEnviadosHoy: boolean;
  isLoadingCpesValidados: boolean;
  isLoadingDataDetalleValidacion: boolean;

  isLoadingDatosCpesFacturados: boolean;
  isLoadingDatosCpesCantidadesFiltro: boolean;
  isLoadingDatosCpesEnviados: boolean;

  //Permisos
  listaPermisosBD: string[] = this._datosDashboard.obtenerPermisos();
  permiso = new permisosDashboard();
  tienePermiso = new permisosDashboardClass();
  constructor(
    private _datosDashboard: DashboardService,
    private cd: ChangeDetectorRef,
    private sReusable: ReusableService,
    public dialog: MatDialog,
    private _router: Router
  ) {
    this.obtenerPermisos();
    this.usuarioLogeado= this.sReusable.getSessionUsuario()
  }

  // lifecycle
  ngOnInit() {
    this.getDatosDashboard();
  }
  ngAfterContentInit() {
    this.dialogDashboard();
    this.tutorial();
  }
  ngOnDestroy() {
    this.cd.detach();
    // unsubscribe
  }

  dialogDashboard(): void {
    // Asincrono para que no muestre error
    let dialogRef;
    if (this.usuarioLogeado.firstTime) {
      setTimeout(
        () =>
          (dialogRef = this.dialog.open(InformacionInicialComponent, {
            width: "440px",
            data: { name: "name" }
          })),
        0
      );

      setTimeout(
        () =>
          dialogRef.afterClosed().subscribe(result => {
            this.usuarioLogeado.firstTime = false;
            this.sReusable.setSessionUsuario(this.usuarioLogeado)
          }),
        0
      );
    }
  }

  getPlanes() {
    let dialogRef;
    dialogRef = this.dialog.open(PlanesComponent, {
      width: "720px",
      data: { name: "name" }
    });

    dialogRef.afterClosed().subscribe(result => {});
  }

  getDatosDashboard() {
    this.customColors = [
      {
        name: "Factura",
        value: coloresCpes.facturas
      },
      {
        name: "Boleta",
        value: coloresCpes.boletas
      },
      {
        name: "Nota de Crédito",
        value: coloresCpes.nc
      },
      {
        name: "Nota de Débito",
        value: coloresCpes.nd
      },
      {
        name: "Guía de Remisión",
        value: coloresCpes.gre
      },
      {
        name: "Servicios Públicos",
        value: coloresCpes.dae
      },
      {
        name: "Retención",
        value: coloresCpes.cr
      },
      {
        name: "Percepción",
        value: coloresCpes.cp
      },
      {
        name: "Resumen Diario de Boletas",
        value: coloresCpes.rc
      },
      {
        name: "Comunicado de Bajas",
        value: coloresCpes.cb
      },
      {
        name: "Reversión",
        value: coloresCpes.rv
      }
    ];
   this.dashboardXTipo();
  }

  dashboardXTipo() {
    let ruc = this.usuarioLogeado.empresa.ruc;
    let idPse = this.usuarioLogeado.empresa.idPse;
    if (this.sReusable.esClientePrepago(this.usuarioLogeado)) {
      this.dashboardPrepago(ruc, idPse);
    } else {
      this.dashboardPostpago(ruc, idPse);
    }
  }
  dashboardPrepago(ruc, idPse) {
    // PRimera Fila

    // Doughnout enviados vs rechazados
    this.cpesDisponiblesPieService(idPse);

    // Progressbar plan
    this.planProgressbarService();

    // cpesEnviadosHoy
    this.enviadosRechazadosHoyService(ruc);

    // Segunda Fila
    this.datosCpesCantidadesFiltroService(ruc);

    //TerceraFila
    this.cpesFacturadosBaService(ruc);

    //CuartaFila
    this.datosCantidadCpesFacturadosBService(ruc);
  }
  dashboardPostpago(ruc, idPse) {
    // PRimera Fila

    // cpesEnviadosHoy
    this.enviadosRechazadosHoyService(ruc);

    // cpes validados
    this.cpesValidadosxFechaService(ruc);

    // Segunda Fila
    this.datosCpesCantidadesFiltroService(ruc);
    
    //TerceraFila
    this.cpesFacturadosBaService(ruc);

    //CuartaFila
    this.datosCantidadCpesFacturadosBService(ruc);
  }

  validarDatosCpesFacturados() {
    let count = 0;
    this.datosCpesFacturados.forEach(function(element) {
      if (element.series.length == 0) {
        count++;
      }
    });
    this.displayDatosCpesFacturados = (count == this.datosCpesFacturados.length)?false:true
  }

  colorescpesDisponibles() {
    // si datos son mayores que 80% y menos que 90 % es naranja mas de 90% y menos de 100% es rojo
    let totalPlan: number =
      this.datosCpesDisponibles[0].value + this.datosCpesDisponibles[1].value;
    let porcentaje = (this.datosCpesDisponibles[0].value * 100) / totalPlan;
    let colores: any;
    if (porcentaje >= 80) {
      if (porcentaje >= 90) {
        colores = {
          domain: [coloresCpes.nc, "#DEDEDE"]
        };
      } else {
        colores = {
          domain: [color_accent, "#DEDEDE"]
        };
      }
    } else {
      colores = {
        domain: [coloresCpes.facturas, "#DEDEDE"]
      };
    }

    return colores;
  }

  // #region services

  planProgressbarService() {
    this.isLoadingPeriodoFacturacionProgressBar = true;
    let idPse = this.usuarioLogeado.empresa.idPse;
    this._datosDashboard
      .getPlanFacturacion(idPse)
      .subscribe((response: responsePeriodoFacturacion) => {
        if (response.estado) {
          this.planFacturacion = response.planFacturacion;
          // Fecha de Planes
          this.getFechaPlanFacturacion();

          // Porcentajes
          let du =
            this.planFacturacion.diasPlan - this.planFacturacion.diasRestantes;
          let porcentaje = (du * 100) / this.planFacturacion.diasPlan;
          this.periodoFacturacionProgressBar.value = porcentaje;
          this.periodoFacturacionProgressBar.color =
            porcentaje < 80 ? "primary" : porcentaje < 90 ? "accent" : "warn";
        }
        this.isLoadingPeriodoFacturacionProgressBar = false;
        this.cd.detectChanges();
      });
    return;
  }

  cpesDisponiblesPieService(idPse) {
    this.isLoadingDataDetalleValidacion = true;
    this.isLoadingDatosCpesDisponibles = true;
    this._datosDashboard
      .getCpesDisponiblesD(idPse)
      .subscribe((response: responseCpesDisponibles) => {
        if (response && response.estado) {
          //si es un plan planIlimitado
          let disponibles = response.cpesDisponibles;
          this.esPlanIlimitado = disponibles.planIlimitado ? true : false;
          this.validacionesUtilizadas = disponibles.validacionUtilizadas;
          // Data Validaciones Pie disponibles
          if (
            disponibles.dataValidaciones != null &&
            disponibles.dataValidaciones.length > 0
          ) {
            this.datosCpesDisponibles = disponibles.dataValidaciones;
          }
          this.colorSchemeCpesDisponibles.domain.push(color_plomo);

          // Data Detalle Validaciones Pie detalles
          if (
            disponibles.dataValidaciones != null &&
            disponibles.dataDetalleValidacion.length > 0
          ) {
            this.datosDetalleValidacion = disponibles.dataDetalleValidacion;
          }
          this.colorSchemeDetalleValidacion.domain.push(color_plomo);
          this.customColorsDetalleValidacion = [
            {
              name: "Aceptados",
              value: coloresCpes.boletas
            },
            {
              name: "En espera",
              value: coloresCpes.cb
            },
            {
              name: "Rechazados",
              value: coloresCpes.nc
            }
          ];

          this.isLoadingDatosCpesDisponibles = false;
          this.isLoadingDataDetalleValidacion = false;
          this.cd.detectChanges();
        } else {
          // service.unsubscribe();
          // this.da
        }
      });
  }

  enviadosRechazadosHoyService(ruc) {
    if(this.tienePermiso.kpiPost){
      this.isLoadingCpesEnviadosHoy = true;
      this._datosDashboard.getCpesEnviadosHoy(ruc).subscribe((response: any) => {
        if (response && response.estado) {
          this.cpesEnviadosHoy = response.cpes.cpesEnviadosHoy;
          this.cpesRechazadosHoy = response.cpes.cpesRechazadosHoy;
        }
        this.isLoadingCpesEnviadosHoy = false;
        this.cd.detectChanges();
      });
    }
  }

  cpesValidadosxFechaService(ruc) {
    var dateDay = new Date().getDate()-1;
    if(this.tienePermiso.kpiPost){
    // cpesValidadosEmisorTCI
    this.isLoadingCpesValidados = true;
    this._datosDashboard
      .getCpesValidados(ruc, dateDay)
      .subscribe((response: any) => {
        if (response && response.estado) {
          this.cpesValidados = response.validaciones;
          this.cpesValidados.fechaInicio = this.sReusable.getFormatoFecha(
            new Date(this.cpesValidados.fechaInicio),
            4
          );
        }
        this.isLoadingCpesValidados = false;
        this.cd.detectChanges();
      });
    }
  }

  datosCpesCantidadesFiltroService(ruc) {
    if(this.tienePermiso.comprobantesEnviados){
    this.displayDatosCpesCantidadesFiltro = true;
    this.isLoadingDatosCpesCantidadesFiltro = true;
    this._datosDashboard
      .getCpesCantidadesFiltro(this.filtroTiempoSelected, ruc)
      .subscribe((response: responseCpesCantidadesFiltro) => {
        if (response && response.estado) {
          //console.log("Resultado getCpesCantidadesFiltro:"+JSON.stringify(response))
          this.datosCpesCantidadesFiltro = response.cpesFacturadosHoraDia;
          if (this.datosCpesCantidadesFiltro.length > 0) {
            this.displayDatosCpesCantidadesFiltro = true;
          } else {
            this.displayDatosCpesCantidadesFiltro = false;
          }
          this.isLoadingDatosCpesCantidadesFiltro = false;
        }
        this.cd.detectChanges();
      });
    }
  }

  cpesFacturadosBaService(ruc) {
    if(this.tienePermiso.acumuladoComprobantes){
      this.isLoadingDatosCpesFacturados = true;
      this.displayDatosCpesFacturados = false;
      this._datosDashboard
        .getCpesFacturadosBA(ruc)
        .subscribe((response: ResponseMultiCpes) => {
          if (response && response.estado) {
  
            this.datosCpesFacturados = response.cpesAprobados;
            this.validarDatosCpesFacturados();
          }
          this.isLoadingDatosCpesFacturados = false;
          this.cd.detectChanges();
        });
    }
  }

  datosCantidadCpesFacturadosBService(ruc) {
    if(this.tienePermiso.cantidadValidaciones){
      this.isLoadingDatosCpesEnviados = true;
      this.displayDatosCpesEnviados = true;
  
      this._datosDashboard
        .getCantidadCpesFacturadosB(ruc)
        .subscribe((response: responseCPESEnviados) => {
          if (response && response.estado) {
            this.datosCpesEnviados = response.cpesTotal;
            let count = 0;
            this.datosCpesEnviados.forEach(function(element) {
              if (element.value == 0) {
                count++;
              }
            });
  
            if (count == this.datosCpesEnviados.length) {
              this.displayDatosCpesEnviados = false;
            }
          }
          this.isLoadingDatosCpesEnviados = false;
          this.cd.detectChanges();
        });
    }
  }

  //#endregion

  // actualizarKpiService(num) {
  //   let ruc = this.usuarioLogeado.empresa.ruc;
  //   switch (num) {
  //     case 1:
  //       this.enviadosRechazadosHoyService(ruc);
  //       break;
  //     case 2:
  //       this.enviadosRechazadosHoyService(ruc);
  //       break;
  //     case 3:
  //       this.cpesValidadosxFechaService(ruc);
  //       break;
  //     case 4:
  //       this.cpesValidadosxFechaService(ruc);
  //       break;
  //     case 5: //Tercera Fila
  //       this.cpesFacturadosBaService(ruc);
  //       break;
  //     case 6: //Segunda Fila
  //       this.datosCpesCantidadesFiltroService(ruc);
  //       break;
  //     case 7: //Cuarta Fila
  //       this.datosCantidadCpesFacturadosBService(ruc);
  //       break;

  //     default:
  //       break;
  //   }
  // }

  // Reutilizables/
  getFechaPlanFacturacion() {
    let inicioPlan: any;
    let finPlan: any;
    if (this.planFacturacion.fechaInicioPlan != null) {
      inicioPlan = this.sReusable.getFormatoFecha(
        new Date(this.planFacturacion.fechaInicioPlan),
        3
      );
    } else {
      inicioPlan = 0;
    }
    if (this.planFacturacion.fechaInicioPlan != null) {
      finPlan = this.sReusable.getFormatoFecha(
        new Date(this.planFacturacion.fechaFinPlan),
        3
      );
    } else {
      finPlan = 0;
    }
    this.planFacturacion.fechaInicioPlan = inicioPlan;
    this.planFacturacion.fechaFinPlan = finPlan;
  }
  // getdiaAnterior() {
  //   let fecha = new Date();
  //   let ayer = new Date(fecha.getTime() - 24 * 60 * 60 * 1000);
  //   return ayer.toLocaleDateString();
  // }
  // getdiaActual() {
  //   let fecha = new Date();
  //   return this.sReusable.getFormatoFecha(fecha, 4);
  // }
  getHoraActual() {
    let fecha = new Date();
    return fecha.toLocaleTimeString();
  }

  changeValueFiltro(evento) {
    if(this.tienePermiso.comprobantesEnviados){
      this.isLoadingDatosCpesCantidadesFiltro = true;
      this.displayDatosCpesCantidadesFiltro = true;
      let ruc = this.usuarioLogeado.empresa.ruc;
      this._datosDashboard
        .getCpesCantidadesFiltro(this.filtroTiempoSelected, ruc)
        .subscribe((response: responseCpesCantidadesFiltro) => {
          //responseCPESEnviados
          if (response && response.estado) {
            this.datosCpesCantidadesFiltro = response.cpesFacturadosHoraDia;
            if (this.datosCpesCantidadesFiltro.length > 0) {
              this.displayDatosCpesCantidadesFiltro = true;
            } else {
              this.displayDatosCpesCantidadesFiltro = false;
            }
            this.isLoadingDatosCpesCantidadesFiltro = false;
            this.cd.detectChanges();
          }
        });
    }
  }
  tutorial() {
    this.tutorialInicial = this.nuevoUsuario ? true : false;
    // this.tutorialInicial = this.nuevoUsuario;
  }

  // cpesDisponibles
  getCpeDisponibleValue() {
    // [0]:Utilizados
    // [1]:Disponibles
    if (this.datosCpesDisponibles[1] != undefined)
      return this.datosCpesDisponibles[1].value;
    else {
      return this.datosCpesDisponibles[0].name == "Disponibles"
        ? this.datosCpesDisponibles[0].value
        : 0;
    }
  }
  getTotalCpeValue() {
    let acumulado: number = 0;
    this.datosCpesDisponibles.forEach(function(data) {
      acumulado += Number(data.value);
    });
    return acumulado;
  }

  // Idioma español 
  tickFormatting(d: any) {
    if (d.constructor.name === 'Date') {
      return d.toLocaleDateString('es-ES');
    }
    return d.toLocaleString('es-ES');
  }

  obtenerPermisos(){
    for(let permiso of this.listaPermisosBD){
      if(permiso === this.permiso.acumuladoComprobantes){
        this.tienePermiso.acumuladoComprobantes = true;//por 6 meses
      }
      if(permiso === this.permiso.cantidadValidaciones){
        this.tienePermiso.cantidadValidaciones = true; //por 12 meses
      }
      if(permiso === this.permiso.comprobantesEnviados){
        this.tienePermiso.comprobantesEnviados = true;//por 24 horas, 7,15,30 dias
      } 
      if(permiso === this.permiso.kpiPost){
        this.tienePermiso.kpiPost = true;
      } 
    }
  }
}
