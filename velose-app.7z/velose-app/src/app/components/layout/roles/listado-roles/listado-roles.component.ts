import { Component, OnInit, isDevMode } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { RolesService, IDataRol } from '../../../../services/roles.service';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DialogVisualizarPermisosComponent } from '../dialog-visualizar-permisos/dialog-visualizar-permisos.component';
import { IDatosDialogConfirmacion, CDatosDialogConfirmacion, SharedDialogConfirmacionComponent } from '../../../shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';

@Component({
  selector: 'app-listado-roles',
  templateUrl: './listado-roles.component.html',
  styleUrls: ['./listado-roles.component.css']
})
export class ListadoRolesComponent implements OnInit {
  
  displayedColumns:string[]
  dataSource:MatTableDataSource<any>
  filtroBusqueda:string
  spinnerTableListaRoles:boolean=true;

  mensajeCantidadMaxima:string;

  constructor(
    private _rolesService:RolesService,
    private _snackBarClassShared:SnackBarConfigurationSharedComponent,
    public dialog: MatDialog,
    private _router:Router) { 
    this.inicializarVariables()
  }

  ngOnInit() {
    this.listarRoles()
    this.cantidadMaximaRoles()
  }

  cantidadMaximaRoles(){
    this._rolesService.obtenerCantidadMaximaRoles().subscribe((response: any) => {
      if (response && response.estado) {
        this.mensajeCantidadMaxima = `* Máximo de roles personalizados permitidos: ${response.roles.cantidadMaximaRoles} roles`;
      }
    });
  }

 //#region Acciones table
  accionRol(row:IDataRol){
    if(row.rolPorDefecto==null)
      return;

    if(isDevMode()){console.log(row.rolPorDefecto)}
    if(row.rolPorDefecto==true){
      this.dialog.open(DialogVisualizarPermisosComponent, {
        width: "500px",
        maxHeight: "80vh",
        data: row
      });
    }
    else{
      this._router.navigate(['/home/editarRoles', {'id': row.idRol}]);
    }
  }
  
  eliminarRol(row){

    if(row.rolPorDefecto){
      this._snackBarClassShared.openSnackBar(`El rol ${row.nombreRol} no puede ser eliminado debido a que es un rol por defecto`,6000,"OK")
      return;
    }

    if(isDevMode()){console.log(row)}

    let nombreRol:string= row.nombreRol
    let dataDialogConfirmacion : IDatosDialogConfirmacion = new CDatosDialogConfirmacion();
    dataDialogConfirmacion.mensaje = `¿Estás seguro que desea eliminar el rol ${nombreRol} con los permisos asignados?`; 
    dataDialogConfirmacion.textoBotonCancelar = "No, todavía";
    dataDialogConfirmacion.textoBotonAceptar= "Si, estoy seguro";
    let dialogRef = this.dialog.open(SharedDialogConfirmacionComponent, {
      width: "400px",
      maxHeight: "80vh",
      data: dataDialogConfirmacion
    });

    dialogRef.afterClosed().subscribe(result =>{
      if(result!=true)
        return;

      this._snackBarClassShared.openSnackBar(`Eliminando rol ${nombreRol}...`,6000,"OK")
  
      this._rolesService.obtenerCantidadUsuariosAsociadosXRol(row.idRol).subscribe(
        (response:any)=>{
          if(response && response.estado==true){
            if(response.usuariosAsociados==0){
              this.spinnerTableListaRoles=true
              this.eliminarRolService(row.idRol)
            }
            else{
              let mensaje:string=`No se puede eliminar el rol ${row.nombreRol} ya que está asignado a ${response.usuariosAsociados} usuario(s).`
              this._snackBarClassShared.openSnackBar(mensaje,7000,"OK")
            }
          }
          else{
            //TO-DO: mostrar snackbar(ocurrio un error inesperado o atachar mensaje de response)
          }
        }
      );
      

    });


  }

  eliminarRolService(id:number){
    this._rolesService.eliminarRol(id).subscribe(
      (response:any)=>  {
        this._snackBarClassShared.openSnackBar(response.mensaje,6000,"OK")
        this.listarRoles()
      } 
    )
  }
 //#endregion


//  #region metodos
inicializarVariables(){
  this.displayedColumns=[ "nombre","descripcion","editar","eliminar"];
  this.dataSource=new MatTableDataSource()
  this.dataSource.data=[]
  this.filtroBusqueda=""
}

listarRoles() {
  this._rolesService.listarRoles(this.filtroBusqueda).subscribe(
    (response: any) => {
      if (isDevMode()){
        console.log(response.mensaje)
      }

    if (response && response.estado) {
    
     this.dataSource.data = response.roles;
    this.spinnerTableListaRoles=false;



      // if(mensajeMostrar!=null){
      //   this.snackBar.open(mensajeMostrar, "OK", {
      //     duration: tiempoMensajeMostrar
      //   });
      // }
    }
  });
}
//#endregion

}
