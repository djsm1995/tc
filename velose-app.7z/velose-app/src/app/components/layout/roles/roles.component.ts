import { Component, OnInit } from '@angular/core';
import { RolesService } from '../../../services/roles.service';
import { SnackBarConfigurationSharedComponent } from '../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {

  inhabilitarBotonCrear:boolean
  constructor( 
    private _rolesService:RolesService,
    private _snackBarClassShared:SnackBarConfigurationSharedComponent,
    private router:Router) { }

  ngOnInit() {
    this.cargarVariablesIniciales();
  }

  cargarVariablesIniciales(){
    this.inhabilitarBotonCrear=false
  }

  crearRol(){
    if(this.inhabilitarBotonCrear){
      return;
    }

    this.inhabilitarBotonCrear = true;
    this._rolesService.obtenerCantidadMaximaRoles().subscribe((response: any) => {
          if (response && !response.roles.pasoLimiteRoles) {
            this.router.navigate(["home/crearRoles"]);
            // this.router.navi
          }else{
            this._snackBarClassShared.openSnackBar("Has alcanzado el limite máximo para la creación de roles",6000,"OK")
          }
          this.inhabilitarBotonCrear = false;
        });
  }

}
