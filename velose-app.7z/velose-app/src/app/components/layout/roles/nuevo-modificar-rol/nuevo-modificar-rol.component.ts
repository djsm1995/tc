import { Component, OnInit, isDevMode } from '@angular/core';
import { ReusableService } from '../../../../services/reusable.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { FlatTreeControl } from '@angular/cdk/tree';
import { IItemNode, IItemFlatNode, RolesService, IDataRolxId, IInfoItem } from '../../../../services/roles.service';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { SelectionModel } from '@angular/cdk/collections';
import { SnackBarConfigurationShared } from '../../../shared/snack-bar/clases/snack-bar-configuration-shared';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';
import { SharedDialogConfirmacionComponent, IDatosDialogConfirmacion, CDatosDialogConfirmacion } from '../../../shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';
import { MatDialog } from '@angular/material/dialog';


const identificadorPermisoCrearRoles='roles.crearRol'
const identificadorPermisoModificarRoles='roles.editarRol'
const identificadorAnalytics='analytics'

@Component({
  selector: 'app-nuevo-modificar-rol',
  templateUrl: './nuevo-modificar-rol.component.html',
  styleUrls: ['./nuevo-modificar-rol.component.css']
})

export class NuevoModificarRolComponent implements OnInit {

   formCrearActualizarRol:FormGroup;
   tienePermisoNuevoModificarRol:boolean

   tituloForm:string;
   esActualizar:boolean;
   idRol:number;
   listaPermisosCargar:IInfoItem[]

   spinnerDatosRol:boolean
   readonly identificadorAnalyticsP = identificadorAnalytics;

  private _transformer = (node: IItemNode , level: number) => {
    let item:IItemFlatNode

    item={
      expandable: !!node.listado && node.listado.length > 0,
      item: node.item, 
      level: level,
    }

    return item

  }

  treeControl :FlatTreeControl<IItemFlatNode>
  treeFlattener: MatTreeFlattener<IItemNode, IItemFlatNode>;
  dataSource :MatTreeFlatDataSource<IItemNode, IItemFlatNode>;

  /** The selection for checklist */
  checklistSelection:SelectionModel<IItemFlatNode> 


  constructor(
    private _reusableService:ReusableService,
    private _rolesService:RolesService,
    private _snackBarClassShared:SnackBarConfigurationSharedComponent,
    private dialog: MatDialog,
    private _router:Router,
    private route: ActivatedRoute) {

    this.tienePermisoNuevoModificarRol=false
    if(!this.verificarAcciones()){
      this._router.navigate(['home/roles'])
    }
    
    this.tituloForm="Nuevo rol"
    this.esActualizar=false;
    this.spinnerDatosRol=false;
    this.listaPermisosCargar=[]


   }

  ngOnInit() {

    this.cargarVariablesTree();
    this.formCrearActualizarRol = new FormGroup({
      nombreRol: new FormControl("",[Validators.required, Validators.maxLength(250)]),
      descripcionRol: new FormControl("",[ Validators.maxLength(250)]),
      permisosRol: new FormArray([],[Validators.required]),
    });
    
    // if(isDevMode()){console.log(this.formCrearActualizarRol)}


    this.route.params.subscribe(params => {
      const urlRegistrar="/home/crearRoles"

      if (params['id'] != undefined) {
        this.tituloForm = 'Actualizar rol';
        this.esActualizar = true;
        this.spinnerDatosRol = true;
        this.idRol=params['id']
      }
      
      this.obtenerPermisosDisponibles()

    });

    

  }

  obtenerPermisosDisponibles(){
    this._rolesService.obtenerPermisosDisponibles().subscribe((response:any)=>{
      if(response && response.estado){
        let listado:IItemNode[]= response.lista
        this.dataSource.data = listado

        if(this.esActualizar==true){
          this.obtenerDatosPorRol()
        }
        // servicio de permisos asignados
      }
      else{
        this._snackBarClassShared.openSnackBar(response.mensaje,6000,"OK")
      }

    })

  }

  obtenerDatosPorRol(){
    if(this.idRol==undefined)
      return;
    this._rolesService.cargarRol(this.idRol).subscribe((response:any)=>{
      if(response && response.estado){
        let data:IDataRolxId= response.data
        if(isDevMode()){console.log(response)}

        this.llenarFormulario(data);
      }
    })
  }

  llenarFormulario(data:IDataRolxId){
    let form= this.formCrearActualizarRol.controls;
    form["nombreRol"].setValue(data.nombreRol)
    form["descripcionRol"].setValue(data.descripcionRol)
    this.cargarPermisosxRol(data)
  }

  cargarPermisosxRol(node: IDataRolxId){

    if(node.lista.length==0){
      // mostrar error y retornar a listado de roles
      if(isDevMode()){console.log("no existe permisos asignados a rol seleccionado .. revisar!!")}

    }
    this.obtenerListadoPermisos(node.lista)

    if(this.listaPermisosCargar.length>=1){
      let dataNode=this.treeControl.dataNodes
      let self=this;
      dataNode.forEach(function(element:IItemFlatNode){
        if(element.expandable==false)//si no tiene hijos
        {
      
          for(let i=0;i<=self.listaPermisosCargar.length-1;i++){
            if(element.item.value == self.listaPermisosCargar[i].value){
              self.todoLeafItemSelectionToggle(element);
              break;
            }
          }
        }
      });
    this.spinnerDatosRol=false;

    }
      
    if(isDevMode()){console.log(this.formCrearActualizarRol.value.permisosRol)}

  }
  private obtenerListadoPermisos(node:IItemNode[]){
    let self=this;
    node.forEach(function(element:IItemNode){
      
      if(element.item.type==0)//permiso
        self.listaPermisosCargar.push(element.item)

      if(element.listado){
        self.obtenerListadoPermisos(element.listado)
      }
      
    })

  }


  cargarVariablesTree(){
    this.treeControl= new FlatTreeControl((node:IItemFlatNode) => node.level, (node:IItemFlatNode) => node.expandable)
    
    this.treeFlattener = new MatTreeFlattener( 
      this._transformer, 
      this.getLevel,
      (node:IItemFlatNode)  => node.expandable,
      (node:IItemNode): IItemNode[] => node.listado);
    
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    this.dataSource.data=[]

    this.checklistSelection= new SelectionModel<IItemFlatNode>(true /* multiple */);

  }

  // #region tree metodos
  
    hasChild = (_index: number, node: IItemFlatNode ) => node.expandable;

    getLevel = (node: IItemFlatNode) => node.level;
  
    /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
    todoLeafItemSelectionToggle(node: IItemFlatNode): void {
      this.checklistSelection.toggle(node);
      this.adicionarQuitarPermiso(node);

      this.checkAllParentsSelection(node);
      

    }

    /* Checks all the parents when a leaf node is selected/unselected */
    checkAllParentsSelection(node: IItemFlatNode): void {
      let parent: IItemFlatNode | null = this.getParentNode(node);
      while (parent) {
        
        this.checkRootNodeSelection(parent);
        this.adicionarModuloSubmodulo(parent);

        parent = this.getParentNode(parent);
      }
    }

    /** Check root node checked state and change it accordingly */
    checkRootNodeSelection(node: IItemFlatNode): void {
      const nodeSelected = this.checklistSelection.isSelected(node);
      const descendants = this.treeControl.getDescendants(node);
      const descAllSelected = descendants.every(child =>
        this.checklistSelection.isSelected(child)
      );
      if (nodeSelected && !descAllSelected) {
        this.checklistSelection.deselect(node);

      } else if (!nodeSelected && descAllSelected) {
        this.checklistSelection.select(node);
      }



    }

    /* Get the parent node of a node */
    getParentNode(node: IItemFlatNode): IItemFlatNode | null {
      const currentLevel = this.getLevel(node);
  
      if (currentLevel < 1) {
        return null;
      }
  
      const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
      if(isDevMode()){console.log(startIndex)}
  
      for (let i = startIndex; i >= 0; i--) {
        const currentNode = this.treeControl.dataNodes[i];
        if (this.getLevel(currentNode) < currentLevel) {
          return currentNode;
        }
      }
      return null;
    }



    /** Whether all the descendants of the node are selected. */
    descendantsAllSelected(node: IItemFlatNode): boolean {
      const descendants = this.treeControl.getDescendants(node);
      const descAllSelected = descendants.every(child =>
        this.checklistSelection.isSelected(child)
      );
      return descAllSelected;
    }  
    
    /** Whether part of the descendants are selected */
    descendantsPartiallySelected(node: IItemFlatNode): boolean {
      const descendants = this.treeControl.getDescendants(node);
      const result = descendants.some(child => this.checklistSelection.isSelected(child));
      return result && !this.descendantsAllSelected(node);
    }

    /** Toggle the to-do item selection. Select/deselect all the descendants node */
    todoItemSelectionToggle(node: IItemFlatNode): void {
      this.checklistSelection.toggle(node);
      this.adicionarQuitarPermiso(node)

      if(isDevMode()){console.log(node)}
      const descendants = this.treeControl.getDescendants(node);

      this.checklistSelection.isSelected(node)
        ? this.checklistSelection.select(...descendants)
        : this.checklistSelection.deselect(...descendants);
      
      descendants.forEach(child=>{
        this.adicionarQuitarPermiso(child)
      })

      // Force update for the parent
      descendants.every(child =>
        this.checklistSelection.isSelected(child)
      );

      
      this.checkAllParentsSelection(node);
    }

    adicionarQuitarPermiso(node:IItemFlatNode){
      if(this.checklistSelection.isSelected(node)==null){
        return;
      }

      let permisos=(<FormArray>(this.formCrearActualizarRol.get("permisosRol")))
      
      if(this.checklistSelection.isSelected(node)){
        this.verificarAdicionPermiso(permisos,node);
      }else{
        const i= permisos.controls.findIndex(
          x => x.value === node.item.value
        )
        permisos.removeAt(i)
      }

      if(isDevMode()){console.log(this.formCrearActualizarRol.get("permisosRol"))}

    }

    adicionarModuloSubmodulo(node:IItemFlatNode){
      let permisos=(<FormArray>(this.formCrearActualizarRol.get("permisosRol")))

      this.adicionarItemPermiso(permisos,node);
    }
  
    verificarAdicionPermiso(permisos:FormArray,node:IItemFlatNode){
      if(permisos.value.lenght<1){
        return;
      }

      this.adicionarItemPermiso(permisos,node);
   
    }


    adicionarItemPermiso(permisos,node){
      let permisoEncontrado:boolean
      permisoEncontrado = permisos.value.find( function(element){
        return element == node.item.value
      })

      if(permisoEncontrado==undefined){
        permisos.push(new FormControl( node.item.value))
      }
    }

  //#endregion


  // #region metodos Form
  guardarDatosRol(){ 
    if(this.formCrearActualizarRol.invalid){
      return;
    }

    let nombreRol:string= this.formCrearActualizarRol.value.nombreRol
    let dataDialogConfirmacion : IDatosDialogConfirmacion = new CDatosDialogConfirmacion();
    dataDialogConfirmacion.mensaje = `¿Estás seguro que desea ${this.esActualizar==true?'modificar':'crear'} el rol ${nombreRol} con los permisos asignados?`; 
    dataDialogConfirmacion.textoBotonCancelar = "No, todavía";
    dataDialogConfirmacion.textoBotonAceptar= "Si, estoy seguro";
    let dialogRef = this.dialog.open(SharedDialogConfirmacionComponent, {
      width: "400px",
      maxHeight: "80vh",
      data: dataDialogConfirmacion
    });

    dialogRef.afterClosed().subscribe(result =>{
      if(result!=true)
        return;

      this._snackBarClassShared.openSnackBar(`${this.esActualizar==true?'Modificando':'Creando'} rol ${nombreRol}...`,6000,"OK")
      this.spinnerDatosRol=true;
      if(this.esActualizar){
        this._rolesService.guardarModificadoRolPermisos(this.assembleDataModificar())
          .subscribe(response => this.rptaGuardarRolPermisos(response));
      }
      else{
        this._rolesService.guardarNuevoRolPermisos(this.formCrearActualizarRol.value)
          .subscribe( response => this.rptaGuardarRolPermisos(response));
      }

    });

  }

  private assembleDataModificar(){
    let data= this.formCrearActualizarRol.value
    data.idRol= this.idRol
    return data
  }

  rptaGuardarRolPermisos(response:any){
    let mensajeSnackbar:string=""

    if (response && response.estado) {
      mensajeSnackbar=(this.esActualizar==true)?`Rol actualizado correctamente`:`Rol creado correctamente`
    }
    else{
      mensajeSnackbar=response.mensaje
    }

    this._snackBarClassShared.openSnackBar(mensajeSnackbar,6000,"OK")
  
    this._router.navigateByUrl("/home/roles")

  }

  //#endregion


  verificarAcciones(){
    let tienePermiso:boolean=false
    let acciones= this._reusableService.getAcciones()
    let permiso:string=""
    const urlRegistrar="/home/crearRoles"
    const urlEditar="/home/editarRoles"
    if(acciones!=null){

      if(isDevMode()){console.log(this._router.url)}

      switch (this._router.url) {
        case urlRegistrar:
          permiso= identificadorPermisoCrearRoles
          break;
        
        default:
          let index=this._router.url.indexOf(";");
          let matchUrl= (index==-1)?this._router.url: this._router.url.substring(0,index)
          if(matchUrl==urlEditar){
            permiso=identificadorPermisoModificarRoles
          }
          break;
      }

      let findPermiso= acciones.find((element)=>{
        return element===permiso
      })
  
      tienePermiso=(findPermiso==undefined)?tienePermiso:true
      
    }

    this.tienePermisoNuevoModificarRol=tienePermiso

    return tienePermiso;
  } 

}
