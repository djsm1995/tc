import { Component, OnInit, Inject, isDevMode } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IDataRol, IInfoItem, RolesService, IDataRolxId, IItemNode } from '../../../../services/roles.service';

@Component({
  selector: 'app-dialog-visualizar-permisos',
  templateUrl: './dialog-visualizar-permisos.component.html',
  styleUrls: ['./dialog-visualizar-permisos.component.css']
})
export class DialogVisualizarPermisosComponent implements OnInit {

  listadoPermisos:IItemNode[]
  spinnerListaRoles:boolean;


  constructor(@Inject(MAT_DIALOG_DATA) public data:IDataRol,
    private _rolesService:RolesService,
  ) { 
    this.spinnerListaRoles=true;
  }
  
  ngOnInit() {
    this._rolesService.cargarRol(this.data.idRol).subscribe
      ((response:any)=>{
        if(response && response.estado==true){
          if(isDevMode()){console.log(response.data.lista)}
          this.listadoPermisos=response.data.lista
          this.spinnerListaRoles=false;

        }
      })

  }

}
