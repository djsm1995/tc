import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { UsuariosService, permisosUsuario, permisosUsuarioClass } from '../../../services/usuarios.service';
import { DialogAgregarEditarUsuariosComponent } from './dialog-agregar-editar-usuarios/dialog-agregar-editar-usuarios.component';
import { ListadoUsuariosComponent } from './listado-usuarios/listado-usuarios.component';


@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {

  @ViewChild(ListadoUsuariosComponent,{static: false}) listado: ListadoUsuariosComponent;

  //@ViewChild('dataSource',{static: false}) childTwo:ListadoUsuariosComponent;

  dataSource:string;
  deshabilitarBotonCrear:boolean;

  //Permisos
  listaPermisosBD: string[] = this._usuariosService.obtenerPermisos();
  permiso = new permisosUsuario();
  tienePermiso = new permisosUsuarioClass();

  constructor(
    public _usuariosService: UsuariosService,
    public snackBar: MatSnackBar,
    public dialog: MatDialog,
  ) {
    this.deshabilitarBotonCrear = false;
    this.obtenerPermisos();
   }

  ngOnInit() {
  }
 
  crearUsuario(){
    if(this.tienePermiso.crearUsuarios){
      this.deshabilitarBotonCrear = true;
      let dialogRef;
      let idAuth = null;
      this._usuariosService.obtenerCantidadMaximaUsuarios().subscribe((response: any) => {
            if (response && !response.usuarios.pasoLimiteUsuarios) {
               dialogRef = this.dialog.open(DialogAgregarEditarUsuariosComponent, {
                width: "500px",
                maxHeight: "80vh",
                data: {
                  idAuth: idAuth,
                }
              });
              dialogRef.afterClosed().subscribe(result =>{
                if(result){
                  this.listado.spinnerTableListaUsuarios=true;
                  this.listado.listarUsuariosAsociados("Usuario creado correctamente",5000);
                  //this.dataSource="Usuario creado correctamente"
                }
               });
            }else{
              this.snackBar.open("Has alcanzado el limite máximo para la creación de usuarios", "OK", {
                duration: 7000
              });
            }
            this.deshabilitarBotonCrear = false;
          });
    }
  }

  obtenerPermisos(){
    for(let permiso of this.listaPermisosBD){
      if(permiso === this.permiso.crearUsuarios){
        this.tienePermiso.crearUsuarios = true;
      }
      if(permiso === this.permiso.eliminarUsuarios){
          this.tienePermiso.eliminarUsuarios = true;
      }
      if(permiso === this.permiso.habilitarInhabilitarUsuarios){
          this.tienePermiso.habilitarInhabilitarUsuarios = true;
      } 
      if(permiso === this.permiso.listarUsuarios){
          this.tienePermiso.listarUsuarios = true;
      } 
      if(permiso === this.permiso.modificarUsuarios){
          this.tienePermiso.modificarUsuarios = true;
      } 
    }
  }


}
