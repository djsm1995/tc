import { Component, OnInit, isDevMode, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsuariosService } from '../../../../services/usuarios.service';
import { ReusableService } from '../../../../services/reusable.service';
import { SharedDialogConfirmacionComponent, IDatosDialogConfirmacion, CDatosDialogConfirmacion } from '../../../shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';
import { DialogAgregarEditarUsuariosComponent } from '../dialog-agregar-editar-usuarios/dialog-agregar-editar-usuarios.component';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';

@Component({
  selector: 'app-listado-usuarios',
  templateUrl: './listado-usuarios.component.html',
  styleUrls: ['./listado-usuarios.component.css']
})
export class ListadoUsuariosComponent implements OnInit {
  //Variable desde UsuariosComponent
  // @Input('data') set entradaDataSource(value:any){
  //   if(isDevMode)console.log("datasouce " + value);
  //   this.listarUsuariosAsociados(value, 5000);
  // }
  @Input() tienePermisoEliminar:boolean = false;
  @Input() tienePermisoEditar:boolean = false;
  @Input() tienePermisoEditarEstado:boolean = false;

  //deshabilitarBotonEliminar:boolean=false;
  spinnerTableListaUsuarios:boolean=true;
  displayedColumns: string[] = ['fotoUsuario', 'nombre', 'apellidos', 'correo', 'nombreRol', 'estado', 'editar', 'eliminar'];
  dataSource = new MatTableDataSource();
  filtroBusquedaFG: FormGroup;
  mensajeCantidadMaxima:string;
  pasoLimiteUsuarios:boolean;

  correoAdmin:string;
  constructor(
    private _usuariosService: UsuariosService,
    private _reusableService: ReusableService,
    private snackBar: SnackBarConfigurationSharedComponent,
    private  dialog: MatDialog,
    //private _changeDetectorRef: ChangeDetectorRef,

  ) { 
    this.correoAdmin = this._reusableService.getSessionUsuario().correo;
  }

  ngOnInit() {
    this.filtroBusquedaFG = new FormGroup({
      Foto: new FormControl("0", [Validators.required]),
      Nombre: new FormControl("0", [Validators.required]),
      ApellidoPaterno: new FormControl("0", [Validators.required]),
      ApellidoMaterno: new FormControl("0", [Validators.required]),
      Correo: new FormControl("0", [Validators.required]), 
      Rol: new FormControl("0", [Validators.required]),
      Estado: new FormControl(false, [Validators.required]) 
     
    });
    this.cantidadMaximaUsuarios();
    this.listarUsuariosAsociados(null,0);
  }

  editarUsuario(idUsuario:number, idAuth:string, nombre:string, apellidos:string, correo:string, idRol:number){
    if(this.tienePermisoEditar){
      let dialogRef = this.dialog.open(DialogAgregarEditarUsuariosComponent, {
        width: "500px",
        maxHeight: "80vh",
        data: {
          idAuth: idAuth,
          nombre: nombre,
          apellidos: apellidos,
          correo: correo,
          idRol: idRol,
          tienePermisoEditarEstado: this.tienePermisoEditarEstado,
          tienePermisoEditar: this.tienePermisoEditar
        }
      });
      dialogRef.afterClosed().subscribe(() =>{
          this.snackBar.openSnackBar("Cargando...", 900, "OK");
          this.spinnerTableListaUsuarios=true;
          this.listarUsuariosAsociados(null,null);
      });
    }
  }

  eliminarUsuario(correo:string,idUsuario:number,idAuth:string){
    if(this.tienePermisoEliminar){
      let dataInterfaz : IDatosDialogConfirmacion = new CDatosDialogConfirmacion();
      dataInterfaz.mensaje = `¿Estás seguro que desea eliminar a ${correo}?`; 
      dataInterfaz.textoBotonCancelar = "No, todavia";
      dataInterfaz.textoBotonAceptar= "Si, estoy seguro";
      let dialogRef = this.dialog.open(SharedDialogConfirmacionComponent, {
        width: "400px",
        maxHeight: "80vh",
        data: dataInterfaz
      });
    
      dialogRef.afterClosed().subscribe(result =>{
        if(result){
          this.snackBar.openSnackBar(`Eliminando a ${correo}...`, 7000, "OK");
          this.spinnerTableListaUsuarios = true;
          this._usuariosService.eliminarUsuario(idUsuario,idAuth).subscribe((response: any) => {
            if (response && response.estado) {
              // this.listarUsuariosAsociados("El usuario ha sido eliminado",4000);
              this.listarUsuariosAsociados(response.usuario.mensaje,4000);
            }else{
              this.listarUsuariosAsociados("No se ha podido procesar la solicitud",4000);
            }
          });
        }
      });
    }
  }

  //Reutilizables
  cantidadMaximaUsuarios(){
    this._usuariosService.obtenerCantidadMaximaUsuarios().subscribe((response: any) => {
      if (response && response.estado) {
        this.mensajeCantidadMaxima = `Máximo de usuario permitidos: ${response.usuarios.cantidadMaximaUsuarios} usuarios`;
        this.pasoLimiteUsuarios = response.usuarios.pasoLimiteUsuarios;
      }
    });
  }
  listarUsuariosAsociados(mensajeMostrar, tiempoMensajeMostrar){
    this._usuariosService.listarUsuarios("").subscribe((response: any) => {
      if (response && response.estado) {
       this.dataSource.data = response.usuariosAsociados;
       this.spinnerTableListaUsuarios=false;
        if(mensajeMostrar!=null){
          this.snackBar.openSnackBar(mensajeMostrar, tiempoMensajeMostrar, "OK");
        }
      }else{
        if(isDevMode())console.log(response.mensaje);
      }
    });
  }

}
