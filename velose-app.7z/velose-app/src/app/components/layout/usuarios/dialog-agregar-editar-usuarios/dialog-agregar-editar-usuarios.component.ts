import { Component, OnInit, ViewChild, ElementRef, Inject, isDevMode } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSelect } from '@angular/material/select';

import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';

import { ReusableService } from '../../../../services/reusable.service';
import { UsuariosService, registroUsuarioClass } from '../../../../services/usuarios.service';
import { RolesService } from '../../../../services/roles.service';
import { responseUsuario } from '../../../../services/usuarios.service';
import { Roles } from '../../../../constantes/catalogo';
import { SnackBarConfigurationSharedComponent } from '../../../shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';

@Component({
  selector: 'app-dialog-agregar-editar-usuarios',
  templateUrl: './dialog-agregar-editar-usuarios.component.html',
  styleUrls: ['./dialog-agregar-editar-usuarios.component.css']
})


export class DialogAgregarEditarUsuariosComponent implements OnInit {
 rolesUsuario: Roles[];
 deshabilitarBotonCrear: boolean = false;
 spinnerDialog: boolean = true;
 spinnerValidarCorreo:boolean = false;
 mensajeValidarCorreo:string;//="Correo inválido";
 checkedEstadoUsuario:boolean;
 formCrearActualizarUsuario:FormGroup;
 //Verificar Modulo de Update o Create
 estaActualizando: boolean;
 
 image : string = null;
 //Otros
 changeTextNom: boolean;
 changeTextApe: boolean;
 changeTextCorr:boolean;
 changeTextCorrConfirmacion:boolean;
 changeTextRoles:boolean; 

 focusTextNom: boolean;
 focusTextApe: boolean;
 focusTextCorr:boolean;
 focusTextCorrConfirmacion:boolean;
 focusTextRoles:boolean;

 //dato si es necesario mandar al servicio o no/ guarda la data anterios y se utiliza al momento de cancelar una accion
 constanteServio:string;
 roles = new FormControl();

 constructor
 (
   @Inject(MAT_DIALOG_DATA) public data: {idAuth:string,idUsuario:number,nombre:string,apellidos:string, correo:string, idRol:number
                                          tienePermisoEditarEstado:boolean, tienePermisoEditar:boolean },
   private _reusableService: ReusableService,
   private _rolService: RolesService,
   private _dialogRef: MatDialogRef<DialogAgregarEditarUsuariosComponent>,
   private _usuarioService: UsuariosService,
   public _router:Router,
   public snackBar: SnackBarConfigurationSharedComponent,
 ) 
 {
   this.data.idAuth != null ? this.estaActualizando = true : this.estaActualizando = false;
   this.changeTextNom = false;
   this.changeTextApe = false;
   this.changeTextCorr = false;
   this.changeTextCorrConfirmacion = false;
   this.changeTextRoles = false;

   this.focusTextNom = true;
   this.focusTextApe = true;
   this.focusTextCorr = true;
   this.focusTextCorrConfirmacion = true;
   this.focusTextRoles = true;
 }
 //Para controlar el focus
 @ViewChild("nombreInput",{static: false}) nomField:ElementRef;
 @ViewChild("apellidoInput",{static: false}) apeField:ElementRef;
 @ViewChild("correosInput",{static: false}) corrField:ElementRef;
//  @ViewChild("filtroRoles",{static: false}) rolField:ElementRef;
 @ViewChild('filtroRoles',{static: false}) rolField: MatSelect;
 @ViewChild("correosConfirmacionInput",{static: false}) corrConfirmacionField:ElementRef;

 ngOnInit() {
  
  this.roles = new FormControl(this.data.idRol,[Validators.required])  
  this.formCrearActualizarUsuario = new FormGroup({
    nombres: new FormControl("",[Validators.required, Validators.maxLength(250)]),
    apellidos: new FormControl("",[Validators.required, Validators.maxLength(250)]),
    correo: new FormControl("", [Validators.required, Validators.maxLength(250), Validators.email],  this.validacionCorreo.bind(this)),
    correoConfirmacion: new FormControl("", [Validators.maxLength(250), Validators.email]),
    fechaCreacion: new FormControl({value:'', disabled:true},[]),
    fechaModificacion: new FormControl({value:'', disabled:true},[]),
    estado: new FormControl({value:''}),
  });
  let form = this.formCrearActualizarUsuario;
  form.addControl('roles', this.roles);
  this.listarRolService();
  // form.controls['apellidos'].setValidators([Validators.required, Validators.maxLength(250)]);
  if(this.estaActualizando){   
    form.controls['nombres'].disable();
    form.controls['apellidos'].disable();
    form.controls['correo'].disable();
    form.controls['fechaCreacion'].disable();
    form.controls['fechaModificacion'].disable();
    form.controls['roles'].disable();
    this.traerDatosUsuarioService(this.data.idAuth);
   }else{
    form.controls['correoConfirmacion'].setValidators([Validators.required]);
    this.formCrearActualizarUsuario.setValidators(correoMatchValidator);
    //this.formCrearActualizarUsuario.controls['correoConfirmacion'].setValidators([Validators.required, Validators.maxLength(250), Validators.email, correoConfirmacionValidacion.bind(this)]);
    //this.formCrearActualizarUsuario.controls['correo'].setValidators([Validators.required, Validators.maxLength(250), Validators.email, correoValidacion.bind(this), this.validacionCorreo.bind(this)]);
    this.image = null;// this.image = "../../../../assets/img/avatar3.png";
    this.spinnerDialog = false;
   }
 
   function correoMatchValidator(g: FormGroup) { 
    if(g.controls['correo'].value != "" || g.controls['correoConfirmacion'].value != ""){
      if(g.controls['correoConfirmacion'].value != ""){
        g.controls['correo'].value === g.controls['correoConfirmacion'].value ? g.controls['correoConfirmacion'].setErrors(null) : g.controls['correoConfirmacion'].setErrors({'incorrect': true});
      }
      return g.controls['correo'].value === g.controls['correoConfirmacion'].value ? null : {'mismatch': true};
    }
    return null;
  }
 } 

listarRolService(){
  this._rolService.listarRoles("").subscribe((response:any) => {
      if (response && response.estado) {
        this.rolesUsuario = response.roles
      }
  });
}

 habilitarInput(identificador:number){
  if(this.estaActualizando && this.data.tienePermisoEditar){
    switch (identificador) {
      case 1:
        // this.validarDatosInput(this.data.nombre,"nombres", this.nomField);
        this.validarDatosInput("nombres", this.nomField);
        this.focusTextNom = false;
        break;
      case 2:
        // this.validarDatosInput(this.data.apellidos,"apellidos", this.apeField);
        this.validarDatosInput("apellidos", this.apeField);
        this.focusTextApe = false;
        break;
      case 3:
        // this.validarDatosInput(this.data.correo,"correo", this.corrField);
        this.validarDatosInput("correo", this.corrField);
        this.focusTextCorr = false;
        break;
      case 4:
        // this.validarDatosInput(null, "roles", null);
        this.validarDatosInput("roles", null);
        this.rolField.open();
        this.rolField.focus();
        this.focusTextRoles = false;
        break;
      default:
        break;
    }
  }
 }

//  validarDatosInput(constanteServio:string, nombreInput:string, field ){
 validarDatosInput(nombreInput:string, field:any ){
    //this.constanteServio = constanteServio;
    this.constanteServio = this.formCrearActualizarUsuario.controls[`${nombreInput}`].value;
    this.formCrearActualizarUsuario.controls[`${nombreInput}`].enable();
    if(field!=null)field.nativeElement.focus()
 }

 

 focusOut(dato:any , identificador:number){
  if(this.estaActualizando){
    let validacion:boolean;
   switch (identificador) {
     case 1:   
       validacion = this.validarDatosFocus(dato.value, "nombres");
       this.focusTextNom = true;
       break;
     case 2:
       validacion = this.validarDatosFocus(dato.value, "apellidos");
       this.focusTextApe = true;
       break;
     case 3:
       validacion = this.validarDatosFocus(dato.value, "correo");
       this.focusTextCorr = true;
       break;
     case 5:
       dato.valueChange.subscribe(x => 
          dato  = x
        );
       validacion = this.validarDatosFocus(dato, "roles");
       this.focusTextRoles = true;
       break;
     default:
       break;
   }

   if(validacion)this.servicioGuardarDato(dato.value, identificador);
  }
 }
 validarDatosFocus(dato:string, nombreInput:string){
  let form = this.formCrearActualizarUsuario;
  form.controls[`${nombreInput}`].disable();
  if(dato=="" || dato ==null){
     form.controls[`${nombreInput}`].setValue(this.constanteServio);
    return false;
  }
  return true;
 }
 
 actualizarEstadotoggle(event: MatSlideToggleChange) {
   if(this.data.tienePermisoEditarEstado){
    this.constanteServio = null;
    this.servicioGuardarDato(event.checked,4);
   }
}

 servicioGuardarDato(dato:any, identificador:number){
   //constanteServicio = para que vaya al servicio cuando la data es la misma
  //  if(this.constanteServio == null || this.constanteServio != dato.trim().toLowerCase() || this.constanteServio != dato){
   if(this.constanteServio == null || this.constanteServio != dato){
    this.constanteServio = dato;
    if(this.formCrearActualizarUsuario.valid){
       this._usuarioService.actualizarDatoUsuario(dato , identificador, this.data.idAuth)
       .subscribe((response:responseUsuario)=>{
         if(response && response.estado){
          this.snackBar.openSnackBar("Procesado", 500,"OK");
         }else{
          if(isDevMode())console.log(response.mensaje);
          this.snackBar.openSnackBar("Dato no procesado", 5000, "OK");
         }
     });
    }
  }
 }
 
 servicioCrearUsuario(){
  this.deshabilitarBotonCrear = true;
  this.snackBar.openSnackBar("Creando nuevo usuario...", 8000, "OK");
  if(!this.estaActualizando && this.formCrearActualizarUsuario.valid){
    this._usuarioService.crearUsuario(this.assembleCrearUsuario()).subscribe((response:responseUsuario)=>{
      if(response && response.estado){
        this._dialogRef.close(true);
      }else{
        if(isDevMode())console.log(response.mensaje);
        this.snackBar.openSnackBar("Sucedio un error inesperado vuelva a intenterlo", 5000, "OK");
      }
  });
 }
}

//#region Reusables traer datos, actualizar datos
 //Reutilizable
 traerDatosUsuarioService(idAuth:string){
   this._usuarioService.obtenerUsuario(idAuth).subscribe((response:any) => {
    if (response.estado) {
      let form = this.formCrearActualizarUsuario;
      //Datos Modificables
      form.controls['nombres'].setValue(response.usuario.nombre);
      form.controls['apellidos'].setValue(response.usuario.apellidos);
      form.controls['correo'].setValue(response.usuario.correo);
      form.controls['estado'].setValue(response.usuario.estadoKeycloak);
      //Datos no Modificables
      this.image = response.usuario.fotoUsuario;// this.image = response.usuario.fotoUsuario!=null?response.usuario.fotoUsuario:"../../../../assets/img/avatar3.png";
      let fechaCreacionN = new Date(response.usuario.fechaCreacion);
      let fechaModificacionN = new Date(response.usuario.fechaModificacion);
      form.controls['fechaCreacion'].setValue(this._reusableService.getFormatoFecha(fechaCreacionN,2));
      form.controls['fechaModificacion'].setValue(this._reusableService.getFormatoFecha(fechaModificacionN,2));
      this.checkedEstadoUsuario = response.usuario.estadoKeycloak;
      if(this.checkedEstadoUsuario === null || !this.data.tienePermisoEditarEstado){
        this.formCrearActualizarUsuario.controls['estado'].disable();
      }
      this.spinnerDialog = false;
    }
    else {
      this.image = null;// this.image = "../../../../assets/img/avatar3.png";
    }
  });
 }
//Volver a la informacion anterior y ya no editar
 cancelarInput(dato){
  this.formCrearActualizarUsuario.controls[`${dato}`].setValue("");
  this.formCrearActualizarUsuario.controls[`${dato}`].setValue(this.constanteServio);
  return;
 }

 validacionCorreo(control: FormControl): Promise<any> | Observable<any> {
    this.spinnerValidarCorreo= true;
    let rpta = 
    this._usuarioService
        .validarCorreo(control.value).pipe(
        map((response: any) => {
          if (response && response.estado) {
            this.spinnerValidarCorreo= false;
          }else{
            this.mensajeValidarCorreo = response.mensaje;
            this.spinnerValidarCorreo= false;
            return { correoRegistrado: true };
          }
          return null;
        }));
    return rpta;  
}

// validacionCorreoConfirmacion(control:FormControl):{[s:string]:boolean} {
//   if(this.formCrearActualizarUsuario &&
//     control.value != this.formCrearActualizarUsuario.controls['correo'].value || control.value != this.formCrearActualizarUsuario.controls['correoConfirmacion'].value){
//     return{ correoIgual: true}
//   }
//   return null;
// }

assembleCrearUsuario(){
    let form = this.formCrearActualizarUsuario;
    let datos= new registroUsuarioClass();
    datos.idAuth =this.data.idAuth;
    datos.idUsuario=this.data.idUsuario;
    datos.nombre= form.controls['nombres'].value;
    datos.apellidos= form.controls['apellidos'].value;
    datos.correo= form.controls['correo'].value;
    datos.idRol= form.controls['roles'].value;
    return datos;
 }
 //#endregion

}
