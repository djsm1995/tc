
import { Component, OnInit,ElementRef,ViewChild, Injectable } from '@angular/core';
import { FormGroup, Validators,FormControl,FormGroupDirective} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { catchError} from 'rxjs/operators';
import { ReCaptcha2Component } from 'ngx-captcha';
import { ReusableService } from '../../services/reusable.service';
import { Constante} from '../../constantes/constante';
import { environment } from '../../../environments/environment';



@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
@Injectable()
export class ChangepasswordComponent implements OnInit {


  public readonly siteKey = environment.apikeyGoogleRecaptcha;
  public captchaIsLoaded = false;
  public captchaSuccess = false;
  public captchaIsExpired = false;
  public captchaResponse?: string;

  public theme: 'light' | 'dark' = 'light';
  public size: 'compact' | 'normal' = 'normal';
  public lang = 'en';
  public type: 'image' | 'audio';
  public useGlobalDomain: boolean = false;

  


  usuarioFormGroup:FormGroup;
  token : string;
  errorMensaje : boolean;
  procesado: boolean;
  enProceso: boolean;
  mensaje : string;

  constructor(private _httpClient:HttpClient,
              private _reusableService:ReusableService,
              private _activatedRoute: ActivatedRoute) {
                  this.procesado = false;
                  this.enProceso=false;
                }

  @ViewChild('captchaElem',{static: false}) captchaElem: ReCaptcha2Component;
  @ViewChild('langInput',{static: false}) langInput: ElementRef;


  ngOnInit() {

      this._activatedRoute.paramMap.subscribe(params => {
      this.token = params.get('token');
      this.errorMensaje=false;  

      this.mostrarForm();
    });

    this.usuarioFormGroup= new FormGroup({
      recaptcha : new FormControl(null),
      'passUsuarioFormControl':new FormControl('',[
                                                    Validators.required,
                                                    Validators.minLength(8),
                                                    Validators.pattern(Constante.pattern.password)
                                                  ]),
      'confirmarPassUsuarioFormControl':new FormControl('',[
                                                            Validators.required,
                                                             Validators.minLength(8),
                                                             this.validacionPassIguales.bind(this),
                                                             Validators.pattern(Constante.pattern.password)
                                                           ]),
          });

 
  }

  validacionPassIguales(control:FormControl):{[s:string]:boolean}{
    if(this.usuarioFormGroup &&
      control.value!=this.usuarioFormGroup.controls['passUsuarioFormControl'].value)
      return{ passIguales:true}
    return null;
  }

    // CAMBIAR CLAVE
    cambiarClave() {
     this.enProceso=true;
     this.usuarioFormGroup.controls['recaptcha'].setValue(null);

     return this._httpClient.post(`${environment.endpointVelose}/auth/clave/cambiar`, {
        "token": this.token,
        "clave": this.usuarioFormGroup.controls['passUsuarioFormControl'].value,
      }).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) })).subscribe(response=>{
            this.procesado = response['estado'];
            this.mensaje = response['mensaje'];

            if(!this.procesado){
              this.errorMensaje=true;
              this.usuarioFormGroup.controls['passUsuarioFormControl'].setValue("");
              this.usuarioFormGroup.controls['confirmarPassUsuarioFormControl'].setValue("");
              this.reload();
              
            }else{
              this.errorMensaje=false;
            }
            this.enProceso=false;
        });
    }

    isProcesado() : boolean {
      return this.procesado;
    }

    mostrarForm() {
     return this._httpClient.post(`${environment.endpointVelose}/auth/clave/form`, {
        "token": this.token,
      })
      .subscribe(response=>{
            if ( response['estado'] == false ) {
              this.procesado = true;
            }
            this.mensaje = response['mensaje'];
        },
        error => {
          this.procesado = true;
          this.mensaje = "Ocurrió un inconveniente mientras se realizaba la transacción, verifique los datos enviados a su correo.";
        });
    }
//Metodos Captcha
    // /*TEMPORAL*/ validarFormularioAndCaptcha(){return false;}

    validarFormularioAndCaptcha(){
      let password = this.usuarioFormGroup.controls["passUsuarioFormControl"];
      let confirmacionPassword = this.usuarioFormGroup.controls["confirmarPassUsuarioFormControl"];
      
      if(password.value == "" || confirmacionPassword.value == "" || this.captchaSuccess == false){
        return true;
      }
      if(this.ocultarCaptcha()){
        return (password.invalid || confirmacionPassword.invalid) ? true : false;
      }
      return (this.usuarioFormGroup.invalid) ? true : false;
    }
    ocultarCaptcha(){
      return Constante.habilitarDeshabilitarCaptcha();
    }
    //Metodos Captcha
    onScriptLoad() {
      console.log('Google reCAPTCHA cargado y está listo para su uso!' )
    }
  
    onScriptError() {
      console.log('Algo se demoró al cargar el reCAPTCHA de Google.')
    }

    //Metodos Captcha
  handleReset(): void {
    this.captchaSuccess = false;
    this.captchaResponse = undefined;
    this.captchaIsExpired = false;
  }

  handleSuccess(captchaResponse: string): void {
    this.captchaSuccess = true;
    this.captchaResponse = captchaResponse;
    this.captchaIsExpired = false;
  }

  handleLoad(): void {
    this.captchaIsLoaded = true;
    this.captchaIsExpired = false;
  }

  handleExpire(): void {
    this.captchaSuccess = false;
    this.captchaIsExpired = true;
  }

  changeTheme(theme: 'light' | 'dark'): void {
    this.theme = theme;
  }

  changeSize(size: 'compact' | 'normal'): void {
    this.size = size;
  }

  changeType(type: 'image' | 'audio'): void {
    this.type = type;
  }

  setLanguage(): void {
    this.lang = this.langInput.nativeElement.value;//this.lang = 'en';
  }
  setUseGlobalDomain(use: boolean): void {
    this.useGlobalDomain = use;
  }

  getCurrentResponse(): void {
    const currentResponse = this.captchaElem.getCurrentResponse();
    if (!currentResponse) {
      alert('No hay una respuesta actual, ¿ha enviado captcha?');
    } else {
      alert(currentResponse);
    }
  }
  getResponse(): void {
    const response = this.captchaElem.getResponse();
    if (!response) {
      alert('No hay respuesta - ¿has enviado captcha?');
    } else {
      alert(response);
    }
  }
  reload(): void {
    this.captchaElem.reloadCaptcha();
  }
  getCaptchaId(): void {
    alert(this.captchaElem.getCaptchaId());
  }
  reset(): void {
    this.captchaElem.resetCaptcha();
  }



}
