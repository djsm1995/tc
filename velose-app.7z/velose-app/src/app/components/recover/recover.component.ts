
import {map,  distinctUntilChanged } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {FormBuilder, FormGroup, Validators,FormControl,FormGroupDirective} from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {RegisterService} from '../../services/register.service';
import {AuthService} from '../../services/auth.service';
import {Constante} from '../../constantes/constante';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-recover',
  templateUrl: './recover.component.html',
  styleUrls: ['./recover.component.css']
})
export class RecoverComponent implements OnInit {
  //Mat spinner
  color = 'primary';
  mode = 'indeterminate';
  value = 5;
  spinner:any = false;
  usuarioFormGroup:FormGroup;

  enviado : boolean;
  enviandoCorreo: boolean = false;

  mensajes:any={
    correo:"",
  }

  constructor(private _registerService: RegisterService,
              private _authService: AuthService,
              private http:HttpClient) {
                  this.enviado = false;
              }

  ngOnInit() {
      this.usuarioFormGroup = new FormGroup({
        correoUsuarioFormControl: new FormControl("", [
          Validators.required,
          Validators.maxLength(250),
          Validators.email
        ])
      });

      this.usuarioFormGroup.controls["correoUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
      if ((Constante.pattern.email).test(data)) { 
        this.usuarioFormGroup.controls["correoUsuarioFormControl"].setAsyncValidators(this.validacionCorreo.bind(this));
      }
      else {
        this.usuarioFormGroup.controls[
          "correoUsuarioFormControl"
        ].clearAsyncValidators();
        this.spinner = false;
        this.mensajes.correo="Formato de correo incorrecto"
      }
      this.usuarioFormGroup.controls["correoUsuarioFormControl"].updateValueAndValidity();
      this.spinner = false;  
    })
  }

    validacionCorreo(control:FormControl):Promise<any>|Observable<any>{
      this.spinner = true;
      let rpta;
      rpta = this._authService.isValidoCorreoRecover(control.value).pipe(
        map((response: any) => {
                this.mensajes.correo=response.mensaje;
                if (response && response.estado) {
                  let button: HTMLElement = <HTMLElement>document.querySelectorAll('.cambiarClaveFocus')[0];
                  button.focus();         
                  return null;
                } else {
                  return {correoRegistrado:true};
                }
            }));
      return rpta
    }

  enviarCorreoRecuperacion() {
    
    

    this.enviandoCorreo = true;
        return this.http.post(`${environment.endpointVelose}/auth/clave/recuperar`, {
           "correo": this.usuarioFormGroup.controls['correoUsuarioFormControl'].value,
         }).subscribe(response=>{
          this.enviandoCorreo = false; 
          
          this.enviado = true;
           //this.enviandoCorreo = false;
              // if ( response.activo ) {
              //     this.enviado = true;
              // } else {
              //   this.usuarioFormGroup.controls['correoUsuarioFormControl'].invalid = true;
              //   this.mensajes.correo="El usuario no esta activo.";
              // }
               
           });
         
          //this.enviado = true;
      
     }

     isEnviado() : boolean {
       return this.enviado;
     }
     validarFormulario(){
       if(this.usuarioFormGroup.valid){
          return false;
       }
       return true;
      
     }

}
