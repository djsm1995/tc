import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormGroup, Validators,FormControl } from '@angular/forms';
import { MatAutocomplete } from '@angular/material/autocomplete';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MatStepper } from '@angular/material/stepper';

import { of  } from 'rxjs/observable/of';
import { Observable } from 'rxjs/Observable';
import { startWith, map, switchMap, debounceTime, tap, finalize, catchError, distinctUntilChanged } from 'rxjs/operators';
import { DialogDatosTarjetaComponent } from './dialog-datos-tarjeta/dialog-datos-tarjeta.component';
import { DialogConfirmacionRegistroComponent } from './dialog-confirmacion-registro/dialog-confirmacion-registro.component';
import { MensajeGenericoComponent } from '../shared/mensaje-generico/mensaje-generico.component';
import { Constante } from '../../constantes/constante';
// Interface
import { Registro, EmpresaR, UsuarioR, ClientePago } from '../../services/register.service';
// Servicios, interfaces, clases
import { PlanesService, Planes, planesResponse, listaCondicionesResponse } from '../../services/planes.service';
import { RegisterService, clientePagoC } from '../../services/register.service';
import { RubrosService, Rubros, RubrosC } from '../../services/rubros.service';
import { PsePartners, PsePartnersService } from '../../services/pse-partners.service';
import { DatosRucService, datosRucResponse, datosRucResponseC } from '../../services/datos-ruc.service';
import { ReusableService } from '../../services/reusable.service';

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"],
})
export class RegisterComponent implements OnInit{
  @ViewChild(MatAutocomplete,{static: false}) matAutocomplete: MatAutocomplete;
  //#region Mat spinner
  color = 'primary';
  mode = 'indeterminate';
  value = 5;
  spinner:any = false;
  //#endregion
  // Variables Globales
  //nuevoRegistro: Registro;
  datosRUC: datosRucResponse = new datosRucResponseC();
  mensajeValidacionRubro: any = null;
  mensajesRegistro: any = {
    correo: "",
    fechaOperatividad:""
  };
  showIconosRegistro: any = {
    fechaOperatividad:false
  }

  planesPago: Planes[];
  listaCondiciones: string[];
  className: string = "borderPlanValidacion";
  dialogResult: string = "";
  // Forms
  usuarioFormGroup: FormGroup;
  empresaFormGroup: FormGroup;
  preguntasFormGroup: FormGroup;
  // autocompletePSE
  isLoadingPadron: boolean = false;
  psePartnerCtrl: FormControl;
  filteredPse: Observable<any[]> = null;
  psePartners: PsePartners[] = [];
  trabajoPseChange = "";
  // autocompleteRubro
  rubroCtrl: FormControl;
  filteredRubro: Rubros[] = [];
  rubro: Rubros[] = [];
  rubroChange = "";
  // Ubigeo
  ubigeo = Constante.UBIGEO;
  ubigeoServicio = Constante.UBIGEOPORDEFECTO;
  ubigeoSeleccionado = {
    departamento: "Lima",
    provincia: "Lima"
  };
  posListaProvincia: number = Number(this.ubigeoServicio.departamento) - 1;
  posListaDistrito: number = 0;

  rutaCertificadoDigital = "";
  // Planes
  sliderCantidadCpes = {
    max: 260000,
    min: 0,
    step: 1000,
    value: 1000
  };
  configSwiper = {
    direction: "horizontal",
    slidesPerView: 1,
    centeredSlides: true,
    initialSlide: 0,
    mousewheel: true,
    navigation: false,
    // scrollbar: true,
    pagination: true
  };
  mostrarPlanes = false;
  // Mensajes por correo registrado y
  showMensajesAdicionales = {
    correo: false,
    ruc: false
  };

  // -- Maqueta preguntas de seguridad
  contadorIntentos:number=0  
  
  constructor(
    private _planesService: PlanesService,
    private _registerService: RegisterService,
    private _PsePartnersService: PsePartnersService,
    private _reusableService: ReusableService,
    private _RubrosService: RubrosService,
    private _datosRucService: DatosRucService,
    @Inject('rucTci') private rucTci: number,
    public _dialog: MatDialog,
    private router: Router
    //private _formBuilder: FormBuilder,
    //private cd: ChangeDetectorRef,
  ) {
    // Filtro Pse Partner
    this.psePartnerCtrl = new FormControl();
    // Filtro Rubros
    this.rubroCtrl = new FormControl();
    this.rubroCtrl.valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
      let codigoRubroFCValue= this.empresaFormGroup.controls["codigoRubroFormControl"].value;
      let rubroFC= this.empresaFormGroup.controls["rubroFormControl"];
      if(codigoRubroFCValue!="" && this.rubroCtrl.value==""){
        this.empresaFormGroup.controls["codigoRubroFormControl"].setValue("")
        rubroFC.setErrors({'incorrect': true});
      }
      if(data != ""){
        let lista: string [] = [];
        this._RubrosService
        .getRubros(data)
        .subscribe(response => {
          if (response.estado) {
            this.filteredRubro = response.rubros;   
            //#region validacion Rubros
              this.filteredRubro.forEach(index => {
                lista.push(index.descripcion);
              });
              if(lista.includes(data) ){                    
                if(this.rubroCtrl.value==null){
                  this.mensajeValidacionRubro = "Seleccione un rubro";
                  rubroFC.setErrors({'incorrect': true});
                }
                if(codigoRubroFCValue==""){
                  this.mensajeValidacionRubro = "No ha seleccionado un rubro";
                  rubroFC.setErrors({'incorrect': true});
                }           
              }else{
                if(this.rubroCtrl.value==null || this.rubroCtrl.value==""){
                  this.mensajeValidacionRubro = "No ha seleccionado un rubro";
                  rubroFC.setErrors({'incorrect': true});
                }else{
                  this.mensajeValidacionRubro = "El rubro indicado no existe";
                  rubroFC.setErrors({'incorrect': true});
                }
              }
            //#endregion         
            }
        });
      }else{
        this._RubrosService
        .getRubros(data)
        .subscribe(response => {
          if (response.estado) {
            this.filteredRubro = response.rubros;   
          }
        })
      }
    });
  }

  ngOnInit() {
    // Obtenemos data inicial
    // this.getPlanes(this.sliderCantidadCpes.value);
    // this.psePartners=this._PsePartnersService.getPsePartners();
    // this.getListaCondiciones();
    let filtro = "";
    this._RubrosService.getRubros(filtro).subscribe(rpta => {
      if (rpta.estado) {
        this.filteredRubro = rpta.rubros;
      }
    });
    this.usuarioFormGroup = new FormGroup({
          nombreUsuarioFormControl: new FormControl("", [Validators.required]),
          apellidoPaternoUsuarioFormControl: new FormControl("", [Validators.required]),
          apellidoMaternoUsuarioFormControl: new FormControl("", [Validators.required]),
          correoUsuarioFormControl: new FormControl("",
            [Validators.required, Validators.maxLength(250), Validators.email],
            this.validacionCorreo.bind(this)
          ),
          passUsuarioFormControl: new FormControl("", [
            Validators.required,
            Validators.minLength(8),
            Validators.pattern(Constante.pattern.password)
          ]),
          confirmarPassUsuarioFormControl: new FormControl("", [
            Validators.required,
            Validators.minLength(8),
            Validators.pattern(Constante.pattern.password),
            this.validacionPassIguales.bind(this)
          ]),
          checkTerminosCondicionesFormControl: new FormControl(true, [Validators.requiredTrue])
    });
    this.empresaFormGroup = new FormGroup({
          checkPseFormControl: new FormControl(false),
          psePartnerFormControl: new FormControl(""),
          idRucPartnerFormControl: new FormControl(""),
          rucFormControl: new FormControl(
            this.datosRUC.datosRuc.ruc,
            [
              Validators.required,
              this.validacionisInteger.bind(this),
              this.validacionRucValido.bind(this)
            ],
            this.rucApto.bind(this)
          ),
          razonSocialFormControl: new FormControl(this.datosRUC.datosRuc.razonSocial, Validators.required),
          rubroFormControl: new FormControl("", Validators.required),
          codigoRubroFormControl: new FormControl("", Validators.required),
          representanteLegalFormControl: new FormControl("", Validators.required),
          telefonoFormControl: new FormControl("", Validators.required),
          departamentoFormControl: new FormControl(this.ubigeoServicio.departamento, Validators.required),
          provinciaFormControl: new FormControl(this.ubigeoServicio.provincia, Validators.required),
          distritoFormControl: new FormControl(this.ubigeoServicio.distrito, Validators.required),
          direccionFormControl: new FormControl(this.datosRUC.datosRuc.direccion, Validators.required)
          // 'certificadoDigitalFormControl':new FormControl('', InputFileDirective.validate ),
    });
    this.preguntasFormGroup= new FormGroup({
      myRecaptcha : new FormControl(false),
      fechaOperatividadCtrl : new FormControl({ value: null, disabled: true}),
      fechaOperatividadCtrlHidden : new FormControl(null)
    });
    //this.myRecaptcha = new FormControl(false, [Validators.required]);
    //this.fechaOperatividadCtrl = new FormControl({ value: null, disabled: true})
    //this.fechaOperatividadCtrlHidden = new FormControl(null)
    
    // CheckPseFormControl
    // this.empresaFormGroup.controls['checkPseFormControl'].valueChanges
    //   .subscribe(data => setTimeout(() => {
    //     if (data) {
    //       this.empresaFormGroup.controls["idRucPartnerFormControl"].setValidators(Validators.required);
    //       this.empresaFormGroup.controls['idRucPartnerFormControl'].setValue("");
    //       this.empresaFormGroup.controls["idRucPartnerFormControl"].updateValueAndValidity();
    //     }
    //     else {
    //       this.empresaFormGroup.controls["idRucPartnerFormControl"].setValue(null);
    //       this.empresaFormGroup.controls['idRucPartnerFormControl'].clearValidators();
    //       this.empresaFormGroup.controls['idRucPartnerFormControl'].updateValueAndValidity()
    //     }
    //   },0));

    this.usuarioFormGroup.controls["passUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data => { 
      this.usuarioFormGroup.controls["confirmarPassUsuarioFormControl"].setValue("")
      this.usuarioFormGroup.controls[
        "confirmarPassUsuarioFormControl"
      ].updateValueAndValidity();

    })
    //this.fechaOperatividadCtrl.valueChanges.subscribe(data => { 
      this.preguntasFormGroup.controls["fechaOperatividadCtrl"].valueChanges.subscribe(data => { 
      //  contabilizar intentos. y adicionar validacion asincrona.
      const maximoIntentos = 3;
      this.contadorIntentos++
      if (this.contadorIntentos > maximoIntentos) {
        this.router.navigate(["/login"]);
        // mensaje d error
        setTimeout(
          () => {
            this._dialog.open(
              MensajeGenericoComponent,
              {
                width: "400px",
                data: {
                  icon: "not_interested",
                  color: "red",
                  titulo: "Alerta de seguridad",
                  mensaje: "Has superado los intentos para validar las preguntas de seguridad. Confirma tus datos en el portal de Sunat."
                }
              }
            );
          }, 0
        );
        return;  
      }
      if (data != null) {
        this.preguntasFormGroup.controls["fechaOperatividadCtrlHidden"].setValue(data)
        this.preguntasFormGroup.controls["fechaOperatividadCtrlHidden"].setAsyncValidators(this.validacionFechaOperatividad.bind(this));
        // this.fechaOperatividadCtrlHidden.
      }
      this.preguntasFormGroup.controls["fechaOperatividadCtrlHidden"].updateValueAndValidity();
    })

    this.usuarioFormGroup.controls["correoUsuarioFormControl"].valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
      if ((Constante.pattern.email).test(data)) { 
        this.usuarioFormGroup.controls["correoUsuarioFormControl"].setAsyncValidators(this.validacionCorreo.bind(this));
      }else {
        this.usuarioFormGroup.controls["correoUsuarioFormControl"].clearAsyncValidators();
        this.showMensajesAdicionales.correo=false;
        this.mensajesRegistro.correo="Formato de correo incorrecto"
      }
      this.usuarioFormGroup.controls["correoUsuarioFormControl"].updateValueAndValidity();
    })
    this.empresaFormGroup.controls["departamentoFormControl"].valueChanges.subscribe(data => {
      this.ubigeoServicio.provincia = null;
      this.ubigeoServicio.distrito = null;
      this.empresaFormGroup.controls["provinciaFormControl"].setValue(null);
      this.empresaFormGroup.controls["distritoFormControl"].setValue(null);
    });
    this.empresaFormGroup.controls["provinciaFormControl"].valueChanges.subscribe(data => {
      this.empresaFormGroup.controls["distritoFormControl"].setValue(null);
      this.ubigeoServicio.distrito = null;
    });
    this.empresaFormGroup.controls["rucFormControl"].valueChanges.subscribe(
      data => {
        if (this.empresaFormGroup.controls["rucFormControl"].errors) {
          // limpiar los demas campos
          this.datosRUC = new datosRucResponseC();
          this.showMensajesAdicionales.ruc = false;
          this.asignarDatos();
        }
      }
    );
    this.filteredPse = this.psePartnerCtrl.valueChanges.pipe(
      startWith(""),
      debounceTime(300), //delay emits
      // map(pse => pse ? this.filterPSE(pse) : this.psePartners.slice())
      tap(value => console.log(value)),
      switchMap(value => {
        if (value == "" || this.trabajoPseChange != value) {
          this.empresaFormGroup.controls["idRucPartnerFormControl"].setValue(
            null
          );
        }
        if (value != "") {
          return this.displayPseFiltered(value);
        } else {
          return of(null);
        }
      })
    );
  }
  // Lista Padron Pse, carga los 5 primeros que coincidan con la busqueda
  displayPseFiltered(value): Observable<any> {
    return this._PsePartnersService
      .getPsePartners({ razonSocial: value.toLowerCase() })
      .pipe(
        map((results: any) => {
          return results.estado && results.padronPse.length >= 1
            ? results.padronPse
            : [];
        }),
        catchError(_ => {
          return of(null);
        }),
        finalize(() => (this.isLoadingPadron = false))
      );
  }

  // Filtros Ubigeo
  onSelectProvincia(result: [any], datoEvaluar?) {
    for (var i = 0; i < result.length; i++) {
      if (
        result[i].selected ||
        (datoEvaluar == undefined
          ? false
          : result[i].cod_Locacion == datoEvaluar)
      ) {
        this.posListaProvincia = i;
        this.ubigeoSeleccionado.departamento = this.ubigeo[i].descripcion;
        break;
      }
    }
  }
  onSelectDistrito(result: [any], datoEvaluar?) {
    for (var i = 0; i < result.length; i++) {
      if (
        result[i].selected ||
        (datoEvaluar == undefined
          ? false
          : result[i].cod_Locacion == datoEvaluar)
      ) {
        this.posListaDistrito = i;
        this.ubigeoSeleccionado.provincia = this.ubigeo[
          this.posListaProvincia
        ].lstUbigeo[i].descripcion;
        break;
      }
    }
  }
  asignarDatos() {
    this.empresaFormGroup.controls["razonSocialFormControl"].setValue(this.datosRUC.datosRuc.razonSocial);
    this.empresaFormGroup.controls["direccionFormControl"].setValue(this.datosRUC.datosRuc.direccion);
    if (this.datosRUC.datosRuc.ubigeo != null) {
      this.ubigeoServicio.departamento = this.datosRUC.datosRuc.ubigeo.substring(
        0,
        2
      );
      this.empresaFormGroup.controls["departamentoFormControl"].setValue(this.ubigeoServicio.departamento);
      this.onSelectProvincia(Constante.UBIGEO,this.ubigeoServicio.departamento);
      this.ubigeoServicio.provincia = this.datosRUC.datosRuc.ubigeo.substring(
        0,
        4
      );
      this.empresaFormGroup.controls["provinciaFormControl"].setValue(this.ubigeoServicio.provincia);
      this.onSelectDistrito(Constante.UBIGEO[this.posListaProvincia].lstUbigeo,this.ubigeoServicio.provincia);
      this.ubigeoServicio.distrito = this.datosRUC.datosRuc.ubigeo;
      this.empresaFormGroup.controls["distritoFormControl"].setValue(this.ubigeoServicio.distrito);
    }
  }

  //#region Validaciones formulario
  validacionisInteger(control: FormControl): { [s: string]: boolean } {
    if (control.value && !Number.isInteger(control.value)) {
      this.datosRUC.mensaje = "El dato ingresado no es un numero";
      return { validacion: true };
    }
    this.resetFormDatosRUC();
    return null;
  }
  validacionRucValido(control: FormControl): { [s: string]: boolean } {
    if (control.value) {
      if (String(control.value).length != 11) {
        this.datosRUC.mensaje = "El dato ingresado no tiene 11 caracteres";
        return { validacion1: true };
      } else if (this.inicioNumeroRUC(control.value)) {
        this.datosRUC.mensaje = "El dato ingresado no es un RUC valido";
        return { validacion2: true };
      } else if (!this.validacionRUC(control.value)) {
        this.datosRUC.mensaje = "El dato ingresado no es un RUC valido";
        return { validacion3: true };
      }
    }
    this.resetFormDatosRUC();
    return null;
  }
  rucApto(control: FormControl): Promise<any> | Observable<any> {
    this.spinner = true;
    //let datosRuc: datosRucResponse;
    this.empresaFormGroup.controls["idRucPartnerFormControl"].setValue(null)
    let rpta = this._datosRucService
      .VerificacionRucRegistro(this.empresaFormGroup.controls["rucFormControl"].value, this.usuarioFormGroup.controls["correoUsuarioFormControl"].value ).pipe(
      map((response: datosRucResponse) => {
        this.showMensajesAdicionales.ruc=false;
        if (response && response.estado) {
          this.datosRUC = response;
          if (response.datosRuc) {
            //llamar message de : Informacion brindad por Sunar, puede modificar el cliente la data brindada
            this.asignarDatos();
            // Si en un futuro , se adiciona el plan de emisor nuevo adicionar un else
            if (response.datosRuc.integracion == true) {
              this.empresaFormGroup.controls["idRucPartnerFormControl"].setValue(this.rucTci)
              this.showMensajesAdicionales.ruc = response.datosRuc.redirectLogin;
              this.spinner = false;
              return (response.datosRuc.redirectLogin == true) ? { validation: true } : null
            }
            this.spinner = false;
            return null;
          }
          this.spinner = false;
          return { validation: true };
        } else {
          this.datosRUC.mensaje = response.mensaje;
          this.spinner = false;
          return { validation: true };
        }
      }));
    return rpta;
  }

  validacionCorreo(control: FormControl): Promise<any> | Observable<any> {
    //valida formato de correo
    let rpta = this._registerService
        .verificacionCorreoRegistro(control.value).pipe(
        map((response: any) => {
          //this.mensajesRegistro.correo = response.mensaje;
          if (response && !response.estado) {
            this.showMensajesAdicionales.correo = true;
            return { correoRegistrado: true };
          }
          this.showMensajesAdicionales.correo = false;
          return null;
        }));
    return rpta;
  }

  validacionPassIguales(control: FormControl): { [s: string]: boolean } {
    if (
      this.usuarioFormGroup &&
      control.value !=
        this.usuarioFormGroup.controls["passUsuarioFormControl"].value
    )
      return { passIguales: true };
    return null;
  }

  validacionFechaOperatividad(control: FormControl): Promise<any> | Observable<any> {
    let ruc = this.empresaFormGroup.controls["rucFormControl"].value
    //valida fecha de operatividad
    let rpta = this._registerService
      .verificacionfechaOperatividad({ ruc: ruc, fechaOperatividad: this._reusableService.getFormatoFecha(control.value, 1)}).pipe(
      map((response: any) => {
        this.mensajesRegistro.fechaOperatividad = response.mensaje;
        this.showIconosRegistro.fechaOperatividad = response.estado
        return (response && !response.estado) ? { fechaOperatividad: true }:null
      }));
    return rpta;
  }
  //#endregion
  
  

  //#region Reutilizables
  resetFormDatosRUC() {
    this.datosRUC = new datosRucResponseC();
  }

  inicioNumeroRUC(ruc) {
    if (
      !(
        (ruc >= 1e10 && ruc < 11e9) ||
        (ruc >= 15e9 && ruc < 18e9) ||
        (ruc >= 2e10 && ruc < 21e9)
      )
    ) {
      return true;
    }
    return false;
  }
  esnumero(campo) {
    return !isNaN(campo);
  }
  validacionRUC(valor) {
    valor = String(valor).trim();
    if (this.esnumero(valor)) {
      if (valor.length == 11) {
        let suma = 0;
        let x = 6;
        let zero = 0;
        for (let i = 0; i < valor.length - 1; i++) {
          if (i == 4) x = 8;
          let digito = valor.charAt(i) - zero;
          x--;
          if (i == 0) {suma += digito * x}
          else suma += digito * x;
        }
        let resto = suma % 11;
        resto = 11 - resto;

        if (resto >= 10) resto = resto - 10;
        if (resto == valor.charAt(valor.length - 1) - zero) {
          return true;
        }
      }
    }
    return false;
  }
 //#endregion
  seleccionPse(pse) { //Razon Social
    this.trabajoPseChange = pse.razonSocial;
    this.empresaFormGroup.controls["idRucPartnerFormControl"].setValue(pse.ruc);
  }
  seleccionRubro(rubro) {
    this.empresaFormGroup.controls['rubroFormControl'].setValue(rubro.descripcion)
    this.empresaFormGroup.controls["codigoRubroFormControl"].setValue(rubro.codigo);
    this.mensajeValidacionRubro=null;
    this.empresaFormGroup.controls["rubroFormControl"].setErrors(null);
  }
  // Plan mas popular
  bgMasPopular(index: any) {
    let className = "";
    className =
      index == this.configSwiper.initialSlide ? this.className : className;
    return className;
  }

  // Dialog Pago
  openDialog(plan: any) {
    if (plan.planInfinito) {
      let dialogRef;
      let nombre = this.usuarioFormGroup.controls["nombreUsuarioFormControl"]
        .value;
      setTimeout(
        () =>
          (dialogRef = this._dialog.open(MensajeGenericoComponent, {
            width: "400px",
            data: {
              icon: "sentiment_satisfied_alt",
              color: "#062a78",
              titulo: "Plan Personalizado",
              mensaje: `Hola ${nombre}, creamos un plan que se adecua a tus necesidades. En el transcurso del día nos estaremos comunicando contigo para brindarte todos los detalles.
                        Tambien puedes contactarnos al número: (01) 3151930`
            }
          })),
        0
      );
      this.router.navigate(["/login"]);
    } else {
      let dialogRef;
      setTimeout(
        () =>
          (dialogRef = this._dialog.open(DialogDatosTarjetaComponent, {
            width: "400px",
            data: {
              tipoOperacion: "N", //N: Nuevo Registro, C: Compra de Plan, V: Validaciones
              plan: plan,
              cliente: this.assembleClientePago(),
              registro: true, //false cuando no se va a registrar luego
              usuarioRegistro: this._registerService.assembleUsuario(
                this.usuarioFormGroup
              ), // enviar si es true registro
              empresaRegistro: this.empresaFormGroup //enviar si true registro
            }
          })),
        0
      );
      setTimeout(
        () =>
          dialogRef.afterClosed().subscribe(result => {
            this.dialogResult = result;
          }),
        0
      );
    }
  }
  openDialogMensaje() {
    let dialogRef;
    let nombre = this.usuarioFormGroup.controls["nombreUsuarioFormControl"]
      .value;
    setTimeout(
      () =>
        (dialogRef = this._dialog.open(MensajeGenericoComponent, {
          width: "400px",
          data: {
            icon: "sentiment_satisfied_alt",
            color: "#062a78",
            titulo: "Cliente de TCI",
            mensaje: `Hola ${nombre}, estamos felices que sigas apostando por nosotros. En el transcurso del día nos estaremos comunicando contigo para indicarte los planes que tenemos para tí. `
          }
        })),
      0
    );
  }

  assembleClientePago() {
    let clientePago: ClientePago = new clientePagoC();
    let datosUsuario = this.usuarioFormGroup.value;
    let datosEmpresa = this.empresaFormGroup.value;
    clientePago.nombre = datosUsuario.nombreUsuarioFormControl;
    clientePago.apellidos = `${
      datosUsuario.apellidoPaternoUsuarioFormControl
    } ${datosUsuario.apellidoMaternoUsuarioFormControl}`;
    clientePago.correo = datosUsuario.correoUsuarioFormControl;
    clientePago.direccion = datosEmpresa.direccionFormControl;
    clientePago.zip = datosEmpresa.distritoFormControl;
    clientePago.ciudad = this.ubigeoSeleccionado.provincia;
    clientePago.estado = this.ubigeoSeleccionado.departamento;
    clientePago.pais = "Perú";
    clientePago.telefono = String(datosEmpresa.telefonoFormControl);
    return clientePago;
  }
  validacionClienteTci(stepperPrincipal) {
    // Es cliente de TCI
    if (this.datosRUC.datosRuc.codigo == 1) {
      this.openDialogMensaje();
      this.router.navigate(["/login"]);
    } else {
      this.goForward(stepperPrincipal);
    }
  }
  // Navegacion Stepper
  goForward = (stepper: MatStepper) => {
    // this.activarServicios(stepper)
    stepper.next();
  };
  goBack = (stepper: MatStepper) => {
    stepper.previous();
  };

  // Navegacion Planes
  getListaCondiciones() {
    this._planesService
      .getListaCondiciones()
      .subscribe((condiciones: listaCondicionesResponse) => {
        if (condiciones.estado) {
          this.listaCondiciones = condiciones.condiciones;
        }
      });
  }
  getPlanes(cpesEnviados) {
    this.mostrarPlanes = this.mostrarPlanes
      ? !this.mostrarPlanes
      : this.mostrarPlanes;
    this._planesService
      .getPlanes(cpesEnviados)
      .subscribe((planes: planesResponse) => {
        this.configSwiper.initialSlide = planes.planRecomendado;
        this.planesPago = planes.planes;
        this.mostrarPlanes = !this.mostrarPlanes;
      });
  }

  // ================================================================================
  // Lectura de un documento en especifico, actualmente se usa
  changeCertificado(input: HTMLInputElement) {
    const file = input.files.item(0).name;
    if (file) {
      // extensiones permitidas cer y pfx
      let extensionesPermitidas = [".cer", ".crt", ".pem"];
      let extension = file.substring(file.lastIndexOf(".")).toLowerCase();
      let permitida = false;
      for (var i = 0; i < extensionesPermitidas.length; i++) {
        if (extensionesPermitidas[i] == extension) {
          permitida = true;
          break;
        }
      }
      if (permitida) {
        this.rutaCertificadoDigital = file;
        // this.empresa.certificadoDigital=file;
        var myReader: FileReader = new FileReader();
        var self = this;
        myReader.onloadend = function(e) {
          self.empresaFormGroup.controls[
            "certificadoDigitalFormControl"
          ].setValue(myReader.result);
          // console.log(myReader.result);
        };
        myReader.readAsText(input.files.item(0));
      }
    }
  }
  // ================================================================================

  registrarUsuarioClienteOSE() {
    // Mostrar mensaje de confirmacion y enviar data al dialog
    let dialogRef;
    setTimeout(
      () =>
        (dialogRef = this._dialog.open(
          DialogConfirmacionRegistroComponent,
          {
            width: "400px",
            data: {
              usuario: this.usuarioFormGroup,
              empresa: this.empresaFormGroup.value,
              preguntasDeSeguridad: {
                fechaOperatividad:this._reusableService.getFormatoFecha(this.preguntasFormGroup.controls["fechaOperatividadCtrl"].value,1)
              }
            }
          }
        )),
      0
    );
    
    // ${ this.reusable.getSessionUsuario().correo }

    // let usuarioRegistro = this._registerService.assembleUsuario(
    //   this.usuarioFormGroup
    // );
    // let empresaRegistro = this._registerService.assembleEmpresaSinFact(
    //   this.empresaFormGroup
    // );

    // this._registerService
    //   .nuevoRegistroUsuarioClienteOSE(usuarioRegistro, empresaRegistro)
    //   .subscribe((rpta: any) => {
    //     //this.router.navigate(['/login'])
    //     // if(!rpta.estado){
    //     //   this.rptaRegistroPago.estado= !this.rptaRegistroPago.estado;
    //     //   this.rptaRegistroPago.mensaje=rpta.mensaje;
    //     // }
    //   });
  }
  //#region Captcha
  validarFechaAndCaptcha(){
    let fechaOperatividad = this.preguntasFormGroup.controls["fechaOperatividadCtrlHidden"];
    let captchaValid = this.preguntasFormGroup.controls["myRecaptcha"].value;
    if(fechaOperatividad.value == null){
      return true;
    }
    if(this.ocultarCaptcha()){
      return (fechaOperatividad.invalid) ? true : false;
    }
    return (this.preguntasFormGroup.invalid || this.preguntasFormGroup.pending) ? true : false;
  }
  ocultarCaptcha(){
    return Constante.habilitarDeshabilitarCaptcha();
  }
  //Metodos Captcha
  onScriptLoad() {
    // console.log('Google reCAPTCHA cargado y está listo para su uso!' )
  }

  onScriptError() {
    console.log('Algo se demoró al cargar el reCAPTCHA de Google.')
  }
  //#endregion
}