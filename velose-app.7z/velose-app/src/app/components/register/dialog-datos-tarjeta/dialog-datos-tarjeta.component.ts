import { Component, OnInit ,Inject, NgModule, Testability} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {Constante} from '../../../constantes/constante';
import { Validators, FormControl, FormGroup } from '@angular/forms';
// Clases e interfaces
import {operacionPagoC,Pago,PagoRC,rptaPagoAlignedC,rptaPagoAligned} from '../../../services/register.service';
import {listaOpcionesPlanResponse,listaOpcionesPlanResponseC,Planes,PlanesC} from '../../../services/planes.service';
// Servicios
import {MiplanService} from '../../../services/miplan.service';
import {PagoService} from '../../../services/pago.service';
import {PlanesService} from '../../../services/planes.service';
import {RegisterService} from '../../../services/register.service';
import { Router } from '@angular/router';


declare var PF:any;
@Component({
  selector: 'app-dialog-datos-tarjeta',
  templateUrl: './dialog-datos-tarjeta.component.html',
  styleUrls: ['./dialog-datos-tarjeta.component.css']
})
export class DialogDatosTarjetaComponent implements OnInit {
operacionActual:any;
planA:PlanesC;
planSeleccionado:any=0;
positionPlan=this.planSeleccionado;
step={
  confirmacion:true,
  pago:false
}
transaccionPagoOK=false;
rptaRegistroPago={
  estado:false,
  mensaje:""
}
registroPagoOK=false;
confirmacionFG: FormGroup;

constructor(
            @Inject(MAT_DIALOG_DATA) public data:any,
            public _dialogRef:MatDialogRef<DialogDatosTarjetaComponent>,
            public _pago:PagoService, public _planes:PlanesService,
            private _miPlan:MiplanService,
            public _registroS:RegisterService,
            private router:Router,
            private dialogRef: MatDialogRef<DialogDatosTarjetaComponent>
          ){
            this.planA=new PlanesC();
          }

  ngOnInit() {
    // this.plan=this._planes.getPlanSeleccionado(this.data.plan.idPlan) ;
    this._planes.getPlanSeleccionado(this.data.plan.idPlan)
        .subscribe( (rpta:any)=>{
          if(rpta.estado)
          this.planA= rpta.plan;
        });

    this.confirmacionFG=new FormGroup({
      'nombreFacturacion':new FormControl(this.data.cliente.nombre,
                                          [ Validators.required,
                                            Validators.maxLength(80)]
                                          ),
      'apellidoFacturacion':new FormControl(this.data.cliente.apellidos,
                                            [ Validators.required,
                                              Validators.maxLength(80)]
                                            ),
      'correoFacturacion':new FormControl(this.data.cliente.correo,
                                          [ Validators.required,
                                            Validators.maxLength(250),
                                            Validators.email]
                                          ),
    });

  }

  comprarPlan(a){
    this.activacionPasos();
    // Llamada Alignet
    this._pago.getNroOperacionHash(this.assembleDatoPagoService())
    .subscribe(rpta=>{
      let rptaC:any = rpta;
      if(rptaC.estado=!null && rptaC.estado){
        this.operacionActual=rpta;
        let precioPlan=Math.round(this.planA.lstOpciones[this.positionPlan].precioFinal*100)/100;
        var self=this;
        if (Constante.activarServicioAlignet) {
          this.dialogRef.disableClose=true;
          PF.Init.execute({
            data: {
              operation: {
                operationNumber: String(
                  this.operacionActual.idOperation
                ), //100009
                amount: String(this.toFixedTrunc(precioPlan, 2)),
                currency: {
                  code: this.data.plan.codMoneda, //'PEN', //
                  symbol: this.data.plan.moneda //'S/.' //
                },
                productDescription: this.data.plan.nombre // 'Televisor 70 pulgadas'
              },
              customer: {
                name: this.data.cliente.nombre, //'Jonatham', //
                lastname: this.data.cliente.apellidos, // 'Mendoza Vasquez', //
                email: this.data.cliente.correo, //'cristhianguzman@hotmail.com', //'jonatham.mendoza@gmail.com', //
                address: this.data.cliente.direccion, // 'Av Casimiro Ulloa 333', //
                zip: this.data.cliente.zip, //'051 42', //
                city: this.data.cliente.ciudad, //'Lima', //
                state: this.data.cliente.estado, //'Lima', //
                country: this.data.cliente.pais, //'Peru', //
                phone: this.data.cliente.telefono //'997558332' //
              },
              signature: this.operacionActual.signature //'1b48272013d9c74d06f737fcbf54f82aff24fbe33b4222575b6a1d58d62bde3b4de6fd6071398c1f302872e313fdd3af17b08a5704db40f9b83035be50326181'
            },
            listeners: {
              afterPay: function (response) {
                self.registrarPago(response);
              }
            },
            settings: {
              key: Constante.PUBLICKEY,
              locale: "es_PE",
              identifier: Constante.IDENTIFIERCOMERCE,
              brands: ["VISA", "AMEX", "MSCD", "DINC"],
              responseType: "extended"
            }
          });
        } else {
          let response = {
            features: {
              authentication: {
                eci: "07",
                vci: "NP"
              }
            },

            identifier: "8461",
            message: "Tu operación se ha realizado con éxito.",
            messageCode: "00",
            operation: {
              amount: "389.40",
              currencyCode: "PEN",
              customer: {
                address: "20432168213 ",
                city: "Lima",
                country: "Perú",
                email: "acasabonah@gmail.com",
                lastname: "cardholderInformation cardholderInformation",
                name: "cardholderInformation",
                phone: "20432168213",
                state: "Lima",
                zip: "150101"
              },
              number: "15063",
              productDescription: "Plan 1"
            },

            payment: {
              accepted: "true",
              bin: "485951",
              cardholderInformation: {
                lastname: "cardholderInformation cardholderInformation",
                name: "cardholderInformation"
              },
              creditDebit: "CREDIT",
              date: "11/01/2019",
              errorCode: "00",
              errorMessage: "Successful approval/completion",
              hour: "14:18:6",
              lastPan: "0036",
              referenceCode: "140714",
              resultCode: "000",
              resultMessage: "Operacion Autorizada",
            },
            signature: "65c7353946a19c633f5be83084195b2dbbbba9b3c5b4e509d7570ff4c61b9c499ef1febf097cfe58cfe263de116d73be3d5011d9bed4db90f3fe713b9e29aff8",
            success: "true"
          };
          self.registrarPago(response);
        }
      }
    });
  }

  assembleDatoPagoService(){
    let datos=new operacionPagoC();
    datos.nombreUsuario=this.data.cliente.nombre;
    datos.correo=this.data.cliente.correo;
    datos.telefono=this.data.cliente.telefono;
    datos.monto=Number(this.toFixedTrunc(this.planA.lstOpciones[this.positionPlan].precioFinal,2));
    // Math.round(this.planA.lstOpciones[this.positionPlan].precioFinal*100)/100;
    datos.simboloMoneda=this.data.plan.moneda;
    datos.codigoMoneda=this.data.plan.codMoneda;
    datos.ubigeo=this.data.cliente.zip;
    datos.direccion=this.data.cliente.direccion;
    datos.idPlan=this.planA.lstOpciones[this.positionPlan].idOpcion;

    return datos;
  }


  assemblePago(){
    let datos=new PagoRC();
    datos.idPlan=this.planA.idPlan;
    datos.idPlanOpcion=this.planA.lstOpciones[this.positionPlan].idOpcion;
    datos.idOperacion=this.operacionActual.idOperation;
    return datos;

  }
  assemblePagoAlignet(rptaPago){
    let datos= new rptaPagoAlignedC();
    datos.idOperacion=this.operacionActual.idOperation;
    datos.eci=(rptaPago.features==null)?null:rptaPago.features.authentication.eci;
    datos.vci=(rptaPago.features==null)?null:rptaPago.features.authentication.vci;
    datos.messageCode=rptaPago.messageCode;
    datos.message=rptaPago.message;

    if (rptaPago.payment.cardholderInformation != null){
      datos.pasarelaResultRequest={
        nombreTitular:`${rptaPago.payment.cardholderInformation.lastname} ${rptaPago.payment.cardholderInformation.name}`,
        digitosTarjeta:(rptaPago.payment.lastPan==undefined)?null:rptaPago.payment.lastPan,
        codigoResultado:rptaPago.payment.resultCode,
        mensajeResultado:rptaPago.payment.resultMessage,
        tipoTarjeta:(rptaPago.payment.creditDebit==undefined)?null:rptaPago.payment.creditDebit,
        estado:rptaPago.payment.accepted,
        bin:(rptaPago.payment.bin==undefined)?null:rptaPago.payment.bin,
      }
    }
    return datos;
  }


  registrarPago(response) {
    if (response.success=="true" && response.payment.accepted=="true") {
      this.transaccionPagoOK= !this.transaccionPagoOK;
      this.registrarPagoAlignet(response);
      switch(this.data.tipoOperacion) {
          case 'N':
                  //console.log("en registro nuevo cliente");
                  this.registrarNuevoCliente(response);
                  break;
          case 'C':

                  this.registrarPlanBaseCliente(response);
                  break;
          case 'V':
                  //console.log("en validaciones de compra de plan");
                  break;
      }
    }
    else {
      this.dialogRef.disableClose = false;
      this.registrarPagoAlignet(response);
    }
  }

  assembleComprarPlanBase(response) {
      //cris
      let params = {
            "idPlan" : this.data.plan.idPlan ,
            "idPlanOpcion": this.planA.lstOpciones[this.positionPlan].idOpcion,
            "idOperacion": response.operation.number,
            "idPse": this.data.idPse,
            "correoFact" : this.data.cliente.correo,

            //ESTO ES PARA VALIDACIONES
            // "cantidad" : this.data.validaciones.cantidad,
            // "precio" : this.data.validaciones.totalPago,

            "nombreContactoFact" : this.data.cliente.nombre,
            "apellidoContactFact" : this.data.cliente.apellidos
        }
    return params;
  }


  registrarNuevoCliente(rptaPago){
    this._registroS.nuevoRegistro(this.data.usuarioRegistro,
                                  this._registroS.assembleEmpresa(this.data.empresaRegistro,this.confirmacionFG),
                                  this.assemblePago())
      .subscribe((rpta:any)=>{
        this.router.navigate(['/login'])
        this.dialogRef.disableClose = false;
        if(!rpta.estado){
          this.rptaRegistroPago.estado= !this.rptaRegistroPago.estado;
          this.rptaRegistroPago.mensaje=rpta.mensaje;
        }

      });
  }

//cris
  registrarPlanBaseCliente(response){
      //console.log("en compra de plan renovacion");
      this._miPlan.registrarPlanAdicional( this.assembleComprarPlanBase(response) ).subscribe(
      //.catch((error:any) => Observable.throw( 'Server error:'+error)).subscribe(
        response=>{
          console.log( "response" );
          this.router.navigate(['dashboard']);  //home/miPlan  //home.miPlan/
        }
      );
  }


  registrarPagoAlignet(rptaPago){
    console.log(this.assemblePagoAlignet(rptaPago));
    this._registroS.registroPagoAlignet(
      this.assemblePagoAlignet(rptaPago))
      .subscribe(rpta => {
        
      });
  }

  activacionPasos() {
    this.step.confirmacion=!this.step.confirmacion
    this.step.pago = !this.step.pago
    this.dialogRef.disableClose = false;

    
  }

  toFixedTrunc(value, n) {
    const f = Math.pow(10, n);
    return (Math.trunc(value*f)/f).toFixed(n);
  }

  onClosedCancel(){ this._dialogRef.close('Cancel')}
  onClosedConfirm(){ this._dialogRef.close('Confirm') }

}
