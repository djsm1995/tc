import { Component, OnInit, Inject, isDevMode } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from "@angular/router";
import { EmpresaR,empresaRC,RegisterService } from '../../../services/register.service'
import { MensajeGenericoComponent } from '../../shared/mensaje-generico/mensaje-generico.component';
import { NullAstVisitor } from '@angular/compiler';


@Component({
  selector: "app-dialog-confirmacion-registro",
  templateUrl: "./dialog-confirmacion-registro.component.html",
  styleUrls: ["./dialog-confirmacion-registro.component.css"]
})
export class DialogConfirmacionRegistroComponent implements OnInit {
  stepCargandoRegistro: boolean = false;
  mensajesCargandoRegistro: string[];
  varCargando = {
    mensaje: "",
    posicion:0
  }
  constructor(
    public _dialog: MatDialog,
    public dialogRef: MatDialogRef<DialogConfirmacionRegistroComponent>,
    public _registroS: RegisterService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    if(isDevMode())console.log(this.data);
  }

  //#region Lyfecicles
  ngOnInit() {
    this.mensajesCargandoRegistro = [
      "Verificando datos ingresados...",
      `Registrando a ${this.data.usuario.value.nombreUsuarioFormControl}...`,
      "Sabías que VelOSE procesa en promedio 2 millones de comprobante por día."
    ];
    this.varCargando.mensaje = this.mensajesCargandoRegistro[0];
    // "Sabias que harían falta 788.832.000 post-its de 5 cm para dar la vuelta al mundo. "
  }
  //#endregion

  //#region Methods
  registrar() {
    this.cargando();
    // Service de registro + popup
    this._registroS
      .nuevoRegistro(
        this._registroS.assembleUsuario(this.data.usuario),
        this.assembleEmpresa(this.data.empresa),
        null,
        this.data.preguntasDeSeguridad
      )
      .subscribe((response: any) => {
        let dialogReMensajeGenerico;
        if (response && response.estado) {
          this.dialogRef.close();
          this.router.navigate(["/login"]);

          //mensaje ok
          setTimeout(() => {
            dialogReMensajeGenerico = this._dialog.open(
              MensajeGenericoComponent,
              {
                width: "400px",
                data: {
                  icon: "thumb_up",
                  color: "#062a78",
                  titulo: "Registro exitoso",
                  mensaje: ` ${
                    this.data.usuario.value.nombreUsuarioFormControl
                  }, hemos enviado un correo electrónico a  ${
                    this.data.usuario.value.correoUsuarioFormControl
                  }. Tu registro fue exitoso, lo que te permite empezar a disfrutar de velOSE. ¡Felicidades!`
                }
              }
            );
          }, 0);
        } else {
          //mostrar mensaje
          if(isDevMode())console.log(response.mensaje);
          this.dialogRef.close();
          this.router.navigate(["/login"]);
          // mensaje d error
          setTimeout(() => {
            dialogReMensajeGenerico = this._dialog.open(
              MensajeGenericoComponent,
              {
                width: "400px",
                data: {
                  icon: "warning",
                  color: "red",
                  titulo: "Mensaje de error",
                  mensaje: response.mensaje
                }
              }
            );
          }, 0);
        }
        this.dialogRef.disableClose = false;
      });
  }

  cargando() {
    this.dialogRef.disableClose = true;
    this.stepCargandoRegistro = true;
    setInterval(() => { this.cambiarMensajeCargando() }, 3000);
  }

  cambiarMensajeCargando() {
    let posicion = this.varCargando.posicion;
    this.varCargando.posicion = (posicion == (this.mensajesCargandoRegistro.length - 1)) ? 0 : posicion+1
    this.varCargando.mensaje = this.mensajesCargandoRegistro[
      this.varCargando.posicion
    ];
  }

  assembleEmpresa(empresa) {
    let empresaRegistro: EmpresaR = new empresaRC();
    if (empresa) {
      let empresaValue = empresa;
      empresaRegistro.ruc = empresaValue.rucFormControl;
      empresaRegistro.razonSocial = empresaValue.razonSocialFormControl;
      empresaRegistro.telefono = empresaValue.telefonoFormControl;
      empresaRegistro.representanteLegal =
        empresaValue.representanteLegalFormControl;
      empresaRegistro.ubigeo = empresaValue.distritoFormControl;
      empresaRegistro.direccion = empresaValue.direccionFormControl;
      empresaRegistro.codRubro = empresaValue.codigoRubroFormControl;
      empresaRegistro.rucPsePartner = empresaValue.idRucPartnerFormControl;
    }
    return empresaRegistro;
  }

  //#endregion
}
