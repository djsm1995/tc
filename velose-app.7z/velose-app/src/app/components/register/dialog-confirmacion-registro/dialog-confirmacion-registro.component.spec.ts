import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogConfirmacionRegistroComponent } from './dialog-confirmacion-registro.component';

xdescribe('DialogConfirmacionRegistroComponent', () => {
  let component: DialogConfirmacionRegistroComponent;
  let fixture: ComponentFixture<DialogConfirmacionRegistroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogConfirmacionRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogConfirmacionRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
