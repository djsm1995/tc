import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import {FormsModule,ReactiveFormsModule } from '@angular/forms';
import {JsonPipe, DatePipe} from '@angular/common';
// Adicionales
import { AngularMaterialModule } from './angular-material/angular-material.module';

import { FlexLayoutModule} from '@angular/flex-layout';
import { SwiperModule,SWIPER_CONFIG,SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { FileUploadModule } from 'ng2-file-upload';
import { NgxFileDropModule  } from 'ngx-file-drop';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
//- para Recortar Imagen
import { ImageCropperModule } from 'ngx-image-cropper';

// Rutas
import { APP_ROUTING, ROUTES } from './app.route';
import { AgmCoreModule } from '@agm/core';
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer';


//#endregion


//#region Componentes
import { AppComponent } from "./app.component";
import { AuthComponent } from "./components/auth/auth.component";
import { RegisterComponent } from "./components/register/register.component";
import { HomeComponent } from "./components/home/home.component";
import { DashboardComponent } from "./components/layout/dashboard/dashboard.component";
import { CasoNegocioComponent } from "./components/layout/caso-negocio/caso-negocio.component";
import { HomologacionComponent } from "./components/layout/homologacion/homologacion.component";
import { TransaccionesComponent } from "./components/layout/transacciones/transacciones.component";
import { ConfirmacionCompraComponent } from "./components/layout/mi-plan/confirmacion-compra/confirmacion-compra.component";
import { MiPlanComponent } from "./components/layout/mi-plan/mi-plan.component";
import { ConsultaValidacionesComponent } from "./components/layout/consulta-validaciones/consulta-validaciones.component";
import { DeclaracionComprobanteComponent } from "./components/layout/declaracion-comprobante/declaracion-comprobante.component";
import { DashboardOperadorComponent } from "./components/layout/dashboard-operador/dashboard-operador.component";
import { CredencialesHomologacionComponent } from "./components/layout/configuracion/credenciales-homologacion/credenciales-homologacion.component";
//--Analitycs
import { DashboardAnalyticsComponent } from './components/layout/analytics/dashboard-analytics/dashboard-analytics.component';
import { ConfiguracionComponent } from './components/layout/analytics/configuracion/configuracion.component';

//#endregion
//#region Dialog
import { DialogDatosTarjetaComponent } from "./components/register/dialog-datos-tarjeta/dialog-datos-tarjeta.component";
import { InformacionInicialComponent } from "./components/layout/dashboard/informacion-inicial/informacion-inicial.component";
import { MensajeFinalCnComponent } from "./components/layout/caso-negocio/mensaje-final-cn/mensaje-final-cn.component";
import { HomologacionLineaComponent } from "./components/layout/homologacion/homologacion-linea/homologacion-linea.component";
import { ErroresHomologacionComponent } from "./components/layout/homologacion/errores-homologacion/errores-homologacion.component";
import { MensajeGenericoComponent } from "./components/shared/mensaje-generico/mensaje-generico.component";
import { PopupDetalleErrorComponent } from "./components/layout/consulta-validaciones/popup-detalle-error/popup-detalle-error.component";
import { ConfiguracionesEmpresAmbienteBetaComponent } from "./components/layout/homologacion/configuraciones-empres-ambiente-beta/configuraciones-empres-ambiente-beta.component";
import { DialogConfirmacionRegistroComponent } from './components/register/dialog-confirmacion-registro/dialog-confirmacion-registro.component';
import { ReprocesarConsultaComprobantesService } from "./services/reprocesar-consulta-comprobantes.service";
import { PopupCargarImagenComponent } from "./components/layout/profile/popup-cargar-imagen/popup-cargar-imagen.component";
import { CambioClaveComponent } from './components/shared/dialogs/cambio-clave/cambio-clave.component';
//--Analitycs
import { DialogVisualizarEjemploComponent } from './components/layout/analytics/configuracion/dialog-visualizar-ejemplo/dialog-visualizar-ejemplo.component';

//#endregion
//#region Componentes Shared
import { NavbarComponent } from "./components/shared/navbar/navbar.component";
import { SidebarComponent } from "./components/shared/sidebar/sidebar.component";
import { PlanesComponent } from "./components/shared/planes/planes.component";
import { CambioPasswordComponent } from "./components/shared/cambio-password/cambio-password.component";
import { PdfViewerComponent } from "./components/shared/pdf-viewer/pdf-viewer.component";
import { MenuListItemComponent } from "./components/shared/menu-list-item/menu-list-item.component";
import { ConfirmacionReenvioComponent } from "./components/layout/homologacion/confirmacion-reenvio/confirmacion-reenvio.component";
import { ChatSupportComponent } from "./components/shared/chat-support/chat-support.component";
import { TutorialComponent } from "./components/shared/tutorial/tutorial.component";
import { RecoverComponent } from "./components/recover/recover.component";
import { ChangepasswordComponent } from "./components/changepassword/changepassword.component";
import { ConfirmacionProduccionComponent } from "./components/layout/homologacion/confirmacion-produccion/confirmacion-produccion.component";
import { ErrorPageComponent } from "./components/shared/error-page/error-page.component";
//--analytics
import { ConfirmacionAnalisisDatosanalyticsComponent } from './components/shared/analytics/confirmacion-analisis-datos-analytics/confirmacion-analisis-datos-analytics.component';

//#endregion
//#region Servicios
import { AuthService } from './services/auth.service';
import { AuthGuardService } from './services/auth-guard.service';
import { RegisterService } from './services/register.service';
import { DashboardService } from './services/dashboard.service';
import { PlanesService } from './services/planes.service';
import { MenuPrincipalService } from './services/menu-principal.service';
import { PsePartnersService } from './services/pse-partners.service';
import { RubrosService } from './services/rubros.service';
import { DatosRucService } from './services/datos-ruc.service';
import { CasosDeNegociosService } from './services/casos-de-negocios.service';
import { HomologacionService } from './services/homologacion.service';
import { ReusableService } from './services/reusable.service';
import { PagoService } from './services/pago.service';
import { TransaccionesService } from './services/transacciones.service';
import { BuscarPdfService } from './services/buscar-pdf.service';
import { MiplanService } from './services/miplan.service';
import { TokenService } from './services/token.service';
import { ConsultaValidacionesService } from './services/consulta-validaciones.service';
import { DashboardOperadorService } from './services/dashboard-operador.service';
import { CorreosService } from './services/correos.service';
import { AnalyticsService } from "./services/analytics.service";
//seguimiento de notificaciones
import { MailTrackingService } from './services/mail-tracking.service';

//#endregion
//#region Graficos
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ChartsModule } from 'ng2-charts/ng2-charts'; //No se utiliza
import { ResaltadoDirective } from './directives/resaltado.directive';//No se utiliza
//#endregion
//#region Pipes
import { CapitalizeFirstPipe } from './pipes/capitalize-first.pipe';
import { FormatoMilesDecimalesMoneda } from './pipes/formato-miles-decimales-moneda.pipe'
//#endregion
//#region Plugin
import { HighlightJsModule, HighlightJsService } from "angular2-highlight-js";
import { PdfViewerModule } from "ng2-pdf-viewer";
import { NgxJsonViewerModule } from "ngx-json-viewer";
import { InputFileDirective } from "./directives/input-file.directive";
import { FileValueAccessorDirective } from "./directives/file-value-accessor.directive";
import { FileSaverModule } from "ngx-filesaver";
import { NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { UserIdleModule } from "angular-user-idle"; //Inactividad
import { InputTrimModule } from 'ng2-trim-directive';

//#endregion
//#region Interceptores
import { InterceptorNoTokenServer } from './http-interceptors/interceptor-no-token-server';
import { Constante } from './constantes/constante';
import { EstadoSUNATComponent } from './components/layout/transacciones/estado-sunat/estado-sunat.component';
import { ConsultaComprobantesComponent } from './components/layout/consulta-comprobantes/consulta-comprobantes.component';
import { DialogReprocesoComprobanteComponent } from './components/layout/consulta-comprobantes/dialog-reproceso-comprobante/dialog-reproceso-comprobante.component';

import { NavbarExternoComponent } from './components/shared/navbar-externo/navbar-externo.component';
//Captcha
import { NgxCaptchaModule } from 'ngx-captcha';
import { RecaptchaModule } from 'angular-google-recaptcha';
import { ProfileComponent } from './components/layout/profile/profile.component';
import { CopiarPegarDirective } from './directives/copiar-pegar.directive';
import { LogisticaMapaComponent } from './components/layout/analytics/dashboard-analytics/logistica-mapa/logistica-mapa.component';
import { KpiVentasComponent } from './components/layout/analytics/dashboard-analytics/kpi-ventas/kpi-ventas.component';
import { GraficasSubMenuProductosComponent } from './components/layout/analytics/dashboard-analytics/graficas/graficas-sub-menu-productos/graficas-sub-menu-productos.component';
import { DataNoEncontradaComponent } from './components/layout/analytics/dashboard-analytics/graficas/data-no-encontrada/data-no-encontrada.component';
import { GraficasSubMenuTiendasComponent } from './components/layout/analytics/dashboard-analytics/graficas/graficas-sub-menu-tiendas/graficas-sub-menu-tiendas.component';
import { GraficasSubMenuClientesComponent } from './components/layout/analytics/dashboard-analytics/graficas/graficas-sub-menu-clientes/graficas-sub-menu-clientes.component';

//seguimiento de notificaciones
import { MailTrackingComponent } from './components/shared/dialogs/mail-tracking/mail-tracking.component';
import { CuentaRegresivaComponent } from './components/shared/analytics/confirmacion-analisis-datos-analytics/cuenta-regresiva/cuenta-regresiva.component';
import { ConfiguracionesGeneralesComponent } from './components/layout/configuraciones-generales/configuraciones-generales.component';
import { NotificacionesVeloseComponent } from './components/layout/configuraciones-generales/notificaciones-velose/notificaciones-velose.component';
import { NotificacionesErrorComponent } from './components/layout/configuraciones-generales/notificaciones-velose/notificaciones-error/notificaciones-error.component';
import { snackBarMensajeComponent } from './components/shared/snack-bar/snack-bar-mensaje.component';
import { SnackBarConfigurationSharedComponent } from './components/shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';


import { environment } from '../environments/environment';
import { MailForwardComponent } from './components/shared/dialogs/mail-tracking/mail-forward/mail-forward.component';
import { TipoMonedaSimboloPipe } from './pipes/tipo-moneda-simbolo.pipe';
import { TipoCpeSerieCorrelativoPipe } from './pipes/tipo-cpe-serie-correlativo.pipe';
import { UsuariosComponent } from './components/layout/usuarios/usuarios.component';
import { ListadoUsuariosComponent } from './components/layout/usuarios/listado-usuarios/listado-usuarios.component';
import { DialogAgregarEditarUsuariosComponent } from './components/layout/usuarios/dialog-agregar-editar-usuarios/dialog-agregar-editar-usuarios.component';
import { SharedDialogConfirmacionComponent } from './components/shared/shared-dialog-confirmacion/shared-dialog-confirmacion.component';
import { GenerarCredencialUsuarioComponent } from './components/generar-credencial-usuario/generar-credencial-usuario.component';
import { PadronesComponent } from './components/layout/padrones/padrones.component';
import { FiltrosBusquedaPadronesComponent } from './components/layout/padrones/filtros-busqueda-padrones/filtros-busqueda-padrones.component';
import { ListadoPadronesComponent } from './components/layout/padrones/listado-padrones/listado-padrones.component';
import { DsContribuyentesComponent } from './components/layout/padrones/listado-padrones/datasource/ds-contribuyentes/datasource-contribuyentes.component';
import { DsComprobantesContingenciaComponent } from './components/layout/padrones/listado-padrones/datasource/ds-comprobantes-contingencia/ds-comprobantes-contingencia.component';
import { DsPadronContribuyenteComponent } from './components/layout/padrones/listado-padrones/datasource/ds-padron-contribuyente/ds-padron-contribuyente.component';
import { DsContrbuyenteAsociadoOseOPseComponent } from './components/layout/padrones/listado-padrones/datasource/ds-contrbuyente-asociado-ose-opse/ds-contrbuyente-asociado-ose-opse.component';
import { DsCertificadoEmisorComponent } from './components/layout/padrones/listado-padrones/datasource/ds-certificado-emisor/ds-certificado-emisor.component';
import { DsComprobantesComponent } from './components/layout/padrones/listado-padrones/datasource/ds-comprobantes/ds-comprobantes.component';
import { DsComprobantesFisicosComponent } from './components/layout/padrones/listado-padrones/datasource/ds-comprobantes-fisicos/ds-comprobantes-fisicos.component';
import { SanitizerSecurityImagePipe } from './pipes/sanitizer-security-image.pipe';
import { RolesComponent } from './components/layout/roles/roles.component';
import { ListadoRolesComponent } from './components/layout/roles/listado-roles/listado-roles.component';
import { NuevoModificarRolComponent } from './components/layout/roles/nuevo-modificar-rol/nuevo-modificar-rol.component';
import { TipoComprobantePipe } from './pipes/tipo-comprobante.pipe';
import { PadronesContribuyentesPipe } from './pipes/padrones-contribuyentes.pipe';
import { FechasPadronesPipe } from './pipes/fechas-padrones.pipe';
import { DialogVisualizarPermisosComponent } from './components/layout/roles/dialog-visualizar-permisos/dialog-visualizar-permisos.component';
import { ContribuyentesEstadoPipe } from './pipes/contribuyentes-estado.pipe';
import { ContribuyenteCondicionPipe } from './pipes/contribuyente-condicion.pipe';
import { PadronesContribuyentesAsociadosPipe } from './pipes/padrones-contribuyentes-asociados.pipe';
import { ListadoDescargasBusquedaComponent } from './components/layout/transacciones/listado-descargas-busqueda/listado-descargas-busqueda.component';
import { FiltrosBusquedaListadoDescargaPipe } from './pipes/filtros-busqueda-listado-descarga.pipe';
import { ListadoPadronesSeriePipe } from './pipes/listado-padrones-serie.pipe';
import { ComprobantesEstadoCPEPipe } from "./pipes/comprobantes-estado-cpe.pipe";
import { FormatoPuntosSuspensivosPipe } from './pipes/formato-puntos-suspensivos.pipe';
//#endregion
// Constante de idTCI
// export const IdTci=0;
export const rucTci="20112811096";

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    AuthComponent,
    RegisterComponent,
    DialogDatosTarjetaComponent,
    DashboardComponent,
    HomeComponent,
    ResaltadoDirective,
    TransaccionesComponent,
    CasoNegocioComponent,
    InformacionInicialComponent,
    MensajeFinalCnComponent,
    PlanesComponent, //dialog
    HomologacionComponent,
    CapitalizeFirstPipe, //pipe
    FormatoMilesDecimalesMoneda, //pipe
    HomologacionLineaComponent,
    CambioPasswordComponent,
    PdfViewerComponent,
    ErroresHomologacionComponent,
    InputFileDirective,
    FileValueAccessorDirective,
    MensajeGenericoComponent,
    MenuListItemComponent,
    MiPlanComponent,
    TutorialComponent,
    ConfirmacionCompraComponent,
    RecoverComponent,
    ChangepasswordComponent,
    ConfirmacionProduccionComponent,
    ChatSupportComponent,
    ConfirmacionReenvioComponent,
    ConfirmacionReenvioComponent,
    ErrorPageComponent,
    ConsultaValidacionesComponent,
    DeclaracionComprobanteComponent,
    PopupDetalleErrorComponent,
    PopupCargarImagenComponent,
    DashboardOperadorComponent,
    CredencialesHomologacionComponent,
    ConfiguracionesEmpresAmbienteBetaComponent,
    EstadoSUNATComponent,
    DialogConfirmacionRegistroComponent,
    ConsultaComprobantesComponent,
    DialogReprocesoComprobanteComponent,
    NavbarExternoComponent,
    ProfileComponent,
    DialogReprocesoComprobanteComponent,
    CambioClaveComponent,
    //analytics
    ConfiguracionComponent,
    DialogVisualizarEjemploComponent,
    DashboardAnalyticsComponent,
    ConfirmacionAnalisisDatosanalyticsComponent,
    CopiarPegarDirective,
    LogisticaMapaComponent,
    KpiVentasComponent,
    GraficasSubMenuProductosComponent,
    DataNoEncontradaComponent,
    GraficasSubMenuTiendasComponent,
    GraficasSubMenuClientesComponent,
    MailTrackingComponent,
    CuentaRegresivaComponent,
    //Configuraciones - Notificaciones(Envio de Correo)
    ConfiguracionesGeneralesComponent,
    NotificacionesVeloseComponent,
    NotificacionesErrorComponent,
    snackBarMensajeComponent,
    SnackBarConfigurationSharedComponent,
    MailForwardComponent,
    TipoMonedaSimboloPipe,
    TipoCpeSerieCorrelativoPipe,
    UsuariosComponent,
    ListadoUsuariosComponent,
    DialogAgregarEditarUsuariosComponent,
    SharedDialogConfirmacionComponent,
    GenerarCredencialUsuarioComponent,
    PadronesComponent,
    FiltrosBusquedaPadronesComponent,
    ListadoPadronesComponent,
    DsContribuyentesComponent,
    DsComprobantesContingenciaComponent,
    DsPadronContribuyenteComponent,
    DsContrbuyenteAsociadoOseOPseComponent,
    DsCertificadoEmisorComponent,
    DsComprobantesComponent,
    DsComprobantesFisicosComponent,
    SanitizerSecurityImagePipe,
    RolesComponent,
    ListadoRolesComponent,
    NuevoModificarRolComponent,
    TipoComprobantePipe,
    PadronesContribuyentesPipe,
    FechasPadronesPipe,
    DialogVisualizarPermisosComponent,
    ContribuyentesEstadoPipe,
    ContribuyenteCondicionPipe,
    PadronesContribuyentesAsociadosPipe,
    ListadoDescargasBusquedaComponent,
    FiltrosBusquedaListadoDescargaPipe,
    ListadoPadronesSeriePipe,
    ComprobantesEstadoCPEPipe,
    FormatoPuntosSuspensivosPipe
  ],
  exports:[
    AngularMaterialModule, 
  ],
  entryComponents: [
    SharedDialogConfirmacionComponent,
    DialogAgregarEditarUsuariosComponent,
    DialogDatosTarjetaComponent,
    InformacionInicialComponent,
    MensajeFinalCnComponent,
    PlanesComponent,
    HomologacionLineaComponent,
    PdfViewerComponent,
    ErroresHomologacionComponent,
    MensajeGenericoComponent,
    ConfirmacionCompraComponent,
    ConfirmacionProduccionComponent,
    ConfirmacionReenvioComponent,
    ErrorPageComponent,
    PopupDetalleErrorComponent,
    PopupCargarImagenComponent,
    ConfiguracionesEmpresAmbienteBetaComponent,
    EstadoSUNATComponent,
    DialogConfirmacionRegistroComponent,
    DialogReprocesoComprobanteComponent,
    CambioClaveComponent,
    DialogVisualizarEjemploComponent,
    MailTrackingComponent,
    MailForwardComponent,
    snackBarMensajeComponent,
    DialogVisualizarPermisosComponent
    //SnackBarConfigurationSharedComponent,


  ],
  imports: [
    BrowserModule,
    APP_ROUTING,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,

    //Captcha
    NgxCaptchaModule,
    RecaptchaModule.forRoot({
      siteKey: environment.apikeyGoogleRecaptcha,
    }),
    HttpClientModule,
    FlexLayoutModule,
    ChartsModule,
    NgxChartsModule,
    // MAterial
    HighlightJsModule,
    PdfViewerModule,
    NgxJsonViewerModule,
    SwiperModule,
    FileUploadModule,
    FileSaverModule,
    NgxFileDropModule,
    NgxMaterialTimepickerModule,
    ImageCropperModule,//Para Recortar Imagen
    // UserIdleModule.forRoot({
    //   idle: Constante.idle,
    //   timeout: Constante.out ,
    //   ping: 120
    // }),
    UserIdleModule.forRoot({ idle: 599, timeout: 59, ping: 120 }),
    NgIdleKeepaliveModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyDg-BGSw6k9vPcTLQ6pbMVMYAvXeBI7fE8"
    }),
    AgmJsMarkerClustererModule,
    InputTrimModule
  ],
  providers: [
    DatePipe,
    AuthService,
    AuthGuardService,
    RegisterService,
    PlanesService,
    MenuPrincipalService,
    PsePartnersService,
    RubrosService,
    DatosRucService,
    DashboardService,
    CasosDeNegociosService,
    HomologacionService,
    ReusableService,
    HighlightJsService,
    PagoService,
    TransaccionesService,
    BuscarPdfService,
    MiplanService,
    TokenService,
    ConsultaValidacionesService,
    DashboardOperadorService,
    CorreosService,
    AnalyticsService,
    ReprocesarConsultaComprobantesService,
    MailTrackingService,
    SnackBarConfigurationSharedComponent,
    ListadoUsuariosComponent,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorNoTokenServer,
      multi: true
    },
    { provide: "rucTci", useValue: rucTci },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
