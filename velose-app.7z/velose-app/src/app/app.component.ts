import { Component, EventEmitter, ChangeDetectorRef, OnInit, AfterContentInit, Output } from '@angular/core';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import {Keepalive} from '@ng-idle/keepalive';
import {TokenService} from './services/token.service';
import { Constante } from './constantes/constante';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {

 
  // idleState = "No Started";
  // showIdle = false;
  constructor(
    // private idle: Idle,
    // private keepalive: Keepalive,
    private tokenS: TokenService,
    private router: Router,
    private cd: ChangeDetectorRef,
  ) {}
  ngOnInit() {

  }

  
  // ngOnInit() {
  //   console.log(this.rutasPermitidasActivas())
  //   // sets an idle timeout of 5 seconds, for testing purposes.
  //   this.idle.setIdle(Constante.INACTIVIDAD.timeIdle);
  //   // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
  //   this.idle.setTimeout(Constante.INACTIVIDAD.timeOut);
  //   // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
  //   this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  //   this.idle.onIdleEnd.subscribe(() => {
  //     this.idleState = 'Activo'
  //     setTimeout(this.reset(), 0);
  //   });
  //   this.idle.onTimeout.subscribe(() => {
  //     this.idleState = '';
  //     this.showIdle = false;
  //     // Sacar de sesion
  //     if (this._reusable.getSessionUsuario() != null) {
  //       // Mensaje Dialog Desconectado
  //       let dialogRef;
  //       setTimeout(() =>
  //         dialogRef = this._dialog.open(MensajeGenericoComponent, {
  //           width: '400px',
  //           data: {
  //             icon: "sentiment_very_dissatisfied",
  //             color: "#062a78",
  //             titulo: "Desconectado",
  //             mensaje: `Has sido desconectado del servidor de Velose, debido a tu inactividad prolongada. `
  //           }
  //         })
  //         , 0);
  //     }
  //     this.tokenS.closeSession();


  //   });
  //   this.idle.onIdleStart.subscribe(() => this.idleState = 'Has sido desactivado');
  //   this.idle.onTimeoutWarning.subscribe((countdown) => {
  //     this.idleState = 'Tu sesion expirará en ' + countdown + ' segundos!';
  //     this.showIdle = true;

  //   });

  //   // sets the ping interval to 15 seconds
  //   // this.keepalive.interval(15);

  //   setTimeout(this.reset(), 0);
  //   // this.reset();

  // }

  // reset() {
  //   this.idle.watch();
  //   this.idleState = 'Started.';
  //   this.showIdle=false;
  //   if(this.cd!= null)
  //   if ( this.cd !== null &&
  //           this.cd !== undefined &&
  //           ! ((this.cd as ViewRef).destroyed)){
  //             this.cd.detectChanges();

  //           }
  // }
}