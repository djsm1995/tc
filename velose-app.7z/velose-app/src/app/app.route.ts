import{ RouterModule,Routes} from '@angular/router';
import{ AuthComponent} from './components/auth/auth.component';
import{ AuthGuardService} from './services/auth-guard.service';
import {RecoverComponent} from './components/recover/recover.component';
import {ChangepasswordComponent} from './components/changepassword/changepassword.component';
import {GenerarCredencialUsuarioComponent} from './components/generar-credencial-usuario/generar-credencial-usuario.component';
import {RegisterComponent} from './components/register/register.component';
import { DashboardComponent } from './components/layout/dashboard/dashboard.component';
import { TransaccionesComponent } from './components/layout/transacciones/transacciones.component';
import { CasoNegocioComponent } from './components/layout/caso-negocio/caso-negocio.component';
import { DeclaracionComprobanteComponent } from './components/layout/declaracion-comprobante/declaracion-comprobante.component';
import { HomologacionComponent } from './components/layout/homologacion/homologacion.component';
import {MiPlanComponent} from './components/layout/mi-plan/mi-plan.component';
import {HomeComponent} from './components/home/home.component';
import {CambioPasswordComponent} from './components/shared/cambio-password/cambio-password.component';
// import { AnalyticsComponent } from './components/analytics/analytics.component';
import { DashboardAnalyticsComponent } from './components/layout/analytics/dashboard-analytics/dashboard-analytics.component';
import { ConfiguracionComponent } from './components/layout/analytics/configuracion/configuracion.component';
import { DashboardOperadorComponent } from './components/layout/dashboard-operador/dashboard-operador.component';
import { CredencialesHomologacionComponent } from './components/layout/configuracion/credenciales-homologacion/credenciales-homologacion.component';
import {ErrorPageComponent} from './components/shared/error-page/error-page.component';
import {ConsultaComprobantesComponent} from './components/layout/consulta-comprobantes/consulta-comprobantes.component';
import {ProfileComponent} from './components/layout/profile/profile.component';
import {ConfiguracionesGeneralesComponent} from './components/layout/configuraciones-generales/configuraciones-generales.component';
import {UsuariosComponent} from './components/layout/usuarios/usuarios.component';
import { Component } from '@angular/core';
import { PadronesComponent } from './components/layout/padrones/padrones.component';
import { RolesComponent } from './components/layout/roles/roles.component';
import { NuevoModificarRolComponent } from './components/layout/roles/nuevo-modificar-rol/nuevo-modificar-rol.component';
import { ListadoDescargasBusquedaComponent } from './components/layout/transacciones/listado-descargas-busqueda/listado-descargas-busqueda.component';

const APP_ROUTES: Routes = [
  // No mover home de posicion 0
  {
    path: "home",
    component: HomeComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: "dashboard",
        canActivate: [AuthGuardService],
        component: DashboardComponent,
        data: {  identificador: "dashboard" }
      },
      {
        path: "transacciones",
        canActivate: [AuthGuardService],
        component: TransaccionesComponent,
        data: { identificador: "comprobantes" }
      },
      {
        path: "descargaBusquedaComprobantes", 
        canActivate: [AuthGuardService],
        component: ListadoDescargasBusquedaComponent,
        data: { identificador: "comprobantes" },
      },
      {
        path: "casoNegocio",
        canActivate: [AuthGuardService],
        component: CasoNegocioComponent,
        data: { identificador: "plataformaPruebas.casoNegociosDFGDFGDFG" }
      },
      {
        path: "homologacion",
        canActivate: [AuthGuardService],
        component: HomologacionComponent,
        data: {identificador: "plataformaPruebas.ambienteBeta"}
      },
      {
        path: "miPlan",
        canActivate: [AuthGuardService],
        component: MiPlanComponent,
        data: { identificador: "miPlan"}
      },
      {
        path: "analytics",
        canActivate: [AuthGuardService],
        component: DashboardAnalyticsComponent,
        data: { identificador: "analytics.charts" }
      },
      {
        path: "configuracionAnalytics",
        canActivate: [AuthGuardService],
        component: ConfiguracionComponent,
        data: { identificador: "analytics.configuracion" }
      },
      {
        path: "consultaComprobantes",
        canActivate: [AuthGuardService],
        component: ConsultaComprobantesComponent,
        data: { identificador: "soporte.comprobantes" } 
      },
      {
        path: "padrones",
        canActivate: [AuthGuardService],
        component: PadronesComponent,
        data: { identificador: "soporte.listadoPadrones" } 
      },
      {
        path: "profile", 
        canActivate: [AuthGuardService],
        component: ProfileComponent,
        data: { identificador: "perfil"}
      },
      {
        path: "configuracionesGenerales",
        canActivate: [AuthGuardService],
        component: ConfiguracionesGeneralesComponent,
        data: { identificador: "configuraciones" } 
      },

      // {
      //   path: "credencialesHomologacion",
      //   canActivate: [AuthGuardService],
      //   component: CredencialesHomologacionComponent,
      //   data: { identificador: "MOD_SOP" }
      // },
      // {
      //   path: "dashboardOperador",
      //   canActivate: [AuthGuardService],
      //   component: DashboardOperadorComponent,
      //   data: { identificador: "MOD_SOP" }
      // }, 
      {
        path: "usuario", 
        canActivate: [AuthGuardService],
        component: UsuariosComponent,
        data: { identificador: "usuarios" }
      },
      {
        path: "roles", 
        canActivate: [AuthGuardService],
        component: RolesComponent,
        data: { identificador: "roles" }
      },
      {
        path: "editarRoles", 
        canActivate: [AuthGuardService],
        component: NuevoModificarRolComponent,
        data: { identificador: "roles" },
      },
      {
        path: "crearRoles", 
        canActivate: [AuthGuardService],
        component: NuevoModificarRolComponent,
        data: { identificador: "roles" },
      },

      // Se debe rederigir 
      // {
      //   path: "**",
      //   pathMatch: "full",
      //   redirectTo: "dashboard",
      //   data: { identificador: "dashboard" } //for while
      // }
      {
        path: "**",
        pathMatch: "full",
        redirectTo: "/404",
        data: { identificador: "404" } //for while
      }

    ]
  },
  { path: "login", component: AuthComponent },
  { path: "recover", component: RecoverComponent },
  { path: "changepassword/:token", component: ChangepasswordComponent },
  { path: "crearCredencial/:token", component: GenerarCredencialUsuarioComponent },
  { path: "register", component: RegisterComponent },
  { path: "404", component: ErrorPageComponent },
  { path: "cambioPassword", component: CambioPasswordComponent },
  { path: "", component: AuthComponent },
  { path: "**", pathMatch: "full", redirectTo: "/404" }
  
];

export const APP_ROUTING = RouterModule.forRoot(APP_ROUTES);//,{useHash:true}

export const ROUTES = APP_ROUTES