import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'contribuyenteCondicion'
})
export class ContribuyenteCondicionPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if(value==0){return "Habido"}
    else return "No habido"
  }


}
