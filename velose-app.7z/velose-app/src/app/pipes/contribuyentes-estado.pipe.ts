import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'contribuyentesEstado'
})
export class ContribuyentesEstadoPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if(value==0){return "Activo"}
    else return "No activo"
  }

}
