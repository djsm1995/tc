import { Pipe, PipeTransform, isDevMode } from '@angular/core';
import { TitleCasePipe } from '@angular/common';

@Pipe({
  name: 'formatoPuntosSuspensivos'
})
export class FormatoPuntosSuspensivosPipe implements PipeTransform {
  
  // constructor(private titleCase:TitleCasePipe ){}

  transform(value: any,arg1?): any {
    let longitudMaxima = (arg1 == null || arg1== undefined )?value.length:arg1
    let result
    result= (value.length>longitudMaxima)?`${value.substring(0,longitudMaxima)}...`:value
    
    if(isDevMode()){console.log(result)}
    let titleCase2:TitleCasePipe= new TitleCasePipe()


    return titleCase2.transform(result);

  }

}
