import { Pipe, PipeTransform, isDevMode } from '@angular/core';
import { CMostrarFiltrosBusqueda, IMostrarFiltrosBusqueda } from '../services/descarga-busqueda-cpes.service';
import { IRequestBusquedaComprobantes, TransaccionesService } from '../services/transacciones.service';
import { Catalogo, Cpe } from '../constantes/catalogo';
import { ReusableService } from '../services/reusable.service';
import { DatePipe } from '@angular/common';


@Pipe({
  name: 'filtrosBusquedaListadoDescarga'
})
export class FiltrosBusquedaListadoDescargaPipe implements PipeTransform {

  // filtrosBusqueda:IMostrarFiltrosBusqueda= new CMostrarFiltrosBusqueda().data
  constructor(private _transaccionesService: TransaccionesService,
    private _reusableService: ReusableService) {}

  transform(value: IRequestBusquedaComprobantes, ...args: any[]): any {
    if(value===null || value==undefined) return "-"
    return this.mostrarFiltrosBusqueda(value);
  }

  mostrarFiltrosBusqueda(filtrosBusqueda:IRequestBusquedaComprobantes):string{
    let nuevosFiltrosBusq : IMostrarFiltrosBusqueda= new CMostrarFiltrosBusqueda().data
    nuevosFiltrosBusq.tipoCpe= this.generarTextoTipo(filtrosBusqueda)
    nuevosFiltrosBusq.serie= this.generarTextoSerie(filtrosBusqueda)
    nuevosFiltrosBusq.correlativo= this.generarTextoCorrelativo(filtrosBusqueda)
    nuevosFiltrosBusq.estadoVelose= this.generarTextoEstadoVelose(filtrosBusqueda)
    nuevosFiltrosBusq.estadoSunat= this.generarTextoEstadoSunat(filtrosBusqueda.estadoSunat)
    nuevosFiltrosBusq.fechaInicio= this.generarTextoFecha(filtrosBusqueda.fechaInicio) 
    nuevosFiltrosBusq.fechaFin= this.generarTextoFecha(filtrosBusqueda.fechaFin) 
    
    let texto:string="";
    if(nuevosFiltrosBusq.tipoCpe!=""){
      texto = `Tipo Cpe: ${nuevosFiltrosBusq.tipoCpe} ,`;
    }
    if(nuevosFiltrosBusq.serie!=""){
      texto = `${texto} Serie: ${nuevosFiltrosBusq.serie} ,`;
    }
    if(nuevosFiltrosBusq.correlativo!=""){
      texto = `${texto} Correlativo: ${nuevosFiltrosBusq.correlativo} ,`;
    }
    // document.write("<p>" + nuevosFiltrosBusq.estadoVelose.bold() + "</p>");
    return `${texto} Estado VelOSE: ${nuevosFiltrosBusq.estadoVelose}, Estado Sunat: ${nuevosFiltrosBusq.estadoSunat}, 
            Fecha Inicio: ${nuevosFiltrosBusq.fechaInicio}, Fecha Fin: ${nuevosFiltrosBusq.fechaFin}`;
    
    
  }

  generarTextoFecha(fecha):string{
    if(fecha==undefined || fecha==null){
      return "No se puede parsear filtro"
    }
    else{
      let datePipe= new DatePipe('en-US').transform(fecha,'d/MM/yyyy, h:mm:ss a')
      return datePipe
    }
  }
  generarTextoTipo(filtrosBusqueda:IRequestBusquedaComprobantes):string{
    if(filtrosBusqueda.tipo == undefined)
      // return "No se encontro filtro"
      return ""

    if(filtrosBusqueda.tipo == null)
      return "Todos"

    let cpes:Cpe= Catalogo.CPES.find(function(element:Cpe){
      return element.codigo == filtrosBusqueda.tipo
    })

    return (cpes==undefined)?"No se pudo parsear filtro":cpes.nombre

  }

  generarTextoSerie(filtrosBusqueda:IRequestBusquedaComprobantes):string{
    if(filtrosBusqueda.tipo == undefined)
      // return "No se encontro filtro"
      return ""

    if(filtrosBusqueda.tipo == null)
      return "-"

    let cpesResumenes:Cpe[]= Catalogo.CPES.filter((cpe)=>{return cpe.esResumen})
    let tipoEsResumen=cpesResumenes.find(function(element:Cpe){
      return element.codigo == filtrosBusqueda.tipo
    })

    if(tipoEsResumen==undefined)
      return (filtrosBusqueda.serie==null)?"-":filtrosBusqueda.serie

    return (filtrosBusqueda.fecha==null)?"-":filtrosBusqueda.fecha
  }

  generarTextoCorrelativo(filtrosBusqueda:IRequestBusquedaComprobantes):string{
    if(filtrosBusqueda.tipo == undefined)
      // return "No se encontro filtro"
      return ""

    if(filtrosBusqueda.tipo == null || filtrosBusqueda.numero==null)
      //return "-"
      return ""

    return String(filtrosBusqueda.numero);

  }


  generarTextoEstadoVelose(filtrosBusqueda:IRequestBusquedaComprobantes):string{
    let texto:string
    if (filtrosBusqueda.estadoDoc==null)
      return "Todos"

    switch (filtrosBusqueda.estadoDoc) {
      case -1:
        texto="Excepciones"
        break;
      case 2:
        if(filtrosBusqueda.estadoAceptadoObs==null && filtrosBusqueda.estadoAnulado==null && filtrosBusqueda.estadoReversa==null) texto="Aceptado"
        if(filtrosBusqueda.estadoAceptadoObs==1) texto="Aceptado con observaciones"
        if(filtrosBusqueda.estadoAnulado==1) texto="Anulado"
        if(filtrosBusqueda.estadoReversa==1) texto="Reversado"
        break;
      default:
        texto="-"
        break;
    }

    return texto;

  }

  generarTextoEstadoSunat(estadoSunat:string):string{

    if(estadoSunat==null)
      return "Todos"

    // let primerEstadoSunat=estadoSunat[0]
    let filtrosSunat= this._transaccionesService.getFiltrosEstadoSunat()

    // if(primerEstadoSunat=="-3")
    //   return "Excepción"

    let textoEstadosunat:any = filtrosSunat.find(element => {
      return element.codigo == estadoSunat
    });

    return (textoEstadosunat==undefined)?"-": textoEstadosunat.descripcion
  }

}
