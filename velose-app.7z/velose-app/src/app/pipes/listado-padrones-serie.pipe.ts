import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'listadoPadronesSerie'
})
export class ListadoPadronesSeriePipe implements PipeTransform {
  transform(value: any, ...args: any[]): any {
    var my_string = '' + value;
    while (my_string.length < 4) {
        my_string = '0' + my_string;
    }

    return my_string;
  }

}
