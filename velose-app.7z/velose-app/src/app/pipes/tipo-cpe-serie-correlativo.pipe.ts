import { Pipe, PipeTransform } from '@angular/core';
import { ReusableService } from '../services/reusable.service';

@Pipe({
  name: 'tipoCpeSerieCorrelativo'
})
export class TipoCpeSerieCorrelativoPipe implements PipeTransform {
  // transform(value: any, args?: any): any {
  constructor(public _reusableService: ReusableService) {}
  
  transform(value: any): any {
    if(value===null) return value
    return this.verMasComprobante(value);
    
  }

  verMasComprobante(data:any) {
    let serie = data.serie;
    let fecha = data.fecha;
    let numero = data.numero;
    let serieCorrelativo = serie != null ? `${serie}-${numero}` : `${fecha}-${numero}`;
    let rpta = {
      cpe: this._reusableService.getComprobanteByCodigo(data.tipo),
      serieCorrelativo: serieCorrelativo,
      estado: this._reusableService.getEstadoRespuestaSolicitud(data.estadoCpe),
    };
    return rpta;
  }

}
