import { Pipe, PipeTransform, isDevMode } from '@angular/core';
import { Catalogo, Moneda } from '../constantes/catalogo';

@Pipe({
  name: 'tipoMonedaSimbolo',
})
export class TipoMonedaSimboloPipe implements PipeTransform {
  // transform(value: any, args?: any): any {
    descripcion: string=""
    simbolo: string=""

  transform(value: string, args: any): any {
    if(value===null) return this.descripcion
    return this.getMonedaByCodigo(value,args);
  }

  getMonedaByCodigo(codigo:string,args) {
    
    let monedas: Moneda[];
    monedas = Catalogo.MONEDAS;

    if (codigo != null) {
      for (var i = 0; i < monedas.length; i++) {
        if (monedas[i].codMoneda == codigo) {
          this.descripcion = monedas[i].descripcion;
          this.simbolo = monedas[i].simbolo;

          return this.mostrarData(args);
        }
      }
    }
    return this.simbolo;
  }

  mostrarData(args){
    let rpta:string
    switch (args) {
      case 'descripcion':
        rpta=this.descripcion
        break;
      case 'simbolo':
        rpta=this.simbolo
        break;
      default:
        break;
    }
    return rpta
  }
}
