import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tipoComprobante'
})
export class TipoComprobantePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if (value === null) return 'Unknown';
    value = value.toString().replace(/^0+/, '');
    switch (value) {
      case '1':
        return "Factura";
      case '3':
        return "Boleta de venta";
      case '7':
        return "Nota de crédito";
      case '8':
        return "Nota de débito";
      case '9':
        return "Guía de remisión remitente";
      case '20':
        return "Comprobante de retención";
      case '40':
        return "Comprobante de percepción";
      case 'RC':
      case '202':
        return "Resumen diario Boletas";
      case 'RA':
      case '207':
        return "Comunicado de baja";
      case 'RR':
      case '205':
        return "Reversión";
      default:
        return "-";
    }
  }

}
