import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'padronesContribuyentes'
})
export class PadronesContribuyentesPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
   let pipeMessage:string="";
    
    if (value === null) return 'Unknown';
    switch(value){
      case 1:
        pipeMessage= "Agente de percepción de ventas internas";
        break;
      case 2:
          pipeMessage= "Agente de percepción de combustibles";
          break;
      case 3:
          pipeMessage= "Agente de retención";
          break;
      case 4:
          pipeMessage= "Exceptuada de la percepción";
          break;
      case 5:
          pipeMessage= "Exportador de Servicios";
          break;
      case 10:
          pipeMessage= "Buen contribuyente";
          break;
      case 11:
          pipeMessage=  "Autorizado a versión UBL 2.0";
          break;
      case 12:
          pipeMessage= "Obligado a enviar código de producto";
          break;
      case 13:
          pipeMessage= "Afiliados al SEE-Empresas supervisadas";
          break;    
      default:
          pipeMessage= value;
          break;
    }
    return `${value}: ${pipeMessage}`;
  }

}
