import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'FormatoMilesDecimalesMoneda'
})
export class FormatoMilesDecimalesMoneda implements PipeTransform {

  transform(value: any,arg1?): any {
    // arg1:Moneda Simbolo
    if(value===null) return value
    
    return (arg1)?
      `${arg1} ${this.formatNumber(this.Redondeo2Decimales(value))}`:
      `${this.formatNumber(this.Redondeo2Decimales(value))}`

  }


  formatNumber(num) {
    let separadorMiles = ",";
    let separadorDecimales = ".";
    num +='';
     var splitStr = num.split('.');
     var splitLeft = splitStr[0];
     var splitRight = splitStr.length > 1 ? splitStr[1] : '00';
     var regx = /(\d+)(\d{3})/;
     while (regx.test(splitLeft)) {
       splitLeft = splitLeft.replace(regx, '$1' + separadorMiles + '$2');
    }
    return splitLeft + '.' + splitRight;
  }

  Redondeo2Decimales(value) {
    return parseFloat(value).toFixed(2);
  }

}
