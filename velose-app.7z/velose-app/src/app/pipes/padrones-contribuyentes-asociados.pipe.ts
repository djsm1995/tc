import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'padronesContribuyentesAsociados'
})
export class PadronesContribuyentesAsociadosPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if(value==1){return "PSE"}
    else if(value==2){return "OSE"}
  }

}
