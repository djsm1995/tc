import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fechasPadrones'
})
export class FechasPadronesPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    
    let result:any;

    let fechaAlta:Date;
    let fechaBaja: Date;
    fechaAlta=args[0];
    fechaBaja=value;

    if(fechaAlta<fechaBaja){
      result = fechaAlta;
    }else{
      result="-"
    }
    //console.log(fechaAlta)
    return result;
  }

}
