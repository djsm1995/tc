import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "comprobantesEstadoCPE"
})
export class ComprobantesEstadoCPEPipe implements PipeTransform {
  transform(value: any, ...args: any[]): any {
    let pipeMessage: string = "";

    switch (value) {
      case 0:
        pipeMessage = "Rechazado";
        break;
      case 1:
        pipeMessage = "Aceptado";
        break;
      case 2:
        pipeMessage = "Anulado";
        break;
    }
    return pipeMessage;
  }
}
