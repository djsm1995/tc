import { Directive,ElementRef,Input,HostListener, isDevMode } from '@angular/core';

@Directive({
  selector: '[appResaltado]'
})
export class ResaltadoDirective {


  constructor(private el:ElementRef) {
    if(isDevMode()) {console.log("resaltado directive")}
   }

   // Obtenemos parametro que envian junto a la directiva
   @Input ("appResaltado") nuevoColor:string;

  @HostListener('mouseenter') mouseEntro(){
    this.resaltar(this.nuevoColor || "red");
  }

  @HostListener('mouseleave') mouseSalio(){
    this.resaltar(null);
  }

  private resaltar (color:string){
    this.el.nativeElement.style.backgroundColor=color;
  }

}
