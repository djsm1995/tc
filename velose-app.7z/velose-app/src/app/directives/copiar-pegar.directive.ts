import { Directive, Output, EventEmitter, HostListener, isDevMode } from '@angular/core';

@Directive({
  selector: '[copiarPegar]'
})
export class CopiarPegarDirective {

  @Output() copiar = new EventEmitter();
  @Output() pegar = new EventEmitter();

  constructor() { }

  @HostListener('keydown.control.v') 
    onCtrlV(e:ClipboardEvent) {
      this.prevenirCopiaPegar(e)
    }

  @HostListener("paste", ["$event"])
    onPaste(e:ClipboardEvent) { //obtiene y valida data de clipboard
      this.prevenirCopiaPegar(e)
    }

  @HostListener('keydown.control.c') 
    onCtrlC(e:ClipboardEvent) {
      this.prevenirCopiaPegar(e)
    }

  @HostListener("copy", ["$event"])
    onCopy(e?) { //obtiene y valida data de clipboard
      this.prevenirCopiaPegar(e)
    }



  // Emitir
  prevenirCopiaPegar(e:ClipboardEvent){
    if(isDevMode()) {console.log("prevenir")}
    if(e!=undefined){
      e.preventDefault();
    }
  }
}
