
import {catchError} from 'rxjs/operators/catchError';
import { Injectable } from '@angular/core';
import {ReusableService} from './reusable.service';
import {Constante} from '../constantes/constante';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class BuscarPdfService {

  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService,

  ) { }

  buscarPdf(id,version){
    return this._httpClient.post(`${environment.endpointVelose}/homologacion/buscarPDF`,
      {parametro1:id,parametro2:version}
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

}
