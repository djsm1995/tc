import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';


@Injectable()
export class RubrosService {
  rubros: Rubros[] =[]
  constructor(private _httpClient:HttpClient) { }

  getRubros(filtro){
    return this._httpClient.post<RubrosResponse>(`${environment.endpointVelose}/user/rubros`,
      {"parametro1": filtro});
  }
}

export class RubrosC{
  codigo:string;
  descripcion:string;
  constructor(){
    this.codigo="";
    this.descripcion="";
  }
}
export interface Rubros{
  codigo:string;
  descripcion:string;
}
export interface RubrosResponse{
  estado:boolean;
  mensaje:string;
  rubros:Rubros[];
}
