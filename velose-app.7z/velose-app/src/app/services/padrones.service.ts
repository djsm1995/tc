import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { catchError } from 'rxjs/operators/catchError';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PadronesService {
  private listadoPadrones:IOpcionListadoPadrones[]=[
    {
      codigo:1,
      descripcion:"Contribuyentes"
    },
    {
      codigo:2,
      descripcion:"Padrón contribuyente"
    },
    {
      codigo:3,
      descripcion:"Contribuyente asociado a un OSE o PSE"
    },
    {
      codigo:4,
      descripcion:"Certificado Emisor"
    },
    {
      codigo:5,
      descripcion:"Comprobantes"
    },
    {
      codigo:6,
      descripcion:"Comprobantes físicos"
    },
    {
      codigo:7,
      descripcion:"Comprobantes de contingencia"
    }
  ]
  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService
  ) { }

  getOpcionesListadoPadrones():IOpcionListadoPadrones[]{
    return this.listadoPadrones;
  }

  countBusquedaPadrones(filtrosBusqueda:IRequestListadoPadrones){
    return this._httpClient.post(
      `${environment.endpointVelose}/supportquery/count`,filtrosBusqueda)
    .pipe(catchError((error:any) =>  { 
      return this._reusableService.getCatch(error) }));
  }

  listadoBusquedaPadrones(filtrosBusqueda:IRequestListadoPadrones){
    return this._httpClient.post(
      `${environment.endpointVelose}/supportquery/listEntries`,filtrosBusqueda)
    .pipe(catchError((error:any) =>  { 
      return this._reusableService.getCatch(error) }));
  }

}

export interface IOpcionListadoPadrones{
  codigo:number; 
  descripcion:string;
}

export interface IRequestListadoPadrones{
  type:number,
  num:number,//maxResults
  page:number,
  searchParam:{
    ruc?:string,
    nomCpe?:string[],
    serie?:number,
    tipoCpe?:number
  }
}

export class CRequestListadoPadrones{
  base:IRequestListadoPadrones;
  
  constructor(){
    this.base={
      type:1,
      num:10,
      page:1,
      searchParam:null
    }
  }
}

export interface IDataListadoPadrones{
  countResultados:number,
  dataFiltros:IRequestListadoPadrones,
}
