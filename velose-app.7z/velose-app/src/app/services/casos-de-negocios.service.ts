
import {catchError} from 'rxjs/operators/catchError';
import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import {ReusableService} from './reusable.service';

@Injectable()
export class CasosDeNegociosService {

  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService,
              ) { }

  getListaCasosNegocio(idPse){
    return this._httpClient.post(`${environment.endpointVelose}/homologacion/listaCasoNegocios/`,
      {"parametro1" : idPse}
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }
  guardarCNSeleccionados(idPse,CN){
    return this._httpClient.post(`${environment.endpointVelose}/homologacion/registrarOpcionesCN/`,
      {
        "idPse" : idPse,
        "listaCasoNegocios":CN
      }).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

}

// Interfaces
  export interface casoNegocio{
    id:number;
    nombre:string;
    lstOperacion:tipoOperacion[];
  }
  export interface tipoOperacion{
    id:number;
    nombre:string;
    seleccionado:boolean;
    lstAfectacion:tipoAfectacion[];
  }
  export interface tipoAfectacion{
    id:number;
    nombre:string;
    seleccionado:boolean;
    casoNegocio?:caso[];
  }
  export interface caso{
    id:number;
    nombreCA:string;
    detalleCaso:string;
  }
  export interface responseCasoNegocio{
    estado:boolean;
    mensaje:string;
    listaCasoNegocios:casoNegocio[];
  }
