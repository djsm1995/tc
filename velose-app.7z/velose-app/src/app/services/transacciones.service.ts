
import { Injectable, isDevMode } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { catchError } from 'rxjs/operators/catchError';

import { ReusableService} from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable()
export class TransaccionesService {

  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService) { }

  getFiltrosFechas(){
    let filtros=[
      {
        descripcion:"Último día",
        codigo:1,
        selected:true
      },
      {
        descripcion:"Última semana",
        codigo:2,
        selected:false
      },
      {
        descripcion:"Último mes",
        codigo:3,
        selected:false
      },
      {
        descripcion:"Entre estas fechas",
        codigo:4,
        selected:false
      }
    ]
    return filtros;
  }
  getFiltrosEstadoSunat(){
    let filtros=[
      {
        descripcion:"Todos",
        codigo:"00"
      },
      {
        descripcion:"Excepción",
        codigo:"-1"
      },
      {
        descripcion:"En proceso",
        codigo:"0"
      },
      {
        descripcion:"Aceptado",
        codigo:"2"
      }
    ]
    return filtros;
  }
  getFiltrosEstadoValidacionesOSE(){
    let filtros=[
      {
        descripcion:"Todos",
        codigo:"00",
        disabled:false,
      },
      {
        descripcion:"Excepciones",
        codigo:"-1",
        disabled:false,
      },
      {
        descripcion:"Aceptado",
        codigo:"2",
        disabled:false,
      },
      {
        descripcion:"Aceptado con observaciones",
        codigo:"2-1",
        disabled:false,
      },
      {
        descripcion:"Anulado",
        codigo:"2-2",
        disabled:false,
      },
      {
        descripcion:"Reversado",
        codigo:"2-3",
        disabled:false,
      },
    ]
    return filtros;
  }



  countSolicitudes(datosContarSolicitud){
    return this._httpClient.post(`${environment.endpointVelose}/solicitud/contar-2`,
    datosContarSolicitud).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getData(dataBuscar) {
    // return this._httpClient.post(`${environment.endpointVelose}/solicitud/buscar`,
    return this._httpClient.post(
      // (isDevMode())?
      // "https://1edf189b-2d7c-49d7-a5d9-4ee55ec13a64.mock.pstmn.io/solicitud/buscar":
      `${environment.endpointVelose}/solicitud/buscar-2`,
      dataBuscar).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  buscarSolicitudes(datosContarSolicitud){
    return this._httpClient.post(`${environment.endpointVelose}/solicitud/buscarSolicitud`,
    datosContarSolicitud).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getCdr(idTrace:number, fecEmision:Date){
    return this._httpClient.post(
      `${environment.endpointVelose}/comprobante/buscarCdr`,
      {
        idTrace:idTrace,
        fechaEmision:fecEmision,
      }
    ).pipe(
    catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getXML(idTrace:number, fecEmision:Date){
    return this._httpClient.post(
      `${environment.endpointVelose}/comprobante/buscarXml`,
      {
        idTrace:idTrace,
        fechaEmision:fecEmision,
      }
    ).pipe(
    catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getEstadoSunat(idTrace) {
    return this._httpClient.post(
      `${environment.endpointVelose}/declaracion/obtenerEstadoSunatComprobante`,
      { idComprobante: idTrace }
    ).pipe(
      catchError((error: any) => { return this._reusableService.getCatch(error) }));
  }

  /********* Permisos *********** */
 obtenerPermisos(buscar:string){
  let arrayAcciones = [];
  const acciones =  this._reusableService.getSessionUsuario().acciones;
  for (var i = 0; i < acciones.length; i++) {
      //if(acciones[i] === nombreModulo){
       if(acciones[i].split('.')[0] === buscar){
        arrayAcciones.push(acciones[i]);
      }
      
    }
  return arrayAcciones;
}

}

export interface IRequestBusquedaComprobantes{
  idTrace?: string,
  pseUsuario?: number,
  codigoMoneda?: string,
  estadoCpe?:number,
  estadoAceptadoObs?: number,
  estadoSunat: string,
  estadoAnulado?: number,
  estadoReversa?: number,
  nomCPE: string,
  ruc: number,
  tipo:string,
  fecha: string,
  serie: string,
  numero: number,
  tipoFecha: number,
  fechaInicio: Date,
  fechaFin: Date,
  maxResults:number,
  page: number,
  estadoDoc:number,
  tipoRol?:number
}

export interface IRequestBusquedaComprobantes2{
  resultados: number,
  pagina:number,
  paginar:boolean,
  filtro:{
    nombreCpe: string,
    ruc: string,
    serie: string,
    correlativo: string,
    estadoVelose: string, //se controlara en el backEnd
    estadoSunat: string, //se controlara en el backEnd
    tipoComprobante: string, //se controlara en el backEnd
    fechaInicio: string,
    fechaFin: string,
    tipoRol:number,
  }

}
export class RequestBusquedaComprobantes{
  resultados: number
  pagina:number
  paginar:boolean
  filtro:{
    nombreCpe: string
    ruc: string
    serie: string
    correlativo: string
    estadoVelose: string //se controlara en el backEnd
    estadoSunat: string //se controlara en el backEnd
    tipoComprobante: string //se controlara en el backEnd
    fechaInicio: string
    fechaFin: string
    tipoRol:number
  }


  constructor(){
    this.resultados = null
    this.pagina = null
    this.filtro={
      nombreCpe: null,
      ruc: null,
      serie: null,
      correlativo : null,
      estadoVelose : "00",
      estadoSunat : "00",
      tipoComprobante : "00",
      fechaInicio : null,
      fechaFin : null,
      tipoRol : null
    }

  }
}

export class CRequestBusquedaComprobantes{
  idTrace: string
  pseUsuario: number
  codigoMoneda: string
  estadoCpe:number
  estadoAceptadoObs: number
  estadoSunat: string
  estadoAnulado: number
  estadoReversa: number
  nomCPE: string
  ruc: number
  tipo:string
  fecha: string
  serie: string
  numero: number
  tipoFecha: number
  fechaInicio: Date
  fechaFin: Date
  maxResults:number
  page: number
  estadoDoc:number
  idRol:number

  constructor(){
    this.idTrace=null
    this.pseUsuario=null
    this.codigoMoneda=null
    this.estadoCpe=null
    this.estadoAceptadoObs=null
    this.estadoSunat=null
    this.estadoAnulado=null
    this.estadoReversa=null
    this.nomCPE=null
    this.ruc=null
    this.tipo=null
    this.fecha=null
    this.serie=null
    this.numero=null
    this.tipoFecha=null
    this.fechaInicio=null
    this.fechaFin=null
    this.maxResults=null
    this.page=null
    this.estadoDoc=null
    this.idRol=null
  }
}

/*Permisos*/
export class permisosComprobanteUsuario{
  //comprobantes:string='comprobantes'
  comprobantes_notificaciones:string='comprobantes.notificaciones'
}
export class permisosComprobanteUsuarioClass{
  //comprobantes:boolean=false
  comprobantes_notificaciones:boolean=false
}
export class permisosComprobanteSoporte{
  //soporte:string='soporte'
  soporte_comprobantes:string='soporte.comprobantes'
  soporte_listadoPadrones:string='soporte.listadoPadrones'
}
export class permisosComprobanteSoporteClass{
  //soporte:boolean=false
  soporte_comprobantes:boolean=false
  soporte_listadoPadrones:boolean=false
}
