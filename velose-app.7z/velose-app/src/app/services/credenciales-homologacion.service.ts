import { Injectable } from "@angular/core";

import { HttpClient } from "@angular/common/http";
import { ReusableService } from "./reusable.service";
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: "root"
})
export class CredencialesHomologacionService {
  constructor(private _httpClient: HttpClient, private _reusableService: ReusableService) {}

  generarCredenciales(request) {
    return this._httpClient
      .post(`${environment.endpointVelose}/homologacion/generarClave`, request)
      .pipe();

  }
}
export class requestBusqueda {
  ruc: string;
  flagConfirmacion: boolean;
  constructor() {
    this.ruc = null;
    this.flagConfirmacion = false;
  }
}
export interface responseCrearCredencial {
  estado: boolean;
  mensaje: string;
  flagConfirmacion: boolean;
}
