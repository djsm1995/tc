import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {ReusableService} from './reusable.service';
import { environment } from '../../environments/environment';


@Injectable()
export class AnalyticsService {


  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService) { }


  // #region menus dashboard Analytics

  getIndicadoresSubmenu(permisoCliente:boolean,permisoProducto:boolean,permisoTienda:boolean):any []{
    let submenu = [];
    if(permisoCliente){
      submenu.push({
          name: "Clientes",
          description: "",
          icon: "supervisor_account",
          value: 1
          // icon: 'people'
        });
    }
    if(permisoProducto){
      submenu.push({
        name: "Productos",
        description: "Top 5 productos de mayor ventas",
        icon: "category",
        value: 2
      });
    }
    if(permisoTienda){
      submenu.push({
        name: "Tiendas",
        description: "Top 5: Tiendas de mayor Ventas",
        icon: "business",
        value: 3
      });
    }
    return submenu
  }

  getMenuPeriodos(permisoHoy:boolean, permisoSemana:boolean, permiso15Dias:boolean, permisoUltimoMes:boolean):any []{
    let menu = [];
    // let menu=[
    //   { option: 1, label: "Hoy" },
    //   { option: 2, label: "Última Semana" },
    //   { option: 3, label: "Últimos 15 días" },
    //   { option: 4, label: "Último mes" }
    // ]
    if(permisoHoy){
      menu.push({ option: 1, label: "Hoy" });
    }
    if(permisoSemana){
      menu.push({ option: 2, label: "Última Semana" });
    }
    if(permiso15Dias){
      menu.push({ option: 3, label: "Últimos 15 días" });
    }
    if(permisoUltimoMes){
      menu.push({ option: 4, label: "Último mes" });
    }
    return menu;
  }

  getMenuTop(permisoTop5:boolean, permisoTop10:boolean, permisoTop20:boolean):number []{
    let menu=[];
    if(permisoTop5){
      menu.push(5);
    }
    if(permisoTop10){
      menu.push(10);
    }
    if(permisoTop20){
      menu.push(20);
    }

    return menu;
  }
  getMenuMonedas(permisoSoles:boolean, permisoDolares:boolean):any []{
    // let menuMonedas=[
    //   { siglas: "PEN", simbolo: "S/" },
    //   { siglas: "USD", simbolo: "$" },
    // ]
    let menuMonedas=[];
    if(permisoSoles){
      menuMonedas.push({siglas: "PEN", simbolo: "S/" });
    }
    if(permisoDolares){
      menuMonedas.push({siglas: "USD", simbolo: "$" });
    }

    return menuMonedas;
  }

  //#endregion

// #region servicios dashboard Analytics Ventas

  getDataKPIChartVentas( dataKPIVentasFiltro:dataKPIVentasFiltroInterface) {
    return this._httpClient.post(`${environment.endpointAnalytics}/dataKPIChart`,
      dataKPIVentasFiltro
    ).catch((error:any) =>  {
      return this._reusableService.getCatch(error) });
  }

  getDataSubMenuGraficos( dataSubMenuGraficoProductos:dataKPIVentasFiltroInterface) {
    return this._httpClient.post(`${environment.endpointAnalytics}/dataNgChart`,dataSubMenuGraficoProductos
      ).catch((error:any) =>  {
        return this._reusableService.getCatch(error) });
  }

  getDataSubMenuGraficosSeries(dataSubMenuGraficoProductos:dataKPIVentasFiltroInterface) {
    return this._httpClient.post(`${environment.endpointAnalytics}/dataNgChartSeries`,dataSubMenuGraficoProductos
      ).catch((error:any) =>  {
        return this._reusableService.getCatch(error) });
  }

  //#endregion      
  

//#region Servicios dashboard Logistica

getDataKPILogChart(idDashboard,idCardChart,ruc,moneda,periodo,unidad,top,receptor) {
      return this._httpClient.post(`${environment.endpointAnalytics}/dataKPILogChart`,
        { "idDashboard" : idDashboard,
          "idCardChart": idCardChart,
          "ruc": ruc,
          "moneda": moneda,
          "periodo": periodo,
          "unidad": unidad,
          "top": top,
          "receptor": receptor
        }
      ).catch((error:any) =>  {
        return this._reusableService.getCatch(error) });
    }

//#endregion


// #region servicios catalogos Configuracion Analytics

subirCatalogoAnalytics(tipoCatalogo:number,data) {
  //1:Productos
  //2:Tiendas
  
  const RUTACARGACATALOGOPRODUCTOS="loadDescriptionItems"
  const RUTACARGACATALOGOTIENDAS="loadSupplierLocations"
  let ruta= null
  switch(tipoCatalogo){
    case 1:
      ruta=RUTACARGACATALOGOPRODUCTOS
      break;
    case 2:
      ruta=RUTACARGACATALOGOTIENDAS
      break;
  }
  if(ruta==null)
    return this._reusableService.getCatch("Tipo catalogo incorrecto")

  return this._httpClient.post(`${environment.endpointAnalytics}/${ruta}`,data)
  .catch((error:any) =>  {
    return this._reusableService.getCatch(error) });
}

//#endregion

//#region servicio de confirmacion para ver modulo de analytics(analisis de datos)

activarModuloAnalytics(aceptacion:boolean,ruc:string) {
  return this._httpClient.post(`${environment.endpointVelose}/analytics/activarModulos`,
    { 
      "aceptaAnalisis" : aceptacion,
      "ruc": ruc
    }
  ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
}

//#endregion
 /********* Permisos *********** */
obtenerPermisos(nombreModulo:string, nombreSubModulo:string){
  let arrayAcciones = [];
  const acciones =  this._reusableService.getSessionUsuario().acciones;
  for (var i = 0; i < acciones.length; i++) {
      if(acciones[i].split('.')[0] === nombreModulo && acciones[i].split('.')[1] === nombreSubModulo){
        arrayAcciones.push(acciones[i]);
      }
    }
  return arrayAcciones;
}

}



// =======================================================================
// =======================================================================


export interface dataKPIVentasServiceInterface{
  name: string
  value: number
  format: string
}

export class dataKPIVentasServiceClass{
  name: string
  value: number
  format: string
  constructor(){
    this.name=null;
    this.value=null;
    this.format=null;
  }
}


export interface dataKPIVentasFiltroInterface{
  idDashboard: number
  idCardChart: number
  ruc: string
  moneda: string
  periodo: string
  top?:number
  receptor?:string
}

export class dataKPIVentasFiltroClass{
  idDashboard: number
  idCardChart: number
  ruc: string
  moneda: string
  periodo: string
  top?:number
  receptor?:string
  constructor(){
    this.idDashboard=1;
    this.idCardChart=null;
    this.ruc=null;
    this.moneda=null;
    this.periodo=null;
    this.top=null;
    this.receptor=null;
  }
}

export interface dataResponseConfirmacionAnalisisDatosAnalytics{
  estado:boolean;
  mensaje:string;
  analisisDatos:dataResponseConfirmacionAnalisisDatos
}

export interface dataResponseConfirmacionAnalisisDatos{
  confirmacion:boolean;
  fechaAceptacionFutura:Date;
}

export class permisosAnalyticsChart{
   // analytics     :string='analytics'
  //analytics_charts:string='analytics.charts'
  confirmacion:string='analytics.charts.confirmacion'
  filtroFechaHoy :string='analytics.charts.filtroFechaHoy'
  filtroFechaSemana :string='analytics.charts.filtroFechaSemana'
  filtroFecha15   	:string='analytics.charts.filtroFecha15'
  filtroFechaMes  	:string='analytics.charts.filtroFechaMes'
  filtroMonedaSoles :string='analytics.charts.filtroMonedaSoles'
  filtroMonedaDolares:string='analytics.charts.filtroMonedaDolares'
  filtroTop5 :string='analytics.charts.filtroTop5'
  filtroTop10:string='analytics.charts.filtroTop10'
  filtroTop20:string='analytics.charts.filtroTop20'
  submenuClientes :string='analytics.charts.submenuClientes'
  submenuProductos:string='analytics.charts.submenuProductos'
  submenuTiendas  :string='analytics.charts.submenuTiendas'
  opcVentas       :string='analytics.charts.opcVentas'
}
export class permisosAnalyticsConfiguracion{
  analytics_configuracion:string='analytics.configuracion'
  catalogoProductos:string='analytics.configuracion.catalogoProductos'
  catalogoTiendas  :string='analytics.configuracion.catalogoTiendas'

}
export class permisosAnalyticsChartClass{
   // analytics     :string='analytics'
  //analytics_charts:boolean=false
  confirmacion:boolean=false
  filtroFechaHoy :boolean=true
  filtroFechaSemana :boolean=false
  filtroFecha15   	:boolean=false
  filtroFechaMes  	:boolean=false
  filtroMonedaSoles :boolean=true
  filtroMonedaDolares:boolean=false
  filtroTop5 :boolean=true
  filtroTop10:boolean=false
  filtroTop20:boolean=false
  submenuClientes :boolean=false
  submenuProductos:boolean=false
  submenuTiendas  :boolean=false
  opcVentas       :boolean=true
}
export class permisosAnalyticsConfiguracionClass{
  analytics_configuracion:boolean=false
  catalogoProductos:boolean=false
  catalogoTiendas  :boolean=false

}