
import {catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import {ReusableService} from './reusable.service';

@Injectable()
export class MiplanService {

  constructor( private _httpClient:HttpClient,
              private _reusableService:ReusableService) {

   }

  getMiPlan(idPse){
    return this._httpClient.post
          (`${environment.endpointVelose}/pago/datosPlanPse`,
            {parametro1:idPse}).pipe(
          catchError((error:any) =>  {return this._reusableService.getCatch(error) })); //Observable.throw('Server error:'+error));
  }

  comprarPaqueteAdicional(data){
    return this._httpClient.post
          (`${environment.endpointVelose}/pago/comprarPaqueteAdicional`,
            data).pipe(
          //.catch((error:any) => Observable.throw( 'Server error:'+error));
          catchError((error:any) =>  {return this._reusableService.getCatch(error) }));

  }

  registrarPlanAdicional(params){
      return this._httpClient.post(`${environment.endpointVelose}/pago/comprarPlan`,params).pipe(
              catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

}

// Interfaces & Clases

export interface MiPlan {
  planActivo:boolean;
  proximoCiclo:boolean;
  fechaInicio:string;
  fechaFin:string;
  fechaProximoCiclo:string;
  cantidadMaximo:number;
  cantidadDisponible:number;
  ilimitado:boolean;
  nombrePlan:string;
  adicional:any;
  lstDetallePlanes?:any,
  correoFact?:any,
  nombreContactoFact?:any,
  apellidoContactFact?:any,
  lstPqtAdicional?:any,
  validacionAdicional?:any,

}
export class miPlanC{
  planActivo:boolean;
  proximoCiclo:boolean;
  fechaInicio:string;
  fechaFin:string;
  fechaProximoCiclo:string;
  cantidadMaximo:number;
  cantidadDisponible:number;
  ilimitado:boolean;
  nombrePlan:string;
  adicional:any;
  lstDetallePlanes?:any;
  correoFact?:any;
  nombreContactoFact?:any;
  apellidoContactFact?:any;
  lstPqtAdicional?:any;
  validacionAdicional?:any


   constructor(){
     let fecha=new Date()

     this.planActivo=false;
     this.proximoCiclo=false;
     this.fechaInicio= fecha.toISOString();
     this.fechaFin=fecha.toISOString();
     this.fechaProximoCiclo=fecha.toISOString();
     this.cantidadMaximo=0;
     this.cantidadDisponible=0;
     this.ilimitado=false;
     this.nombrePlan="";
     this.adicional=null;
     this.lstDetallePlanes=null;
     this.correoFact=null;
     this.nombreContactoFact=null;
     this.apellidoContactFact=null;
     this.lstPqtAdicional=null;
     this.validacionAdicional=0


   }
 }

export interface responseMiPlan {
  "estado":boolean;
  "mensaje":string;
  "datos":MiPlan;
}
