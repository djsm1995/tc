
import {catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';

@Injectable()
export class PsePartnersService {
  psePartners: PsePartners[] = [
    {
      id:1,
      nombre:"TCI",
      empresas:50
    },
    {
      id:2,
      nombre:"ACEPTA PERU",
      empresas:1
    },
    {
      id:3,
      nombre:"CLOUDWARE 360",
      empresas:5
    },
    {
      id:4,
      nombre:"XEROX DEL PERU",
      empresas:10
    }
    // {
    //   ruc:4,
    //   razonSocial:"XEROX DEL PERU",
    //   empresas:10
    // }
  ];
  constructor(private _htppClient: HttpClient, private _reusableService: ReusableService) { }

  getPsePartners(razonSocial) {
    return this._htppClient
      .post(`${environment.endpointVelose}/pse/padron`, razonSocial).pipe(
      catchError((error: any) => {
        return this._reusableService.getCatch(error);
      }));
  }

}

export interface PsePartners{
  id:number;
  nombre:string;
  empresas:number;
}
