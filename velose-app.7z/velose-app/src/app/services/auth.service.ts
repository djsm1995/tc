
import {catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { HttpClient  } from '@angular/common/http';
import { JwtHelperService } from "@auth0/angular-jwt";
import { Router } from '@angular/router';
import { ReusableService} from './reusable.service';
import { environment } from '../../environments/environment';


@Injectable()
export class AuthService {
  private jwtHelper: JwtHelperService = new JwtHelperService();

  constructor(
    private _httpClient: HttpClient,
    public _router: Router,
    private _reusableService: ReusableService,
  ) {}

  verificarLogin(datosLogin) {
    if (datosLogin.valid) {
      // obtenemos datos del servicio de logeo - Backend
      return this._httpClient
        .post(`${environment.endpointVelose}/auth/login`, {
          correo: datosLogin.controls.correoLoginFormControl.value.toLowerCase(),
          password: datosLogin.controls.passLoginFormControl.value
        }).pipe(
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }));
    }
  }

  // =======================================================================================
  // AuthGuardService
  isAuthenticated() {
    return localStorage.getItem("usuarioLogeado") == null ? false : true;
  }

  isTokenExpired() {
    let usuarioLogeado = this._reusableService.getSessionUsuario();
    let expired = this.jwtHelper.isTokenExpired(usuarioLogeado.token);
    return expired; //false
  }
  
  isValidoCorreoRecover(correo) {
    return this._httpClient.post(`${environment.endpointVelose}/auth/clave/validarCorreo`, {
        "correo": correo.toLowerCase()
      }).pipe(
        catchError((error: any) => { return this._reusableService.getCatch(error) }));

  }

}


// TO-DO
// interface en registro
// interface de usuario
