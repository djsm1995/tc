import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  constructor(
    private _httpClient: HttpClient,
    private _reusableService:ReusableService) { }

    actualizarDatoUsuario(dato:any, identificador:number, idAuth:string){
      let data = this.tipoDeDato(dato, identificador, idAuth);
      return this._httpClient.post(`${environment.endpointVelose}/usuario/actualizarUsuarioAsociado`, data
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    } 
    obtenerCantidadMaximaUsuarios(){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/obtenerCantidadMaximaUsuarios`, 
      {}
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    }
    listarUsuarios(filtro:string){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/listarUsuarioAsociados`, 
      {
        "filtro" : filtro
      }
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    }
    eliminarUsuario(idUsuario:number,idAuth:string){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/eliminarUsuarioAsociado`, 
      {
        "idUsuario" : idUsuario,
        "idAuth" : idAuth
      }
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    }

    obtenerUsuario(idAuth:string){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/obtenerDatosUsuarioAsociado`, 
      {
        "idAuth" : idAuth
      }
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    } 
      
    crearUsuario(data:any){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/crearUsuarioAsociado`, data
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    }
    validarCorreo(correo:string){
      return this._httpClient.post(`${environment.endpointVelose}/usuario/validarCorreo`, 
      {
        "correo":correo
      }
      ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
    }


    /*REUSABLE*/
    private tipoDeDato(dato:any,identificador:number, idAuth:string){
      let data;
      switch (identificador) {
            case 1:
              data = {nombre:dato,idAuth:idAuth};
              return data;
            case 2:
              data = {apellidos:dato,idAuth:idAuth};
              return data;
            case 3:
              data = {correo:dato,idAuth:idAuth};
              return data;
            case 4:
              data = {estado:dato,idAuth:idAuth};
              return data;
            case 5:
              data = {idRol:dato,idAuth:idAuth};
              return data;
            default:
              break;
          }
    }

    /********* Permisos *********** */
  obtenerPermisos(){
    let arrayAcciones = [];
    const acciones =  this._reusableService.getSessionUsuario().acciones;
    for (var i = 0; i < acciones.length; i++) {
        //if(acciones[i] === nombreModulo){
         if(acciones[i].split('.')[0] === "usuarios"){
          arrayAcciones.push(acciones[i]);
        }
        
      }
    return arrayAcciones;
  }
}

export interface responseUsuario {
  "estado":boolean;
  "mensaje":string;
  "datos":string;
}

export class registroUsuarioClass
{
  idUsuario:number;
  idAuth:string;
  correo:string;
  nombre:string;
  apellidos:string;
  idRol:number;

  constructor(){
    this.idUsuario=null;
    this.idAuth="";
    this.correo="";
    this.nombre=""; 
    this.apellidos="";
    this.idRol=null;
  }
}

export class permisosUsuario{
  listarUsuarios: string='usuarios.listarUsuarios'
  crearUsuarios:  string='usuarios.crearUsuarios'
  modificarUsuarios: string='usuarios.modificarUsuarios'
  eliminarUsuarios: string='usuarios.eliminarUsuarios'
  habilitarInhabilitarUsuarios: string='usuarios.habilitarInhabilitarUsuarios'
}
export class permisosUsuarioClass{
  listarUsuarios:boolean=false
  crearUsuarios:boolean=false
  modificarUsuarios:boolean=false
  eliminarUsuarios:boolean=false
  habilitarInhabilitarUsuarios:boolean=false

}