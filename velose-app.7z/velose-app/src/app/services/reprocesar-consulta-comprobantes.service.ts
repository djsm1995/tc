import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ReusableService } from './reusable.service';


@Injectable({
  providedIn: 'root'
})
export class ReprocesarConsultaComprobantesService {
  estadoDeclare:any[]=[
    {
      descripcion: "Comprobante declarado",
      codigo: "2",
      reprocesar: false
    },
    {
      descripcion: "Excepción SOAP Sunat - Comprobante",
      codigo: "3",
      reprocesar: true
    },
    {
      descripcion: "Excepción Velose App - Comprobante",
      codigo: "4",
      reprocesar: true
    },
    {
      descripcion: "Resumen Declarado",
      codigo: "8",
      reprocesar: false
    },
    {
      descripcion: "Excepción SOAP Sunat - Resumen",
      codigo: "6",
      reprocesar: true
    },
    {
      descripcion: "Excepción Velose App - Resumen",
      codigo: "7",
      reprocesar: true
    },
    {
      descripcion: "Error máximo intentos o tiempo superados",
      codigo: "9",
      reprocesar: true
    }
  ];
  constructor(private _httpClient: HttpClient,
              private _reusableService: ReusableService,
  ) {   }

  reprocesar(data: any) {
    return this._httpClient
      .post(
        `${environment.endpointVelose}/declaracion/reprocesarComprobantes`,
        data
      )
      .catch((error: any) => {
        return this._reusableService.getCatch(error);
      });
    
  }

  getListaestadoDeclare():any[] {
    return this.estadoDeclare
  }
}
