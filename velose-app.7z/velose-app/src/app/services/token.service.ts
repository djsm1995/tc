import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { ReusableService, InterceptorSkipHeaderRefresh} from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable()
export class TokenService {

  constructor(
    private _dialogRef: MatDialog,
    private _httpClient:HttpClient,
    private _reusableService:ReusableService ,
       private _router:Router) {
  }

  refreshInterceptorToken() {
    const headers = new HttpHeaders().set(InterceptorSkipHeaderRefresh, "");
    let refreshToken = this._reusableService.getRefreshToken();
    let token = this._reusableService.getToken();
    if (refreshToken != null) {
      return this._httpClient
        .post(`${environment.endpointVelose}/auth/refreshToken`, { token: token, refreshToken: refreshToken }, { headers })
    }
    else {
      return refreshToken;
    }
  }

  refreshToken(){
    let refreshToken = this._reusableService.getRefreshToken();
    let token = this._reusableService.getToken();
    return this._httpClient
        .post(`${environment.endpointVelose}/auth/refreshToken`, { token: token, refreshToken: refreshToken })
  }

  guardarNuevoToken(dataToken){
    let usuarioLogeado:any= this._reusableService.getSessionUsuario();
    usuarioLogeado.token=dataToken.accessToken;
    usuarioLogeado.token_refresh=dataToken.refreshToken;
    this._reusableService.setSessionUsuario(usuarioLogeado)
  }

  logoutService(token){
    this._httpClient
    .post(`${environment.endpointVelose}/auth/logout`,{token:token})
  }

  closeSession(){ 
    let token= this._reusableService.getToken()
    
    localStorage.removeItem("usuarioLogeado")
    this._dialogRef.closeAll();
    this._router.navigate(["login"]);

    if(token!=null){
      // Se enviara token como data del body ya que este servicio no verificara el token en header  - el servicio no regresara 401
      this.logoutService(token)
    }

  }

}
