import { Injectable } from '@angular/core';
import { JwtHelperService } from "@auth0/angular-jwt";

import { Observable} from 'rxjs/Observable';
import { Catalogo, Cpe, Moneda, EstadoRpta} from '../constantes/catalogo';
import { environment } from '../../environments/environment';
import { throwError } from 'rxjs';



const TOKEN_KEY = 'AuthToken';
export const InterceptorSkipHeaderRefresh = "X-Skip-Interceptor";
@Injectable()
export class ReusableService {
  private jwtHelper: JwtHelperService = new JwtHelperService();
  constructor() {}


  getSessionUsuario() {
    let usuarioSession = JSON.parse(localStorage.getItem("usuarioLogeado"));
    return usuarioSession;
  }
  setSessionUsuario(usuarioLogeado){
    localStorage.setItem("usuarioLogeado",JSON.stringify(usuarioLogeado));
  }

  esAdministrador(tipoRol:number){
    return (tipoRol==1)?true:false
  }
  actualizarDatosProfile(identificador:number, value:string){
    let datoUsuario = this.getSessionUsuario();
    switch (identificador) {
      case 1:
      datoUsuario.nombre=value
        break;
      case 2:
      datoUsuario.apellidos=value
        break;
      case 3:
      datoUsuario.imagenUsuario=value
        break;
      default:
        break;
    }

    localStorage.removeItem('usuarioLogeado')
    localStorage.setItem('usuarioLogeado',JSON.stringify(datoUsuario))

  }

  getModulos():string[]{
    if (localStorage.getItem("usuarioLogeado") == null) {
      return null;
    }
    return this.getSessionUsuario().modulos;
  }
  getAcciones():string[]{
    if (localStorage.getItem("usuarioLogeado") == null) {
      return null;
    }
    return this.getSessionUsuario().acciones;
  }

  getToken() {
    if (localStorage.getItem("usuarioLogeado") == null) {
      return null;
    }
    return this.getSessionUsuario().token;
  }
  getTokenJson() {
    if (this.getToken() == null) return null;
    return this.jwtHelper.decodeToken(this.getToken());
  }
  getRefreshToken() {
    if (localStorage.getItem("usuarioLogeado") == null) {
      return null;
    }
    return this.getSessionUsuario().token_refresh;
  }

  getToday() {
    let date:Date = new Date();
    return date;
  }

  getHoraFecha(date:Date=this.getToday()):string{
    let timeToday:string
    timeToday=`${date.getHours}:${date.getMinutes}`
    return timeToday;
  }

  setHoraFecha(date:Date=this.getToday(),tiempo:string="00:00:00"):Date{
    let nuevaFecha:Date =date;
    let tiempoSplit= tiempo.split(":")
    
    let horas:number= parseInt(this.validarFechaSet(tiempoSplit[0]));
    let minutos:number=parseInt(this.validarFechaSet(tiempoSplit[1]));
    let segundos:number=parseInt(this.validarFechaSet(tiempoSplit[2]));
    
    nuevaFecha.setHours(horas,minutos,segundos)
    return nuevaFecha;
  }

  validarFechaSet(tiempo){
    return (tiempo== null ||tiempo==undefined)?"00":tiempo
  }

  getFormatoFecha(fecha: Date, formato, fechaFin?: boolean) {
    let rpta:any;
    switch (formato) {
      case 1: // fecha iso date to string
        rpta = fecha.toISOString();
        break;
      case 2:
        if (fechaFin) fecha.setHours(23, 59, 59, 59);
        // fecha=fecha.getTime
        rpta =
          [
            this.padLeft(fecha.getDate()),
            this.padLeft(fecha.getMonth() + 1),
            fecha.getFullYear()
          ].join("/") +
          " " +
          [
            this.padLeft(fecha.getHours()),
            this.padLeft(fecha.getMinutes()),
            this.padLeft(fecha.getSeconds()),
            this.padLeft(fecha.getMilliseconds())

          ].join(":");
        break;
      case 3: //Formato plan de facturacion Dashboard
        let meses = [
          "Ene",
          "Feb",
          "Mar",
          "Abr",
          "May",
          "Jun",
          "Jul",
          "Ago",
          "Set",
          "Oct",
          "Nov",
          "Dic"
        ];
        rpta = `${fecha.getDate()} ${meses[fecha.getMonth()]}`;//se cambio el -1 : [fecha.getMonth() - 1
        break;
      case 4:
        rpta = [
          this.padLeft(fecha.getDate()),
          this.padLeft(fecha.getMonth() + 1),
          fecha.getFullYear()
        ].join("/");
        break;
      default:
        rpta = fecha.toString();
        break;
    }
    return rpta;
  }
  padLeft(base: number) {
    let rpta: any = base;
    rpta = base >= 10 ? rpta : `0${base}`;
    return rpta;
  }

  getFormatoMiles(base: number,dec : number) {
    let rpta: any = base;
    let baseK = 1000;
    let baseM = 1000000;

    // bases
    if (base >= 0 && base <= baseK) {
        //return rpta;
        if (dec>0) {
          rpta = this.Redondeo2Decimales(base);
          return this.formatNumber(rpta);
        } else {
          return rpta;
        }
    }
    // Miles
    else if (base >= baseK && base < baseM) {
      rpta = String(base / baseK).split(".");
      return `${rpta[0]}K`;
    }
    // Millones
    else {

      rpta = String(base / baseM).split(".");
      return `${rpta[0]}M`;
    }
  }

  getFormatoMilesDecimalesMoneda(valor, codMoneda?: string) {
    valor = this.Redondeo2Decimales(valor);
    let moneda = codMoneda || '';
    return `${moneda} ${this.getFormatoMiles(valor,2)}`;
  }

  getFormatoMilesMoneda(valor, codMoneda?: string) {
    let moneda = codMoneda || '';
    return `${moneda} ${this.getFormatoMiles(valor,2)}`;
  }

  formatNumber(num) {
    let separadorMiles = ",";
    let separadorDecimales = ".";
    num +='';
     var splitStr = num.split('.');
     var splitLeft = splitStr[0];
     var splitRight = splitStr.length > 1 ? splitStr[1] : '00';
     var regx = /(\d+)(\d{3})/;
     while (regx.test(splitLeft)) {
       splitLeft = splitLeft.replace(regx, '$1' + separadorMiles + '$2');
    }
    return splitLeft + '.' + splitRight;
  }

  getComprobanteByCodigo(codigo) {
    let cpes: Cpe[];
    cpes = Catalogo.CPES;
    let rpta = "";
    for (var i = 0; i < cpes.length; i++) {
      if (cpes[i].codigo == codigo) {
        rpta = cpes[i].nombre;
        return rpta;
      }
    }
    return rpta;
  }
  getEstadoRespuestaSolicitud(codigo) {
    let estados: EstadoRpta[];
    estados = Catalogo.ESTADOSRESPUESTA;
    let rpta = "";
    for (var i = 0; i < estados.length; i++) {
      if (estados[i].codEstado == codigo) {
        rpta = estados[i].descripcion;
        return rpta;
      }
    }
    return estados;
  }

  validarMedidaArchivo(longitudMaxima,LongitudActual){
    //los datos a enviar deben estar con la misma unidad de medida.
    return (LongitudActual>longitudMaxima)?false:true;
  }

  // String64
  utf8Encode(string) {
    var utftext = "";
    string = string.replace(/\r\n/g, "\n");

    for (var n = 0; n < string.length; n++) {
      var c = string.charCodeAt(n);

      if (c < 128) {
        utftext += String.fromCharCode(c);
      } else if (c > 127 && c < 2048) {
        utftext += String.fromCharCode((c >> 6) | 192);
        utftext += String.fromCharCode((c & 63) | 128);
      } else {
        utftext += String.fromCharCode((c >> 12) | 224);
        utftext += String.fromCharCode(((c >> 6) & 63) | 128);
        utftext += String.fromCharCode((c & 63) | 128);
      }
    } // Next n

    return utftext;
  }
  ut8Decode(utftext) {
    var string = "";
    var i = 0;
    var c, c1, c2, c3;
    c = c1 = c2 = 0;

    while (i < utftext.length) {
      c = utftext.charCodeAt(i);

      if (c < 128) {
        string += String.fromCharCode(c);
        i++;
      } else if (c > 191 && c < 224) {
        c2 = utftext.charCodeAt(i + 1);
        string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
        i += 2;
      } else {
        c2 = utftext.charCodeAt(i + 1);
        c3 = utftext.charCodeAt(i + 2);
        string += String.fromCharCode(
          ((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63)
        );
        i += 3;
      }
    } // Whend

    return string;
  } // End Function _utf8_decode

  // Redondeo
  toFixedTrunc(value, n) {
    const f = Math.pow(10, n);
    return (Math.trunc(value * f) / f).toFixed(n);
  }
  Redondeo2Decimales(value) {
    return parseFloat(value).toFixed(2);
  }
  getCatch(error) {
    return throwError("Server error:" + error);
  }

  // Aleatorios
  getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

  //tipo de clientes (0,1,2)
  esClientePrepago(usuarioLogeado) {
    let clientePrepago: boolean = false;
    clientePrepago = usuarioLogeado.habilitarPagos
    // clientePrepago = (this.getSessionUsuario().empresa.tipoEmisor== Catalogo.TIPOEMISOR.emisorNuevo)?true:clientePrepago;
    return clientePrepago;
  }

  // #region environment
  esAmbienteDev(){
    return (environment.ambiente =="dev")?true:false;
  }
  //#endregion
  /********* Permisos *********** */
  obtenerPermisos(permiso:string){
    let arrayAcciones = [];
    const acciones =  this.getSessionUsuario().acciones;
    for (var i = 0; i < acciones.length; i++) {
        //if(acciones[i] === nombreModulo){
         if(acciones[i].split('.')[0] === permiso){
          arrayAcciones.push(acciones[i]);
        }
        
      }
    return arrayAcciones;
  }
  //Comparar si fecha es menor a fecha actual;
  compararFechaMenor(fecha1:Date){
   let Hoy = new Date();//Fecha actual del sistema
   var AnyoFecha = fecha1.getFullYear();
   var MesFecha = fecha1.getMonth();
   var DiaFecha = fecha1.getDate();
   
   var AnyoHoy = Hoy.getFullYear();
   var MesHoy = Hoy.getMonth();
   var DiaHoy = Hoy.getDate();

    if (AnyoFecha < AnyoHoy){ //alert ("1) La fecha introducida es anterior a Hoy");
      return true;
    }else{
        if (AnyoFecha == AnyoHoy && MesFecha < MesHoy){//alert ("2) La fecha introducida es anterior a Hoy");	
            return true;		
        }else{
            if (AnyoFecha == AnyoHoy && MesFecha == MesHoy && DiaFecha < DiaHoy){ //alert ("3) La fecha introducida es anterior a Hoy");
                return true;
            }
            else{
                if (AnyoFecha == AnyoHoy && MesFecha == MesHoy && DiaFecha == DiaHoy){ //alert ("4) Has introducido la fecha de Hoy");
                    return true;
                }else{//alert ("5) La fecha introducida es posterior a Hoy");
                    return false;
                }
            }
        }
    }
  }
}

export interface IResponseService{
  estado:boolean,
  mensaje:string
}
