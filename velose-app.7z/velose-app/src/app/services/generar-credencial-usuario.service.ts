import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class GenerarCredencialUsuarioService {

  constructor(private _httpClient: HttpClient, private _reusableService: ReusableService) { }

  generarCredencial(idAuth, clave){
    return this._httpClient.post(`${environment.endpointVelose}/auth/crearClave/registrar`, {
      // "token": this.token,
      "idAuthUsuario": idAuth,
      "clave": clave,

    }).catch((error: any) => {
      return this._reusableService.getCatch(error);
    });
  }
}
