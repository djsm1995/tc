import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService, IResponseService } from './reusable.service';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators/catchError';
import { IRequestBusquedaComprobantes, IRequestBusquedaComprobantes2 } from './transacciones.service';

@Injectable({
  providedIn: 'root'
})
export class DescargaBusquedaCpesService {

  ///endpointVelose:string="https://0312793f-7f58-4058-a325-ab9fe30ef8ed.mock.pstmn.io"
  endpointVelose:string= environment.endpointVelose

  constructor( 
    private _httpClient:HttpClient,
    private _reusableService:ReusableService) { }


  getMaximaSolicitudExportacionCpe(){
    return this._httpClient
    .get(`${this.endpointVelose}/solicitud/cantidadMaximaDescargas`)
    .pipe(
      catchError((error:any) =>  { return this._reusableService.getCatch(error) })
    );
  }
  getListadoDescargasBusquedaCpe(){
    return this._httpClient
      .get(`${this.endpointVelose}/solicitud/listadoDescargas`)
      .pipe(
        catchError((error:any) =>  { return this._reusableService.getCatch(error) })
      );
  }

  exportarBusquedaCpe(filtrosBusqueda:IRequestBusquedaComprobantes2){
    console.log(filtrosBusqueda.filtro);
    return this._httpClient.post(
      `${this.endpointVelose}/solicitudReporte/guardarListadoCPEs`,
      filtrosBusqueda.filtro
    ).pipe(
    catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }


  
  
}

  export interface ISolicitudDescargaCpe{
  idSolicitud:number,
  fechaExportacion:Date,
  pesoArchivo:string,
  filtroBusqueda:IRequestBusquedaComprobantes,
  linkArchivo:string,
  estado:string
}



export interface IListadoSolicitudDescargaCpe extends IResponseService{
  listado:ISolicitudDescargaCpe[]
}

export interface ICantidadMaximaSolicitudExportacion extends IResponseService{
  reporteSolicitud:{
    cantidadMaxima:number,
    cantidadUtilizada:number
  }
}

export interface IMostrarFiltrosBusqueda{
  tipoCpe:string,
  serie:string,
  correlativo:string,
  estadoVelose:string,
  estadoSunat:string,
  fechaInicio:string,
  fechaFin:string
}

export class CMostrarFiltrosBusqueda{
  data:IMostrarFiltrosBusqueda
  constructor(){
    this.data={
      tipoCpe:"Todos",
      serie:"-",
      correlativo:"-",
      estadoVelose:"Todos",
      estadoSunat:"Todos",
      fechaInicio:"-",
      fechaFin:"-"
    }
    
  }
}
