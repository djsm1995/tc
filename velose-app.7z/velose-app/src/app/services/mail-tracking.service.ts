
import {catchError} from 'rxjs/operators/catchError';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { formatDate } from "@angular/common";
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { Observable } from 'rxjs/Observable';

const ESTADO_ENVIO_PENDIENTE = 0;
const ESTADO_ENVIO_ENVIADO = 1;
const ESTADO_ENVIO_RECHAZADO = 2;
const ESTADO_ENVIO_REBOTADO = 3;
const ESTADO_EVENTO_BLOQUEADO = 4;
const ESTADO_EVENTO_DIFERIDO = 5;
const ESTADO_EVENTO_PROCESADO = 6;
const ESTADO_EVENTO_CLICK = 7;
const ESTADO_EVENTO_ABIERTO = 8;

@Injectable()
export class MailTrackingService {

  view : TrackView = { delivered: 0, opened: 0, header : [] ,seguimiento:''};

  solicitud : Solicitud;

  constructor(private _httpClient:HttpClient,
              private _reusableService:ReusableService) {
  }

  convertToView( lista ) {
    let enviados : number = 0;
    let entregados : number = 0;
    let abiertos : number = 0;
    let resSolicitud : any = { };
    if ( lista.length > 0 ) {

          resSolicitud = lista[0];
          this.solicitud = new Solicitud();

          this.solicitud["codigo"] = resSolicitud["cod-solicitud"];
          this.solicitud["asunto"] = resSolicitud["asunto"];
          this.solicitud["remitente"] = resSolicitud["remitente"];
          this.solicitud["alias"] = resSolicitud["alias-remitente"];
          this.solicitud["fecha"] = resSolicitud["fecha-registro"];

          let resPeticiones = resSolicitud["peticiones-solicitud"];
          let peticiones : Peticion[] = [];
          let envios : Peticion[] = [];
          let reenvios : Peticion[] = [];

          for (let p=0;p<resPeticiones.length; p++) {

            let peticion : Peticion = new Peticion();

            peticion.fecha = resPeticiones[p]["fecha-registro"];
            peticion.tipo = resPeticiones[p]["tipo_peticion"];

            let resMensajes = resPeticiones[p]["mensajes_peticion"];
            let mensajes : Mensaje[] = [];

            for (let m=0;m<resMensajes.length; m++) {

              let mensaje : Mensaje = new Mensaje();

              mensaje.correo = resMensajes[m]["correo"];
              mensaje.estado = resMensajes[m]["estado-mensaje"];
              mensaje.estadoNombre = this.getEstadoNombre( mensaje.estado );
              mensaje.contador = resMensajes[m]["contador-mensaje-abierto"];

              enviados++;
              entregados = entregados + this.isDelivered(mensaje.estado);

              mensaje.icono = this.getIconName(mensaje.estado);
              mensaje.icono_color = this.getIconColor(mensaje.estado);

              let resEventos = resMensajes[m]["eventos-mensaje"];
              let eventos : Evento[] = [];

              if ( resEventos != null ) {
                for (let e=0;e<resEventos.length; e++) {
                  let evento : Evento = new Evento();
                  evento.estado = resEventos[e]["estado-evento"];
                  evento.estadoNombre = this.getEstadoNombre( evento.estado );

                  if ( evento.estado == 8 ) { abiertos++; }

                  evento.fecha = resEventos[e]["fecha-evento"];
                  evento.descripcion = resEventos[e]["descripcion-evento"];

                  eventos.push( evento );
                }
              }
              mensaje.eventos = eventos;
              mensajes.push( mensaje );
            }

            peticion.mensajes = mensajes;

            peticiones.push( peticion );
            switch ( peticion.tipo ) {
              case 1:
                envios.push( peticion );
                break;
              case 2:
                reenvios.push( peticion );
                break;
              default:
                break;
            }

          }

          this.solicitud.peticiones = peticiones;
          this.solicitud.envios = envios;
          this.solicitud.reenvios = reenvios;

          this.view.header = [];
          this.view.header.push( { "key": "De", "value": this.solicitud.remitente  } );
          this.view.header.push( { "key": "Asunto", "value": this.solicitud.asunto } );
          this.view.header.push( { "key": "Fecha", "value": formatDate(this.solicitud.fecha, "dd/MM/yyyy h:mm:ss a", "en-US") } );
          // this.view.header.push( { "key": "Seguimiento", "value": enviados+" procesados, "+entregados+" enviados, "+abiertos+" veces abiertos" } );

          this.view.seguimiento =  `${enviados} procesados, ${entregados} enviados, ${abiertos} veces abiertos.`
          this.view.listEnvios = this.solicitud.envios;
          this.view.listReenvios = this.solicitud.reenvios;

    }

    return this.solicitud;
  }

  getEstadoNombre(estado) {
    let nombre = "";
    switch ( estado ) {
      case 0:
        nombre = "Pendiente";
        break;
      case 1:
        nombre = "Enviado";
        break;
      case 2:
        nombre = "Rechazado";
        break;
      case 3:
        nombre = "Rebotado";
        break;
      case 4:
        nombre = "Bloqueado";
        break;
      case 5:
        nombre = "Diferido";
        break;
      case 6:
        nombre = "Procesado";
        break;
      case 7:
        nombre = "Click";
        break;
      case 8:
        nombre = "Abierto";
        break;
    }
    return nombre;
  }

  retriveTrackingNotification(id_solicitud) : any {
    return this._httpClient.post(`${environment.endpointVelose}/notificacion/tracking`,
      { "idNotificacion": id_solicitud }
    ).pipe(catchError((error:any) =>  { return this.responseErrorSendGrid(error) }));
  }

  responseErrorSendGrid(error) {
    if (error.status == 500 ) {
      return new Observable( (observer) => observer.next({ "estado": false, "mensaje": "El servicio de seguimiento de notificaciones no responde en este momento. Intente de nuevo en unos minutos." }) )
      // return new Observable( (observer) => observer.next({ "estado": false, "mensaje": "Tenemos una demora en el servicio de seguimiento de notificaciones. Intente de nuevo en unos minutos." }) )
    } else {
      return this._reusableService.getCatch(error);
    }
  }

  forwardNotification(id_solicitud,email) : any {
    return this._httpClient.post(`${environment.endpointVelose}/mail/forward`,
      { "idNotificacion" : id_solicitud,
        "to": email
      }
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));

  }

  getIconName(estado) {
    let _eventName = "";
    switch ( estado ) {
      case ESTADO_ENVIO_PENDIENTE:
        _eventName = "warning";
        break;
      case ESTADO_ENVIO_ENVIADO:
        _eventName = "check_circle";
        break;
      case ESTADO_ENVIO_RECHAZADO:
        _eventName = "error";
        break;
      case ESTADO_ENVIO_REBOTADO:
        _eventName = "error";
        break;
      case ESTADO_EVENTO_BLOQUEADO:
        _eventName = "error";
        break;
      case ESTADO_EVENTO_DIFERIDO:
        _eventName = "warning";
        break;
      case ESTADO_EVENTO_PROCESADO:
        _eventName = "check_circle";
        break;
      case ESTADO_EVENTO_CLICK:
        _eventName = "check_circle";
        break;
      case ESTADO_EVENTO_ABIERTO:
        _eventName = "check_circle";
        break;
      default:
        _eventName = "error";
        break;
    }
    return _eventName;
  }

  getIconColor(estado) {
    let _eventColor = "";
    switch ( estado ) {
      case ESTADO_ENVIO_PENDIENTE:
        _eventColor = "color-ambar";
        break;
      case ESTADO_ENVIO_ENVIADO:
        _eventColor = "color-velose";
        break;
      case ESTADO_ENVIO_RECHAZADO:
        _eventColor = "color-warn";
        break;
      case ESTADO_ENVIO_REBOTADO:
        _eventColor = "color-warn";
        break;
      case ESTADO_EVENTO_BLOQUEADO:
        _eventColor = "color-warn";
        break;
      case ESTADO_EVENTO_DIFERIDO:
        _eventColor = "color-ambar";
        break;
      case ESTADO_EVENTO_PROCESADO:
        _eventColor = "color-velose";
        break;
      case ESTADO_EVENTO_CLICK:
        _eventColor = "color-velose";
        break;
      case ESTADO_EVENTO_ABIERTO:
        _eventColor = "color-velose";
        break;
      default:
        _eventColor = "color-warn";
        break;
    }
    return _eventColor;
  }

  isDelivered(estado) {
    let retorno = 0;
    switch ( estado ) {
      case ESTADO_ENVIO_ENVIADO:
        retorno = 1;
        break;
      case ESTADO_EVENTO_ABIERTO:
        retorno = 1;
        break;
      default:
        retorno = 0;
        break;
    }
    return retorno;
  }

}

export class Evento {
  icono ?: string;
  icono_color ?: string;
  estado : number;
  estadoNombre : string;
  fecha : string;
  descripcion ?: string;

  constructor() {
  }
};

export class Mensaje {
  icono ?: string;
  icono_color ?: string;
  correo : string;
  estado : number;
  estadoNombre : string;
  contador : number;
  eventos : Evento[];

  constructor() {
  }
};

export class Peticion {
  fecha : string;
  tipo : number;
  mensajes : Mensaje[];

  constructor() {
  }

}

export class Solicitud {
  codigo : string;
  asunto : string;
  remitente : string;
  alias : string;
  fecha : string;
  peticiones : Peticion[];

  envios : Peticion[];
  reenvios : Peticion[];

  constructor() {
  }

}

export class TrackView {
  header ?: any;
  from_email ?: string;
  subject ?: string;
  delivered ?: number;
  opened ?: number;
  processed ?: string;
  peticiones ?: Solicitud[];
  listEnvios ?: any;
  listReenvios ?: any;
  seguimiento?:string;

  constructor() {
  }

}
