import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable()
export class ConsultaValidacionesService {

  constructor(private _httpClient: HttpClient,
    private _reusableService: ReusableService, ) { }


  getDataDeclaraciones(datosConsultaValidaciones) {
    //alert(JSON.stringify(datosConsultaValidaciones));
    return this._httpClient.post(`${environment.endpointVelose}/declaracion/listaComprobantes`,
      datosConsultaValidaciones).catch((error: any) => { return this._reusableService.getCatch(error) });
  }

  countDeclaraciones(datosContarDeclaracion) {
    //alert(JSON.stringify(datosConsultaValidaciones));
    return this._httpClient.post(`${environment.endpointVelose}/declaracion/contarComprobantes`,
      datosContarDeclaracion).catch((error: any) => { return this._reusableService.getCatch(error) });
  }

  getDataDeclaracionesxId(data) {
    return (
      this._httpClient.post(`${environment.endpointVelose}/declaracion/obtenerComprobantesPorId`, { "idComprobante": data })
        .catch((error: any) => {
          return this._reusableService.getCatch(error);
        })
    );
  }
}
