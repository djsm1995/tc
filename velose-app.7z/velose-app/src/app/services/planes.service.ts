
import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';

import {catchError} from 'rxjs/operators';
import { environment } from '../../environments/environment';
import {ReusableService} from './reusable.service';

@Injectable()
export class PlanesService {
  private http: HttpClient;

  constructor(
    _httpBackend: HttpBackend,
    private _reusableService:ReusableService) 
    {
      this.http = new HttpClient(_httpBackend);
    }

  getPlanes(cpesEmitidos){
    // adicionar token diferente en headers
    return this.http.post<planesResponse>(`${environment.endpointVelose}/pago/planes`,
      {parametro1:cpesEmitidos}).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getListaCondiciones(){
    return this.http.post<listaCondicionesResponse>(`${environment.endpointVelose}/pago/planes/listaCondiciones`,{}).pipe(
           catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }

  getPlanSeleccionado(idPlan){
    return this.http.post<listaOpcionesPlanResponse>(`${environment.endpointVelose}/pago/opcionPlan`,{
      parametro1:idPlan
    }).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));

  }

}

//=======================================================
//=======================================================

export class listaOpcionesPlanResponseC
{
  mensaje:string;
  estado:boolean;
  plan:Planes;
  constructor(){
    this.estado=false;
    this.mensaje="";
    this.plan={
      idPlan:null,
      nombre:"",
      moneda:"",
      precio:null,
      codMoneda:"",
      periocidad:"",
      detalle:[],
      planInfinito:null,
      lstOpciones:[],
    };

  }
};

export class PlanesC
{
  idPlan:number;
  nombre:string;
  moneda:string;
  precio:number;
  codMoneda:string;
  periocidad:string;
  detalle:string[];
  planInfinito:boolean;
  lstOpciones?:listaOpcionesPlan[];

  constructor(){
      this.idPlan=null,
      this.nombre="",
      this.moneda="",
      this.precio=null,
      this.codMoneda="",
      this.periocidad="",
      this.detalle=[],
      this.planInfinito=null,
      this.lstOpciones=[{
        idOpcion:null,
        periocidad:"",
        precio:null,
        precioIgv:null,
        descuento:null,
        precioFinal:null,
        descripcionDescuento:"",
      }]
  }
};
export interface planesResponse{
    mensaje:string,
    estado:boolean,
    planes:Planes[],
    planRecomendado:number
 }
export interface Planes{
  idPlan:number;
  nombre:string;
  moneda:string;
  precio:number;
  codMoneda:string;
  periocidad:string;
  detalle:string[];
  planInfinito:boolean;
  lstOpciones?:listaOpcionesPlan[];
}
export interface listaOpcionesPlanResponse{
    mensaje:string,
    estado:boolean,
    plan:Planes,
}
export interface listaOpcionesPlan{
  idOpcion:number;
  periocidad:string;
  precio:number;
  precioIgv:number;
  descuento:number;
  precioFinal:number;
  descripcionDescuento:string;
}
export interface listaCondicionesResponse{
  mensaje:string,
  estado:boolean,
  condiciones:string[],
}
