
import {catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';
import { HttpClient, HttpBackend } from '@angular/common/http';
import {ReusableService} from './reusable.service';

@Injectable()
export class PagoService {
  private http: HttpClient;

  constructor(_httpBackend: HttpBackend,
              private _reusableService:ReusableService )
              { this.http = new HttpClient(_httpBackend); }

  getNroOperacionHash(datos){
    // adicionar token diferente en headers
    return this.http.post(`${environment.endpointVelose}/pago/hash`,datos
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }


}
