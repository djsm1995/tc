
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators/catchError';
import { environment } from '../../environments/environment';
import { ReusableService } from './reusable.service';

@Injectable()
export class DashboardService {
  // Cpes Facturados Barras Anidadas (6 meses)
  private CpesFacturadosBA: MultiCpes[] = [
    {
      name: "Oct 2017",
      series: [
        {
          name: "F",
          value: 19000
        },
        {
          name: "B",
          value: 30254
        },
        {
          name: "NC",
          value: 300
        },
        {
          name: "ND",
          value: 580
        },
        {
          name: "CRE",
          value: 1500
        },
        {
          name: "CPE",
          value: 1580
        },
        {
          name: "REV",
          value: 5880
        },
        {
          name: "RA",
          value: 2580
        },
        {
          name: "RC",
          value: 999
        },
        {
          name: "GRE",
          value: 1879
        }
      ]
    },
    {
      name: "Nov 2017",
      series: [
        {
          name: "F",
          value: 15000
        },
        {
          name: "B",
          value: 21254
        },
        {
          name: "NC",
          value: 300
        },
        {
          name: "ND",
          value: 580
        },
        {
          name: "CRE",
          value: 2500
        },
        {
          name: "CPE",
          value: 580
        },
        {
          name: "REV",
          value: 880
        },
        {
          name: "RA",
          value: 8580
        },
        {
          name: "RC",
          value: 1999
        },
        {
          name: "GRE",
          value: 9879
        }
      ]
    },
    {
      name: "Dic 2017",
      series: [
        {
          name: "F",
          value: 12000
        },
        {
          name: "B",
          value: 12254
        },
        {
          name: "NC",
          value: 300
        },
        {
          name: "ND",
          value: 580
        },
        {
          name: "CRE",
          value: 1500
        },
        {
          name: "CPE",
          value: 1580
        },
        {
          name: "REV",
          value: 5880
        },
        {
          name: "RA",
          value: 2580
        },
        {
          name: "RC",
          value: 999
        },
        {
          name: "GRE",
          value: 1879
        }
      ]
    },
    {
      name: "Ene 2018",
      series: [
        {
          name: "F",
          value: 17850
        },
        {
          name: "B",
          value: 20254
        },
        {
          name: "NC",
          value: 3000
        },
        {
          name: "ND",
          value: 1800
        },
        {
          name: "CRE",
          value: 2500
        },
        {
          name: "CPE",
          value: 3580
        },
        {
          name: "REV",
          value: 1880
        },
        {
          name: "RA",
          value: 580
        },
        {
          name: "RC",
          value: 799
        },
        {
          name: "GRE",
          value: 2879
        }
      ]
    },
    {
      name: "Feb 2018",
      series: [
        {
          name: "F",
          value: 21000
        },
        {
          name: "B",
          value: 17254
        },
        {
          name: "NC",
          value: 3000
        },
        {
          name: "ND",
          value: 2480
        },
        {
          name: "CRE",
          value: 8500
        },
        {
          name: "CPE",
          value: 1580
        },
        {
          name: "REV",
          value: 7880
        },
        {
          name: "RA",
          value: 1580
        },
        {
          name: "RC",
          value: 2999
        },
        {
          name: "GRE",
          value: 6879
        }
      ]
    },
    {
      name: "Mar 2018",
      series: [
        {
          name: "F",
          value: 18000
        },
        {
          name: "B",
          value: 18254
        },
        {
          name: "NC",
          value: 300
        },
        {
          name: "ND",
          value: 580
        },
        {
          name: "CRE",
          value: 1500
        },
        {
          name: "CPE",
          value: 1580
        },
        {
          name: "REV",
          value: 5880
        },
        {
          name: "RA",
          value: 2580
        },
        {
          name: "RC",
          value: 999
        },
        {
          name: "GRE",
          value: 1879
        }
      ]
    }
  ];
  // Cpes Enviados x filtros de Fecha y Hora
  private CpesFacturadosxH: baseGraficoSeries[] = [
    {
      name: "F",
      series: [
        {
          name: "7:00 am",
          value: 190
        },
        {
          name: "8:00 am",
          value: 302
        },
        {
          name: "9:00 am",
          value: 300
        },
        {
          name: "10:00 am",
          value: 580
        },
        {
          name: "11:00 am",
          value: 255
        },
        {
          name: "12:00 pm",
          value: 785
        }
      ]
    },
    {
      name: "B",
      series: [
        {
          name: "7:00 am",
          value: 290
        },
        {
          name: "8:00 am",
          value: 202
        },
        {
          name: "9:00 am",
          value: 100
        },
        {
          name: "10:00 am",
          value: 680
        },
        {
          name: "11:00 am",
          value: 555
        },
        {
          name: "12:00 pm",
          value: 885
        }
      ]
    },
    {
      name: "NC",
      series: [
        {
          name: "7:00 am",
          value: 1
        },
        {
          name: "8:00 am",
          value: 3
        },
        {
          name: "9:00 am",
          value: 3
        },
        {
          name: "10:00 am",
          value: 0
        },
        {
          name: "11:00 am",
          value: 2
        },
        {
          name: "12:00 pm",
          value: 5
        }
      ]
    },
    {
      name: "ND",
      series: [
        {
          name: "7:00 am",
          value: 0
        },
        {
          name: "8:00 am",
          value: 1
        },
        {
          name: "9:00 am",
          value: 10
        },
        {
          name: "10:00 am",
          value: 3
        },
        {
          name: "11:00 am",
          value: 2
        },
        {
          name: "12:00 pm",
          value: 0
        }
      ]
    },
    {
      name: "CRE",
      series: [
        {
          name: "7:00 am",
          value: 50
        },
        {
          name: "8:00 am",
          value: 10
        },
        {
          name: "9:00 am",
          value: 25
        },
        {
          name: "10:00 am",
          value: 30
        },
        {
          name: "11:00 am",
          value: 20
        },
        {
          name: "12:00 pm",
          value: 8
        }
      ]
    },
    {
      name: "CPE",
      series: [
        {
          name: "7:00 am",
          value: 30
        },
        {
          name: "8:00 am",
          value: 8
        },
        {
          name: "9:00 am",
          value: 25
        },
        {
          name: "10:00 am",
          value: 30
        },
        {
          name: "11:00 am",
          value: 20
        },
        {
          name: "12:00 pm",
          value: 8
        }
      ]
    },
    {
      name: "REV",
      series: [
        {
          name: "7:00 am",
          value: 3
        },
        {
          name: "8:00 am",
          value: 80
        },
        {
          name: "9:00 am",
          value: 250
        },
        {
          name: "10:00 am",
          value: 3
        },
        {
          name: "11:00 am",
          value: 0
        },
        {
          name: "12:00 pm",
          value: 8
        }
      ]
    },
    {
      name: "RA",
      series: [
        {
          name: "7:00 am",
          value: 30
        },
        {
          name: "8:00 am",
          value: 150
        },
        {
          name: "9:00 am",
          value: 50
        },
        {
          name: "10:00 am",
          value: 38
        },
        {
          name: "11:00 am",
          value: 9
        },
        {
          name: "12:00 pm",
          value: 28
        }
      ]
    },
    {
      name: "RC",
      series: [
        {
          name: "7:00 am",
          value: 100
        },
        {
          name: "8:00 am",
          value: 50
        },
        {
          name: "9:00 am",
          value: 50
        },
        {
          name: "10:00 am",
          value: 48
        },
        {
          name: "11:00 am",
          value: 90
        },
        {
          name: "12:00 pm",
          value: 280
        }
      ]
    },
    {
      name: "GRE",
      series: [
        {
          name: "7:00 am",
          value: 3
        },
        {
          name: "8:00 am",
          value: 15
        },
        {
          name: "9:00 am",
          value: 5
        },
        {
          name: "10:00 am",
          value: 13
        },
        {
          name: "11:00 am",
          value: 9
        },
        {
          name: "12:00 pm",
          value: 2
        }
      ]
    }
  ];
  public CpesFacturadosxD: baseGraficoSeries[] = [
    {
      name: "F",
      series: [
        {
          name: "2 Abr",
          value: 890
        },
        {
          name: "3 Abr",
          value: 943
        },
        {
          name: "4 Abr",
          value: 969
        },
        {
          name: "5 Abr",
          value: 1030
        },
        {
          name: "6 Abr",
          value: 996
        },
        {
          name: "7 Abr",
          value: 6788
        }
      ]
    },
    {
      name: "B",
      series: [
        {
          name: "2 Abr",
          value: 4052
        },
        {
          name: "3 Abr",
          value: 3834
        },
        {
          name: "4 Abr",
          value: 3747
        },
        {
          name: "5 Abr",
          value: 3881
        },
        {
          name: "6 Abr",
          value: 3646
        },
        {
          name: "7 Abr",
          value: 6153
        }
      ]
    },
    {
      name: "NC",
      series: [
        {
          name: "2 Abr",
          value: 102
        },
        {
          name: "3 Abr",
          value: 118
        },
        {
          name: "4 Abr",
          value: 124
        },
        {
          name: "5 Abr",
          value: 106
        },
        {
          name: "6 Abr",
          value: 127
        },
        {
          name: "7 Abr",
          value: 117
        }
      ]
    },
    {
      name: "ND",
      series: [
        {
          name: "2 Abr",
          value: 0
        },
        {
          name: "3 Abr",
          value: 0
        },
        {
          name: "4 Abr",
          value: 0
        },
        {
          name: "5 Abr",
          value: 0
        },
        {
          name: "6 Abr",
          value: 0
        },
        {
          name: "7 Abr",
          value: 0
        }
      ]
    },
    {
      name: "CRE",
      series: [
        {
          name: "2 Abr",
          value: 165
        },
        {
          name: "3 Abr",
          value: 117
        },
        {
          name: "4 Abr",
          value: 105
        },
        {
          name: "5 Abr",
          value: 95
        },
        {
          name: "6 Abr",
          value: 82
        },
        {
          name: "7 Abr",
          value: 153
        }
      ]
    },
    {
      name: "CPE",
      series: [
        {
          name: "2 Abr",
          value: 23
        },
        {
          name: "3 Abr",
          value: 24
        },
        {
          name: "4 Abr",
          value: 23
        },
        {
          name: "5 Abr",
          value: 32
        },
        {
          name: "6 Abr",
          value: 27
        },
        {
          name: "7 Abr",
          value: 27
        }
      ]
    },
    {
      name: "REV",
      series: [
        {
          name: "2 Abr",
          value: 0
        },
        {
          name: "3 Abr",
          value: 0
        },
        {
          name: "4 Abr",
          value: 0
        },
        {
          name: "5 Abr",
          value: 1
        },
        {
          name: "6 Abr",
          value: 0
        },
        {
          name: "7 Abr",
          value: 0
        }
      ]
    },
    {
      name: "RA",
      series: [
        {
          name: "2 Abr",
          value: 0
        },
        {
          name: "3 Abr",
          value: 0
        },
        {
          name: "4 Abr",
          value: 0
        },
        {
          name: "5 Abr",
          value: 0
        },
        {
          name: "6 Abr",
          value: 0
        },
        {
          name: "7 Abr",
          value: 0
        }
      ]
    },
    {
      name: "RC",
      series: [
        {
          name: "2 Abr",
          value: 0
        },
        {
          name: "3 Abr",
          value: 0
        },
        {
          name: "4 Abr",
          value: 0
        },
        {
          name: "5 Abr",
          value: 1
        },
        {
          name: "6 Abr",
          value: 0
        },
        {
          name: "7 Abr",
          value: 0
        }
      ]
    },
    {
      name: "GRE",
      series: [
        {
          name: "2 Abr",
          value: 0
        },
        {
          name: "3 Abr",
          value: 0
        },
        {
          name: "4 Abr",
          value: 0
        },
        {
          name: "5 Abr",
          value: 0
        },
        {
          name: "6 Abr",
          value: 0
        },
        {
          name: "7 Abr",
          value: 0
        }
      ]
    }
  ];
  // Cpes Disponibles graficos Doughnout
  private cpesDisponiblesD = [
    {
      name: "Utilizados",
      value: 0
    },
    {
      name: "Disponibles",
      value: 10000
    }
  ];

  // planFacturacion
  private planFacturacion = {
    fechaInicioPlan: "16 Abr",
    fechaFinPlan: "15 May",
    diasPlan: 30,
    diasRestantes: 30
  };
  // Cpes Facturados Barras  (12 meses)
  public CpesEnviados = [
    {
      name: "Abr 2017",
      value: 35000
    },
    {
      name: "May 2017",
      value: 78500
    },
    {
      name: "Jun 2017",
      value: 77800
    },
    {
      name: "Jul 2017",
      value: 18900
    },
    {
      name: "Ago 2017",
      value: 60000
    },
    {
      name: "Set 2017",
      value: 55000
    },
    {
      name: "Oct 2017",
      value: 38000
    },
    {
      name: "Nov 2017",
      value: 78500
    },
    {
      name: "Dic 2017",
      value: 7800
    },
    {
      name: "Ene 2018",
      value: 19900
    },
    {
      name: "Feb 2018",
      value: 80000
    },
    {
      name: "Mar 2018",
      value: 25000
    }
  ];

  constructor(private _httpClient: HttpClient, private _reusableService: ReusableService) {}

  // First Row
  getCpesDisponiblesD(idPse) {
    // return this.cpesDisponiblesD;
    return (
      this._httpClient
        .post(`${environment.endpointVelose}/home/cpesDisponibles`, {
          value: idPse
        }).pipe(
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }))
    );
  }
  getCpesEnviadosHoy(ruc) {
    return this._httpClient
      .post(`${environment.endpointVelose}/home/cpesEnviadosHoy`, { value: ruc }).pipe(
      catchError((error: any) => {
        return this._reusableService.getCatch(error);
      }));
    //.catch((error:any) => Observable.throw( 'Server error:'+error));
  }

  getCpesValidados(ruc,diasAnterioridad) {
    return this._httpClient
      .post(`${environment.endpointVelose}/home/cpesValidados`, {
        ruc: ruc,
        dias: diasAnterioridad
      }).pipe(
      catchError((error: any) => {
        return this._reusableService.getCatch(error);
      }));
    //.catch((error:any) => Observable.throw( 'Server error:'+error));
  }

  // Second Row
  getCpesFacturadosBA(ruc: any) {
    // return this.CpesFacturadosBA;
    return (
      this._httpClient
        .post(`${environment.endpointVelose}/home/cpesEnviados6Meses`, {
          value: ruc
        }).pipe(
        //.catch((error:any) => Observable.throw( 'Server error:'+error));
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }))
    );
  }
  getCpesCantidadesFiltro(filtro, ruc) {
    let datoretorno = new baseGraficoSeriesC();
    return (
      this._httpClient
        .post(`${environment.endpointVelose}/home/cpesEnviadosHoraDia`, {
          nroRuc: ruc,
          idDetalleParametro: filtro
        }).pipe(
        //.catch((error:any) => Observable.throw( 'Server error:'+error));
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }))
    );
  }
  getPlanFacturacion(idPse) {
    return (
      this._httpClient
        .post(`${environment.endpointVelose}/home/periodoFacturacion`, {
          value: idPse
        }).pipe(
        //.catch((error:any) => Observable.throw( 'Server error:'+error));
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }))
    );
    // return this.planFacturacion;
  }

  // Third Row
  getCantidadCpesFacturadosB(ruc) {
    // return this.CpesEnviados;
    return (
      this._httpClient
        .post(`${environment.endpointVelose}/home/cpesEnviados12Meses`, {
          value: ruc
        }).pipe(
        //.catch((error:any) => Observable.throw( 'Server error:'+error));
        catchError((error: any) => {
          return this._reusableService.getCatch(error);
        }))
    );
  }

   /********* Permisos *********** */
   obtenerPermisos(){
    let arrayAcciones = [];
    const acciones =  this._reusableService.getSessionUsuario().acciones;
    for (var i = 0; i < acciones.length; i++) {
        //if(acciones[i] === nombreModulo){
         if(acciones[i].split('.')[0] === "dashboard"){
          arrayAcciones.push(acciones[i]);
        }
        
      }
    return arrayAcciones;
  }
}
// ======================================================
// ======================================================

export interface MultiCpes{
  "name":string; //fecha
  "series":any[]; //valoresCpes
}
export interface ResponseMultiCpes{
  "estado":boolean;
  "mensaje":string;
  "cpesAprobados":MultiCpes[];
}

export interface baseGraficoSeries{
  name:string;
  series:any[];
}
export class baseGraficoSeriesC{
   name:string;
   series:any[];

   constructor(){
     this.name= "";
     this.series= [];
   }
 }

 export class baseGraficoDisponibles{
   detallePlan:baseGraficoValue[];
   detalleAdicional:baseGraficoValue[];

   constructor(){
     this.detallePlan= [];
     this.detalleAdicional= [];
   }
 }
export interface baseGraficoValue{
  name:string;
  value:number;
}
export interface baseCPEDisponibles{
  // detallePlan:baseGraficoValue[];
  // detalleAdicional:baseGraficoValue[];
  planIlimitado:  boolean;
  dataValidaciones: any[];
  dataDetalleValidacion:any[];
  validacionUtilizadas:number;
}



export class baseGraficoValueC{
   name:string;
   value:number;

   constructor(){
     this.name= "";
     this.value= 0;
   }
 }

export interface responsePeriodoFacturacion {
  "estado":boolean;
  "mensaje":string;
  "planFacturacion":periodoFacturacion;
}
export interface periodoFacturacion {
  fechaInicioPlan:string;
  fechaFinPlan:string;
  diasPlan:number;
  diasRestantes:number;
  planActivo:boolean
}
export class periodoFacturacionC{
   fechaInicioPlan:string= "";
   fechaFinPlan:string= "";
   diasPlan:number= 0;
   diasRestantes:number= 0;
   planActivo=true;
   constructor(){
     this.fechaInicioPlan= "";
     this.fechaFinPlan= "";
     this.diasPlan= 0;
     this.diasRestantes= 0;
     this.planActivo=true;
   }
 }

export interface responseAcumuladoCPESEnviados {
  "estado":boolean;
  "mensaje":string;
  "cpesFacturadosBA":baseGraficoSeries;
}
export interface responseCPESEnviados {
  "estado":boolean;
  "mensaje":string;
  "cpesTotal":baseGraficoValue[];
}
export interface responseCpesCantidadesFiltro {
  "estado":boolean;
  "mensaje":string;
  "cpesFacturadosHoraDia":baseGraficoSeries;
}

export interface responseCpesDisponibles {
  "estado":boolean;
  "mensaje":string;
  "cpesDisponibles":baseCPEDisponibles;
}


export class permisosDashboard{
  //dashboard: string='dashboard'
  kpiPost:   string='dashboard.kpiPost'
  comprobantesEnviados :string='dashboard.comprobantesEnviados'
  acumuladoComprobantes:string='dashboard.acumuladoComprobantes'
  cantidadValidaciones :string='dashboard.cantidadValidaciones'
}
export class permisosDashboardClass{
  //dashboard: string='dashboard'
  kpiPost:boolean=false
  comprobantesEnviados :boolean=false
  acumuladoComprobantes:boolean=false
  cantidadValidaciones :boolean=false
}