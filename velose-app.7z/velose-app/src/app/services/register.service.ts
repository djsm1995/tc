
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FormGroup} from '@angular/forms';
import {catchError} from 'rxjs/operators';
import { environment } from '../../environments/environment';
import {ReusableService} from './reusable.service';

@Injectable()
export class RegisterService {

  constructor(private _httpClient:HttpClient,
              private _reusbaleService:ReusableService ) { }

 // Validacion usuario para registroUsuario
   verificacionCorreoRegistro(correo){
   return this._httpClient.post(`${environment.endpointVelose}/user/validarCorreo`, {
        "correo":correo.toLowerCase()}).pipe(
        catchError((error:any) =>  { return this._reusbaleService.getCatch(error) }));
  }
  
 // Validacion de fecha de operatividad para e registro
  verificacionfechaOperatividad(preguntas){
    return this._httpClient.post(`${environment.endpointVelose}/user/validarPreguntas`, preguntas).pipe(
        catchError((error:any) =>  { return this._reusbaleService.getCatch(error) }));
   }

  nuevoRegistro(usuarioF, empresaF, pagos, preguntasSeguridad = null) {
      return this._httpClient.post(`${environment.endpointVelose}/user/registrarUsuario`,{
        "usuario":usuarioF,
        "empresa":empresaF,
        "pago": pagos,
        "preguntasDeSeguridad":preguntasSeguridad
      }).pipe(catchError((error:any) =>  { return this._reusbaleService.getCatch(error) }));
   }

   nuevoRegistroUsuarioClienteOSE(usuarioF,empresaF){
      return this._httpClient.post(`${environment.endpointVelose}/user/registrarUsuarioClienteOSE`,{
        "usuario":usuarioF,
        "empresa":empresaF
      }).pipe(catchError((error:any) =>  { return this._reusbaleService.getCatch(error) }));
   }



   registroPagoAlignet(rptaAligned){
     return this._httpClient.post(`${environment.endpointVelose}/pago/respuestaAligned`, rptaAligned).pipe(
    catchError((error:any) =>  { return this._reusbaleService.getCatch(error) }));
   }
   assembleUsuario(usuario:FormGroup){
     let usuarioRegistro:UsuarioR= new UsuarioRC();
     if(usuario){
       let usarioValue=usuario.value;
       usuarioRegistro.nombre=usarioValue.nombreUsuarioFormControl;
       usuarioRegistro.apellidoPaterno=usarioValue.apellidoPaternoUsuarioFormControl;
       usuarioRegistro.apellidoMaterno=usarioValue.apellidoMaternoUsuarioFormControl;
       usuarioRegistro.correo=usarioValue.correoUsuarioFormControl;
       usuarioRegistro.clave=usarioValue.confirmarPassUsuarioFormControl;
     }
     return usuarioRegistro;
   }

   assembleEmpresa(empresa:FormGroup,facturacion:FormGroup){
     let empresaRegistro:EmpresaR = new empresaRC();
     if(empresa.value){
      let empresaValue=empresa.value;
      let facturacionValue=facturacion.value;
       empresaRegistro.ruc=empresaValue.rucFormControl;
       empresaRegistro.razonSocial=empresaValue.razonSocialFormControl;
       empresaRegistro.telefono=empresaValue.telefonoFormControl;
       empresaRegistro.representanteLegal=empresaValue.representanteLegalFormControl;
       empresaRegistro.rucPsePartner = empresaValue.idRucPartnerFormControl;
       empresaRegistro.ubigeo=empresaValue.distritoFormControl;
       empresaRegistro.certificadoDigital=empresaValue.certificadoDigitalFormControl;
       empresaRegistro.direccion=empresaValue.direccionFormControl;
       empresaRegistro.codRubro=empresaValue.codigoRubroFormControl;
       empresaRegistro.correoFact=facturacionValue.correoFacturacion;
       empresaRegistro.nombreContactoFact=facturacionValue.nombreFacturacion;
       empresaRegistro.apellidoContactFact=facturacionValue.apellidoFacturacion;
      }
     return empresaRegistro
   }


   assembleEmpresaSinFact(empresa:FormGroup) {
     let empresaRegistro : EmpresaR = new empresaRC();
     if ( empresa.value ) {
         let empresaValue=empresa.value;
         empresaRegistro.ruc=empresaValue.rucFormControl;
         empresaRegistro.razonSocial=empresaValue.razonSocialFormControl;
         empresaRegistro.telefono=empresaValue.telefonoFormControl;
         empresaRegistro.representanteLegal=empresaValue.representanteLegalFormControl;
         empresaRegistro.rucPsePartner = empresaValue.idRucPartnerFormControl;
         empresaRegistro.ubigeo=empresaValue.distritoFormControl;
         empresaRegistro.certificadoDigital=empresaValue.certificadoDigitalFormControl;
         empresaRegistro.direccion=empresaValue.direccionFormControl;
         empresaRegistro.codRubro=empresaValue.codigoRubroFormControl;
      }
      return empresaRegistro
   }

}
//===================================================================================
export class clientePagoC
{
  nombre:string;
  apellidos:string;
  correo:string;
  direccion:string;
  zip:string;
  ciudad:string;
  estado:string;
  pais:string;
  telefono:string;
  constructor(){
    this.nombre="";
    this.apellidos="";
    this.correo="";
    this.direccion="";
    this.zip="";
    this.ciudad="";
    this.estado="";
    this.pais="";
    this.telefono="";
  }
}
export class operacionPagoC
{
  nombreUsuario:string;
  correo:string;
  telefono:number;
  monto:number;
  simboloMoneda:string;
  codigoMoneda:string;
  ubigeo:string;
  direccion:string;
  idPlan:number;

  constructor(){
    this.nombreUsuario="";
    this.correo="";
    this.telefono=null;
    this.monto=null;
    this.simboloMoneda="";
    this.codigoMoneda="";
    this.ubigeo="";
    this.direccion="";
    this.idPlan=null;

  }
}
export class UsuarioRC
{
  nombre:string;
  apellidoPaterno:string;
  apellidoMaterno:string;
  correo:string;
  clave:string;

  constructor(){
    this.nombre="";
    this.apellidoPaterno="";
    this.apellidoMaterno="";
    this.correo="";
    this.clave="";
  }
}
export class empresaRC {
         empresa: EmpresaR;
         rucPsePartner: number;
         ruc: number;
         razonSocial: string;
         telefono: number;
         representanteLegal: string;
         ubigeo: string;
         certificadoDigital: string;
         direccion: string;
         codRubro: string;
         correoFact?: string;
         nombreContactoFact?: string;
         apellidoContactFact?: string;

         constructor() {
           this.rucPsePartner = null;
          //  this.idRucPartner = null;
           this.ruc = null;
           this.razonSocial = "";
           this.telefono = null;
           this.ubigeo = "";
           this.certificadoDigital = "";
           this.representanteLegal = "";
           this.direccion = "";
           this.codRubro = "";
           this.correoFact = "";
           this.nombreContactoFact = "";
           this.apellidoContactFact = "";
         }
       }

export class PagoRC{
  idPlan:number;
  idPlanOpcion:number;
  idOperacion:number;

  constructor(){
    this.idPlan=null,
    this.idPlanOpcion=null,
    this.idOperacion=null
  }
}
export class rptaPagoAlignedC{
  idOperacion:number;
  eci:string;
  vci:string;
  messageCode:string;
  message:string;
  pasarelaResultRequest:{
    nombreTitular:string;
    digitosTarjeta:string;
    codigoResultado:string;
    mensajeResultado:string;
    tipoTarjeta:string;
    estado:boolean;
    bin:number;
  }

  constructor(){
    this.idOperacion=null;
    this.eci="";
    this.vci="";
    this.messageCode="";
    this.message="";
    this.pasarelaResultRequest={
      nombreTitular:"",
      digitosTarjeta:"",
      codigoResultado:"",
      mensajeResultado:"",
      tipoTarjeta:"",
      estado:false,
      bin:null
    }
  }
}


//===================================================================================
// Interfaces Usuario registro

export interface Registro{
  usuario:UsuarioR,
  empresa:EmpresaR,
  plan:Plan
}
export interface UsuarioR{
  // id:number,
  nombre:string,
  apellidoPaterno:string,
  apellidoMaterno:string,
  correo:string,
  clave:string
}
export interface EmpresaR {
  rucPsePartner: number;
  ruc: number;
  razonSocial: string;
  telefono: number;
  representanteLegal: string;
  ubigeo: string;
  certificadoDigital: string;
  codRubro: string;
  direccion: string;
  correoFact? :string;
  nombreContactoFact?: string;
  apellidoContactFact?: string;
}
export interface Plan{
  idPlan:number,
  nombre:string,
  precio:number,
  tarjeta:Tarjeta

}
export interface Tarjeta{
  nombreTitular:string,
  correoElectronico:string,
  nroTarjeta:number,
  fechaVencimiento:string,
  cvv:number
}
export interface ClientePago{
  nombre:string,
  apellidos:string,
  correo:string,
  direccion:string,
  zip:string,
  ciudad:string,
  estado:string,
  pais:string,
  telefono:string,
}
export interface  Pago {
    idPlan:number;
    idPlanOpcion:number;
    idOperacion:number;
    correoFacturacion?:string;
}
export interface  rptaPagoAligned {
    idOperacion:number;
    eci:string;
    vci:string;
    messageCode:string;
    message:string;
    pasarelaResultRequest:{
      nombreTitular:string;
      digitosTarjeta:string;
      codigoResultado:string;
      mensajeResultado:string;
      tipoTarjeta:string;
      estado:boolean;
      bin:number;
    }
}
