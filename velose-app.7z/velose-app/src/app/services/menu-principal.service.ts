import { Injectable, isDevMode } from '@angular/core';
import { TokenService } from './token.service';
import { OpcionesMenu } from '../components/shared/navbar/opciones-menu';
import { startWith } from 'rxjs/operators/startWith';

@Injectable( )
export class MenuPrincipalService {

  private menuNav:NavItem[]= [];
  public sidenav: any;
  constructor(
    private tokenS: TokenService,
  ) { }


  getMenuNav():NavItem[]{
    let listamodulosServicio:any[] =JSON.parse(localStorage.getItem("usuarioLogeado")).modulos;
               
    if (listamodulosServicio == null || listamodulosServicio==undefined ||listamodulosServicio.length<1) {
      if(isDevMode()) {console.log("No cuenta con acceso a ningun modulo");}
      this.tokenS.closeSession();
      return;
    }

    let opcionesMenuPrincipal:NavItem[]= OpcionesMenu
    let menuPermisos:NavItem[]=[]

    let self = this;
    opcionesMenuPrincipal.forEach( (opcionMenu:NavItem) =>
    {
      let busquedaModuloOpcion= self.busquedaOpcionMenu(listamodulosServicio,opcionMenu)
      if(busquedaModuloOpcion!=undefined){
        opcionMenu=self.verificarSubmodulos(opcionMenu,listamodulosServicio);
        menuPermisos.push(opcionMenu)
      }
    }
    )
    return menuPermisos;
  }

  verificarSubmodulos(opcionMenu:NavItem,listamodulosServicio:string[]){
    if(opcionMenu.submodulos==null ||opcionMenu.submodulos==undefined || opcionMenu.submodulos.length==0){
      return opcionMenu
    }
    
    let prefijo:string= `${opcionMenu.identificador}.`
    let submodulosIdentificadores:string[]=[];
    let submodulos:NavItem[]=[]

    listamodulosServicio.forEach((modulo:string) => {
      if(modulo.startsWith(prefijo)){
        submodulosIdentificadores.push(modulo)        
      }
    });

    if(submodulosIdentificadores.length>=1){
      opcionMenu.submodulos.forEach((submodulo:NavItem)=>{

        let busquedaSubModuloOpcion= this.busquedaOpcionMenu(submodulosIdentificadores,submodulo)
        if(busquedaSubModuloOpcion!=undefined){
          submodulos.push(submodulo)
        }
      })
      opcionMenu.submodulos=submodulos
    }
      
    return opcionMenu;
  }

  busquedaOpcionMenu(base:string[],opcion:NavItem):any{
    let response=base.find((element)=>{
      return element===opcion.identificador
    })
    return response
  }

  public closeNav() {
    this.sidenav.close();
  }
}

export interface NavItem{
  descripcion:string;
  pathRedirect:string;
  icon:string;
  identificador:string;
  submodulos?:Submodulos[];
}
export interface Submodulos{
  descripcion:string;
  pathRedirect:string;
  icon: string;
  identificador:string;
}
