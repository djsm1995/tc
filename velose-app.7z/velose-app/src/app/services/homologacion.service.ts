import { Injectable, isDevMode } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs/Observable';
import {ReusableService} from './reusable.service';
import { throwError } from 'rxjs';


@Injectable()
export class HomologacionService {
  listaLenguajeProgramacion=[
    {
      lenguaje:"Java",
      codigo:`
          package tci.net.pe.jtransport.ws.sender;

          import com.sun.istack.internal.ByteArrayDataSource;
          import tci.net.pe.jtransport.util.HeaderHandlerResolver;
          import tci.net.pe.jtransport.ws.ambiente.sunat.BillService;
          import tci.net.pe.jtransport.ws.ambiente.sunat.BillService_Service;
          import javax.activation.DataHandler;
          import javax.activation.DataSource;
          import javax.xml.namespace.QName;
          import javax.xml.ws.Service;
          import javax.xml.ws.WebEndpoint;
          import javax.xml.ws.WebServiceClient;
          import javax.xml.ws.WebServiceException;
          import java.net.MalformedURLException;
          import java.net.URL;

          @WebServiceClient(name = "billService", targetNamespace = "http://service.gem.factura.comppago.registro.servicio.sunat.gob.pe/", wsdlLocation = "https://e-beta.sunat.gob.pe/ol-ti-itcpfegem-beta/billService?wsdl")
          public class SenderSunat extends Service {

            private static URL BILLSERVICE_WSDL_LOCATION = null;
            private static WebServiceException BILLSERVICE_EXCEPTION = null;
            private final static QName BILLSERVICE_QNAME = new QName("http://service.gem.factura.comppago.registro.servicio.sunat.gob.pe/", "billService");
            static {
                URL url = null;
                WebServiceException e = null;
                try {
                    url = new URL("https://beta.ose.tci.net.pe/ol-ti-itcpe/ws/billService?wsdl");
                } catch (MalformedURLException ex) {
                    e = new WebServiceException(ex);
                }
                BILLSERVICE_WSDL_LOCATION = url;
                BILLSERVICE_EXCEPTION = e;
            }

            public byte[] sendBill(String ruc, String usuarioSol, String claveSol, String nombreArchivo, byte[] comprobanteXML) {
                HeaderHandlerResolver handlerResolver = new HeaderHandlerResolver();
                /****Ejemplo: Aqui mandariamos  20351565784 para el ruc - 25698634781 para el usuarioSol * **/
                handlerResolver.setStrUsuario( ruc, usuarioSol);
                /****Ejemplo: Aqui mandariamos  20535659649 para la claveSol  ***/
                handlerResolver.setStrClave(claveSol);
                // byte[] documentoBytes = archivos.zip --> Para este Ejemplo.
                javax.activation.DataHandler contentFile = convertArrayByteToDataHandler(comprobanteXML);
                BillService_Service billService_serviceTest = new BillService_Service();
                billService_serviceTest.setHandlerResolver(handlerResolver);
                BillService portBillService = getBillServicePort();
                return portBillService.sendBill(nombreArchivo, contentFile);
            }

            public SenderSunat() {
                super(__getWsdlLocation(), BILLSERVICE_QNAME);
            }
            public static DataHandler convertArrayByteToDataHandler(byte[] arrayByte) {
                DataSource dataSource = new ByteArrayDataSource(arrayByte, "application/xml");
                DataHandler dataHandler = new DataHandler(dataSource);
                return dataHandler;
            }
            @WebEndpoint(name = "BillServicePort")
            public BillService getBillServicePort() {
                return super.getPort(new QName("http://service.gem.factura.comppago.registro.servicio.sunat.gob.pe/", "BillServicePort"), BillService.class);
            }
            private static URL __getWsdlLocation() {
                if (BILLSERVICE_EXCEPTION!= null) {
                    throw BILLSERVICE_EXCEPTION;
                }
                return BILLSERVICE_WSDL_LOCATION;
            }

          }
    `
    },
    {
      lenguaje:"Fox Pro",
      codigo:`
        #import <UIKit/UIKit.h>
        #import "Dependency.h"
import { environment } from '../../environments/environment';

        @protocol WorldDataSource
        @optional
        - (NSString*)worldName;
        @required
        - (BOOL)allowsToLive;
        @end

        @property (nonatomic, readonly) NSString *title;
        - (IBAction) show;
        @end
      `
    },
    {
      lenguaje:"ASP .Net",
      codigo:`
        @requires_authorization
        def somefunc(param1='', param2=0):
          r'''A docstring'''
          if param1 > param2: # interesting
              print 'Gre\'ater'
          return (param2 - param1 + 1 + 0b10l) or None

        class SomeClass:
          pass

        >>> message = '''interpreter
        ... prompt'''
      `
    },
    {
      lenguaje:"Visual Basic 6",
      codigo:`
        class TestCoOrds
          {
            static void Main()
            {
                CoOrds myCoOrds = new CoOrds(10, 15);
                myCoOrds.PrintCoOrds();

                // Keep the console window open in debug mode.
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
            }
          }
          // Output: CoOrds: 10,15
      `
    },
  ]

  constructor(private _httpClient:HttpClient,
              private _reusableService:ReusableService) { }

  getListaCasosNegocio(datosAmbienteBeta){
    return this._httpClient.post(`${environment.endpointVelose}/homologacion/obtenerOpcionesCN`,datosAmbienteBeta)
          .catch((error:any) =>  {return this._reusableService.getCatch(error) }); ;
  }
  getlistaLenguajeProgramacion(){ return this.listaLenguajeProgramacion; }
  getdatosconexionWsHomologacion(data){
    return this._httpClient.post(`${environment.endpointVelose}/homologacion/obtenerDatosAmbienteBeta`,
      data)
      //.catch((error:any) => Observable.throw( 'Server error:'+error));
      .catch((error:any) =>  {return this._reusableService.getCatch(error) });
  }

  // Prueba xml en linea
  pruebaXml(data){
    return this._httpClient.post
          (`${environment.endpointVelose}/homologacion/validarXml`,
            data)
          //.catch((error:any) => Observable.throw( 'Server error:'+error));;
          .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }
  consultarTicket(data){
    return this._httpClient.post
          (`${environment.endpointVelose}/homologacion/consultarTicket`,
            { ticketSunat:data})
          //.catch((error:any) => Observable.throw( 'Server error:'+error));;
          .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  consultarInformacionPSE(data){
    return this._httpClient.post
          (`${environment.endpointVelose}/homologacion/conexionProduccion`,
            { idPSE:data})
          //.catch((error:any) => Observable.throw( 'Server error:'+error));;
          .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

// Envio correo datos de Produccion
  correoDatosProduccion(ruc,action){
    this._httpClient.post(`${environment.endpointVelose}/pse/credentials`,
      {ruc:ruc,
        action:action
      })
      .catch((error: any) => throwError( 'Server error:'+error)).subscribe(
          (response:any)=>{
            if(response.estado){
              if(isDevMode()) {console.log(JSON.stringify(response))}
            }
            else{
              if(isDevMode()) {console.log("Error envio de correo")}
              if(isDevMode()) {console.log(response);}
            }
          }
        );

  }
}

// ============================================================================
// ============================================================================

export class datosWsC{
  codigo:string;
  descripcion:string;
  url:string;
  usuario:string;
  password:string;
  conectado?:boolean
  constructor(){
    this.url="";
    this.descripcion="";
    this.url="";
    this.conectado=false;
  }
}
export interface datosWs {
  url:string;
  usuario:string;
  password:string;
  conectado?:boolean
}
export interface homologacion{
  id:number,
  nombreCN:string,
  obligatriosCompletados:boolean,
  avance:number,
  casosNegocio:casos[],
}
export interface casos{
  idCasoDetalle:number,
  nombreCaso:string,
  detalleCaso:string,
  tipoOperacion:string,
  tipoAfectacion:string,
  estado:number, // 1-ok 2-error 3-pendiente (Ya no)

  // formato:string,
  // pdfEjemplo:string,
  // obligatorio:boolean
}

export interface responseXML{
  estado:string,
  ticket:string,
  respuesta:string,
  codigoError:string,
  load:string,
  cdr?:string,
}
export class responseXMLC{
  estado:string;
  ticket:string;
  respuesta:string;
  codigoError:string;
  load:string;
  cdr?:string;

  constructor(){
    this.estado=null;
    this.ticket=null;
    this.respuesta=null;
    this.load="determinate";
    this.codigoError=null;
    this.cdr=""
  }
};

export interface PruebatuXMLC
{
  estado:string;
  mensaje:string;
  respuetaValidacion:pruebatuXML;
};
export interface pruebatuXML{
  estado:number,
  nombreXml:string,
  mensaje:string,
  mensaje2?:string,
  traza:string,
  codigoSunat:string,
  archivoXml?:string,
  ticketSunat?:string,

}
export class pruebatuXMLC{
  estado:number;
  nombreXml:string;
  mensaje:string;
  mensaje2?:string;
  traza:string;
  codigoSunat:string;
  archivoXml?:string
  ticketSunat?:string
  constructor(){
    this.estado=null;
    this.nombreXml="";
    this.mensaje="";
    this.mensaje2="";
    this.traza=null;
    this.codigoSunat=null;
    this.archivoXml=""
    this.ticketSunat=null
  }
}
// Respuesta ticket
export interface consultaTicket{
  estado:number,
  mensaje:string,
  mensaje2?:string,
  status?:string
}
export class consultaTicketC{
  estado:number;
  mensaje:string;
  mensaje2?:string;
  status?:string
  constructor(){
    this.estado=null;
    this.mensaje="";
    this.mensaje2=null;
    this.status=null;
  }
}
