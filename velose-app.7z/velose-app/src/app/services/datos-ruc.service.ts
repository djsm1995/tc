
import { HttpClient } from '@angular/common/http';
import { Injectable,Inject } from '@angular/core';

import {catchError} from 'rxjs/operators';
import {Constante} from '../constantes/constante';
import {ReusableService} from './reusable.service';



import { environment } from '../../environments/environment';

@Injectable()
export class DatosRucService {
  // const idTCI=1;
  datosRuc:DatosRuc;

  constructor(
    @Inject('rucTci') private _rucTci: number,
    private _httpclient:HttpClient,
    private _reusableService:ReusableService ) { }

  VerificacionRuc(ruc){
        return this._httpclient.post(`${environment.endpointVelose}/user/validarRuc`, {
            "tipoDocumento": 1,
            "nroDocumento": ruc
        }).pipe(catchError((error:any) =>  {return this._reusableService.getCatch(error) }));
  }
  VerificacionRucRegistro(ruc, correo){
      return this._httpclient.post(`${environment.endpointVelose}/user/validarRuc`, {
        "tipoDocumento": 1,
        "nroDocumento": ruc,
        "correo":correo
      }).pipe(catchError((error:any) =>  {return this._reusableService.getCatch(error) }));
  }
  //Obtener razon social por el ruc
  obtenerDataContribuyente(ruc){
    return this._httpclient.post(`${environment.endpointVelose}/pse/obtenerDataContribuyente`, {
      "ruc": ruc
    }).pipe(catchError((error:any) =>  {return this._reusableService.getCatch(error) }));
  }
}

export class datosRucResponseC
{
  estado:boolean;
  mensaje:string;
  datosRuc:DatosRuc;
  constructor(){
    this.estado=false;
    this.mensaje="Ruc inválido";
    this.datosRuc = {
      codigo:null,
      direccion:"",
      razonSocial:"",
      ubigeo:this.getUbigeo(),
      ruc: null,
      integracion: false,
      redirectLogin:false
    };
  }
  getUbigeo(){
    let ubigeo=Constante.UBIGEOPORDEFECTO
    return ubigeo.distrito;
  }
}

 export interface DatosRuc{
   codigo:number,
   direccion:string,
   razonSocial:string,
   ubigeo:string
   ruc:number,
  //  mensaje: string,
   integracion: boolean,
   redirectLogin:boolean,
 }

export interface datosRucResponse{
  estado:boolean,
  mensaje:string,
  datosRuc:DatosRuc;
}