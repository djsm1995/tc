import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {catchError} from 'rxjs/operators/catchError';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ConfiguracionesGeneralesService {

  constructor(
    private _httpClient:HttpClient,
    private _reusableService:ReusableService,
    ) { }

  //#region  Notificaciones por correo cuando haya una excepcion
  getDatosExcepcion(){
    return this._httpClient.post(`${environment.endpointVelose}/notificacion/obtenerDatosExcepcion`,
      {}
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }
  saveCorreo(empresaConfiguracionNotExcepcion){
    return this._httpClient.post(`${environment.endpointVelose}/notificacion/guardarDatosExcepcion/`, empresaConfiguracionNotExcepcion
    ).pipe(catchError((error:any) =>  { return this._reusableService.getCatch(error) }));
  }
  //#endregion

  /********* Permisos *********** */
  obtenerPermisos(){
    let arrayAcciones = [];
    const acciones =  this._reusableService.getSessionUsuario().acciones;
    for (var i = 0; i < acciones.length; i++) {
        //if(acciones[i] === nombreModulo){
         if(acciones[i].split('.')[0] === "configuraciones"){
          arrayAcciones.push(acciones[i]);
        }
        
      }
    return arrayAcciones;
  }

}

//Interfaces
export interface interfaceDatosNotificacionExcepcion{
  estadoNotificacion:boolean,
  emailTo:string,
  estadoReenvio:boolean
}

export class permisosConfiguraciones{
  confi_notifi: string = 'configuraciones.notificaciones'
}
export class permisosConfiguracionesClass{
  confi_notifi:boolean=false;
}

export class permisosConfNotificacionIncidencia{
  // configuraciones_notificaciones: string='configuraciones.notificaciones'
  confi_notifi_incidencias:  string='configuraciones.notificaciones.incidencias'
  confi_notifi_incidencias_activarNotificacion: string='configuraciones.notificaciones.incidencias.activarNotificacion'
  confi_notifi_incidencias_activarReenvio: string='configuraciones.notificaciones.incidencias.activarReenvio'
}
export class permisosConfNotificacionIncidenciaClass{
  confi_notifi_incidencias:boolean=false
  confi_notifi_incidencias_activarNotificacion:boolean=false
  confi_notifi_incidencias_activarReenvio:boolean=false

}