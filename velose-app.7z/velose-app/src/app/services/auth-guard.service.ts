import { Injectable, isDevMode } from '@angular/core';
import {Router,ActivatedRouteSnapshot,RouterStateSnapshot,
        CanActivate} from '@angular/router';
import {AuthService} from './auth.service';
import {ReusableService} from './reusable.service';
import {TokenService} from './token.service';
import { JwtHelperService } from "@auth0/angular-jwt";
import { SnackBarConfigurationSharedComponent } from '../components/shared/snack-bar/snack-bar-configuration-shared/snack-bar-configuration-shared.component';

@Injectable()
export class AuthGuardService  implements CanActivate{
  private jwtHelper: JwtHelperService = new JwtHelperService();
  constructor(private _auth:AuthService,
              private tokenS:TokenService,
              private _reusable: ReusableService,
    public _snackBarClassShared: SnackBarConfigurationSharedComponent,
              private router:Router ) {}

  canActivate(next:ActivatedRouteSnapshot,state:RouterStateSnapshot){
    let puedeIngresar:boolean=false;
    // Muestra info adicional de la nueva pagina a la deseo navegar
    if(!this._auth.isAuthenticated()){
      console.log("No esta logeado o el token expiró. Bloqueado for Guard");
      this.tokenS.closeSession();
      return puedeIngresar;
    }

    if(this.verificarModulos(next)){
      puedeIngresar= !puedeIngresar;
    }
    else{
      this.mostrarMensajeRutaProhibida();
      this.tokenS.closeSession();
      console.log("No tiene permiso para la ruta ingresada. Bloqueado for Guard");         
    }

    return puedeIngresar

  }
  verificarModulos(next: ActivatedRouteSnapshot) {    
    let modulos:string[]= this._reusable.getSessionUsuario().modulos
    let response:boolean=false
    if (modulos.length >= 1) {
      let moduloHome = next.firstChild != undefined ? next.firstChild.data.identificador : next.data != undefined ? next.data.identificador : "noExisteIdentificador";
      let findModulo = modulos.find((element) => {
         return element.toUpperCase() === moduloHome.toUpperCase();
      });
      response= (findModulo != undefined) ? true : false
    }
    return response
   
  }

  mostrarMensajeRutaProhibida(){
    this._snackBarClassShared.openSnackBar(
      `${this._reusable.getSessionUsuario().nombre}, no tienes permiso para acceder a la ruta solicitada.
       Revisa el url al que deseas ingresar.`,
      7000,
      "OK"
    )

  }
}
