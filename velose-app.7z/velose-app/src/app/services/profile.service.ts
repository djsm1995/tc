import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {


  constructor(
    private _httpClient: HttpClient,
    private _reusableService:ReusableService) {
    }
  
    // #region metodos
    
    //#endregion

  saveDatoUsuario(dato, identificador:number){
    let data = this.tipoDeDato(identificador, dato);
    return this._httpClient.post(`${environment.endpointVelose}/profile/actualizarDatosUsuario`, data
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  } 
    
  saveFotoUsuario(imagen){
    return this._httpClient.post(`${environment.endpointVelose}/profile/actualizarFotoUsuario`, 
    {
      "fotoUsuario" : imagen
    }
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }   



  private tipoDeDato(identificador:number, dato){
    let data;
    switch (identificador) {
          case 1:
            data = {nombres:dato};
            return data;
            //break;
          case 2:
           data = {apellidos:dato};
           return data;
           //break;
          default:
            break;
        }
  }

  cambiarClaveInterno(clave,nuevaClave){
    let data = 
    {
      clave:clave,
      nuevaClave:nuevaClave
    }
    return this._httpClient.post(`${environment.endpointVelose}/profile/actualizarClave`, data
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  /********* Permisos *********** */
  obtenerPermisos(){
    let arrayAcciones = [];
    const acciones =  this._reusableService.getSessionUsuario().acciones;
    for (var i = 0; i < acciones.length; i++) {
        //if(acciones[i] === nombreModulo){
         if(acciones[i].split('.')[0] === "perfil"){
          arrayAcciones.push(acciones[i]);
        }
        
      }
    return arrayAcciones;
  }
  
}
export interface responseMiProfile {
  "estado":boolean;
  "mensaje":string;
  "datos":string;
}

export class permisosPerfil{
  editarNombreApellido: string='perfil.editarNombreApellido'
  cambiarClave:  string='perfil.cambiarClave'
  cambiarImagen: string='perfil.cambiarImagen'
}
export class permisosPerfilClass{
  editarNombreApellido:boolean=false
  cambiarClave:boolean=false
  cambiarImagen:boolean=false

}