import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RolesService {
  endpointVeloseMock:string="https://ccc0a019-2d4d-4f45-a453-1d2e1385ea11.mock.pstmn.io"
  endpointVelose:string= environment.endpointVelose

  constructor(    
    private _httpClient: HttpClient,
    private _reusableService:ReusableService) { }

  listarRoles(filtroBusqueda:string){
    return this._httpClient.post(
      `${this.endpointVelose}/rol/listar`, 
      { "filtro" : filtroBusqueda}
    )
    .catch((error:any) =>  { return this._reusableService.getCatch(error)});
  }

  obtenerCantidadMaximaRoles(){
    return this._httpClient.post(`${this.endpointVelose}/rol/cantidadMaxima`, 
    {}
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  obtenerPermisosDisponibles(){
    return this._httpClient.post(`${this.endpointVelose}/rol/permisosDisponibles`, 
    {}
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  guardarNuevoRolPermisos(data:any){
    return this._httpClient.post(`${this.endpointVelose}/rol/registrar`, 
    data
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  guardarModificadoRolPermisos(data:any){
    return this._httpClient.post(`${this.endpointVelose}/rol/modificar`, data
    ).catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  cargarRol(id:number){
    return this._httpClient.get(`${this.endpointVelose}/rol/cargar/${id}`)
    .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  obtenerCantidadUsuariosAsociadosXRol(id:number){
    return this._httpClient.get(`${this.endpointVelose}/rol/obtenerUsuariosxRol/${id}`)
    .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }

  eliminarRol(id:number){
    return this._httpClient.delete(`${this.endpointVelose}/rol/eliminar/${id}`)
    .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }
  obtenerRol(){
    return this._httpClient.get(`${environment.endpointVelose}/rol/obtenerRol`)
    .catch((error:any) =>  { return this._reusableService.getCatch(error) });
  }
  

}

export interface IDataRol{
  idRol:number;
  nombreRol:string;
  descripcion:string;
  rolPorDefecto:boolean;
}

export interface IDataRolxId{
  nombreRol:string;
  descripcionRol:string;
  lista:IItemNode[];
}


/**
 * Food data with nested structure.
 * Each node has a name and an optiona list of children.
 */
export interface IItemNode  {
  item: IInfoItem;
  listado?: IItemNode [];
}

export interface IInfoItem{
  name:string,
  value:number,
  value_name:string,
  type:number,
}


/** Flat node with expandable and level information */
export interface IItemFlatNode  {
  expandable: boolean;
  item: IInfoItem;
  level: number;
}
