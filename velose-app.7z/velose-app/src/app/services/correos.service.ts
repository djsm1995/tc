import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { ReusableService } from './reusable.service';
import { environment } from '../../environments/environment';


@Injectable()
export class CorreosService {
  constructor(private _httpClient: HttpClient, private _reusableService: ReusableService) {}

  sendCorreoComprobantesRecibidos(parametros) {
    return this._httpClient
      .post(`${environment.endpointVelose}/mail/send`, parametros)
      .catch((error: any) => {
        return this._reusableService.getCatch(error);
      });
  }
}
