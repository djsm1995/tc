import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { of } from "rxjs/observable/of";
import { catchError } from 'rxjs/operators/catchError';
import { Observable } from "rxjs/Observable";

import { ReusableService } from "./reusable.service";
import { environment } from '../../environments/environment';


@Injectable()
export class DashboardOperadorService {
  metodosRecibidos = [
    {
      name: "SendBill",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "SendSummary",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesDeclarados = [
    {
      name: "SendBill",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "SendSummary",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesXSegundoSendBill = [
    {
      name: "Factura",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Boleta",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Nota de Crédito",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Nota de Débito",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Servicios Públicos",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Retención",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Guía de Remisión",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  comprobantesXSegundoSendSummary = [
    {
      name: "Resumen Diario de Boletas",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Comunicado de Bajas",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    },
    {
      name: "Reversión",
      series: [
        {
          name: "09:19:47",
          value: 0
        },
        {
          name: "09:19:48",
          value: 0
        },
        {
          name: "09:19:49",
          value: 0
        },
        {
          name: "09:19:50",
          value: 0
        },
        {
          name: "09:19:51",
          value: 0
        },
        {
          name: "09:19:52",
          value: 0
        },
        {
          name: "09:19:53",
          value: 0
        },
        {
          name: "09:19:54",
          value: 0
        },
        {
          name: "09:19:55",
          value: 0
        },
        {
          name: "09:19:56",
          value: 0
        },
        {
          name: "09:19:57",
          value: 0
        },
        {
          name: "09:19:58",
          value: 0
        },
        {
          name: "09:19:59",
          value: 0
        },
        {
          name: "09:20:00",
          value: 0
        },
        {
          name: "09:20:01",
          value: 0
        }
      ]
    }
  ];
  
  constructor(private _httpClient: HttpClient, private _reusableService: ReusableService) {}
  getMetodosRecibidos() {
    return this.metodosRecibidos;
  }
  getComprobantesxDeclarar(data): Observable<{}> {
    return this._httpClient.post
      (`${environment.endpointVelose}/declaracion/obtenerComprobantesEncolados`,data)
      .pipe(catchError(err=>of("Service error: "+ JSON.stringify(err))))

  }
  VerificacionRuc() {
    return this._httpClient
      .post(`${environment.endpointVelose}/user/validarRuc`, {
        tipoDocumento: 1,
        nroDocumento: 10706579996
      })
      .map(rpta => {
        return this.comprobantesDeclarados;
      })
      .catch((error: any) => {
        return this._reusableService.getCatch(error);
      });
  }
}

// ======================================================
// Interfaces ===========================================
// ======================================================

export interface configuraciones {
  refreshDashboard: string;
  maximo: number;
  tiempoEnvioCorreo: number;
  correo: string;
}

export interface baseGraficoSeries{
  name:string;
  series:any[];
}
export interface baseGraficosValue{
  name:string;
  value:number;
}
export class baseGraficoSeriesC{
  name:string;
  series: baseGraficosValue[];

   constructor(){
     this.name= "";
     this.series= [{name:"", value:0}];
   }
 }

export class dataServicio{
  name: string;
  series: any[];

  constructor() {
    this.name = "";
    this.series = [];
  }
}