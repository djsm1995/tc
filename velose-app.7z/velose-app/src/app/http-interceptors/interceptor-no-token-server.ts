import { Injectable, Injector, isDevMode } from '@angular/core';
import { Router } from '@angular/router';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaderResponse, HttpProgressEvent, HttpResponse, HttpUserEvent, HttpErrorResponse } from '@angular/common/http';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable, BehaviorSubject } from 'rxjs/Rx';
import { switchMap, catchError, finalize,filter,take } from 'rxjs/operators';
// import {Constante} from '../constantes/constante';
import { ReusableService, InterceptorSkipHeaderRefresh} from '../services/reusable.service';
import {TokenService} from '../services/token.service';
import {AuthService} from '../services/auth.service';
import {MensajeGenericoComponent} from '../components/shared/mensaje-generico/mensaje-generico.component';
import {ServicioSinToken} from '../constantes/servicio-con-token'
import { fromPromise } from 'rxjs/observable/fromPromise';

//verificar si se utiliza
import 'rxjs/add/observable/throw'
import 'rxjs/add/operator/catch';
import { throwError } from 'rxjs';

@Injectable()
export class InterceptorNoTokenServer implements HttpInterceptor {
  isRefreshingToken: boolean = false;
  isRequestNull: boolean = false;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>(null);

  constructor(private _reusableService: ReusableService,
              private router: Router,
              private _auth:AuthService,
              public _dialog:MatDialog,
              private injector: Injector) { }

  addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
    if(token==null){
      if(isDevMode()) {console.log("token expired")}
      return null;
    }

    return req.clone({ setHeaders: { Authorization: 'Bearer ' + token }})
  }

  servicioSinToken(authReq:HttpRequest<any>,next){
    let listado = ServicioSinToken.listadoServicioSinToken
    let findService = listado.find((element) => {
      let  matchElement=(authReq.url.match(element)==null)? null:authReq.url.match(element)[0]
      return matchElement == authReq.url;
    });

    return (findService==undefined)?
      this.returnIntercept(this.addToken(authReq,this._reusableService.getToken()), next):
      this.returnIntercept(authReq, next);
  }


  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any> | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    let authReq = req;
    return this.servicioSinToken(authReq,next)
  }

  returnIntercept(req,next: HttpHandler){
    if(req==null && !this.isRequestNull){
      this.isRequestNull=true;
      this.tokenExpiredSession();
      return throwError(null);
    }

    return next.handle(req)
          .catch((error, caught) => {
            switch(error.status) {
                case 401:
                // console.log("actualizando token")
                  return this.handle401Error(req, next);

                case 409:
                  return this.handle409Error(req, next);
                    
                default:
                    if(isDevMode()) {console.log(error)}
                    if(isDevMode()) {console.log(caught)}
                    //retornar error al metodo que lo llamo
                return throwError(error);
            }
          }) as any;
  }

  //#region StatusCode
  
  handle401Error(req, next){
    if (!this.isRefreshingToken) {
      if(isDevMode()) {console.log(req)}

      this.isRefreshingToken = true;
      // Reset here so that the following requests wait until the token
            // comes back from the refreshToken call.
      this.tokenSubject.next(null);
      const tokenService = this.injector.get(TokenService);
      return tokenService.refreshInterceptorToken().pipe(
        switchMap((response:any)=>{
          if(response.estado){
            tokenService.guardarNuevoToken(response.infoToken)
            // this.guardarNuevoToken(response.infoToken) 
            this.tokenSubject.next(this._reusableService.getToken()) 

            return next.handle(this.addToken(req, this._reusableService.getToken()))
          }
          return this.tokenExpiredSession()
  
        }),
        catchError((error:any)=>{
          return this.tokenExpiredSession()
        }),
        finalize(()=>{
          this.isRefreshingToken=false;
        })
      )
    }
    else{
      return this.tokenSubject.pipe(
        filter(token=>token!=null),
        take(1),
        switchMap(token =>{
          //console.log(token)
          return next.handle(this.addToken(req,token))
        })
      )
    }  

  }

  handle409Error(req, next){
    if(this._reusableService.getSessionUsuario()!=null){
      this.dobleSession();
      return [];
    }
    else{
      return throwError("Sesion no activa")
    }
  }

  //#endregion

  // #region LogOut

  dobleSession(){
    const tokenService = this.injector.get(TokenService);

    let dialogRef;
    setTimeout(() =>
        dialogRef = this._dialog.open(MensajeGenericoComponent, {
          width: '400px',
          data: { icon:"sentiment_very_dissatisfied",
          color:"#062a78",
          titulo:"Doble sesión",
          mensaje:`Has sido desconectado del servidor de Velose. Se ha iniciado una nueva sesion con tu usuario.`
        }
      })
    , 0);
    tokenService.closeSession()
    return throwError("");
  }

  tokenExpiredSession(){
    const tokenService = this.injector.get(TokenService);
    // Mensaje Dialog Desconectado
    let dialogRef;
    setTimeout(() =>
        dialogRef = this._dialog.open(MensajeGenericoComponent, {
          width: '400px',
          data: { icon:"sentiment_very_dissatisfied",
          color:"#062a78",
          titulo:"Desconectado",
          mensaje:`Has sido desconectado del servidor de Velose, debido a que no tienes una sesión activa. `
        }
      })
    , 0);

    tokenService.closeSession()
    return throwError("");
  }

  //#endregion
}
