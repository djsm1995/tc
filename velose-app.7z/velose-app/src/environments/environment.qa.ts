
export const environment = {
  production: false,
  endpointVelose:"https://qa.ose.tci.net.pe/ose-portal",
  endpointGrafana:"https://beta.ose.tci.net.pe/monitor/login",
  endpointAnalytics:"https://analytics.tci.net.pe/analytics-beta",
  apikeyGoogleRecaptcha:'6Lf4-KsUAAAAAKJutNK_xvJJ_wT83lWsyEigml1u',
  ambiente:"qa"
};
