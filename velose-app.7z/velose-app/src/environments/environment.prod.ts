export const environment = {
  production: true,
  endpointVelose:"https://ose.tci.net.pe/ose-portal",
  endpointGrafana:"https://ose.tci.net.pe/monitor/login",
  endpointAnalytics:"https://analytics.tci.net.pe/analytics",
  apikeyGoogleRecaptcha:'6LdZ6oIUAAAAAE6xSNVKrCZEO9dL2ca0YAlYdoGL',//modificar con el apikey de produccion
  ambiente:"prod"
};
