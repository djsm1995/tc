# Theme
* Se utilizo el tema preconstruido deeppurple-amber 
* Act:54AC48 Ant:673AB7
* Act- Warn: FFD740

## Environments
* Los ambientes de qa, beta y dev estan configurados para no compilar con aot

## Build
* Si el despliegue es para produccion cambiar el apikeyGoogleRecaptcha de environment.prod por la clave correcta
* Ejecuta 'ng build -c nombreAmbiente --aot --build-optimizer --vendor-chunk' de esta manera compilas con aot y visualizas cuanto pesan todas las librerias del proyecto.
* Adicionar '--stats-json' si se desea visualizar todas las librerias que contiene el proyecto.
* 'npx webpack-bundle-analyzer dist/stats.json'

## Server
* Si deseas el ambiente de dev , ejecuta 'ng serve' el puerto por defecto asignado es el 4200 si deseas asignarle otro puerto ejecuta 'ng serve --port=4201'
* Si deseas otro ambiente 'ng serve -c nombreAmbiente' o 'ng serve -configuration==nombreAmbiente'

##Librerias
* NgxMaterialTimepickerModule requiere import { OverlayModule } from "@angular/cdk/overlay"; en v6

